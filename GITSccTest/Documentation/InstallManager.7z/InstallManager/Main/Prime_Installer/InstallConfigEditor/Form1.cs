﻿using InstallerConfiguration;
using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace InstallConfigEditor
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private string _currentFilename = string.Empty;

		private void openToolStripMenuItem_Click(object sender, EventArgs e)
		{
			openFileDialog1.DefaultExt = "xml";
			if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				XmlSerializer ser = new XmlSerializer(typeof(InstallConfig));
				StreamReader sr = new StreamReader(openFileDialog1.FileName);
				InstallConfig config = (InstallConfig)ser.Deserialize(sr);
				sr.Close();

				propertyGrid1.SelectedObject = config;
				_currentFilename = openFileDialog1.FileName;
			}
		}

		private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			saveFileDialog1.DefaultExt = "xml";
			if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				SavePropertyToFile(saveFileDialog1.FileName);
			}
		}

		private void SavePropertyToFile(string filename)
		{
			XmlSerializer ser = new XmlSerializer(typeof(InstallConfig));
			StreamWriter sw = new StreamWriter(filename);
			ser.Serialize(sw, propertyGrid1.SelectedObject);
			sw.Close();
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (_currentFilename.Length == 0)
			{
				saveAsToolStripMenuItem_Click(sender, e);
			}
			else
			{
				SavePropertyToFile(_currentFilename);
			}
		}

		private void newToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (propertyGrid1.SelectedObject != null)
			{
				System.Windows.Forms.DialogResult result = MessageBox.Show("Do you want to save the current file first?", "Save File?", MessageBoxButtons.YesNoCancel);
				if (result == System.Windows.Forms.DialogResult.Cancel)
				{
					return;
				}
				else if (result == System.Windows.Forms.DialogResult.Yes)
				{
					saveAsToolStripMenuItem_Click(sender, e);
				}
			}

			propertyGrid1.SelectedObject = new InstallConfig();
		}

		private void CheckSaveBeforeClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
		{
			if (propertyGrid1.SelectedObject != null)
			{
				if (MessageBox.Show("Do you want to save before existing?", "Save before close.", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
				{
					saveAsToolStripMenuItem_Click(sender, e);
				}
			}
		}
	}
}