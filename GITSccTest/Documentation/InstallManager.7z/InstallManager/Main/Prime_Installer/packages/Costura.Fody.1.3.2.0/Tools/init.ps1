﻿param($installPath, $toolsPath, $package, $project)

Import-Module (Join-Path $toolsPath commands.psm1)