﻿using InstallerConfiguration;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace InstallerRunner
{
	public class DbRunner
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		public static void RunScripts(DbInstall dbToInstall)
		{
			try
			{
				var scriptFiles = GetScriptsToRun(dbToInstall);

				SqlConnection conn = new SqlConnection(dbToInstall.ConnectionString);
				Server server = new Server(new ServerConnection(conn));
				server.ConnectionContext.InfoMessage += new SqlInfoMessageEventHandler(SqlMessageWriter);

				foreach (string script in scriptFiles)
				{
					log.Info("Excuting " + Path.GetFileName(script));
					server.ConnectionContext.ExecuteNonQuery(File.ReadAllText(script));
					dbToInstall.ScriptsCompleted.Add(script);
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed performing DB updates on " + dbToInstall.ConnectionString, ex);
				throw;
			}
		}

		private static void SqlMessageWriter(object sender, SqlInfoMessageEventArgs e)
		{
			log.Info(e.Message);
		}

		public static List<string> GetScriptsToRun(DbInstall dbToInstall)
		{
			List<string> scriptFiles = new List<string>();

			if (!string.IsNullOrEmpty(dbToInstall.ControlFileName))
			{
				scriptFiles = GetScriptsToRunFromControlFile(dbToInstall);
			}
			else
			{
				scriptFiles = GetScriptsToRunFromFolder(dbToInstall);
			}

			return scriptFiles;
		}

		private static List<string> GetScriptsToRunFromFolder(DbInstall dbToInstall)
		{
			List<string> scriptFiles = new List<string>();
			string dbScriptFolder = Path.Combine(Helper.GetApplicationPath(), dbToInstall.ScriptsFolderName);

			log.Info("Scanning scripts in " + dbScriptFolder);
			scriptFiles = Directory.GetFiles(dbScriptFolder, "*.sql").ToList();
			scriptFiles.Sort();

			return scriptFiles;
		}

		private static List<string> GetScriptsToRunFromControlFile(DbInstall dbToInstall)
		{
			List<string> scriptFiles = new List<string>();
			string scriptsPath = Path.Combine(Helper.GetApplicationPath(), dbToInstall.ScriptsFolderName);
			string controlFilePath = Path.Combine(scriptsPath, dbToInstall.ControlFileName);

			log.Info("Reading db script control file " + controlFilePath);
			StreamReader sr = new StreamReader(controlFilePath);
			string script = string.Empty;

			while ((script = sr.ReadLine()) != null)
			{
				scriptFiles.Add(Path.Combine(scriptsPath, script.Trim()));

				if (!File.Exists(scriptFiles.Last()))
				{
					throw new Exception(string.Format("Script file {0} does not exist.", script));
				}
			}

			sr.Close();

			return scriptFiles;
		}

		public static void Rollback(DbInstall dbToRollBack)
		{
			if (string.IsNullOrEmpty(dbToRollBack.RollbackFolderName))
			{
				log.InfoFormat("No rollback script for {0} connectiong to {1}, skipping.", dbToRollBack.HostMachineName, dbToRollBack.ConnectionString);
				return;
			}

			try
			{
				SqlConnection conn = new SqlConnection(dbToRollBack.ConnectionString);
				Server server = new Server(new ServerConnection(conn));

				// Rollbacks go in the opposite order to which they were originally run
				dbToRollBack.ScriptsCompleted.Reverse();

				foreach (string script in dbToRollBack.ScriptsCompleted)
				{
					string rollbackScript = GetRollbackScriptName(dbToRollBack, script);

					if (File.Exists(rollbackScript))
					{
						log.Info("Excuting " + Path.GetFileName(rollbackScript));
						server.ConnectionContext.ExecuteNonQuery(File.ReadAllText(rollbackScript));
					}
					else
					{
						log.InfoFormat("No rollback script for {0} skipping.", script);
					}
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed rolling back DB on " + dbToRollBack.ConnectionString, ex);
				throw;
			}
		}

		private static string GetRollbackScriptName(DbInstall dbToRollBack, string script)
		{
			string originalScriptPath = Path.Combine(Helper.GetApplicationPath(), dbToRollBack.ScriptsFolderName);
			string rollbackPath = Path.Combine(Helper.GetApplicationPath(), dbToRollBack.RollbackFolderName);

			return script.Replace(originalScriptPath, rollbackPath);
		}
	}
}