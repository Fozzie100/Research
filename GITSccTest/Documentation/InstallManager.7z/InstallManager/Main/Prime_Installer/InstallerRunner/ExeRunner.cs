﻿using InstallerConfiguration;
using System;
using System.IO;
using System.Linq;

namespace InstallerRunner
{
	internal class ExeRunner
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		public static void InstallExe(ExeInstall exeToInstall, string installCode)
		{
			try
			{
				log.Info("Installing " + exeToInstall.ExeName);
				BackUpExe(exeToInstall, installCode);
				DeployExe(exeToInstall);
				CopyFilesToDrServer(exeToInstall);
				log.Info("Install Complete.");
			}
			catch (Exception ex)
			{
				log.Fatal("Failed installing exe " + exeToInstall.ExeName, ex);
				throw;
			}
		}

		public static void CopyFilesToDrServer(ExeInstall exeToCopyToDr)
		{
			if (string.IsNullOrEmpty(exeToCopyToDr.DisasterRecoveryPath))
			{
				log.InfoFormat("No DR for {0}, skipping stage.", exeToCopyToDr.ExeName);
				return;
			}

			try
			{
				log.InfoFormat("Backing up {0} to {1} for DR.", exeToCopyToDr.ExeName, exeToCopyToDr.DisasterRecoveryPath);
				exeToCopyToDr.Actions |= ExeActions.DeployedToDr;
				Helper.DeleteAllFilesAndFoldersRecursively(exeToCopyToDr.DisasterRecoveryPath);
				Helper.CopyFilesRecursively(exeToCopyToDr.InstallPath, exeToCopyToDr.DisasterRecoveryPath, "*.*");
				log.Info("DR backup complete.");
			}
			catch (Exception ex)
			{
				log.Fatal("Failed copying to DR for " + exeToCopyToDr.ExeName, ex);
				throw;
			}
		}

		public static void RestoreLatestBackUp(ExeInstall exeToRestore, string installCode)
		{
			string backupPath = GetLatestBackupFolder(exeToRestore.BackupPath, installCode);

			if (backupPath == string.Empty)
			{
				log.InfoFormat("There are no backups for {0} in {1}", exeToRestore.ExeName, exeToRestore.BackupPath);
				return;
			}

			log.Info("Restoring files from " + backupPath);
			Helper.DeleteAllFilesAndFoldersRecursively(exeToRestore.InstallPath);
			Helper.CopyFilesRecursively(backupPath, exeToRestore.InstallPath, "*.*");
			log.Info("Restore complete");
		}

		private static void BackUpExe(ExeInstall exeToBackUp, string installCode)
		{
			if (string.IsNullOrEmpty(exeToBackUp.BackupPath))
			{
				log.FatalFormat("No Backup Path for {0}.", exeToBackUp.ExeName);
				throw new Exception("No Back Path Specified for Exe " + exeToBackUp.ExeName);
			}

			if (!ValidateReleaseStructure(exeToBackUp))
			{
				log.FatalFormat("Release structure invalid for exe {0} on {1}", exeToBackUp.ExeName, exeToBackUp.HostMachineName);
				throw new Exception(string.Format("Release structure invalid for service {0} on {1}", exeToBackUp.ExeName, exeToBackUp.HostMachineName));
			}

			try
			{
				string backUpFolder = Path.Combine(exeToBackUp.BackupPath, (installCode ?? string.Empty) + DateTime.Now.ToString("yyyyMMddhhmmss"));
				log.InfoFormat("Backing up Service {0} to {1}.", exeToBackUp.ExeName, backUpFolder);

				if (Directory.Exists(exeToBackUp.InstallPath))
				{
					Helper.CopyFilesRecursively(exeToBackUp.InstallPath, backUpFolder, "*.*");
					exeToBackUp.Actions |= ExeActions.BackedUp;
				}
				else
				{
					log.InfoFormat("Install folder {0} does not exist, skipping backup.", exeToBackUp.InstallPath);
				}

				log.Info("Backing up complete.");
			}
			catch (Exception ex)
			{
				log.Fatal("Failed Backing up " + exeToBackUp.ExeName, ex);
				throw;
			}
		}

		private static bool ValidateReleaseStructure(ExeInstall exe)
		{
			string exeFilesPath = Path.Combine(Helper.GetApplicationPath(), exe.ExeName);

			if (!Directory.Exists(exeFilesPath))
			{
				return false;
			}

			return true;
		}

		private static void DeployExe(ExeInstall exeToDeploy)
		{
			if (!ValidateReleaseStructure(exeToDeploy))
			{
				log.FatalFormat("Release structure invalid for exe {0} on {1}", exeToDeploy.ExeName, exeToDeploy.HostMachineName);
				throw new Exception(string.Format("Release structure invalid for service {0} on {1}", exeToDeploy.ExeName, exeToDeploy.HostMachineName));
			}

			try
			{
				log.Info("Deploying files to install folder.");

				// We set the action first here as if this fails it could be part complete and we'd still
				// want to undo it in the rollback
				exeToDeploy.Actions |= ExeActions.DeployedToLocal;
				string exeFolder = Path.Combine(Helper.GetApplicationPath(), exeToDeploy.ExeName);
				Helper.DeleteAllFilesAndFoldersRecursively(exeToDeploy.InstallPath);
				Helper.CopyFilesRecursively(exeFolder,
																		exeToDeploy.InstallPath,
																		"*.*");

				// Is there a special Config for the install?
				if (!string.IsNullOrEmpty(exeToDeploy.ConfigRelativePath))
				{
					string configFilePath = Path.Combine(exeFolder, exeToDeploy.ConfigRelativePath);
					log.Info("Applying custom config " + configFilePath);
					Helper.CopyFilesRecursively(configFilePath, exeToDeploy.InstallPath, "*.*");
				}

				log.Info("Files deployed.");
			}
			catch (Exception ex)
			{
				log.Fatal("Failed copying to release for " + exeToDeploy.ExeName, ex);
				throw;
			}
		}

		public static string GetLatestBackupFolder(string backupRootFolder, string installCode)
		{
			try
			{
				var directory = new DirectoryInfo(backupRootFolder);
				var latest = directory.GetDirectories(installCode + "*")
															.OrderByDescending(d => d.CreationTime)
															.First();
				return latest.FullName;
			}
			catch
			{
				return string.Empty;
			}
		}
	}
}