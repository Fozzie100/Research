﻿using InstallerConfiguration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace InstallerRunner
{
	public class ReportRunner
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		public static void RunRssScripts(ReportInstall reportsToInstall)
		{
			try
			{
				string rssScriptFolder = Path.Combine(Helper.GetApplicationPath(), reportsToInstall.ReportPath);
				var scriptFiles = GetScriptsToRunFromFolder(reportsToInstall);

				foreach (string script in scriptFiles)
				{
					log.Info("Excuting " + Path.GetFileName(script));
					RunReportInstaller(reportsToInstall, script);
					reportsToInstall.ScriptsCompleted.Add(Path.GetFileName(script));
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed performing report install on " + reportsToInstall.ReportServer, ex);
				throw;
			}
		}

		public static List<string> GetScriptsToRunFromFolder(ReportInstall reportsToInstall)
		{
			List<string> scriptFiles = new List<string>();
			string reportFolder = Path.Combine(Helper.GetApplicationPath(), reportsToInstall.ReportPath);

			log.Info("Scanning rss files in " + reportFolder);
			scriptFiles = Directory.GetFiles(reportFolder, "*.rss").ToList();
			scriptFiles.Sort();

			return scriptFiles;
		}

		private static void RunReportInstaller(ReportInstall reportsToInstall, string rssFile)
		{
			try
			{
				log.InfoFormat("Installing rss file {0} on {1}", Path.GetFileName(rssFile), reportsToInstall.ReportServer);

				Process proc = new Process();
				proc.StartInfo.FileName = Path.Combine(Helper.GetApplicationPath(), "rs.exe");
				proc.StartInfo.Arguments = string.Format("-i \"{0}\" -s {1} -l {2} -v BACKUPLOCATION=\"{3}\"",
					rssFile,
					reportsToInstall.ReportServer,
					reportsToInstall.TimeOut,
					Path.Combine(Helper.GetApplicationPath(), reportsToInstall.BackupPath));
				proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				proc.StartInfo.RedirectStandardOutput = true;
				proc.StartInfo.UseShellExecute = false;

				proc.Start();
				string outputResult = proc.StandardOutput.ReadToEnd();
				proc.WaitForExit();
				log.Info(outputResult);

				if (proc.ExitCode != 0)
				{
					throw new Exception(string.Format("rs.exe falied for {0} on server {1}" + rssFile, reportsToInstall.ReportServer));
				}

				log.Info("Install sucessfull.");
			}
			catch (Exception ex)
			{
				log.Fatal("Failed installing report " + rssFile, ex);
				throw;
			}
		}

		public static void Rollback (ReportInstall reportToRollback)
		{
			// TODO: We already keep track of what was sucessfully completed in the reportToRollback.ScriptsComplete property
			//       so this can be used to
			throw new Exception("There is currently no automated rollback process for Reports, please contact the Development team for assistance.");
		}
	}
}
