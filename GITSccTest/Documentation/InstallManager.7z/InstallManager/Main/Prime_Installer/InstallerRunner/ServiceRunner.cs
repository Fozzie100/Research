﻿using InstallerConfiguration;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;

namespace InstallerRunner
{
	public class ServiceRunner
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
		private static string InstallUtilPath = System.Runtime.InteropServices.RuntimeEnvironment.GetRuntimeDirectory();

		public static void StopService(ServiceInstall serviceToStop)
		{
			try
			{
				if (IsServiceInstalled(serviceToStop))
				{
					log.Info("Stopping service " + serviceToStop.ServiceName);

					ServiceController service = new ServiceController(serviceToStop.ServiceName);
					service.Stop();
					service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
					serviceToStop.Actions |= ServiceActions.Stoped;

					log.Info(serviceToStop.ServiceName + " stopped sucessfully.");
				}
				else
				{
					log.Info(serviceToStop.ServiceName + " not installed, skipping stop.");
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed stopping Service " + serviceToStop.ServiceName, ex);
				throw;
			}
		}

		public static void BackupService(ServiceInstall serviceToBackUp, string installCode)
		{
			if (!IsValidForBackupStep(serviceToBackUp))
			{
				return;
			}

			try
			{
				string backUpFolder = Path.Combine(serviceToBackUp.BackupPath, (installCode ?? string.Empty) + DateTime.Now.ToString("yyyyMMddhhmmss"));
				log.InfoFormat("Backing up Service {0} to {1}.", serviceToBackUp.ServiceName, backUpFolder);
				Helper.CopyFilesRecursively(serviceToBackUp.InstallPath, backUpFolder, "*.*");
				serviceToBackUp.Actions |= ServiceActions.BackedUp;
				log.Info("Backing up complete.");
			}
			catch (Exception ex)
			{
				log.Fatal("Failed Backing up Service " + serviceToBackUp.ServiceName, ex);
				throw;
			}
		}

		public static void CopyReleaseToDrFolder(ServiceInstall serviceToCopy)
		{
			if (string.IsNullOrEmpty(serviceToCopy.DisasterRecoveryPath))
			{
				log.InfoFormat("No DR for Service {0}, skipping stage.", serviceToCopy.ServiceName);
				return;
			}

			try
			{
				log.InfoFormat("Backing up Service {0} to {1} for DR.", serviceToCopy.ServiceName, serviceToCopy.DisasterRecoveryPath);
				serviceToCopy.Actions |= ServiceActions.DeployedToDr;
				Helper.DeleteAllFilesAndFoldersRecursively(serviceToCopy.DisasterRecoveryPath);
				Helper.CopyFilesRecursively(serviceToCopy.InstallPath, serviceToCopy.DisasterRecoveryPath, "*.*");
				log.Info("DR backup complete.");
			}
			catch (Exception ex)
			{
				log.Fatal("Failed copying to DR for Service " + serviceToCopy.ServiceName, ex);
				throw;
			}
		}

		public static void InstallService(ServiceInstall serviceToInstall)
		{
			if (string.IsNullOrEmpty(serviceToInstall.ServiceFilename))
			{
				log.InfoFormat("Service {0} has no filname specified, skipping install", serviceToInstall.ServiceName);
				return;
			}

			if (!ValidateReleaseStructure(serviceToInstall))
			{
				log.FatalFormat("Release structure invalid for service {0} on {1}", serviceToInstall.ServiceName, serviceToInstall.HostMachineName);
				throw new Exception(string.Format("Release structure invalid for service {0} on {1}", serviceToInstall.ServiceName, serviceToInstall.HostMachineName));
			}

			log.Info("Deploying service files for " + serviceToInstall.ServiceName);
			CopyToRelease(serviceToInstall);

			try
			{
				if (!IsServiceInstalled(serviceToInstall))
				{
					RunServiceInstaller(serviceToInstall);
					serviceToInstall.Actions |= ServiceActions.Installed;
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed installing Service " + serviceToInstall.ServiceName, ex);
				throw;
			}
		}

		public static void RestoreLatestBackUp(ServiceInstall serviceToRestore, string installCode)
		{
			string backupPath = GetLatestBackupFolder(serviceToRestore.BackupPath, installCode);

			if (backupPath == string.Empty)
			{
				log.InfoFormat("There are no backups for {0} in {1}", serviceToRestore.ServiceName, serviceToRestore.BackupPath);
				return;
			}

			log.Info("Restoring files from " + backupPath);
			Helper.DeleteAllFilesAndFoldersRecursively(serviceToRestore.InstallPath);
			Helper.CopyFilesRecursively(backupPath, serviceToRestore.InstallPath, "*.*");
			log.Info("Restore complete");
		}

		public static void StartService(ServiceInstall serviceToStart)
		{
			try
			{
				if (IsServiceInstalled(serviceToStart))
				{
					log.Info("Starting service " + serviceToStart.ServiceName);

					ServiceController service = new ServiceController(serviceToStart.ServiceName);
					service.Start();
					service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
					serviceToStart.Actions |= ServiceActions.Started;
					log.Info(serviceToStart.ServiceName + " started sucessfully.");
				}
				else
				{
					throw new Exception(string.Format("Trying to start service '{0}'. This service is not installed.", serviceToStart.ServiceName));
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed Starting Service " + serviceToStart.ServiceName, ex);
				throw;
			}
		}

		public static string GetLatestBackupFolder(string backupRootFolder, string installCode)
		{
			try
			{
				var directory = new DirectoryInfo(backupRootFolder);
				var latest = directory.GetDirectories(installCode + "*")
															.OrderByDescending(d => d.CreationTime)
															.First();
				return latest.FullName;
			}
			catch
			{
				return string.Empty;
			}
		}

		private static bool IsValidForBackupStep(ServiceInstall serviceToBackUp)
		{
			if (string.IsNullOrEmpty(serviceToBackUp.ServiceFilename))
			{
				log.InfoFormat("No Service file for Service {0}, skipping stage.", serviceToBackUp.ServiceName);
				return false;
			}

			if (string.IsNullOrEmpty(serviceToBackUp.BackupPath))
			{
				log.FatalFormat("No backup path for Service {0}.", serviceToBackUp.ServiceName);
				throw new Exception("No Back Path Specified for Service " + serviceToBackUp.ServiceName);
			}

			if (!Directory.Exists(serviceToBackUp.InstallPath))
			{
				log.InfoFormat("Install path doesn't exist for Service {0}, skipping stage.", serviceToBackUp.ServiceName);
				return false;
			}

			if (!ValidateReleaseStructure(serviceToBackUp))
			{
				log.FatalFormat("Release structure invalid for service {0} on {1}", serviceToBackUp.ServiceName, serviceToBackUp.HostMachineName);
				throw new Exception(string.Format("Release structure invalid for service {0} on {1}", serviceToBackUp.ServiceName, serviceToBackUp.HostMachineName));
			}

			return true;
		}

		private static bool ValidateReleaseStructure(ServiceInstall service)
		{
			string serviceFilesPath = Path.Combine(Helper.GetApplicationPath(), service.ServiceName);

			if (!Directory.Exists(serviceFilesPath))
			{
				return false;
			}

			return true;
		}

		private static void CopyToRelease(ServiceInstall serviceToCopy)
		{
			try
			{
				// We set the action first here as if this fails it could be part complete and we'd still
				// want to undo it in the rollback
				serviceToCopy.Actions |= ServiceActions.DeployedToLocal;
				string serviceFolder = Path.Combine(Helper.GetApplicationPath(), serviceToCopy.ServiceName);
				Helper.DeleteAllFilesAndFoldersRecursively(serviceToCopy.InstallPath);
				Helper.CopyFilesRecursively(serviceFolder,
																		serviceToCopy.InstallPath,
																		"*.*");

				// Is there a special Config for the install?
				if (!string.IsNullOrEmpty(serviceToCopy.ConfigRelativePath))
				{
					string configFilePath = Path.Combine(serviceFolder, serviceToCopy.ConfigRelativePath);
					log.Info("Applying custom config " + configFilePath);
					Helper.CopyFilesRecursively(configFilePath, serviceToCopy.InstallPath, "*.*");
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed copying to release for Service " + serviceToCopy.ServiceName, ex);
				throw;
			}
		}

		private static void RunServiceInstaller(ServiceInstall serviceToInstall)
		{
			try
			{
				log.Info("Installing service files for " + serviceToInstall.ServiceName);

				Process proc = new Process();
				proc.StartInfo.FileName = Path.Combine(InstallUtilPath, "installutil.exe");
				proc.StartInfo.Arguments = string.Format(@"/username={0} /password={1} /unattended {2}",
					serviceToInstall.UserNameToRunAs,
					serviceToInstall.PasswordForUserToRunAs,
					Path.Combine(serviceToInstall.InstallPath, serviceToInstall.ServiceFilename));
				proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				proc.StartInfo.RedirectStandardOutput = true;
				proc.StartInfo.UseShellExecute = false;

				proc.Start();
				string outputResult = proc.StandardOutput.ReadToEnd();
				proc.WaitForExit();
				log.Info(outputResult);

				if (proc.ExitCode != 0)
				{
					throw new Exception("InstallUtil falied for " + serviceToInstall.ServiceFilename);
				}
			}
			catch (Exception ex)
			{
				log.Fatal("Failed installing Service " + serviceToInstall.ServiceName, ex);
				throw;
			}
		}

		private static bool IsServiceInstalled(ServiceInstall service)
		{
			return ServiceController.GetServices().FirstOrDefault(s => s.ServiceName == service.ServiceName) != null;
		}
	}
}