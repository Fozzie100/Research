﻿using InstallerConfiguration;
using System;
using System.Linq;

namespace InstallerRunner
{
	public class InstallManager
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		public static bool RunInstaller(InstallConfig installConfig)
		{
			try
			{
				log.Info("Starting Installer for " + Environment.MachineName);

				if (!HasValidActions(installConfig))
				{
					log.Fatal("Install has no actions for machine " + System.Environment.MachineName);
					throw new Exception(string.Format("Install has no actions for machine {0}. Contact your Development Team for validation.", System.Environment.MachineName));
				}

				// Stop Services
				foreach (ServiceInstall service in installConfig.ServiceInstalls.Where(s => s.HostMachineName == Environment.MachineName))
				{
					ServiceRunner.StopService(service);
				}

				// Backup Services
				foreach (ServiceInstall service in installConfig.ServiceInstalls.Where(s => s.HostMachineName == Environment.MachineName))
				{
					ServiceRunner.BackupService(service, installConfig.InstallCode);
				}

				// DB Scripts
				foreach (DbInstall db in installConfig.DbInstalls.Where(d => d.HostMachineName == Environment.MachineName))
				{
					DbRunner.RunScripts(db);
				}

				// SSRS scripts
				foreach (ReportInstall report in installConfig.ReportInstalls.Where(r => r.HostMachineName == Environment.MachineName))
				{
					ReportRunner.RunRssScripts(report);
				}

				// Install Services
				foreach (ServiceInstall service in installConfig.ServiceInstalls.Where(s => s.HostMachineName == Environment.MachineName))
				{
					ServiceRunner.InstallService(service);
				}

				// DR Boxes
				foreach (ServiceInstall service in installConfig.ServiceInstalls.Where(s => s.HostMachineName == Environment.MachineName))
				{
					ServiceRunner.CopyReleaseToDrFolder(service);
				}

				// Start Services
				foreach (ServiceInstall service in installConfig.ServiceInstalls.Where(s => s.HostMachineName == Environment.MachineName))
				{
					ServiceRunner.StartService(service);
				}

				// Exe Deployments
				foreach (ExeInstall exe in installConfig.ExeInstalls.Where(e => e.HostMachineName == Environment.MachineName))
				{
					ExeRunner.InstallExe(exe, installConfig.InstallCode);
				}

				log.InfoFormat("Completed Installer sucessfully for {0} on {1}", installConfig.InstallCode, Environment.MachineName);
				return true;
			}
			catch (Exception ex)
			{
				log.Fatal("Install Failed.  Attempting Rollback.", ex);
				Rollback(installConfig);
				log.Info("Rollback Complete.");
				return false;
			}
		}

		public static void RunFullRollback(InstallConfig config)
		{
			log.Info("Full Rollback Started.");

			SetFlagsToCompletedStateReadyForRollback(config);

			Rollback(config);

			log.Info("Rollback Complete.");
		}

		private static bool HasValidActions(InstallConfig installConfig)
		{
			return installConfig.DbInstalls.Where(e => e.HostMachineName == Environment.MachineName).Count() > 0
							|| installConfig.ServiceInstalls.Where(e => e.HostMachineName == Environment.MachineName).Count() > 0
							|| installConfig.ExeInstalls.Where(e => e.HostMachineName == Environment.MachineName).Count() > 0;
		}

		private static void Rollback(InstallConfig config)
		{
			log.Info("Rollback Started.");

			// Ok so we've had problems first lets stop any services that we managed to start back up so we can
			// begin to undo everything
			foreach (ServiceInstall service in config.ServiceInstalls.Where(s => (s.Actions & ServiceActions.Started) == ServiceActions.Started))
			{
				ServiceRunner.StopService(service);
			}

			// Now lets get our database back in shape
			foreach (DbInstall db in config.DbInstalls.Where(d => d.ScriptsCompleted.Count > 0))
			{
				DbRunner.Rollback(db);
			}

			// So far so good, now lets get our service restord.
			foreach (ServiceInstall service in config.ServiceInstalls.Where(s => ((s.Actions & ServiceActions.BackedUp) == ServiceActions.BackedUp)))
			{
				ServiceRunner.RestoreLatestBackUp(service, config.InstallCode);
			}

			foreach (ServiceInstall service in config.ServiceInstalls.Where(s => ((s.Actions & ServiceActions.DeployedToDr) == ServiceActions.DeployedToDr)))
			{
				ServiceRunner.CopyReleaseToDrFolder(service);
			}

			foreach (ServiceInstall service in config.ServiceInstalls.Where(s => (s.Actions & ServiceActions.Stoped) == ServiceActions.Stoped))
			{
				ServiceRunner.StartService(service);
			}

			// Now finally we'll sort out our executables
			foreach (ExeInstall exe in config.ExeInstalls.Where(e => (e.Actions & ExeActions.BackedUp) == ExeActions.BackedUp))
			{
				ExeRunner.RestoreLatestBackUp(exe, config.InstallCode);
			}

			foreach (ExeInstall exe in config.ExeInstalls.Where(e => (e.Actions & ExeActions.DeployedToDr) == ExeActions.DeployedToDr))
			{
				ExeRunner.CopyFilesToDrServer(exe);
			}

			// TODO: This is probably better situated under the db loop above.  It's only here because rollback is unsupport and I
			//       want to get everything else nicely rolled back before we start throwing exceptions
			foreach (ReportInstall report in config.ReportInstalls.Where(r => r.ScriptsCompleted.Count > 0))
			{
				ReportRunner.Rollback(report);
			}

			log.Info("Rollback Complete.");
		}

		private static void SetFlagsToCompletedStateReadyForRollback(InstallConfig config)
		{
			SetCompletedFlagsForServices(config);

			SetCompletedFlagsForDatabases(config);

			SetCompletedFlagsForExes(config);

			SetCompletedFlagsForReports(config);
		}

		private static void SetCompletedFlagsForReports(InstallConfig config)
		{
			foreach (ReportInstall report in config.ReportInstalls.Where(r => r.HostMachineName == Environment.MachineName))
			{
				report.ScriptsCompleted = ReportRunner.GetScriptsToRunFromFolder(report);
			}
		}

		private static void SetCompletedFlagsForExes(InstallConfig config)
		{
			foreach (ExeInstall exe in config.ExeInstalls.Where(e => e.HostMachineName == Environment.MachineName))
			{
				exe.Actions |= ExeActions.DeployedToLocal;

				if (!string.IsNullOrEmpty(exe.DisasterRecoveryPath))
				{
					exe.Actions |= ExeActions.DeployedToDr;
				}

				if (!string.IsNullOrEmpty(exe.BackupPath) && ExeRunner.GetLatestBackupFolder(exe.BackupPath, config.InstallCode) != string.Empty)
				{
					exe.Actions |= ExeActions.BackedUp;
				}
			}
		}

		private static void SetCompletedFlagsForDatabases(InstallConfig config)
		{
			foreach (DbInstall db in config.DbInstalls.Where(d => d.HostMachineName == Environment.MachineName))
			{
				db.ScriptsCompleted = DbRunner.GetScriptsToRun(db);
			}
		}

		private static void SetCompletedFlagsForServices(InstallConfig config)
		{
			foreach (ServiceInstall service in config.ServiceInstalls.Where(s => s.HostMachineName == Environment.MachineName))
			{
				// These actions must have happened
				service.Actions |= ServiceActions.Started;
				service.Actions |= ServiceActions.DeployedToLocal;

				// The following are conditional actions
				if (!string.IsNullOrEmpty(service.DisasterRecoveryPath))
				{
					service.Actions |= ServiceActions.DeployedToDr;
				}

				// We won't actually uninstall a service we'll just leave it stopped
				if (!string.IsNullOrEmpty(service.BackupPath))
				{
					if (ServiceRunner.GetLatestBackupFolder(service.BackupPath, config.InstallCode) != string.Empty)
					{
						service.Actions |= ServiceActions.BackedUp;
						service.Actions |= ServiceActions.Stoped;
					}
				}
			}
		}
	}
}