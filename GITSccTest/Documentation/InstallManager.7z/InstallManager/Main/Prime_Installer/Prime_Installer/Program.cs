﻿using Ftse.Research.Framework.Net.Mail;
using InstallerConfiguration;
using InstallerRunner;
using log4net;
using log4net.Appender;
using log4net.Repository.Hierarchy;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Serialization;

namespace Prime_Installer
{
	internal class Program
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger
		(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		private static void Main(string[] args)
		{
			string installCode = "unknown";
			string installState = "unknown";

			if (args.Length > 1)
			{
				log.Info("You must specify the config file to process as the only parameter, or enter no parameters to process all configs in the current folder. Press any Key to Quit.");
				Console.ReadKey();
				return;
			}

			try
			{
				InstallConfig config = LoadConfig(args);
				installCode = config.InstallCode ?? installCode;
				bool isInstall = IsInstall(installCode);

				if (GetPermissionToContinue(isInstall))
				{
					if (isInstall)
					{
						installState = ExecuteForInstall(config);
					}
					else
					{
						installState = ExecuteForRollback(config);
					}
				}
			}
			catch (Exception ex)
			{
				Console.ForegroundColor = ConsoleColor.Red;
				log.Fatal("The installer has failed. Please contact your friendly neighbourhood development team for assitance.", ex);
				Console.ResetColor();
				installState = "unrecoverable FAIL";
			}
			finally
			{
				SendDevTeamEmail(installCode, installState);
			}

			Console.WriteLine("Complete.  Press any key to continue.");
			Console.ReadKey(true);
		}

		private static string ExecuteForRollback(InstallConfig config)
		{
			string installState = string.Empty;

			InstallManager.RunFullRollback(config);
			installState = "Rollback Only Sucess";
			Console.ForegroundColor = ConsoleColor.Green;
			log.InfoFormat("Sucessful Completion.");
			Console.ResetColor();

			return installState;
		}

		private static string ExecuteForInstall(InstallConfig config)
		{
			string installState = string.Empty;

			if (InstallManager.RunInstaller(config))
			{
				Console.ForegroundColor = ConsoleColor.Green;
				log.InfoFormat("Sucessful Completion.");
				installState = "Sucess";
				Console.ResetColor();
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				log.InfoFormat("Install failed but sucessful rollback was completed.");
				installState = "Failed, sucessfully rolled back";
				Console.ResetColor();
			}

			return installState;
		}

		private static void SendDevTeamEmail(string installCode, string installState)
		{
			string emailAddress = GetToEmailAddress();

			// We dont always want send an email particularly if not in cds or live
			if (emailAddress.Length == 0)
			{
				return;
			}

			SmtpMail mail = new SmtpMail()
			{
				To = emailAddress,
				Subject = string.Format("Prime Installer {0} for Install Code {1}.", installState, installCode),
				Body = string.Format("Prime Installer was executed by user {0} on machine {1}.", System.Environment.UserName, System.Environment.MachineName),
				Format = EmailFormat.PlainText
			};

			string logFilename = GetLogFilename();

			if (logFilename.Length > 0)
			{
				mail.Attachments.Add(logFilename);
			}
			
			mail.Send();
		}

		private static string GetToEmailAddress()
		{
			if (IsLiveServer(Environment.MachineName))
			{
				return ConfigurationManager.AppSettings["liveEmailTo"] ?? "primebackendsupport@ftse.com";
			}
			else if (IsCdsServer(Environment.MachineName))
			{
				return ConfigurationManager.AppSettings["cdsEmailTo"] ?? "primebackendsupport@ftse.com";
			}
			else
			{
				return ConfigurationManager.AppSettings["testEmailTo"] ?? string.Empty;
			}
		}

		private static InstallConfig LoadConfig(string file)
		{
			InstallConfig config = null;

			XmlSerializer ser = new XmlSerializer(typeof(InstallConfig));
			StreamReader sr = new StreamReader(file);
			config = (InstallConfig)ser.Deserialize(sr);
			sr.Close();

			return config;
		}

		private static string GetLogFilename()
		{
			var rootAppender = ((Hierarchy)LogManager.GetRepository())
																				 .Root.Appenders.OfType<FileAppender>()
																				 .FirstOrDefault();

			return rootAppender != null ? rootAppender.File : string.Empty;
		}

		private static bool GetPermissionToContinue(bool forInstall)
		{
			log.InfoFormat("Seeking permission to proceed on {0}.", System.Environment.MachineName);

			Console.Write("Do you wish to perform this {0} on ", forInstall ? "install" : "rollback");
			Console.ForegroundColor = GetConsoleColourForMachine(System.Environment.MachineName);
			Console.Write(System.Environment.MachineName);
			Console.ResetColor();
			Console.WriteLine("?");
			Console.WriteLine("Press 'Y' to continue or any other key to abort.");

			ConsoleKeyInfo cki = Console.ReadKey(true);

			if (cki.KeyChar == 'y' || cki.KeyChar == 'Y')
			{
				log.Info("Permission to proceed received. User clicked " + cki.Key);
				return true;
			}
			else
			{
				log.Info("User aborted. User clicked " + cki.Key);
				return false;
			}
		}

		private static ConsoleColor GetConsoleColourForMachine(string machine)
		{
			if (IsLiveServer(machine))
			{
				return ConsoleColor.Red;
			}

			if (IsCdsServer(machine))
			{
				return ConsoleColor.Yellow;
			}

			return ConsoleColor.White;
		}

		private static bool IsLiveServer(string machine)
		{
			return !string.IsNullOrEmpty(ConfigurationManager.AppSettings["liveServers"]) &&
						ConfigurationManager.AppSettings["liveServers"].Split('|').ToList().Contains(machine);
		}

		private static bool IsCdsServer(string machine)
		{
			return !string.IsNullOrEmpty(ConfigurationManager.AppSettings["cdsServers"]) &&
						ConfigurationManager.AppSettings["cdsServers"].Split('|').ToList().Contains(machine);
		}

		private static bool IsInstall(string installCode)
		{
			log.Info("Asking for install or rollback?.");

			Console.WriteLine("Perform an install or a full rollback?.");
			Console.WriteLine("Press 'R' to rollback or any other key to install {0}.", installCode);
			ConsoleKeyInfo cki = Console.ReadKey(true);

			if (cki.KeyChar == 'r' || cki.KeyChar == 'R')
			{
				log.InfoFormat("User entered '{0}' to rollback.", cki.Key);
				return false;
			}
			else
			{
				log.InfoFormat("User entered '{0}' to install.", cki.Key);
				return true;
			}
		}

		private static InstallConfig LoadConfig(string[] args)
		{
			if (args.Length == 1)
			{
				return LoadConfig(args[0]);
			}
			else if (args.Length == 0)
			{
				InstallConfig result = new InstallConfig();

				foreach (string settingsFile in Directory.GetFiles(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), "*.xml"))
				{
					result.Combine(LoadConfig(settingsFile));
				}

				return result;
			}
			else
			{
				throw new Exception("Invalid arguments.  Must be one or zero arguments.");
			}
		}
	}
}