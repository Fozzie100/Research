﻿using System;
using InstallerRunner;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ServiceProcess;
using System.Collections.Generic;
using System.Linq;

namespace InstallerConfiguration.Tests
{
	[TestClass]
	public class ServiceRunner_Tests
	{
		[TestMethod]
		public void StartService_StopService_SucessfulExisting()
		{
			// Arrange
			string serviceName = "TabletInputService";
			if (ServiceController.GetServices().FirstOrDefault(s => s.ServiceName == serviceName) == null &&
						new ServiceController(serviceName).Status == ServiceControllerStatus.Running)
			{
				throw new Exception("The tablet input service we use for testing isn't running.");
			}

			ServiceInstall service = new ServiceInstall() {	ServiceName = serviceName	};

			ServiceRunner.StopService(service);
			Assert.IsTrue(new ServiceController(serviceName).Status == ServiceControllerStatus.Running);

			
			ServiceRunner.StartService(service);
			Assert.IsTrue(new ServiceController(serviceName).Status == ServiceControllerStatus.Running);
		}

		[TestMethod]
		public void StopService_SucessfulExistingService()
		{
			ServiceInstall service = new ServiceInstall()
			{
				ServiceName = "My Simple Service"
			};

			ServiceRunner.StopService(service);
		}

		[TestMethod]
		public void Install_SucessfulNewService()
		{
			ServiceInstall service = new ServiceInstall()
			{
				ServiceName = "My Simple Service",
				ServiceFilename = @"SampleService.exe",
				InstallPath = @"D:\Services\SampleService\",
				UserNameToRunAs = @"FT-SE\AlexPi",
				PasswordForUserToRunAs = @"xxx"
			};

			ServiceRunner.InstallService(service);
		}
	}
}
