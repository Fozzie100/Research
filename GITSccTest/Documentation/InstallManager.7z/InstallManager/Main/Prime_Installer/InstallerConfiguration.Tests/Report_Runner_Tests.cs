﻿using InstallerRunner;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InstallerConfiguration.Tests
{
	[TestClass]
	public class Report_Runner_Tests
	{
		[TestMethod]
		public void InstallReport()
		{
			ReportInstall report = new ReportInstall()
			{
			};

			ReportRunner.RunRssScripts(report);
		}
	}
}