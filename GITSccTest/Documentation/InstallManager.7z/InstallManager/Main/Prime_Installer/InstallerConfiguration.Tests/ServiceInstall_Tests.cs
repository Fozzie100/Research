﻿using InstallerRunner;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InstallerConfiguration.Tests
{
	[TestClass]
	public class ServiceInstall_Tests
	{
		[TestMethod]
		public void StartService_SucessfulExistingService()
		{
			ServiceInstall service = new ServiceInstall()
			{
				ServiceName = "My Simple Service"
			};

			ServiceRunner.StartService(service);
		}

		[TestMethod]
		public void StopService_SucessfulExistingService()
		{
			ServiceInstall service = new ServiceInstall()
			{
				ServiceName = "My Simple Service"
			};

			ServiceRunner.StopService(service);
		}

		[TestMethod]
		public void Install_SucessfulNewService()
		{
			ServiceInstall service = new ServiceInstall()
			{
				ServiceName = "My Simple Service",
				ServiceFilename = @"SampleService.exe",
				InstallPath = @"D:\Services\SampleService\",
				UserNameToRunAs = @"FT-SE\AlexPi",
				PasswordForUserToRunAs = @"xxx"
			};

			ServiceRunner.InstallService(service);
		}
	}
}