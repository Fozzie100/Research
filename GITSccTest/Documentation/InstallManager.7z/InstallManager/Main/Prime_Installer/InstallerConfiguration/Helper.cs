﻿using System.IO;

namespace InstallerConfiguration
{
	internal class Helper
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		public static void CopyFilesRecursively(string sourceFolder, string destinationFolder, string fileMask)
		{
			if (!Directory.Exists(sourceFolder))
			{
				return;
			}

			if (!Directory.Exists(destinationFolder))
			{
				log.Info("Creating Folder " + destinationFolder);
				Directory.CreateDirectory(destinationFolder);
			}

			foreach (string folder in Directory.GetDirectories(sourceFolder))
			{
				CopyFilesRecursively(folder, Path.Combine(destinationFolder, Path.GetFileName(folder.TrimEnd(Path.DirectorySeparatorChar))), fileMask);
			}

			foreach (string file in Directory.GetFiles(sourceFolder, fileMask))
			{
				string destinationFile = Path.Combine(destinationFolder, Path.GetFileName(file));
				log.InfoFormat("Copying {0} to {1}", file, destinationFile);
				File.Copy(file, destinationFile, true);
			}
		}
	}
}