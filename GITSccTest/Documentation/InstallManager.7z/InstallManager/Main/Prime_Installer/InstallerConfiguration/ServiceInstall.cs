﻿using System;
using System.ComponentModel;
using System.Xml.Serialization;

namespace InstallerConfiguration
{
	[TypeConverter(typeof(ServiceInstallConverter))]
	public class ServiceInstall
	{
		public ServiceInstall()
		{
		}

		#region Properties

		[XmlAttribute()]
		public string HostMachineName { get; set; }

		[XmlAttribute()]
		public string ServiceName { get; set; }

		[XmlAttribute()]
		public string ServiceFilename { get; set; }

		[XmlAttribute()]
		public string InstallPath { get; set; }

		[XmlAttribute()]
		public string ConfigRelativePath { get; set; }

		[XmlAttribute()]
		public string BackupPath { get; set; }

		[XmlAttribute()]
		public string DisasterRecoveryPath { get; set; }

		[XmlAttribute()]
		public string UserNameToRunAs { get; set; }

		[XmlAttribute()]
		public string PasswordForUserToRunAs { get; set; }

		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[XmlIgnore]
		public ServiceActions Actions { get; set; }

		#endregion Properties

		public override string ToString()
		{
			return this.HostMachineName + ", " + this.ServiceName;
		}
	}

	[FlagsAttribute]
	public enum ServiceActions
	{
		Ready = 1,
		BackedUp = 2,
		Stoped = 4,
		DeployedToLocal = 8,
		Installed = 16,
		Started = 32,
		DeployedToDr = 64
	}

	internal class ServiceInstallConverter : ExpandableObjectConverter
	{
		public override object ConvertTo(ITypeDescriptorContext context,
															 System.Globalization.CultureInfo culture,
															 object value, Type destType)
		{
			if (destType == typeof(string) && value is ServiceInstall)
			{
				ServiceInstall service = (ServiceInstall)value;
				return service.HostMachineName + ", " + service.ServiceName;
			}
			return base.ConvertTo(context, culture, value, destType);
		}
	}
}