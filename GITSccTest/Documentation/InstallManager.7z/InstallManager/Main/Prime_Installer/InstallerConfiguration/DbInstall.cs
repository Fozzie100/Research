﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml.Serialization;

namespace InstallerConfiguration
{
	[TypeConverter(typeof(DbInstallConverter))]
	public class DbInstall
	{
		[XmlAttribute()]
		public string HostMachineName { get; set; }

		[XmlAttribute()]
		public string ConnectionString { get; set; }

		[XmlAttribute()]
		public string ScriptsFolderName { get; set; }

		[XmlAttribute()]
		public string ControlFileName { get; set; }

		[XmlAttribute()]
		public string RollbackFolderName { get; set; }

		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[XmlIgnore]
		public List<string> ScriptsCompleted { get; set; }

		public DbInstall()
		{
			this.ScriptsCompleted = new List<string>();
		}

		public override string ToString()
		{
			return this.HostMachineName + ", " + this.ScriptsFolderName;
		}
	}

	internal class DbInstallConverter : ExpandableObjectConverter
	{
		public override object ConvertTo(ITypeDescriptorContext context,
															 System.Globalization.CultureInfo culture,
															 object value, Type destType)
		{
			if (destType == typeof(string) && value is DbInstall)
			{
				DbInstall db = (DbInstall)value;
				return db.HostMachineName + ", " + db.ScriptsFolderName;
			}
			return base.ConvertTo(context, culture, value, destType);
		}
	}
}