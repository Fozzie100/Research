﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml.Serialization;

namespace InstallerConfiguration
{
	[TypeConverter(typeof(ReportInstallConverter))]
	public class ReportInstall
	{
		[XmlAttribute()]
		public string HostMachineName { get; set; }

		[XmlAttribute()]
		public string ReportPath { get; set; }

		[XmlAttribute()]
		public string ReportServer { get; set; }

		[XmlAttribute()]
		public string TimeOut { get; set; }

		[XmlAttribute()]
		public string BackupPath { get; set; }

		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[XmlIgnore]
		public List<string> ScriptsCompleted { get; set; }
	}

	internal class ReportInstallConverter : ExpandableObjectConverter
	{
		public override object ConvertTo(ITypeDescriptorContext context,
															 System.Globalization.CultureInfo culture,
															 object value, Type destType)
		{
			if (destType == typeof(string) && value is ReportInstall)
			{
				ReportInstall report = (ReportInstall)value;
				return report.HostMachineName + ", " + report.ReportServer;
			}
			return base.ConvertTo(context, culture, value, destType);
		}
	}
}