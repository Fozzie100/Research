﻿using System;
using System.ComponentModel;
using System.Xml.Serialization;

namespace InstallerConfiguration
{
	[TypeConverter(typeof(ExeInstallConverter))]
	public class ExeInstall
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		[XmlAttribute()]
		public string HostMachineName { get; set; }

		[XmlAttribute()]
		public string ExeName { get; set; }

		[XmlAttribute()]
		public string InstallPath { get; set; }

		[XmlAttribute()]
		public string ConfigRelativePath { get; set; }

		[XmlAttribute()]
		public string BackupPath { get; set; }

		[XmlAttribute()]
		public string DisasterRecoveryPath { get; set; }

		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[XmlIgnore]
		public ExeActions Actions { get; set; }

		public override string ToString()
		{
			return this.HostMachineName + ", " + this.ExeName;
		}
	}

	[FlagsAttribute]
	public enum ExeActions
	{
		Ready = 1,
		BackedUp = 2,
		DeployedToLocal = 4,
		DeployedToDr = 8
	}

	internal class ExeInstallConverter : ExpandableObjectConverter
	{
		public override object ConvertTo(ITypeDescriptorContext context,
															 System.Globalization.CultureInfo culture,
															 object value, Type destType)
		{
			if (destType == typeof(string) && value is ExeInstall)
			{
				ExeInstall exe = (ExeInstall)value;
				return exe.HostMachineName + ", " + exe.ExeName;
			}
			return base.ConvertTo(context, culture, value, destType);
		}
	}
}