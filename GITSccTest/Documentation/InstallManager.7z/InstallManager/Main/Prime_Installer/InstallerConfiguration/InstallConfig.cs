﻿using System.Collections.Generic;

namespace InstallerConfiguration
{
	public class InstallConfig
	{
		public string InstallCode { get; set; }

		public List<ServiceInstall> ServiceInstalls { get; set; }

		public List<DbInstall> DbInstalls { get; set; }

		public List<ExeInstall> ExeInstalls { get; set; }

		public List<ReportInstall> ReportInstalls { get; set; }

		public InstallConfig()
		{
			this.DbInstalls = new List<DbInstall>();
			this.ExeInstalls = new List<ExeInstall>();
			this.ServiceInstalls = new List<ServiceInstall>();
			this.ReportInstalls = new List<ReportInstall>();
		}

		public void Combine(InstallConfig configToCombine)
		{
			CombineDbInstalls(configToCombine);

			CombineExeInstalls(configToCombine);

			CombineServiceInstalls(configToCombine);

			CombineReportInstalls(configToCombine);

			if (string.IsNullOrEmpty(this.InstallCode))
			{
				this.InstallCode = configToCombine.InstallCode;
			}
		}

		private void CombineReportInstalls(InstallConfig configToCombine)
		{
			if (configToCombine.ReportInstalls != null)
			{
				if (this.ReportInstalls == null)
				{
					this.ReportInstalls = new List<ReportInstall>();
				}

				this.ReportInstalls.AddRange(configToCombine.ReportInstalls);
			}
		}

		private void CombineServiceInstalls(InstallConfig configToCombine)
		{
			if (configToCombine.ServiceInstalls != null)
			{
				if (this.ServiceInstalls == null)
				{
					this.ServiceInstalls = new List<ServiceInstall>();
				}

				this.ServiceInstalls.AddRange(configToCombine.ServiceInstalls);
			}
		}

		private void CombineExeInstalls(InstallConfig configToCombine)
		{
			if (configToCombine.ExeInstalls != null)
			{
				if (this.ExeInstalls == null)
				{
					this.ExeInstalls = new List<ExeInstall>();
				}

				this.ExeInstalls.AddRange(configToCombine.ExeInstalls);
			}
		}

		private void CombineDbInstalls(InstallConfig configToCombine)
		{
			if (configToCombine.DbInstalls != null)
			{
				if (this.DbInstalls == null)
				{
					this.DbInstalls = new List<DbInstall>();
				}

				this.DbInstalls.AddRange(configToCombine.DbInstalls);
			}
		}
	}
}