﻿using DbFieldValidation.Data;
using Ftse.Research.Framework.IO;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbFieldValidation
{
    public class FileValidator
    {
			public ValidationResult ValidateFile (string filename, string delimiter, bool hasHeader, bool replacesSpacesWithUnderScoreInHeadings, bool ignoreUnknownColumnsInData, string connectionString, string schema, string tableName, int maximumNumberOfErorrs = 50)
			{
				ValidationResult result = new ValidationResult()
				{
					IsValid = true,
					Message = "File is valid"
				};

				StreamReader reader = null;

				try
				{
					reader = new StreamReader(filename);
					string line = string.Empty;
					RowValidator rowValidator = null;
					int errorsEncountered = 0;
					int rowCount = 0;

					if (hasHeader)
					{
						line = reader.ReadLine();
						rowValidator = new RowValidator(line, delimiter, schema, tableName, connectionString, replacesSpacesWithUnderScoreInHeadings, ignoreUnknownColumnsInData);
					}
					else
					{
						rowValidator = new RowValidator(null, delimiter, schema, tableName, connectionString, replacesSpacesWithUnderScoreInHeadings, ignoreUnknownColumnsInData);
					}

					while ((line = reader.ReadLine()) != null)
					{
						rowCount++;

						ValidationRowResult rowValidation = rowValidator.ValidateRow(line);
						rowValidation.RowNumber = rowCount;

						if (!rowValidation.IsValid)
						{
							errorsEncountered++;

							result.IsValid = false;

							result.Message += rowValidation.ToString() + "\r\n";
						}

						if (errorsEncountered >= maximumNumberOfErorrs)
						{
							break;
						}
					}
				}
				catch (Exception ex)
				{
					result.IsValid = false;
					result.Message += ex.Message;
				}
				finally
				{
					if (reader != null)
					{
						reader.Close();
					}
				}

				return result;
			}
    }
}
