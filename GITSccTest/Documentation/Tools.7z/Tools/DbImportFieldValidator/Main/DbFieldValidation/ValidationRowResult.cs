﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbFieldValidation
{
	public class ValidationRowResult
	{
		/// <summary>
		/// Describes if the row exhibits no errors.
		/// </summary>
		public bool IsValid
		{
			get
			{
				if (FieldResults == null) return true;

				return !FieldResults.Exists(f => !f.IsValid);
			}
		}

		/// <summary>
		/// Position in parent file if known.  If unknown value will be 0.
		/// </summary>
		public int RowNumber { get; set; }

		/// <summary>
		/// List of all the fields in the row that contained errors.
		/// </summary>
		public List<FieldValidationResult> FieldResultErrors 
		{
			get
			{
				return FieldResults.FindAll(f => !f.IsValid).ToList();
			}
		}

		/// <summary>
		/// List of all the results of field validation.  Will contain one result for each field.
		/// </summary>
		public List<FieldValidationResult> FieldResults { get; set; }

		public ValidationRowResult()
		{
			this.FieldResults = new List<FieldValidationResult>();
		}

		public override string ToString()
		{
			if (IsValid)
			{
				if (RowNumber == 0)
					return string.Format("Row is valid", RowNumber);
				else
					return string.Format("Row {0} is valid", RowNumber);
			}
			else
			{
				string errorMessage = string.Empty;
				
				if (RowNumber == 0)
					errorMessage = string.Format("Row Contains the following errors\r\n", RowNumber);
				else
					errorMessage = string.Format("Row {0} Contains the following errors\r\n", RowNumber);

				return errorMessage + FieldResultErrors.Select(e => e.ToString()).Aggregate((i, j) => i + "\r\n" + j);
			}
		}
	}
}
