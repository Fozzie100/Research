﻿namespace DbFieldValidation.FieldValidation
{
	/// <summary>
	/// Validation class used to validate BigInt fields
	/// </summary>
	internal class BigIntValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a bigint column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			const long SqlBigIntMaxValue = 9223372036854775807;

			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty for column " + columnDefinition.ColumnName);
			}

			try
			{
				//only do the tests if its not blank and not nullable
				if (!string.IsNullOrWhiteSpace(value))
				{
					long testValue;
					bool isValid = long.TryParse(value, out testValue);
					if (isValid)
					{
						if (testValue > SqlBigIntMaxValue)
						{
							result.AddError(string.Format("Value '{0}' is bigger than maximum allowed for BigInt for column {1}", value, columnDefinition.ColumnName));
						}
					}
					else
					{
						result.AddError("Unable to parse value '" + value + "' to int for column " + columnDefinition.ColumnName); 
					}
				}
			}
			catch
			{
				result.AddError("Unable to parse value '" + value + "' to int " + columnDefinition.ColumnName);
			}
			return result;
		}
	}
}