﻿namespace DbFieldValidation.FieldValidation
{
	/// <summary>
	/// Validation class used to validate Decimal fields
	/// </summary>
	internal class DecimalValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a decimal column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty for column " + columnDefinition.ColumnName);
			}

			if (!string.IsNullOrWhiteSpace(value))
			{
				decimal checkValue;
				bool isValidNumber = decimal.TryParse(value, out checkValue);
				if (!isValidNumber)
				{
					result.AddError("Unable to parse value '" + value + "' to decimal " + columnDefinition.ColumnName);
					isValidNumber = false;
				}
				else
				{
					int decimalPointLocation = value.IndexOf('.');
					string decimalPart = string.Empty;
					if (decimalPointLocation > -1)
					{
						decimalPart = value.Substring(decimalPointLocation + 1);
					}
					if (decimalPart.Length > columnDefinition.NumericScale)
					{
						result.AddError(string.Format("Value after decimal place for '{0}' is too large for column {1}", value, columnDefinition.ColumnName));
					}
					string wholeNumberPart = value;
					if (decimalPointLocation > -1)
					{
						wholeNumberPart = value.Substring(0, decimalPointLocation);
					}
					if (wholeNumberPart.Length > (columnDefinition.NumericPrecision - columnDefinition.NumericScale))
					{
						result.AddError(string.Format(
							"whole number part of value '{0}' will not fit for Column {1} with Precision {2} and scale {3}"
							, value, columnDefinition.ColumnName, columnDefinition.NumericPrecision, columnDefinition.NumericScale));
					}
				}
			}
			return result;
		}

	}
}