﻿using Ftse.Research.Framework;

namespace DbFieldValidation.FieldValidation
{
	/// <summary>
	/// Class used to validate strings
	/// </summary>
	internal class StringValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a string column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty for column " + columnDefinition.ColumnName);
			}
			else
			{
				if (columnDefinition.CharacterMaximumLength > -1) //varchar max fields are given to us as -1 length by information schema, so assume all will fit here
				{
					if (value.Length > columnDefinition.CharacterMaximumLength)
					{
						result.AddError(string.Format("Value {0} is too large to fit: FieldSize of {1} in column {2}", value, columnDefinition.CharacterMaximumLength, columnDefinition.ColumnName));
					}
				}
			}
			return result;
		}
	}
}