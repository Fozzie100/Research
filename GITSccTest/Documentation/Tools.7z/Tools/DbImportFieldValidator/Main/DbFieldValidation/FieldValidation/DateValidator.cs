﻿using System;
using System.Globalization;

namespace DbFieldValidation.FieldValidation
{
	/// <summary>
	/// Validation class used to validate Date fields
	/// </summary>
	internal class DateValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a date column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			const string TimeDelimiter = ":";
			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty for column " + columnDefinition.ColumnName);
			}
			if (!string.IsNullOrWhiteSpace(value))
			{
				DateTime outValue;
				//check for a time only as this will probably work on DateTime.TryParse unfortunately
				if ((value.IndexOf(TimeDelimiter) > 0) && (value.Length == 8))
				{
					result.AddError(string.Format("Value '{0}' appears to be a time only for column {1}", value, columnDefinition.ColumnName));
				}
				else
				{
					if (!DateTime.TryParse(value, out outValue))
					{
						if (DateTime.TryParseExact(value, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out outValue))
						{
							//date is ok
						}
						else
						{
							if (!DateTime.TryParseExact(value, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out outValue))
							{
								result.AddError("Unable to parse value '" + value + "' to date " + columnDefinition.ColumnName);
							}
						}
					}
				}
			}
			return result;
		}
	}
}