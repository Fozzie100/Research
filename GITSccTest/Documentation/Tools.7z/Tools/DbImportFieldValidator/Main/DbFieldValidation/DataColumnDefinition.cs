﻿namespace DbFieldValidation
{
	/// <summary>
	/// Defines a column in the database
	/// </summary>
	internal class DataColumnDefinition
	{
		/// <summary>
		/// Index within the table
		/// </summary>
		public int ColumnIndex { get; set; }
		/// <summary>
		/// Column Name
		/// </summary>
		public string ColumnName { get; set; }
		/// <summary>
		/// Data Type
		/// </summary>
		public string DataType { get; set; }
		/// <summary>
		/// Whether the field is nullable
		/// </summary>
		public bool IsNullable { get; set; }
		/// <summary>
		/// Number of characters allowed
		/// </summary>
		public int? CharacterMaximumLength { get; set; }
		/// <summary>
		/// Numeric Precision
		/// </summary>
		public int? NumericPrecision { get; set; }
		/// <summary>
		/// Numeric Scale
		/// </summary>
		public int? NumericScale { get; set; }
	}
}