﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DbFieldValidation
{
	/// <summary>
	/// Helper class to read a set of lines from a Text File
	/// </summary>
	public static class PartialTextFileReader
	{
		/// <summary>
		/// Reads a file
		/// </summary>
		/// <param name="filePath">Path to the file</param>
		/// <param name="numberOfLinesToRead">Number of lines of the file to read</param>
		/// <returns>string array</returns>
		public static string[] ReadFile(string filePath, int numberOfLinesToRead)
		{
			List<string> lines = new List<string>();
			using (TextReader reader = new StreamReader(filePath))
			{
				string line = null;
				while (((line = reader.ReadLine()) != null) && (lines.Count < numberOfLinesToRead))
				{
					lines.Add(line);
				}
			}
			return lines.ToArray();
		}
	}
}