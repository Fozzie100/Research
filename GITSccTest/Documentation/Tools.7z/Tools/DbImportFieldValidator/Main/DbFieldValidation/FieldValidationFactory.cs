﻿using DbFieldValidation.FieldValidation;

namespace DbFieldValidation
{
	/// <summary>
	/// Factory class for obtaining Field Validators
	/// </summary>
	internal static class FieldValidationFactory
	{
		/// <summary>
		/// Returns the Validator for a specific DataType
		/// </summary>
		/// <param name="dataType">Data Type</param>
		/// <returns>IFieldValidator</returns>
		public static IFieldValidator GetValidator(string dataType)
		{
			const string DataTypeChar = "CHAR";
			const string DataTypeVarChar = "VARCHAR";
			const string DataTypeInt = "INT";
			const string DataTypeBigInt = "BIGINT";
			const string DataTypeDecimal = "DECIMAL";
			const string DataTypeDate = "DATE";
			const string DataTypeDateTime = "DATETIME";
			const string DataTypeFloat = "FLOAT";

			dataType = dataType.ToUpper();
			switch (dataType)
			{
				case DataTypeChar:
				case DataTypeVarChar:
					return new StringValidator();
				case DataTypeInt:
					return new IntValidator();
				case DataTypeBigInt:
					return new BigIntValidator();
				case DataTypeDecimal:
					return new DecimalValidator();
				case DataTypeDate:
					return new DateValidator();
				case DataTypeDateTime:
					return new DateTimeValidator();
				case DataTypeFloat:
					return new FloatValidator();
				default:
					return null;
			}
		}
	}
}