﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ftse.Research.Framework;
using DbFieldValidation.Data;

namespace DbFieldValidation
{
	public class RowValidator
	{
		private SortedDictionary<int, DataColumnDefinition> _databaseTableColumnDefinitionsByIndex;
		private SortedDictionary<string, DataColumnDefinition> _databaseTableColumnDefinitionsByColumnName;
		private string[] _headerFields = null;
		string _delimiter;
		private DataTable _resultsDataTable;
		private bool _ignoreUnknownColumnsInData;

		public RowValidator (string headingRow, string delimiter, string schema, string tableName, string connectionString, bool replacesSpacesWithUnderScoreInHeadings, bool ignoreUnknownColumnsInData)
		{
			Initialise(headingRow, delimiter, schema, tableName, connectionString, replacesSpacesWithUnderScoreInHeadings, ignoreUnknownColumnsInData);
		}

		public RowValidator(string headingRow, string delimiter, string tableNameIncSchema, string connectionString, bool replacesSpacesWithUnderScoreInHeadings, bool ignoreUnknownColumnsInData)
		{
			string[] parts = tableNameIncSchema.Split('.');
			string schema = string.Empty;
			string table = string.Empty;

			if (parts.Length > 1)
			{
				schema = parts[parts.Length - 2];
			}

			table = parts[parts.Length - 1];

			Initialise(headingRow, delimiter, schema, table, connectionString, replacesSpacesWithUnderScoreInHeadings, ignoreUnknownColumnsInData);
		}

		private void Initialise (string headingRow, string delimiter, string schema, string tableName, string connectionString, bool replacesSpacesWithUnderScoreInHeadings, bool ignoreUnknownColumnsInData)
		{
			DataTable definitionDataTable = DataAccess.GetTableDefinition(connectionString, schema, tableName);
			ReadDatabaseTableDefinition(definitionDataTable);
			_delimiter = delimiter;
			_ignoreUnknownColumnsInData = ignoreUnknownColumnsInData;

			if (!String.IsNullOrEmpty(headingRow))
			{
				if (replacesSpacesWithUnderScoreInHeadings)
				{
					headingRow = headingRow.Replace(' ', '_');
				}

				_headerFields = headingRow.Split(_delimiter.ToCharArray());
			}
		}

		public ValidationRowResult ValidateRow(string row)
		{

			ValidationRowResult result = new ValidationRowResult();

			string[] lineItems = row.Split(_delimiter.ToCharArray());

			for (int columnCount = 0; columnCount < lineItems.Length; columnCount++)
			{
				string columnName = _headerFields[columnCount].ToLower();
				string fieldValue = lineItems[columnCount];

				DataColumnDefinition columnDefinition = GetColumnDataDefinition(columnCount);

				if (columnDefinition != null)
				{
					FieldValidationResult fieldResult = ValidateField(columnName, columnDefinition, fieldValue);

					if (!fieldResult.IsValid)
					{
						result.FieldResults.Add(fieldResult);
					}
				}
				else if (!_ignoreUnknownColumnsInData)
				{
					FieldValidationResult error = new FieldValidationResult();
					error.AddError(string.Format("Data Column {0} was not found in the DB table", columnName));
					result.FieldResults.Add(error);
				}
			}

			return result;
		}

		private DataColumnDefinition GetColumnDataDefinition(int columnCount)
		{
			if (_headerFields == null)
			{
				if (_databaseTableColumnDefinitionsByIndex.ContainsKey(columnCount))
				{
					return _databaseTableColumnDefinitionsByIndex[columnCount];
				}
				else
				{
					return null;
				}
			}
			else
			{
				string columnName = _headerFields[columnCount].ToLower();

				if (_databaseTableColumnDefinitionsByColumnName.ContainsKey(columnName))
				{
					return _databaseTableColumnDefinitionsByColumnName[columnName];
				}
				else
				{
					return null;
				}
			}
		}		

		/// <summary>
		/// Validates a column for each line in the provided lines
		/// </summary>
		/// <param name="rowIndex">Row Index</param>
		/// <param name="columnName">Name of the column</param>
		/// <param name="DataColumnDefinition">columnDefinition</param>
		private FieldValidationResult ValidateField(string columnName, DataColumnDefinition columnDefinition, string value)
		{
			IFieldValidator validator = FieldValidationFactory.GetValidator(columnDefinition.DataType);

			if (validator == null)
			{
				FieldValidationResult result = new FieldValidationResult();
				result.AddError(string.Format("Column {0} has an unknown data type of {1}", columnName, columnDefinition.DataType));
				return result;
			}

			return validator.ValidateField(value, columnDefinition);
		}

		private void ReadDatabaseTableDefinition(DataTable definitionDataTable)
		{
			_databaseTableColumnDefinitionsByIndex = new SortedDictionary<int, DataColumnDefinition>();
			_databaseTableColumnDefinitionsByColumnName = new SortedDictionary<string, DataColumnDefinition>();
			foreach (DataRow definitionRow in definitionDataTable.Rows)
			{
				DataColumnDefinition definition = new DataColumnDefinition();
				definition.ColumnIndex = int.Parse(definitionRow["ORDINAL_POSITION"].ToString());
				definition.ColumnName = definitionRow["COLUMN_NAME"].ToString().ToLower();
				definition.DataType = definitionRow["DATA_TYPE"].ToString();
				definition.IsNullable = SafeConvert.YesNoValueToBoolean(definitionRow["IS_NULLABLE"].ToString());
				definition.CharacterMaximumLength = ToNullableInt(definitionRow["CHARACTER_MAXIMUM_LENGTH"]);
				definition.NumericPrecision = ToNullableInt(definitionRow["NUMERIC_PRECISION"]);
				definition.NumericScale = ToNullableInt(definitionRow["NUMERIC_SCALE"]);
				_databaseTableColumnDefinitionsByIndex.Add(definition.ColumnIndex - 1, definition);
				_databaseTableColumnDefinitionsByColumnName.Add(definition.ColumnName, definition);
			}
		}

		private static int? ToNullableInt(object value)
		{
			if ((value == null) || (value == DBNull.Value))
			{
				return null;
			}
			else
			{
				return int.Parse(value.ToString());
			}
		}
	}
}
