﻿using System;
using System.IO;
using Ftse.Research.Framework.Logging;
using log4net;

namespace LogDirectoryCleaner
{
	/// <summary>
	/// Deletes the contents of Sql App Log
	/// </summary>
	public static class AppLogCleaner
	{
		#region Private Static Fields
		private static readonly ILog Logger = LogProvider.GetLogger();
		#endregion

		#region Public Static Methods
		/// <summary>
		/// Delete all files older than a specified age
		/// </summary>
		/// <param name="directoryPath">Path to clean</param>
		/// <param name="maximumFileAge">Maximum age for a file</param>
		public static void CleanDirectory(string directoryPath, int maximumFileAge)
		{
			if (!Directory.Exists(directoryPath))
			{
				Logger.InfoFormat("Directory '{0}' does not exist", directoryPath);
				return;
			}
			Logger.InfoFormat("Cleaning Directory '{0}' -  removing files older than {1} days", directoryPath, maximumFileAge);
			string[] filePaths = Directory.GetFiles(directoryPath);
			foreach (string filePath in filePaths)
			{
				FileInfo info = new FileInfo(filePath);
				if (DateTime.Today.Subtract(info.LastWriteTime).Days > maximumFileAge)
				{
					File.Delete(filePath);
				}
			}
		}
		#endregion
	}
}