﻿using System;
using log4net;
using Ftse.Research.Framework.Logging;

namespace LogDirectoryCleaner
{
	public static class Program
	{
		#region Private Static Fields
		private static readonly ILog Logger = LogProvider.GetLogger();
		#endregion

		/// <summary>
		/// Main application entry point
		/// </summary>
		/// <param name="args">string array of arguments</param>
		public static void Main(string[] args)
		{
			Logger.Info("Cleaning Test Applog");
			AppLogCleaner.CleanDirectory(@"\\Uktc3-prtest01\AppLog\PRIME", 10);
			Logger.Info("Cleaning BB Applog");
			AppLogCleaner.CleanDirectory(@"\\ukubs-sql05\AppLog\PRIME", 10);
			Logger.Info("Cleaning RA Applog");
			AppLogCleaner.CleanDirectory(@"\\ukubs-sql01ra\Applog\PRIME", 10);
			Logger.Info("Cleaning Test Indices Applog");
			AppLogCleaner.CleanDirectory(@"\\UKTC3-PRTEST01\Applog\Indices", 5);
		}
	}
}