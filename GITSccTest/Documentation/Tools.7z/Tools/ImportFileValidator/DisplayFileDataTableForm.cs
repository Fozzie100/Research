﻿using System;
using System.Data;
using System.Windows.Forms;

namespace ImportFileValidator
{
	/// <summary>
	/// Form used to display file contents
	/// </summary>
	public partial class DisplayFileDataTableForm : Form
	{
		#region Constructors
		/// <summary>
		/// Private Constructor to prevent incorrect instantiation
		/// </summary>
		private DisplayFileDataTableForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Creates a new instance of DisplayFileDataTableForm
		/// </summary>
		/// <param name="dataTable">DataTable to display</param>
		public DisplayFileDataTableForm(DataTable dataTable) : this()
		{
			uiResultsDataGridView.DataSource = dataTable;
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the locate button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiLocateColumnButton_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(uiLocateColumnTextBox.Text))
			{
				string columnName = uiLocateColumnTextBox.Text;
				if (!uiResultsDataGridView.Columns.Contains(columnName))
				{
					MessageBox.Show(this, "Unable to locate column", "x", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
				}
				else
				{
					uiResultsDataGridView.FirstDisplayedScrollingColumnIndex = uiResultsDataGridView.Columns[columnName].Index;
				}
			}
		#endregion
		}

		private void uiLocateRowButton_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(uiLocateRowButton.Text))
			{
				int rowNumber;
				if (int.TryParse(uiLocateRowTextBox.Text, out rowNumber))
				{
					if (rowNumber < uiResultsDataGridView.Rows.Count)
					{
						//locate row number before as they are zero based
						uiResultsDataGridView.FirstDisplayedScrollingRowIndex = (rowNumber - 1);
					}
				}
				else
				{
					MessageBox.Show(this, "Please Enter a valid row number", "x", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
				}
			}

		}
	}
}