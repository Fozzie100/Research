﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using Ftse.Research.Framework.IO;
using ImportFileValidator.Data;
using System.Text;
using System.Collections.Generic;

namespace ImportFileValidator
{
	/// <summary>
	/// Main Application form
	/// </summary>
	public partial class MainForm : Form
	{
		#region Private Instance Fields
		private bool _stop = false;
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new instance of MainForm
		/// </summary>
		public MainForm()
		{
			InitializeComponent();
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the validate button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiValidateButton_Click(object sender, EventArgs e)
		{
			_stop = false;
			uiTabControl.TabPages.Clear();

			if ((string.IsNullOrWhiteSpace(uiSchemaTextBox.Text)) || (string.IsNullOrWhiteSpace(uiTableNameTextBox.Text)))
			{
				MessageBox.Show(this, "Please insert schema and table name to compare against", "Enter database details", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			if (uiTextRadioButton.Checked)
			{
				if (TextValidationIsSetup())
				{
					string[]  lines = uiRowValuesTextBox.Text.Split(Environment.NewLine.ToCharArray());
					ValidationResult result = ProcessLines("Results", lines);
					if (result.IsValid)
					{
						MessageBox.Show(this, result.Message, "Valid Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					else
					{
						MessageBox.Show(this, result.Message, "Validation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
			}
			else if (uiFileRadioButton.Checked)
			{
				if (FileValidationIsSetup())
				{
					uiToolStripStatusLabel.Text = "Loading File... please wait";
					Application.DoEvents();
					string[] lines = ReadFile(uiFilePathTextBox.Text);
					uiToolStripStatusLabel.Text = "Validating File... please wait";
					Application.DoEvents();
					ValidationResult result = ProcessLines(Path.GetFileName(uiFilePathTextBox.Text), lines);
					if (result.IsValid)
					{
						MessageBox.Show(this, result.Message, "Valid File", MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					else
					{
						MessageBox.Show(this, result.Message, "Validation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
			}
			else if (uiDirectoryRadioButton.Checked)
			{
				if (DirectoryValidationIsSetup())
				{
					TabPage tabPage = new TabPage("Results");
					DataGridView gridView = new DataGridView();
					DataTable resultsTable = new DataTable();
					resultsTable.Columns.Add("FileName", typeof(string));
					resultsTable.Columns.Add("Status", typeof(string));
					tabPage.Controls.Add(gridView);
					gridView.Dock = DockStyle.Fill;
					gridView.DataSource = resultsTable;
					gridView.AllowUserToAddRows = false;
					gridView.AllowUserToDeleteRows = false;
					gridView.ReadOnly = true;
					gridView.CellDoubleClick += new DataGridViewCellEventHandler(ResultsGridView_CellDoubleClick);
					uiTabControl.TabPages.Add(tabPage);
					Application.DoEvents(); //This is really bad, but refresh the screen

					SearchOption searchOption = SearchOption.TopDirectoryOnly;
					if (uiIncludeSubDirectoriesCheckBox.Checked)
					{
						searchOption = SearchOption.AllDirectories;
					}
					string[] filePaths = Directory.GetFiles(uiDirectoryPathTextBox.Text, uiPatternTextBox.Text, searchOption);
					bool anyFileInvalid = false;
					foreach (string filePath in filePaths)
					{
						if (_stop)
						{
							break;
						}
						string fileName = Path.GetFileName(filePath);
						string[] lines = ReadFile(filePath);
						ValidationResult result = ProcessLines(fileName, lines);
						anyFileInvalid |= (!result.IsValid);
						resultsTable.Rows.Add(fileName, result.IsValid ? "VALID" : "INVALID");
					}
					if (anyFileInvalid)
					{
						MessageBox.Show(this, "One of more files failed validation", "Validation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
					else
					{
						MessageBox.Show(this, "All files successfully validated", "Valid File", MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
				}
			}
		}

		/// <summary>
		/// Event raised when the browse for file button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiBrowseForFileButton_Click(object sender, EventArgs e)
		{
			uiOpenFileDialog.Filter = "Text File|*.txt|All Files|*.*";
			if (uiOpenFileDialog.ShowDialog(this) == DialogResult.OK)
			{
				uiFilePathTextBox.Text = uiOpenFileDialog.FileName;
			}
		}

		/// <summary>
		/// Event raised when the Text Radio button has its state changed
		/// </summary>
		/// <param name="sender">RadioButton raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiTextRadioButton_CheckedChanged(object sender, EventArgs e)
		{
			uiFilePathTextBox.Enabled = false;
			uiBrowseForFileButton.Enabled = false;
			uiRowValuesTextBox.Enabled = true;
			uiDisplayTextAsTableButton.Enabled = true;
			uiDirectoryPathTextBox.Enabled = false;
			uiPatternTextBox.Enabled = false;
			uiBrowseForDirectoryButton.Enabled = false;
			uiIncludeSubDirectoriesCheckBox.Enabled = false;
		}

		/// <summary>
		/// Event raised when the Text Radio button has its state changed
		/// </summary>
		/// <param name="sender">RadioButton raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiFileRadioButton_CheckedChanged(object sender, EventArgs e)
		{
			uiFilePathTextBox.Enabled = true;
			uiBrowseForFileButton.Enabled = true;
			uiRowValuesTextBox.Enabled = false;
			uiDisplayTextAsTableButton.Enabled = false;
			uiDirectoryPathTextBox.Enabled = false;
			uiPatternTextBox.Enabled = false;
			uiBrowseForDirectoryButton.Enabled = false;
			uiIncludeSubDirectoriesCheckBox.Enabled = false;
		}

		private void uiDirectoryRadioButton_CheckedChanged(object sender, EventArgs e)
		{
			uiFilePathTextBox.Enabled = false;
			uiBrowseForFileButton.Enabled = false;
			uiRowValuesTextBox.Enabled = false;
			uiDisplayTextAsTableButton.Enabled = false;
			uiDirectoryPathTextBox.Enabled = true;
			uiPatternTextBox.Enabled = true;
			uiBrowseForDirectoryButton.Enabled = true;
			uiIncludeSubDirectoriesCheckBox.Enabled = true;
		}


		/// <summary>
		/// Event raised when the Browse for directory button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiBrowseForDirectoryButton_Click(object sender, EventArgs e)
		{
			if (uiFolderBrowserDialog.ShowDialog(this) == DialogResult.OK)
			{
				uiDirectoryPathTextBox.Text = uiFolderBrowserDialog.SelectedPath;
			}
		}

		/// <summary>
		/// Event raised when a row is double clicked within the Results Grid View
		/// </summary>
		/// <param name="sender">DataGridView raising the event</param>
		/// <param name="e">DataGridViewCellEventArgs</param>
		/// <remarks>Applies to directory traverse only</remarks>
		private void ResultsGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridView gridView = sender as DataGridView;
				DataGridViewRow row = gridView.Rows[e.RowIndex];
				string fileName = row.Cells["FileName"].Value.ToString();
				if (uiTabControl.TabPages.ContainsKey(fileName))
				{
					uiTabControl.SelectedTab = uiTabControl.TabPages[fileName];
				}
			}
		}

		/// <summary>
		/// Event raised when the stop button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		/// <remarks>This only works because we have a few Application.DoEvents in the code</remarks>
		private void uiStopButton_Click(object sender, EventArgs e)
		{
			_stop = true;
		}
		#endregion

		#region Private Methods
		/// <summary>
		/// Processes lines and displays the result
		/// </summary>
		/// <param name="description">Description to display</param>
		/// <param name="lines">String Array</param>
		private ValidationResult ProcessLines(string description, string[] lines)
		{
			ValidationResult result = new ValidationResult();

			DataTable definitionDataTable = DataAccess.GetTableDefinition(uiSchemaTextBox.Text, uiTableNameTextBox.Text);
			if (definitionDataTable.Rows.Count == 0)
			{
				result.IsValid = false;
				result.Message = string.Format("Please ensure the Table name is correct\nCannot define [{0}].[{1}]", uiSchemaTextBox.Text, uiTableNameTextBox.Text);
				return result;
			}
			try
			{
				uiToolStripStatusLabel.Text = string.Format("Processing {0} please wait", description);
				Application.DoEvents(); //This is really bad, but refresh the screen
				Cursor.Current = Cursors.WaitCursor;

				int maximumNumberOfErrors = 50; //default
				int parsedMaxNumberOfErrors = 0;
				if (int.TryParse(uiMaximumNumberOfErrorsTextBox.Text, out parsedMaxNumberOfErrors))
				{
					maximumNumberOfErrors = parsedMaxNumberOfErrors;
				}
				DataTable resultsDataTable = null;
				using (DataTableVerifier tableVerifier = new DataTableVerifier(uiDelimiterTextBox.Text, maximumNumberOfErrors))
				{
					if (uiFirstLineHasHeadersCheckBox.Checked)
					{
						if (uiReplaceSpaceWithUnderscoreCheckBox.Checked)
						{
							lines[0] = lines[0].Replace(" ", "_");
						}
						resultsDataTable = tableVerifier.ValidateByColumnNames(definitionDataTable, lines);
					}
					else
					{
						resultsDataTable = tableVerifier.ValidateByOrdinalPosition(definitionDataTable, lines);
					}
				}
				int recordCount = resultsDataTable.Rows.Count;
				uiToolStripStatusLabel.Text = string.Format("{0} problem records found", recordCount);
				if (recordCount == 0)
				{
					result.Message = "Import should succeed";
				}
				else
				{
					result.IsValid = false;
					uiTabControl.TabPages.Add(description, description);
					TabPage tabPage = uiTabControl.TabPages[description];
					DataGridView gridView = new DataGridView();
					GroupBox buttonGroupBox = new GroupBox();
					buttonGroupBox.Size = new System.Drawing.Size(1, 35);
					Button button = new Button();
					button.Text = "Display As Table";
					button.Size = new System.Drawing.Size(100, 23);
					buttonGroupBox.Controls.Add(button);
					button.Location = new System.Drawing.Point(5, 10);
					button.Click += new EventHandler(button_Click);
					button.Tag = description;
					tabPage.Controls.Add(gridView);
					tabPage.Controls.Add(buttonGroupBox);
					gridView.Dock = DockStyle.Fill;
					buttonGroupBox.Dock = DockStyle.Bottom;
					gridView.DataSource = resultsDataTable;
					Application.DoEvents(); //This is really bad, but refresh the screen
					result.Message = string.Format("Number of problems found {0}", recordCount);
				}
			}
			catch (Exception ex)
			{
				result.IsValid = false;
				result.Message = string.Format("Error while validating {0}\n{1}", description, ex.ToString());
			}
			finally
			{
				Cursor.Current = Cursors.Default;
			}	
			return result;
		}

		/// <summary>
		/// Checks to see whether all entries for Text validation have been setup
		/// </summary>
		/// <returns>boolean</returns>
		private bool TextValidationIsSetup()
		{
			if (string.IsNullOrWhiteSpace(uiRowValuesTextBox.Text))
			{
				MessageBox.Show(this, "Please insert the text to validate\nFirst Row should be header row", "Enter Text to validate", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Checks to see whether all entries for single file validation have been setup
		/// </summary>
		/// <returns>boolean</returns>
		private bool FileValidationIsSetup()
		{
			if (string.IsNullOrWhiteSpace(uiFilePathTextBox.Text))
			{
				MessageBox.Show(this, "Please insert the Path to the file to validate", "Enter Path to file to validate", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			if (!File.Exists(uiFilePathTextBox.Text))
			{
				MessageBox.Show(this, "The specified file path cannot be found", "File does not exist", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Checks to see whether all entries for Directory validation have been setup
		/// </summary>
		/// <returns>boolean</returns>
		private bool DirectoryValidationIsSetup()
		{
			if (string.IsNullOrWhiteSpace(uiDirectoryPathTextBox.Text))
			{
				MessageBox.Show(this, "Please insert the path to the folder containing files to validate", "Enter Path to folder to validate", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			if (string.IsNullOrWhiteSpace(uiPatternTextBox.Text))
			{
				MessageBox.Show(this, "Please insert a pattern for files to locate", "Enter Pattern", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			if (uiPatternTextBox.Text.Equals("*.*"))
			{
				if (MessageBox.Show(this, "Processing all files could potentially take a long time\nAre you sure you wish to do this?", "All files pattern detected", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
				{
					return false;
				}
			}
			if (!Directory.Exists(uiDirectoryPathTextBox.Text))
			{
				MessageBox.Show(this, "The specified folder cannot be found", "Folder does not exist", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Reads either the entire or path of a file
		/// </summary>
		/// <param name="filePath">Path to the file</param>
		/// <returns>string array of text lines from the file</returns>
		private string[] ReadFile(string filePath)
		{
			string[] lines = null;
			if (uiValidateFirstXLines.Checked)
			{
				lines = PartialTextFileReader.ReadFile(filePath, (int)uiValidateFirstXNumericUpDown.Value);
			}
			else
			{
				lines = TextFileReader.ReadFile(filePath);
			}
			return lines;
		}

		/// <summary>
		/// Displays a string array as a DataTable
		/// </summary>
		/// <param name="lines">string array of lines to display</param>
		private void DisplayLinesAsDataTable(string[] lines)
		{
			DataTable table = DataTableCreator.CreateDataTable(lines, uiDelimiterTextBox.Text, uiFirstLineHasHeadersCheckBox.Checked);
			using (DisplayFileDataTableForm form = new DisplayFileDataTableForm(table))
			{
				form.ShowDialog(this);
			}
		}
		#endregion

		void button_Click(object sender, EventArgs e)
		{
			string[] lines = null;
			if (uiTextRadioButton.Checked)
			{
				lines = uiRowValuesTextBox.Text.Split(Environment.NewLine.ToCharArray());
			}
			else if (uiFileRadioButton.Checked)
			{
				lines = ReadFile(uiFilePathTextBox.Text);
			}
			else if (uiDirectoryRadioButton.Checked)
			{
				string fileName = ((Button)sender).Tag.ToString();
				string filePath = Path.Combine(uiDirectoryPathTextBox.Text, fileName);
				lines = ReadFile(filePath);
			}
			DisplayLinesAsDataTable(lines);
		}

		private void uiDisplayTextAsTableButton_Click(object sender, EventArgs e)
		{
			string[] lines = uiRowValuesTextBox.Text.Split(Environment.NewLine.ToCharArray());
			DisplayLinesAsDataTable(lines);
		}

		private void uiFirstLineHasHeadersCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			uiReplaceSpaceWithUnderscoreCheckBox.Enabled = uiFirstLineHasHeadersCheckBox.Checked;
			if (!uiReplaceSpaceWithUnderscoreCheckBox.Enabled)
			{
				uiReplaceSpaceWithUnderscoreCheckBox.Checked = false;
			}
		}
	}
}