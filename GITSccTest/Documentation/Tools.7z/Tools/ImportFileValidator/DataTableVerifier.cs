﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Ftse.Research.Framework;

namespace ImportFileValidator
{
	/// <summary>
	/// Class used to verify strings against a database Table
	/// </summary>
	public class DataTableVerifier : IDisposable
	{
		#region Private Constants
		private const string ResultsColumnColumnName = "Column";
		private const string ResultsColumnDataType = "DataType";
		private const string ResultsColumnRecordIndex = "Record";
		private const string ResultsColumnValue = "Value";
		private const string ResultsColumnError = "Issue";
		#endregion

		#region Private Instance Fields
		private DataTable _resultsDataTable;
		private string[] _originalLines;
		private char[] _delimiters;
		private SortedDictionary<int, DataColumnDefinition> _databaseTableColumnDefinitionsByIndex;
		private SortedDictionary<string, DataColumnDefinition> _databaseTableColumnDefinitionsByColumnName;
		#endregion

		#region Public Properties
		/// <summary>
		/// Maximum Number of errors this object will process before ceasing
		/// </summary>
		public int MaxiumNumberOfErrors { get; set; }
		/// <summary>
		/// Delimiter to use when parsing each record
		/// </summary>
		public string Delimiter { get; set; }
		/// <summary>
		/// Number of errors found
		/// </summary>
		public int NumberOfErrors { get; set; }
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new instance of DataTableVerifier
		/// </summary>
		/// <param name="delimiter">Delimiter to use when parsing each record</param>
		public DataTableVerifier(string delimiter)
		{
			const int DefaultMaximumNumberOfErrors = 50;

			//set the delimiter as the first character passed in
			this.Delimiter = delimiter;
			this._delimiters = this.Delimiter.ToCharArray();
			this.MaxiumNumberOfErrors = DefaultMaximumNumberOfErrors;
		}

		/// <summary>
		/// Creates a new instance of DataTableVerifier
		/// </summary>
		/// <param name="delimiter">Delimiter to use when parsing each record</param>
		/// <param name="maximumNumberOfErrors">Maximum Number Of Errors To Process</param>
		public DataTableVerifier(string delimiter, int maximumNumberOfErrors) : this(delimiter)
		{
			this.MaxiumNumberOfErrors = maximumNumberOfErrors;
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Validates a set of records against a Database Table using first row as header records
		/// </summary>
		/// <param name="definitionDataTable">DataTable retrieved from InformationSchema.Columns</param>
		/// <param name="lines">String array of lines</param>
		/// <returns>DataTable of problem records</returns>
		/// <remarks>Assumes first line is a header record</remarks>
		public DataTable ValidateByColumnNames(DataTable definitionDataTable, string[] lines)
		{
			_originalLines = lines;
			ReadDatabaseTableDefinition(definitionDataTable);
			SetupValidation();

			string[] headerItems = _originalLines[0].Split(this.Delimiter.ToCharArray());

			for (int rowIndex = 1; rowIndex < _originalLines.Length; rowIndex++)
			{
				string[] lineItems = _originalLines[rowIndex].Split(this.Delimiter.ToCharArray());
				for (int columnCount = 0; columnCount < lineItems.Length; columnCount++)
				{
					string columnName = headerItems[columnCount].ToLower();
					string fieldValue = lineItems[columnCount];
					if (_databaseTableColumnDefinitionsByColumnName.ContainsKey(columnName))
					{
						DataColumnDefinition columnDefinition = _databaseTableColumnDefinitionsByColumnName[columnName];
						ValidateField(rowIndex, columnName, columnDefinition, fieldValue);
					}
					else
					{
						RecordError(columnName, string.Empty, rowIndex, columnName, "Column Not Found");
					}
					//once we get to maximumNumberOfErrors errors dont bother doing anymore as thats too many to process
					if (this.NumberOfErrors >= this.MaxiumNumberOfErrors)
					{
						break;
					}
				}
				if (this.NumberOfErrors >= this.MaxiumNumberOfErrors)
				{
					break;
				}
			}
			return _resultsDataTable;
		}

		/// <summary>
		/// Validates a set of records against a Database Table using first row as header records
		/// </summary>
		/// <param name="definitionDataTable">DataTable retrieved from InformationSchema.Columns</param>
		/// <param name="lines">String array of lines</param>
		/// <returns>DataTable of problem records</returns>
		/// <remarks>Assumes first line is a header record</remarks>
		public DataTable ValidateByOrdinalPosition(DataTable definitionDataTable, string[] lines)
		{
			_originalLines = lines;
			ReadDatabaseTableDefinition(definitionDataTable);
			SetupValidation();

			string[] headerItems = _originalLines[0].Split(this.Delimiter.ToCharArray());

			for (int rowIndex = 0; rowIndex < _originalLines.Length; rowIndex++)
			{
				string[] lineItems = _originalLines[rowIndex].Split(this.Delimiter.ToCharArray());
				for (int columnCount = 0; columnCount < lineItems.Length; columnCount++)
				{
					string columnName = headerItems[columnCount];
					string fieldValue = lineItems[columnCount];
					if (_databaseTableColumnDefinitionsByIndex.ContainsKey(columnCount))
					{
						DataColumnDefinition columnDefinition = _databaseTableColumnDefinitionsByIndex[columnCount];
						ValidateField(rowIndex, columnName, columnDefinition, fieldValue);
					}
					else
					{
						RecordError(columnCount.ToString(), string.Empty, rowIndex, columnCount.ToString(), "Column Not Found");
					}
					//once we get to maximumNumberOfErrors errors dont bother doing anymore as thats too many to process
					if (this.NumberOfErrors >= this.MaxiumNumberOfErrors)
					{
						break;
					}
				}
				if (this.NumberOfErrors >= this.MaxiumNumberOfErrors)
				{
					break;
				}
			} 
			return _resultsDataTable;
		}
		#endregion

		#region Private Methods
		/// <summary>
		/// Resets the object and sets up the details needed for validation
		/// </summary>
		private void SetupValidation()
		{
			//reset error count
			this.NumberOfErrors = 0;
			//setup the results table
			ConstructResultsDataTable();
			//split the file into lines
			GetLinesToProcess();
			//check to see if all lines are the same split length
			EnsureAllLinesAreSameLengths();
		}

		/// <summary>
		/// Checks to see if all lines read from the file are the same length
		/// </summary>
		private void EnsureAllLinesAreSameLengths()
		{
			List<int> nonMatchingRecordLengths = new List<int>();

			int headerColumnCount = _originalLines[0].Length - _originalLines[0].Replace(this.Delimiter, string.Empty).Length; 

			//check each row and make sure there is the same number of columns, if not mark and remove it so we dont bother trying to process
			for (int i = 1; i < _originalLines.Length; i++)
			{
				int rowColumnCount = _originalLines[i].Length - _originalLines[i].Replace(this.Delimiter, string.Empty).Length;
				if (rowColumnCount != headerColumnCount)
				{
					nonMatchingRecordLengths.Add(i);
					RecordError("ROW ERROR", string.Empty, i, string.Empty, string.Format("Inconsistent number of columns - Expected {0} Actual {1}", headerColumnCount, rowColumnCount));
					//check for too many errors
					if (this.NumberOfErrors >= this.MaxiumNumberOfErrors)
					{
						break;
					}
				}
			}

			//remove any indexes which were duff
			_originalLines = RemoveIndices<string>(_originalLines, nonMatchingRecordLengths.ToArray());
		}

		/// <summary>
		/// Records an entry in the error table
		/// </summary>
		/// <param name="columnName">Name of the column causing the problem</param>
		/// <param name="dataType">DataType of the column</param>
		/// <param name="recordIndex">Index of the record</param>
		/// <param name="value">Value which caused the problem</param>
		/// <param name="error">Details of the issue</param>
		private void RecordError(string columnName, string dataType, int recordIndex, object value, string error)
		{
			_resultsDataTable.Rows.Add(columnName, dataType, recordIndex, value, error);
			this.NumberOfErrors++;
		}

		/// <summary>
		/// Creates the results table used by methods of this objects
		/// </summary>
		/// <returns>DataTable</returns>
		private void ConstructResultsDataTable()
		{
			_resultsDataTable = new DataTable();
			_resultsDataTable.Columns.Add(ResultsColumnColumnName, typeof(string));
			_resultsDataTable.Columns.Add(ResultsColumnDataType, typeof(string));
			_resultsDataTable.Columns.Add(ResultsColumnRecordIndex, typeof(string));
			_resultsDataTable.Columns.Add(ResultsColumnValue, typeof(string));
			_resultsDataTable.Columns.Add(ResultsColumnError, typeof(string));
		}

		/// <summary>
		/// Gets all the non empty lines within the passed in array and returns them in order split by delimiter
		/// </summary>
		private void GetLinesToProcess()
		{
			var query = from string line
						in _originalLines
						where string.IsNullOrEmpty(line) == false
						select line;
			_originalLines = query.ToArray();
		}
		#endregion

		#region IDisposable
		/// <summary>
		/// Disposes of this item
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Disposes of this item
		/// </summary>
		/// <param name="disposing">Flag to say if the item is being disposed</param>
		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				// free managed resources
				if (_resultsDataTable != null)
				{
					try
					{
						_resultsDataTable.Dispose();
						_resultsDataTable = null;
					}
					catch
					{
						//ignore errors, do best attempt at disposing
					}
				}
			}
		}
		#endregion

		private void ReadDatabaseTableDefinition(DataTable definitionDataTable)
		{
			_databaseTableColumnDefinitionsByIndex = new SortedDictionary<int, DataColumnDefinition>();
			_databaseTableColumnDefinitionsByColumnName = new SortedDictionary<string, DataColumnDefinition>();
			foreach (DataRow definitionRow in definitionDataTable.Rows)
			{
				DataColumnDefinition definition = new DataColumnDefinition();
				definition.ColumnIndex = int.Parse(definitionRow["ORDINAL_POSITION"].ToString());
				definition.ColumnName = definitionRow["COLUMN_NAME"].ToString().ToLower();
				definition.DataType = definitionRow["DATA_TYPE"].ToString();
				definition.IsNullable = SafeConvert.YesNoValueToBoolean(definitionRow["IS_NULLABLE"].ToString());
				definition.CharacterMaximumLength = ToNullableInt(definitionRow["CHARACTER_MAXIMUM_LENGTH"]);
				definition.NumericPrecision = ToNullableInt(definitionRow["NUMERIC_PRECISION"]);
				definition.NumericScale = ToNullableInt(definitionRow["NUMERIC_SCALE"]);
				_databaseTableColumnDefinitionsByIndex.Add(definition.ColumnIndex -1, definition);
				_databaseTableColumnDefinitionsByColumnName.Add(definition.ColumnName, definition);
			}
		}

		private static int? ToNullableInt(object value)
		{
			if ((value == null) || (value == DBNull.Value))
			{
				return null;
			}
			else
			{
				return int.Parse(value.ToString());
			}
		}

		/// <summary>
		/// Validates a column for each line in the provided lines
		/// </summary>
		/// <param name="rowIndex">Row Index</param>
		/// <param name="columnName">Name of the column</param>
		/// <param name="DataColumnDefinition">columnDefinition</param>
		private void ValidateField(int rowIndex, string columnName, DataColumnDefinition columnDefinition, string value)
		{
			IFieldValidator validator = FieldValidationFactory.GetValidator(columnDefinition.DataType);
			if (validator == null)
			{
				RecordError(columnName, columnDefinition.DataType, 0, columnDefinition.DataType, "Unknown Data Type");
				return;
			}

			FieldValidationResult result = validator.ValidateField(value, columnDefinition);
			if (!result.IsValid)
			{
				RecordError(columnName, columnDefinition.DataType, rowIndex, value, result.ToString());
			}
		}

		private T[] RemoveIndices<T>(T[] originalArray, params int[] indexesToRemove)
		{
			if (indexesToRemove.Length == 0)
			{
				return originalArray;
			}
			T[] newIndicesArray = new T[originalArray.Length - indexesToRemove.Length];
			int i = 0;
			int j = 0;
			while (i < originalArray.Length)
			{
				if (!indexesToRemove.Contains(i))
				{
					newIndicesArray[j] = originalArray[i];
					j++;
				}
				i++;
			} 
			return newIndicesArray;
		}
	}
}