﻿namespace ImportFileValidator
{
	partial class DisplayFileDataTableForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DisplayFileDataTableForm));
			this.uiResultsDataGridView = new System.Windows.Forms.DataGridView();
			this.uiControlGroupBox = new System.Windows.Forms.GroupBox();
			this.uiLocateColumnButton = new System.Windows.Forms.Button();
			this.uiLocateColumnTextBox = new System.Windows.Forms.TextBox();
			this.uiLocateColumnLabel = new System.Windows.Forms.Label();
			this.uiLocateRowButton = new System.Windows.Forms.Button();
			this.uiLocateRowTextBox = new System.Windows.Forms.TextBox();
			this.uiLocateRowLabel = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.uiResultsDataGridView)).BeginInit();
			this.uiControlGroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiResultsDataGridView
			// 
			this.uiResultsDataGridView.AllowUserToAddRows = false;
			this.uiResultsDataGridView.AllowUserToDeleteRows = false;
			this.uiResultsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.uiResultsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiResultsDataGridView.Location = new System.Drawing.Point(0, 35);
			this.uiResultsDataGridView.Name = "uiResultsDataGridView";
			this.uiResultsDataGridView.ReadOnly = true;
			this.uiResultsDataGridView.Size = new System.Drawing.Size(822, 489);
			this.uiResultsDataGridView.TabIndex = 0;
			// 
			// uiControlGroupBox
			// 
			this.uiControlGroupBox.Controls.Add(this.uiLocateRowButton);
			this.uiControlGroupBox.Controls.Add(this.uiLocateRowTextBox);
			this.uiControlGroupBox.Controls.Add(this.uiLocateRowLabel);
			this.uiControlGroupBox.Controls.Add(this.uiLocateColumnButton);
			this.uiControlGroupBox.Controls.Add(this.uiLocateColumnTextBox);
			this.uiControlGroupBox.Controls.Add(this.uiLocateColumnLabel);
			this.uiControlGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
			this.uiControlGroupBox.Location = new System.Drawing.Point(0, 0);
			this.uiControlGroupBox.Name = "uiControlGroupBox";
			this.uiControlGroupBox.Size = new System.Drawing.Size(822, 35);
			this.uiControlGroupBox.TabIndex = 1;
			this.uiControlGroupBox.TabStop = false;
			// 
			// uiLocateColumnButton
			// 
			this.uiLocateColumnButton.Location = new System.Drawing.Point(259, 8);
			this.uiLocateColumnButton.Name = "uiLocateColumnButton";
			this.uiLocateColumnButton.Size = new System.Drawing.Size(75, 23);
			this.uiLocateColumnButton.TabIndex = 2;
			this.uiLocateColumnButton.Text = "Locate";
			this.uiLocateColumnButton.UseVisualStyleBackColor = true;
			this.uiLocateColumnButton.Click += new System.EventHandler(this.uiLocateColumnButton_Click);
			// 
			// uiLocateColumnTextBox
			// 
			this.uiLocateColumnTextBox.Location = new System.Drawing.Point(92, 9);
			this.uiLocateColumnTextBox.Name = "uiLocateColumnTextBox";
			this.uiLocateColumnTextBox.Size = new System.Drawing.Size(161, 20);
			this.uiLocateColumnTextBox.TabIndex = 1;
			// 
			// uiLocateColumnLabel
			// 
			this.uiLocateColumnLabel.AutoSize = true;
			this.uiLocateColumnLabel.Location = new System.Drawing.Point(7, 13);
			this.uiLocateColumnLabel.Name = "uiLocateColumnLabel";
			this.uiLocateColumnLabel.Size = new System.Drawing.Size(78, 13);
			this.uiLocateColumnLabel.TabIndex = 0;
			this.uiLocateColumnLabel.Text = "Locate Column";
			// 
			// uiLocateRowButton
			// 
			this.uiLocateRowButton.Location = new System.Drawing.Point(594, 9);
			this.uiLocateRowButton.Name = "uiLocateRowButton";
			this.uiLocateRowButton.Size = new System.Drawing.Size(75, 23);
			this.uiLocateRowButton.TabIndex = 5;
			this.uiLocateRowButton.Text = "Locate";
			this.uiLocateRowButton.UseVisualStyleBackColor = true;
			this.uiLocateRowButton.Click += new System.EventHandler(this.uiLocateRowButton_Click);
			// 
			// uiLocateRowTextBox
			// 
			this.uiLocateRowTextBox.Location = new System.Drawing.Point(427, 10);
			this.uiLocateRowTextBox.Name = "uiLocateRowTextBox";
			this.uiLocateRowTextBox.Size = new System.Drawing.Size(161, 20);
			this.uiLocateRowTextBox.TabIndex = 4;
			// 
			// uiLocateRowLabel
			// 
			this.uiLocateRowLabel.AutoSize = true;
			this.uiLocateRowLabel.Location = new System.Drawing.Point(342, 14);
			this.uiLocateRowLabel.Name = "uiLocateRowLabel";
			this.uiLocateRowLabel.Size = new System.Drawing.Size(65, 13);
			this.uiLocateRowLabel.TabIndex = 3;
			this.uiLocateRowLabel.Text = "Locate Row";
			// 
			// DisplayFileDataTableForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(822, 524);
			this.Controls.Add(this.uiResultsDataGridView);
			this.Controls.Add(this.uiControlGroupBox);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "DisplayFileDataTableForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "File Display";
			((System.ComponentModel.ISupportInitialize)(this.uiResultsDataGridView)).EndInit();
			this.uiControlGroupBox.ResumeLayout(false);
			this.uiControlGroupBox.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.DataGridView uiResultsDataGridView;
		private System.Windows.Forms.GroupBox uiControlGroupBox;
		private System.Windows.Forms.Button uiLocateColumnButton;
		private System.Windows.Forms.TextBox uiLocateColumnTextBox;
		private System.Windows.Forms.Label uiLocateColumnLabel;
		private System.Windows.Forms.Button uiLocateRowButton;
		private System.Windows.Forms.TextBox uiLocateRowTextBox;
		private System.Windows.Forms.Label uiLocateRowLabel;
	}
}