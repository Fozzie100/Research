﻿
namespace ImportFileValidator
{
	internal class ValidationResult
	{
		public bool IsValid { get; set; }
		public string Message { get; set; }

		public ValidationResult()
		{
			IsValid = true;	
		}
	}
}
