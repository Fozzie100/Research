﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DbFieldValidation.Data
{
	/// <summary>
	/// Simple Data Access Class
	/// </summary>
	internal static class DataAccess
	{
		/// <summary>
		/// Returns the Column definition for a table within the database
		/// </summary>
		/// <param name="schemaName">Name of the Schema</param>
		/// <param name="tableName">Name of the table</param>
		/// <returns>DataTable</returns>
		public static DataTable GetTableDefinition(string connectionString, string schemaName, string tableName)
		{
			DataTable definitionDataTable = new DataTable();

			string sqlStatement = "select * from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName";
			using (SqlConnection connection = new SqlConnection(connectionString))
			{
				connection.Open();
				using (SqlDataAdapter adapter = new SqlDataAdapter(sqlStatement, connection))
				{
					adapter.SelectCommand.Parameters.AddWithValue("@SchemaName", schemaName);
					adapter.SelectCommand.Parameters.AddWithValue("@TableName", tableName);
					adapter.Fill(definitionDataTable);
				}
			}
			return definitionDataTable;
		}
	}
}