﻿namespace ImportFileValidator
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.uiValidateButton = new System.Windows.Forms.Button();
			this.uiTableNameTextBox = new System.Windows.Forms.TextBox();
			this.uiTableNameLabel = new System.Windows.Forms.Label();
			this.uiRowValuesTextBox = new System.Windows.Forms.TextBox();
			this.uiSchemaLabel = new System.Windows.Forms.Label();
			this.uiSchemaTextBox = new System.Windows.Forms.TextBox();
			this.uiStatusStrip = new System.Windows.Forms.StatusStrip();
			this.uiToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.uiMainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.uiDisplayTextAsTableButton = new System.Windows.Forms.Button();
			this.uiWarningLabel = new System.Windows.Forms.Label();
			this.uiValidateFirstXNumericUpDown = new System.Windows.Forms.NumericUpDown();
			this.uiValidateFirstXLines = new System.Windows.Forms.CheckBox();
			this.uiFileValidationLabel = new System.Windows.Forms.Label();
			this.uiLinePanel = new System.Windows.Forms.Panel();
			this.uiIncludeSubDirectoriesCheckBox = new System.Windows.Forms.CheckBox();
			this.uiStopButton = new System.Windows.Forms.Button();
			this.uiPatternTextBox = new System.Windows.Forms.TextBox();
			this.uiPatternLabel = new System.Windows.Forms.Label();
			this.uiBrowseForDirectoryButton = new System.Windows.Forms.Button();
			this.uiDirectoryPathTextBox = new System.Windows.Forms.TextBox();
			this.uiDirectoryRadioButton = new System.Windows.Forms.RadioButton();
			this.uiBrowseForFileButton = new System.Windows.Forms.Button();
			this.uiFilePathTextBox = new System.Windows.Forms.TextBox();
			this.uiFileRadioButton = new System.Windows.Forms.RadioButton();
			this.uiTextRadioButton = new System.Windows.Forms.RadioButton();
			this.uiTabControl = new System.Windows.Forms.TabControl();
			this.uiTableDetailsGroupBox = new System.Windows.Forms.GroupBox();
			this.uiReplaceSpaceWithUnderscoreCheckBox = new System.Windows.Forms.CheckBox();
			this.uiDelimiterTextBox = new System.Windows.Forms.TextBox();
			this.uiFirstLineHasHeadersCheckBox = new System.Windows.Forms.CheckBox();
			this.uiDelimiterLabel = new System.Windows.Forms.Label();
			this.uiMaximumNumberOfErrorsTextBox = new System.Windows.Forms.TextBox();
			this.uiMaximumNumberOfErrorsLabel = new System.Windows.Forms.Label();
			this.uiOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.uiFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.uiStatusStrip.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).BeginInit();
			this.uiMainSplitContainer.Panel1.SuspendLayout();
			this.uiMainSplitContainer.Panel2.SuspendLayout();
			this.uiMainSplitContainer.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiValidateFirstXNumericUpDown)).BeginInit();
			this.uiTableDetailsGroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiValidateButton
			// 
			this.uiValidateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiValidateButton.Location = new System.Drawing.Point(117, 169);
			this.uiValidateButton.Name = "uiValidateButton";
			this.uiValidateButton.Size = new System.Drawing.Size(75, 23);
			this.uiValidateButton.TabIndex = 16;
			this.uiValidateButton.Text = "Validate";
			this.uiValidateButton.UseVisualStyleBackColor = true;
			this.uiValidateButton.Click += new System.EventHandler(this.uiValidateButton_Click);
			// 
			// uiTableNameTextBox
			// 
			this.uiTableNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiTableNameTextBox.Location = new System.Drawing.Point(238, 11);
			this.uiTableNameTextBox.Name = "uiTableNameTextBox";
			this.uiTableNameTextBox.Size = new System.Drawing.Size(332, 20);
			this.uiTableNameTextBox.TabIndex = 3;
			// 
			// uiTableNameLabel
			// 
			this.uiTableNameLabel.AutoSize = true;
			this.uiTableNameLabel.Location = new System.Drawing.Point(167, 15);
			this.uiTableNameLabel.Name = "uiTableNameLabel";
			this.uiTableNameLabel.Size = new System.Drawing.Size(65, 13);
			this.uiTableNameLabel.TabIndex = 2;
			this.uiTableNameLabel.Text = "Table Name";
			// 
			// uiRowValuesTextBox
			// 
			this.uiRowValuesTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiRowValuesTextBox.Enabled = false;
			this.uiRowValuesTextBox.Location = new System.Drawing.Point(117, 6);
			this.uiRowValuesTextBox.Multiline = true;
			this.uiRowValuesTextBox.Name = "uiRowValuesTextBox";
			this.uiRowValuesTextBox.Size = new System.Drawing.Size(673, 85);
			this.uiRowValuesTextBox.TabIndex = 1;
			this.uiRowValuesTextBox.Tag = "";
			// 
			// uiSchemaLabel
			// 
			this.uiSchemaLabel.AutoSize = true;
			this.uiSchemaLabel.Location = new System.Drawing.Point(9, 15);
			this.uiSchemaLabel.Name = "uiSchemaLabel";
			this.uiSchemaLabel.Size = new System.Drawing.Size(46, 13);
			this.uiSchemaLabel.TabIndex = 0;
			this.uiSchemaLabel.Text = "Schema";
			// 
			// uiSchemaTextBox
			// 
			this.uiSchemaTextBox.Location = new System.Drawing.Point(61, 11);
			this.uiSchemaTextBox.Name = "uiSchemaTextBox";
			this.uiSchemaTextBox.Size = new System.Drawing.Size(98, 20);
			this.uiSchemaTextBox.TabIndex = 1;
			this.uiSchemaTextBox.Text = "loader";
			// 
			// uiStatusStrip
			// 
			this.uiStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiToolStripStatusLabel});
			this.uiStatusStrip.Location = new System.Drawing.Point(0, 654);
			this.uiStatusStrip.Name = "uiStatusStrip";
			this.uiStatusStrip.Size = new System.Drawing.Size(796, 22);
			this.uiStatusStrip.TabIndex = 2;
			this.uiStatusStrip.Text = "statusStrip1";
			// 
			// uiToolStripStatusLabel
			// 
			this.uiToolStripStatusLabel.Name = "uiToolStripStatusLabel";
			this.uiToolStripStatusLabel.Size = new System.Drawing.Size(38, 17);
			this.uiToolStripStatusLabel.Text = "Ready";
			// 
			// uiMainSplitContainer
			// 
			this.uiMainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiMainSplitContainer.Location = new System.Drawing.Point(0, 57);
			this.uiMainSplitContainer.Name = "uiMainSplitContainer";
			this.uiMainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiMainSplitContainer.Panel1
			// 
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiDisplayTextAsTableButton);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiWarningLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiValidateFirstXNumericUpDown);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiValidateFirstXLines);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiFileValidationLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiLinePanel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiIncludeSubDirectoriesCheckBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiStopButton);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiPatternTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiPatternLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiBrowseForDirectoryButton);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiDirectoryPathTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiDirectoryRadioButton);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiBrowseForFileButton);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiFilePathTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiFileRadioButton);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiTextRadioButton);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiRowValuesTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiValidateButton);
			// 
			// uiMainSplitContainer.Panel2
			// 
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiTabControl);
			this.uiMainSplitContainer.Size = new System.Drawing.Size(796, 597);
			this.uiMainSplitContainer.SplitterDistance = 195;
			this.uiMainSplitContainer.TabIndex = 1;
			// 
			// uiDisplayTextAsTableButton
			// 
			this.uiDisplayTextAsTableButton.Location = new System.Drawing.Point(8, 33);
			this.uiDisplayTextAsTableButton.Name = "uiDisplayTextAsTableButton";
			this.uiDisplayTextAsTableButton.Size = new System.Drawing.Size(103, 23);
			this.uiDisplayTextAsTableButton.TabIndex = 18;
			this.uiDisplayTextAsTableButton.Text = "Display Table";
			this.uiDisplayTextAsTableButton.UseVisualStyleBackColor = true;
			this.uiDisplayTextAsTableButton.Click += new System.EventHandler(this.uiDisplayTextAsTableButton_Click);
			// 
			// uiWarningLabel
			// 
			this.uiWarningLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiWarningLabel.AutoSize = true;
			this.uiWarningLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.uiWarningLabel.ForeColor = System.Drawing.Color.Red;
			this.uiWarningLabel.Location = new System.Drawing.Point(308, 102);
			this.uiWarningLabel.Name = "uiWarningLabel";
			this.uiWarningLabel.Size = new System.Drawing.Size(168, 13);
			this.uiWarningLabel.TabIndex = 6;
			this.uiWarningLabel.Text = "Recommended for large files";
			// 
			// uiValidateFirstXNumericUpDown
			// 
			this.uiValidateFirstXNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiValidateFirstXNumericUpDown.Location = new System.Drawing.Point(249, 98);
			this.uiValidateFirstXNumericUpDown.Name = "uiValidateFirstXNumericUpDown";
			this.uiValidateFirstXNumericUpDown.Size = new System.Drawing.Size(55, 20);
			this.uiValidateFirstXNumericUpDown.TabIndex = 5;
			this.uiValidateFirstXNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.uiValidateFirstXNumericUpDown.ThousandsSeparator = true;
			this.uiValidateFirstXNumericUpDown.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
			// 
			// uiValidateFirstXLines
			// 
			this.uiValidateFirstXLines.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiValidateFirstXLines.AutoSize = true;
			this.uiValidateFirstXLines.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.uiValidateFirstXLines.Checked = true;
			this.uiValidateFirstXLines.CheckState = System.Windows.Forms.CheckState.Checked;
			this.uiValidateFirstXLines.Location = new System.Drawing.Point(118, 101);
			this.uiValidateFirstXLines.Name = "uiValidateFirstXLines";
			this.uiValidateFirstXLines.Size = new System.Drawing.Size(128, 17);
			this.uiValidateFirstXLines.TabIndex = 4;
			this.uiValidateFirstXLines.Text = "Validate First [x] Lines";
			this.uiValidateFirstXLines.UseVisualStyleBackColor = true;
			// 
			// uiFileValidationLabel
			// 
			this.uiFileValidationLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiFileValidationLabel.AutoSize = true;
			this.uiFileValidationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.uiFileValidationLabel.Location = new System.Drawing.Point(5, 100);
			this.uiFileValidationLabel.Name = "uiFileValidationLabel";
			this.uiFileValidationLabel.Size = new System.Drawing.Size(72, 13);
			this.uiFileValidationLabel.TabIndex = 3;
			this.uiFileValidationLabel.Text = "File Validation";
			// 
			// uiLinePanel
			// 
			this.uiLinePanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiLinePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.uiLinePanel.Location = new System.Drawing.Point(6, 95);
			this.uiLinePanel.Name = "uiLinePanel";
			this.uiLinePanel.Size = new System.Drawing.Size(780, 1);
			this.uiLinePanel.TabIndex = 2;
			// 
			// uiIncludeSubDirectoriesCheckBox
			// 
			this.uiIncludeSubDirectoriesCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.uiIncludeSubDirectoriesCheckBox.AutoSize = true;
			this.uiIncludeSubDirectoriesCheckBox.Enabled = false;
			this.uiIncludeSubDirectoriesCheckBox.Location = new System.Drawing.Point(506, 149);
			this.uiIncludeSubDirectoriesCheckBox.Name = "uiIncludeSubDirectoriesCheckBox";
			this.uiIncludeSubDirectoriesCheckBox.Size = new System.Drawing.Size(136, 17);
			this.uiIncludeSubDirectoriesCheckBox.TabIndex = 13;
			this.uiIncludeSubDirectoriesCheckBox.Text = "Include Sub Directories";
			this.uiIncludeSubDirectoriesCheckBox.UseVisualStyleBackColor = true;
			// 
			// uiStopButton
			// 
			this.uiStopButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiStopButton.Location = new System.Drawing.Point(198, 169);
			this.uiStopButton.Name = "uiStopButton";
			this.uiStopButton.Size = new System.Drawing.Size(75, 23);
			this.uiStopButton.TabIndex = 17;
			this.uiStopButton.Text = "Stop";
			this.uiStopButton.UseVisualStyleBackColor = true;
			this.uiStopButton.Click += new System.EventHandler(this.uiStopButton_Click);
			// 
			// uiPatternTextBox
			// 
			this.uiPatternTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.uiPatternTextBox.Enabled = false;
			this.uiPatternTextBox.Location = new System.Drawing.Point(690, 147);
			this.uiPatternTextBox.Name = "uiPatternTextBox";
			this.uiPatternTextBox.Size = new System.Drawing.Size(100, 20);
			this.uiPatternTextBox.TabIndex = 15;
			// 
			// uiPatternLabel
			// 
			this.uiPatternLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.uiPatternLabel.AutoSize = true;
			this.uiPatternLabel.Location = new System.Drawing.Point(643, 151);
			this.uiPatternLabel.Name = "uiPatternLabel";
			this.uiPatternLabel.Size = new System.Drawing.Size(41, 13);
			this.uiPatternLabel.TabIndex = 14;
			this.uiPatternLabel.Text = "Pattern";
			// 
			// uiBrowseForDirectoryButton
			// 
			this.uiBrowseForDirectoryButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.uiBrowseForDirectoryButton.Enabled = false;
			this.uiBrowseForDirectoryButton.Location = new System.Drawing.Point(421, 145);
			this.uiBrowseForDirectoryButton.Name = "uiBrowseForDirectoryButton";
			this.uiBrowseForDirectoryButton.Size = new System.Drawing.Size(75, 23);
			this.uiBrowseForDirectoryButton.TabIndex = 12;
			this.uiBrowseForDirectoryButton.Text = "Browse";
			this.uiBrowseForDirectoryButton.UseVisualStyleBackColor = true;
			this.uiBrowseForDirectoryButton.Click += new System.EventHandler(this.uiBrowseForDirectoryButton_Click);
			// 
			// uiDirectoryPathTextBox
			// 
			this.uiDirectoryPathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiDirectoryPathTextBox.Enabled = false;
			this.uiDirectoryPathTextBox.Location = new System.Drawing.Point(117, 147);
			this.uiDirectoryPathTextBox.Name = "uiDirectoryPathTextBox";
			this.uiDirectoryPathTextBox.Size = new System.Drawing.Size(303, 20);
			this.uiDirectoryPathTextBox.TabIndex = 11;
			// 
			// uiDirectoryRadioButton
			// 
			this.uiDirectoryRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiDirectoryRadioButton.AutoSize = true;
			this.uiDirectoryRadioButton.Location = new System.Drawing.Point(7, 148);
			this.uiDirectoryRadioButton.Name = "uiDirectoryRadioButton";
			this.uiDirectoryRadioButton.Size = new System.Drawing.Size(108, 17);
			this.uiDirectoryRadioButton.TabIndex = 10;
			this.uiDirectoryRadioButton.Text = "Validate Directory";
			this.uiDirectoryRadioButton.UseVisualStyleBackColor = true;
			this.uiDirectoryRadioButton.CheckedChanged += new System.EventHandler(this.uiDirectoryRadioButton_CheckedChanged);
			// 
			// uiBrowseForFileButton
			// 
			this.uiBrowseForFileButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.uiBrowseForFileButton.Location = new System.Drawing.Point(715, 119);
			this.uiBrowseForFileButton.Name = "uiBrowseForFileButton";
			this.uiBrowseForFileButton.Size = new System.Drawing.Size(75, 23);
			this.uiBrowseForFileButton.TabIndex = 9;
			this.uiBrowseForFileButton.Text = "Browse";
			this.uiBrowseForFileButton.UseVisualStyleBackColor = true;
			this.uiBrowseForFileButton.Click += new System.EventHandler(this.uiBrowseForFileButton_Click);
			// 
			// uiFilePathTextBox
			// 
			this.uiFilePathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiFilePathTextBox.Location = new System.Drawing.Point(117, 121);
			this.uiFilePathTextBox.Name = "uiFilePathTextBox";
			this.uiFilePathTextBox.Size = new System.Drawing.Size(592, 20);
			this.uiFilePathTextBox.TabIndex = 8;
			// 
			// uiFileRadioButton
			// 
			this.uiFileRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiFileRadioButton.AutoSize = true;
			this.uiFileRadioButton.Checked = true;
			this.uiFileRadioButton.Location = new System.Drawing.Point(7, 122);
			this.uiFileRadioButton.Name = "uiFileRadioButton";
			this.uiFileRadioButton.Size = new System.Drawing.Size(82, 17);
			this.uiFileRadioButton.TabIndex = 7;
			this.uiFileRadioButton.TabStop = true;
			this.uiFileRadioButton.Text = "Validate File";
			this.uiFileRadioButton.UseVisualStyleBackColor = true;
			this.uiFileRadioButton.CheckedChanged += new System.EventHandler(this.uiFileRadioButton_CheckedChanged);
			// 
			// uiTextRadioButton
			// 
			this.uiTextRadioButton.AutoSize = true;
			this.uiTextRadioButton.Location = new System.Drawing.Point(7, 10);
			this.uiTextRadioButton.Name = "uiTextRadioButton";
			this.uiTextRadioButton.Size = new System.Drawing.Size(87, 17);
			this.uiTextRadioButton.TabIndex = 0;
			this.uiTextRadioButton.Text = "Validate Text";
			this.uiTextRadioButton.UseVisualStyleBackColor = true;
			this.uiTextRadioButton.CheckedChanged += new System.EventHandler(this.uiTextRadioButton_CheckedChanged);
			// 
			// uiTabControl
			// 
			this.uiTabControl.Alignment = System.Windows.Forms.TabAlignment.Bottom;
			this.uiTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiTabControl.Location = new System.Drawing.Point(0, 0);
			this.uiTabControl.Name = "uiTabControl";
			this.uiTabControl.SelectedIndex = 0;
			this.uiTabControl.Size = new System.Drawing.Size(796, 398);
			this.uiTabControl.TabIndex = 0;
			// 
			// uiTableDetailsGroupBox
			// 
			this.uiTableDetailsGroupBox.Controls.Add(this.uiReplaceSpaceWithUnderscoreCheckBox);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiDelimiterTextBox);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiFirstLineHasHeadersCheckBox);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiDelimiterLabel);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiMaximumNumberOfErrorsTextBox);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiMaximumNumberOfErrorsLabel);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiSchemaTextBox);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiSchemaLabel);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiTableNameTextBox);
			this.uiTableDetailsGroupBox.Controls.Add(this.uiTableNameLabel);
			this.uiTableDetailsGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
			this.uiTableDetailsGroupBox.Location = new System.Drawing.Point(0, 0);
			this.uiTableDetailsGroupBox.Name = "uiTableDetailsGroupBox";
			this.uiTableDetailsGroupBox.Size = new System.Drawing.Size(796, 57);
			this.uiTableDetailsGroupBox.TabIndex = 0;
			this.uiTableDetailsGroupBox.TabStop = false;
			// 
			// uiReplaceSpaceWithUnderscoreCheckBox
			// 
			this.uiReplaceSpaceWithUnderscoreCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiReplaceSpaceWithUnderscoreCheckBox.AutoSize = true;
			this.uiReplaceSpaceWithUnderscoreCheckBox.Location = new System.Drawing.Point(311, 37);
			this.uiReplaceSpaceWithUnderscoreCheckBox.Name = "uiReplaceSpaceWithUnderscoreCheckBox";
			this.uiReplaceSpaceWithUnderscoreCheckBox.Size = new System.Drawing.Size(176, 17);
			this.uiReplaceSpaceWithUnderscoreCheckBox.TabIndex = 9;
			this.uiReplaceSpaceWithUnderscoreCheckBox.Text = "Replace space with underscore";
			this.uiReplaceSpaceWithUnderscoreCheckBox.UseVisualStyleBackColor = true;
			// 
			// uiDelimiterTextBox
			// 
			this.uiDelimiterTextBox.Location = new System.Drawing.Point(61, 35);
			this.uiDelimiterTextBox.Name = "uiDelimiterTextBox";
			this.uiDelimiterTextBox.Size = new System.Drawing.Size(98, 20);
			this.uiDelimiterTextBox.TabIndex = 7;
			this.uiDelimiterTextBox.Text = "|";
			// 
			// uiFirstLineHasHeadersCheckBox
			// 
			this.uiFirstLineHasHeadersCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiFirstLineHasHeadersCheckBox.AutoSize = true;
			this.uiFirstLineHasHeadersCheckBox.Checked = true;
			this.uiFirstLineHasHeadersCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.uiFirstLineHasHeadersCheckBox.Location = new System.Drawing.Point(170, 38);
			this.uiFirstLineHasHeadersCheckBox.Name = "uiFirstLineHasHeadersCheckBox";
			this.uiFirstLineHasHeadersCheckBox.Size = new System.Drawing.Size(129, 17);
			this.uiFirstLineHasHeadersCheckBox.TabIndex = 8;
			this.uiFirstLineHasHeadersCheckBox.Text = "First Line has headers";
			this.uiFirstLineHasHeadersCheckBox.UseVisualStyleBackColor = true;
			this.uiFirstLineHasHeadersCheckBox.CheckedChanged += new System.EventHandler(this.uiFirstLineHasHeadersCheckBox_CheckedChanged);
			// 
			// uiDelimiterLabel
			// 
			this.uiDelimiterLabel.AutoSize = true;
			this.uiDelimiterLabel.Location = new System.Drawing.Point(9, 39);
			this.uiDelimiterLabel.Name = "uiDelimiterLabel";
			this.uiDelimiterLabel.Size = new System.Drawing.Size(47, 13);
			this.uiDelimiterLabel.TabIndex = 6;
			this.uiDelimiterLabel.Text = "Delimiter";
			// 
			// uiMaximumNumberOfErrorsTextBox
			// 
			this.uiMaximumNumberOfErrorsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.uiMaximumNumberOfErrorsTextBox.Location = new System.Drawing.Point(715, 12);
			this.uiMaximumNumberOfErrorsTextBox.Name = "uiMaximumNumberOfErrorsTextBox";
			this.uiMaximumNumberOfErrorsTextBox.Size = new System.Drawing.Size(75, 20);
			this.uiMaximumNumberOfErrorsTextBox.TabIndex = 5;
			this.uiMaximumNumberOfErrorsTextBox.Text = "50";
			this.uiMaximumNumberOfErrorsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// uiMaximumNumberOfErrorsLabel
			// 
			this.uiMaximumNumberOfErrorsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.uiMaximumNumberOfErrorsLabel.AutoSize = true;
			this.uiMaximumNumberOfErrorsLabel.Location = new System.Drawing.Point(576, 15);
			this.uiMaximumNumberOfErrorsLabel.Name = "uiMaximumNumberOfErrorsLabel";
			this.uiMaximumNumberOfErrorsLabel.Size = new System.Drawing.Size(133, 13);
			this.uiMaximumNumberOfErrorsLabel.TabIndex = 4;
			this.uiMaximumNumberOfErrorsLabel.Text = "Maximum Number of Errors";
			// 
			// uiOpenFileDialog
			// 
			this.uiOpenFileDialog.Title = "Locate File to Validate";
			// 
			// uiFolderBrowserDialog
			// 
			this.uiFolderBrowserDialog.Description = "Select the Folder to locate files within";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(796, 676);
			this.Controls.Add(this.uiMainSplitContainer);
			this.Controls.Add(this.uiStatusStrip);
			this.Controls.Add(this.uiTableDetailsGroupBox);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Import File Validator";
			this.uiStatusStrip.ResumeLayout(false);
			this.uiStatusStrip.PerformLayout();
			this.uiMainSplitContainer.Panel1.ResumeLayout(false);
			this.uiMainSplitContainer.Panel1.PerformLayout();
			this.uiMainSplitContainer.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).EndInit();
			this.uiMainSplitContainer.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.uiValidateFirstXNumericUpDown)).EndInit();
			this.uiTableDetailsGroupBox.ResumeLayout(false);
			this.uiTableDetailsGroupBox.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button uiValidateButton;
		private System.Windows.Forms.TextBox uiTableNameTextBox;
		private System.Windows.Forms.Label uiTableNameLabel;
		private System.Windows.Forms.TextBox uiRowValuesTextBox;
		private System.Windows.Forms.Label uiSchemaLabel;
		private System.Windows.Forms.TextBox uiSchemaTextBox;
		private System.Windows.Forms.StatusStrip uiStatusStrip;
		private System.Windows.Forms.ToolStripStatusLabel uiToolStripStatusLabel;
		private System.Windows.Forms.SplitContainer uiMainSplitContainer;
		private System.Windows.Forms.RadioButton uiFileRadioButton;
		private System.Windows.Forms.RadioButton uiTextRadioButton;
		private System.Windows.Forms.GroupBox uiTableDetailsGroupBox;
		private System.Windows.Forms.TextBox uiFilePathTextBox;
		private System.Windows.Forms.Button uiBrowseForFileButton;
		private System.Windows.Forms.OpenFileDialog uiOpenFileDialog;
		private System.Windows.Forms.TextBox uiMaximumNumberOfErrorsTextBox;
		private System.Windows.Forms.Label uiMaximumNumberOfErrorsLabel;
		private System.Windows.Forms.TextBox uiDelimiterTextBox;
		private System.Windows.Forms.Label uiDelimiterLabel;
		private System.Windows.Forms.TabControl uiTabControl;
		private System.Windows.Forms.TextBox uiPatternTextBox;
		private System.Windows.Forms.Label uiPatternLabel;
		private System.Windows.Forms.Button uiBrowseForDirectoryButton;
		private System.Windows.Forms.TextBox uiDirectoryPathTextBox;
		private System.Windows.Forms.RadioButton uiDirectoryRadioButton;
		private System.Windows.Forms.FolderBrowserDialog uiFolderBrowserDialog;
		private System.Windows.Forms.Button uiStopButton;
		private System.Windows.Forms.CheckBox uiIncludeSubDirectoriesCheckBox;
		private System.Windows.Forms.CheckBox uiFirstLineHasHeadersCheckBox;
		private System.Windows.Forms.NumericUpDown uiValidateFirstXNumericUpDown;
		private System.Windows.Forms.CheckBox uiValidateFirstXLines;
		private System.Windows.Forms.Label uiFileValidationLabel;
		private System.Windows.Forms.Panel uiLinePanel;
		private System.Windows.Forms.Label uiWarningLabel;
		private System.Windows.Forms.Button uiDisplayTextAsTableButton;
		private System.Windows.Forms.CheckBox uiReplaceSpaceWithUnderscoreCheckBox;
	}
}

