﻿using System.Data;

namespace ImportFileValidator
{
	/// <summary>
	/// Helper Class used to create DataTables
	/// </summary>
	internal static class DataTableCreator
	{
		/// <summary>
		/// Creates a DataTable from an array of strings
		/// </summary>
		/// <param name="lines">Array of strings</param>
		/// <param name="delimiter">Delimiter to use when splitting the string</param>
		/// <param name="firstLineIsHeaders">Flag indicating whether the first line contains the headers</param>
		/// <returns>DataTable</returns>
		public static DataTable CreateDataTable(string[] lines, string delimiter, bool firstLineIsHeaders)
		{
			DataTable dataTable = new DataTable();
			int dataStartIndex = 0;
			if (firstLineIsHeaders)
			{
				dataStartIndex = 1;
			}
			string[] temp = lines[0].Split(delimiter.ToCharArray());
			for (int i = 0; i < temp.Length; i++)
			{
				DataColumn column = dataTable.Columns.Add();
				if (firstLineIsHeaders)
				{
					column.ColumnName = temp[i];
				}
			}

			for (int i = dataStartIndex; i < lines.Length; i++)
			{
				if (!string.IsNullOrWhiteSpace(lines[i]))
				{
					string[] x = lines[i].Split(delimiter.ToCharArray());
					dataTable.Rows.Add(x);
				}
			}
			return dataTable;
		}
	}
}