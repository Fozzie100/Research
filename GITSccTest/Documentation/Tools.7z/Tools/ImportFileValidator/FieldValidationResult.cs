﻿using System.Collections.Generic;

namespace ImportFileValidator
{
	/// <summary>
	/// Validation result returned from Validation Methods
	/// </summary>
	internal class FieldValidationResult
	{
		#region Private Instance Fields
		private List<string> _errors = new List<string>();
		#endregion

		#region Public Properties
		/// <summary>
		/// Flag determining whether the Field was valid
		/// </summary>
		public bool IsValid { get; private set; }
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new instance of FieldValidationResult
		/// </summary>
		public FieldValidationResult()
		{
			IsValid = true;
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Adds an error to the Validation Result and sets the Valid flag to false
		/// </summary>
		/// <param name="message">Error message to add</param>
		public void AddError(string message)
		{
			IsValid = false;
			_errors.Add(message);
		}

		/// <summary>
		/// Returns the string representation of this object
		/// </summary>
		public override string ToString()
		{
			return string.Join(" - ", _errors.ToArray());
		}
		#endregion
	}
}