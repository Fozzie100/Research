﻿namespace ImportFileValidator.FieldValidation
{
	/// <summary>
	/// Validation class used to validate Decimal fields
	/// </summary>
	internal class DecimalValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a decimal column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty");
			}

			if (!string.IsNullOrWhiteSpace(value))
			{
				decimal checkValue;
				bool isValidNumber = decimal.TryParse(value, out checkValue);
				if (!isValidNumber)
				{
					result.AddError("Unable to parse value to decimal");
					isValidNumber = false;
				}
				else
				{
					int decimalPointLocation = value.IndexOf('.');
					string decimalPart = string.Empty;
					if (decimalPointLocation > -1)
					{
						decimalPart = value.Substring(decimalPointLocation + 1);
					}
					if (decimalPart.Length > columnDefinition.NumericScale)
					{
						result.AddError("Value after decimal place too large");
					}
					string wholeNumberPart = value;
					if (decimalPointLocation > -1)
					{
						wholeNumberPart = value.Substring(0, decimalPointLocation);
					}
					if (wholeNumberPart.Length > (columnDefinition.NumericPrecision - columnDefinition.NumericScale))
					{
						result.AddError("whole number part of value will not fit");
					}
				}
			}
			return result;
		}

	}
}