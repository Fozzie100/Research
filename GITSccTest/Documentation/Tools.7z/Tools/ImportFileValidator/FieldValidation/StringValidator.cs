﻿using Ftse.Research.Framework;

namespace ImportFileValidator.FieldValidation
{
	/// <summary>
	/// Class used to validate strings
	/// </summary>
	internal class StringValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a string column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty");
			}
			else
			{
				if (columnDefinition.CharacterMaximumLength > -1) //varchar max fields are given to us as -1 length by information schema, so assume all will fit here
				{
					if (value.Length > columnDefinition.CharacterMaximumLength)
					{
						result.AddError("Value is too large to fit: Value Length - " + value.Length + " - FieldSize - " + columnDefinition.CharacterMaximumLength);
					}
				}
			}
			return result;
		}
	}
}