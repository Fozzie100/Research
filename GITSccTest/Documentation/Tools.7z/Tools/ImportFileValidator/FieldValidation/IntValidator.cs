﻿namespace ImportFileValidator.FieldValidation
{
	/// <summary>
	/// Validation class used to validate Int fields
	/// </summary>
	internal class IntValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into an int column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			const int SqlIntMaxValue = 2147483647;
			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty");
			}
			try
			{
				//only do the tests if its not blank and not nullable
				if (!string.IsNullOrWhiteSpace(value))
				{
					int testValue;
					bool valid = int.TryParse(value, out testValue);
					if (valid)
					{
						if (testValue > SqlIntMaxValue)
						{
							result.AddError("Value is bigger than maximum allowed for int");
						}
					}
					else
					{
						result.AddError("Unable to parse value to int");
					}
				}
			}
			catch
			{
				result.AddError("Unable to parse value to int");
			}
			return result;
		}
	}
}