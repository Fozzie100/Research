﻿namespace ImportFileValidator.FieldValidation
{
	/// <summary>
	/// Validator used to validate Floats
	/// </summary>
	internal class FloatValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a float column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty");
			}

			if (!string.IsNullOrWhiteSpace(value))
			{
				decimal checkValue;
				bool isValidNumber = decimal.TryParse(value, out checkValue);
				if (!isValidNumber)
				{
					result.AddError("Unable to parse value to decimal");
					isValidNumber = false;
				}
			}
			return result;
		}
	}
}