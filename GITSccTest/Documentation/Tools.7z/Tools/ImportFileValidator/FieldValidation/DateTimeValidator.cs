﻿using System;
using System.Globalization;

namespace ImportFileValidator.FieldValidation
{
	/// <summary>
	/// Validation class used to validate DateTime fields
	/// </summary>
	internal class DateTimeValidator : IFieldValidator
	{
		/// <summary>
		/// Validates a field to check it should fit into a datetime column
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		/// <returns>FieldValidationResult</returns>
		public FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition)
		{
			const string TimeDelimiter = ":";

			FieldValidationResult result = new FieldValidationResult();

			if ((!columnDefinition.IsNullable) && (string.IsNullOrWhiteSpace(value)))
			{
				result.AddError("Field is not nullable and value is empty");
			}
			if (!string.IsNullOrWhiteSpace(value))
			{
				if ((value.IndexOf(TimeDelimiter) > 0) && (value.Length == 8))
				{
					result.AddError("Value appears to be a time only");
				}
				else
				{
					DateTime outValue;
					if (!DateTime.TryParse(value, out outValue))
					{
						if (!DateTime.TryParseExact(value, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out outValue))
						{
							result.AddError("Unable to parse value to date time");
						}
					}
				}
			}
			return result;
		}

	}
}