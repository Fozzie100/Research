﻿using System.Data;

namespace ImportFileValidator
{
	/// <summary>
	/// Interface defining methods Field Validators must implement
	/// </summary>
	interface IFieldValidator
	{
		/// <summary>
		/// Validates a field
		/// </summary>
		/// <param name="value">Value to validate</param>
		/// <param name="columnDefinition">DataColumnDefinition defining the column</param>
		FieldValidationResult ValidateField(string value, DataColumnDefinition columnDefinition);
	}
}