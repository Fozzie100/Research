﻿using System;
using System.Linq;
using System.Windows.Forms;
using BloombergTableGenerator.ScriptGeneration;

namespace BloombergTableGenerator
{
	public partial class AddFieldsToTableForm : Form
	{
		public AddFieldsToTableForm()
		{
			InitializeComponent();
		}

		private void uiGenerateToolStripButton_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(uiFieldListTextBox.Text))
			{
				return;
			}

			//Get the list of fields
			string[] fields = uiFieldListTextBox.Text.Split(Environment.NewLine.ToCharArray());
			fields = (from string path in fields
						 where !string.IsNullOrWhiteSpace(path)
						 select path).ToArray();

			AlterTableScriptGenerator generator = new AlterTableScriptGenerator(uiTableNameToolStripTextBox.Text);
			using (PrimeEntities entities = new PrimeEntities())
			{
				foreach (string field in fields)
				{
					string fieldName = field.Trim();
					BloombergField columnDefinition = (
						from BloombergField column in entities.BloombergFields
						where column.FieldName == fieldName
						select column).FirstOrDefault();
					if (columnDefinition != null)
					{
						generator.AddColumn(columnDefinition.FieldName.ToLower() + " " + columnDefinition.DataType);
					}
					else
					{
						generator.AddColumn("---------------" + fieldName + "----------------------COLUMN NOT FOUND");
					}
				}
				uiScriptTextBox.Text = generator.ToString();
			}

			/*
			using (PrimeEntities entities = new PrimeEntities())
			{
				for (int i = 0; i < fields.Length; i++)
				{
					string field = fields[i];

					if (!string.IsNullOrWhiteSpace(field))
					{
						field = field.Trim();
						BloombergField columnDefinition =
							(from BloombergField column in entities.BloombergFields
							 where column.FieldName == field
							 select column).FirstOrDefault();
						if (columnDefinition != null)
						{
							schemaGenerator.AddColumn(columnDefinition.FieldName + " " + columnDefinition.DataType);
						}
						else
						{
							schemaGenerator.AddColumn("---------------" + field + "----------------------COLUMN NOT FOUND");
						}
					}
				}
				uiScriptTextBox.Text = schemaGenerator.ToString();
			}
			 */

		}
	}
}