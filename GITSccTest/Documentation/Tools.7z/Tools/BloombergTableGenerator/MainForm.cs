﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using BloombergTableGenerator.ScriptGeneration;

namespace BloombergTableGenerator
{
	/// <summary>
	/// Main Application Form
	/// </summary>
	public partial class MainForm : Form
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of MainForm
		/// </summary>
		public MainForm()
		{
			InitializeComponent();
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the Generate ToolStripButton is clicked
		/// </summary>
		/// <param name="sender">ToolStripButton raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiGenerateToolStripButton_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(uiFieldListTextBox.Text))
			{
				return;
			}

			int numberOfParts = uiTableNameToolStripTextBox.Text.Count(c => c == '.');
			if (numberOfParts != 1)
			{
				MessageBox.Show(this, "Table name should be in form SCHEMA.TABLE", "Please correct table name");
				return;
			}

			TableScriptGenerator generator = new TableScriptGenerator(uiTableNameToolStripTextBox.Text);
			GenerationSettings settings = new GenerationSettings();
			settings.GenerateVarCharColumns = uiGenerateVarcharToolStripButton.Checked;
			settings.UpdateValues(uiStartingFromToolStripTextBox.Text, uiUpToToolStripTextBox.Text);

			Cursor.Current = Cursors.WaitCursor;
			try
			{
				string[] fields = uiFieldListTextBox.Text.Split(Environment.NewLine.ToCharArray());
				fields = (from string path in fields
						  where !string.IsNullOrWhiteSpace(path)
						  select path).ToArray();

				uiToolStripStatusLabel.Text = "Generating Scripts Please Wait...";
				Application.DoEvents();

				List<string> columns = new List<string>();
				using (PrimeEntities entities = new PrimeEntities())
				{
					for (int i = 0; i < fields.Length; i++)
					{
						string field = fields[i];

						BloombergField columnDefinition =
							(from BloombergField column in entities.BloombergFields
							 where column.FieldName == field
							 select column).FirstOrDefault();
						if (columnDefinition != null)
						{
							generator.AddColumn(columnDefinition.FieldName.ToLower() + " " + GetDataType(i, columnDefinition.DataType, settings));
						}
						else
						{
							generator.AddColumn("---------------" + field.ToLower() + "----------------------COLUMN NOT FOUND");
						}
					}
				}
				uiScriptTextBox.Text = generator.ToString();
			}
			finally
			{
				Cursor.Current = Cursors.Default;
				uiToolStripStatusLabel.Text = "Ready";
			}
		}
		#endregion

		private string GetDataType(int columnIndex, string dataType, GenerationSettings settings)
		{
			if (settings.GenerateVarCharColumns)
			{
				if ((columnIndex >= settings.StartIndex) && (columnIndex <= settings.EndIndex))
				{
					return "VARCHAR(MAX)";
				}
				else
				{
					return dataType;
				}
			}
			else
			{
				return dataType;
			}
		}

		private void uiAdvancedOptionsToolStripButton_Click(object sender, EventArgs e)
		{
			uiAdvancedOptionsToolStrip.Visible = uiAdvancedOptionsToolStripButton.Checked;
		}

		private void uiGenerateVarcharToolStripButton_Click(object sender, EventArgs e)
		{
			uiGenerateVarcharToolStripButton.Image = uiGenerateVarcharToolStripButton.Checked ? uiImageList.Images["CheckBoxChecked.png"] : uiImageList.Images["CheckBoxUnChecked.png"];
		}

		private string[] GetFilePaths()
		{
			string[] filePaths = uiFilePathsTextBox.Text.Split(Environment.NewLine.ToCharArray());
			filePaths = (from string path in filePaths
						 where !string.IsNullOrWhiteSpace(path)
						 select path).ToArray();

			uiToolStripStatusLabel.Text = "Reading Field Names Please Wait...";
			Application.DoEvents();
			foreach (string filePath in filePaths)
			{
				if (!File.Exists(filePath))
				{
					uiScriptTextBox.Text = filePath + " not found";
					Cursor.Current = Cursors.Default;
					uiToolStripStatusLabel.Text = "Ready";
					return null;
				}
			}
			return filePaths;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string[] filePaths = GetFilePaths();
			if (filePaths == null)
			{
				return;
			}
			List<string> allFields = BloombergFieldReader.GetFieldNames(filePaths);
			uiFieldListTextBox.Text = string.Join(Environment.NewLine, allFields.ToArray());
		}
	}
}