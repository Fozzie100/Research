﻿using BloombergTableGenerator.ScriptGeneration.Base;

namespace BloombergTableGenerator.ScriptGeneration
{
	/// <summary>
	/// Generator used to generate scripts for Loader Schema
	/// </summary>
	internal class CreateLoaderScriptGenerator : CreateTableScriptGeneratorBase
	{
		#region Constructors 
		/// <summary>
		/// Creates a new instance of LoaderScriptGenerator
		/// </summary>
		/// <param name="tableName">Name of the table</param>
		public CreateLoaderScriptGenerator(string tableName) : base(tableName)
		{
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Returns the list of additional columns to add to the script
		/// </summary>
		protected override string[] AdditionalColumnDefinitions
		{
			get
			{
				return new string[] { "IDENT VARCHAR(32)", "CODE INT", "NO_OF_FIELDS INT" };
			}
		}

		/// <summary>
		/// Name of the schema to create script for
		/// </summary>
		protected string SchemaName
		{
			get { return "LOADER"; }
		}

		/// <summary>
		/// Flag indicating whether to generate the placeholder for a primary key
		/// </summary>
		protected override bool ScriptRequiresPrimaryKey
		{
			get { return false; }
		}
		#endregion

		protected override bool AddTrackingColumns
		{
			get { return false; }
		}

	}
}