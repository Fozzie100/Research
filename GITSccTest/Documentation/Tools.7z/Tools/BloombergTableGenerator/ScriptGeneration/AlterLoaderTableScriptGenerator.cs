﻿using BloombergTableGenerator.ScriptGeneration.Base;

namespace BloombergTableGenerator.ScriptGeneration
{
	/// <summary>
	/// Generator used to generate alter table scripts for Loader Schema
	/// </summary>
	internal class AlterLoaderTableScriptGenerator : AlterTableScriptGeneratorBase
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of AlterLoaderTableScriptGenerator
		/// </summary>
		/// <param name="tableName">Name of the table</param>
		public AlterLoaderTableScriptGenerator(string tableName) : base(tableName)
		{
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Name of the schema to create script for
		/// </summary>
		protected override string SchemaName
		{
			get { return "LOADER"; }
		}
		#endregion
	}
}