﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BloombergTableGenerator.ScriptGeneration.Base
{
	/// <summary>
	/// Base class for created alter scripts for tables
	/// </summary>
	public abstract class AlterTableScriptGeneratorBase : ScriptGeneratorBase
	{
		#region Properties
		/// <summary>
		/// List of columns on the table
		/// </summary>
		public List<string> ExistingColumns { get; private set; }
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new instance of AlterTableScriptGeneratorBase
		/// </summary>
		/// <param name="tableName">Table Name to alter</param>
		public AlterTableScriptGeneratorBase(string tableName) : base(tableName)
		{
			ExistingColumns = new List<string>();
			LoadTableSchema();
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Creates a script representation of this object
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			if (Columns.Count == 0)
			{
				return "NO NEW COLUMNS REQUIRED";
			}
			else
			{
				List<string> textLines = new List<string>();
				textLines.Add("ALTER TABLE [" + SchemaName + "].[" + this.TableName + "]");
				textLines.Add("(");
				textLines.Add("ADD");
				textLines.Add(string.Join("," + Environment.NewLine, Columns.ToArray()));
				textLines.Add(")");
				textLines.Add("GO");
				textLines.Add(string.Empty);
				textLines.Add("PRINT '<<< ALTERED TABLE [" + SchemaName + "].[" + this.TableName + "] >>>'");
				textLines.Add("GO");
				return string.Join(Environment.NewLine, textLines.ToArray());
			}
		}
		#endregion

		public override void AddColumn(string columnDefinition)
		{
			string columnNameToCheck = columnDefinition.ToLower().Split(' ')[0];
			if (!ExistingColumns.Contains(columnNameToCheck))
			{
				base.AddColumn(columnDefinition);
			}
		}

		/// <summary>
		/// Load the schema of the existing table
		/// </summary>
		private void LoadTableSchema()
		{
			string sqlStatement = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@SchemaName AND TABLE_NAME = @TableName";
			using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Prime"].ConnectionString))
			{
				connection.Open();
				using (SqlCommand command = connection.CreateCommand())
				{
					command.CommandText = sqlStatement;
					command.CommandType = CommandType.Text;
					command.Parameters.AddWithValue("@SchemaName", this.SchemaName);
					command.Parameters.AddWithValue("@TableName", this.TableName);
					using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
					{
						while (reader.Read())
						{
							ExistingColumns.Add(reader["COLUMN_NAME"].ToString().ToLower());
						}
						reader.Close();
					}
				}
			}
		}
	}
}
