﻿using System;
using System.Collections.Generic;

namespace BloombergTableGenerator.ScriptGeneration.Base
{
	public abstract class CreateTableScriptGeneratorBase : ScriptGeneratorBase
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of CreateTableScriptGeneratorBase
		/// </summary>
		/// <param name="tableName">Name of the table</param>
		public CreateTableScriptGeneratorBase(string tableName) : base(tableName)
		{

		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Creates a script representation of this object
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			List<string> textLines = new List<string>();
			textLines.Add("IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[" + SchemaName + "].[" + this.TableName + "]') AND type in (N'U'))");
			textLines.Add("BEGIN");
			textLines.Add("\tDROP TABLE [" + SchemaName + "].[" + this.TableName + "]");
			textLines.Add("\tPRINT '<<< DROPPED TABLE [" + SchemaName + "].[" + this.TableName + "] >>>'");
			textLines.Add("END");
			textLines.Add("GO");
			textLines.Add(string.Empty);
			textLines.Add("CREATE TABLE [" + SchemaName + "].[" + this.TableName + "]");
			textLines.Add("(");
			foreach (string additionalColumn in AdditionalColumnDefinitions)
			{
				textLines.Add(string.Concat("\t", additionalColumn, ","));
			}
			textLines.Add(string.Join("," + Environment.NewLine, Columns.ToArray()));
			if (this.AddTrackingColumns)
			{
				textLines[textLines.Count - 1] = string.Concat(textLines[textLines.Count - 1], ",");
				textLines.Add(string.Concat("\t", "last_updt_user_nm varchar(30) not null constraint ", this.TableName, "_last_updt_user_nm default suser_name(),"));
				textLines.Add(string.Concat("\t", "last_updt_dtime datetime not null constraint ", this.TableName, "_last_updt_dtime default getdate(),"));
				textLines.Add(string.Concat("\t", "created_date_time datetime not null constraint ", this.TableName, "_created_date_time default getdate()"));
			}
			textLines.Add(")");
			textLines.Add("GO");
			textLines.Add(string.Empty);
			if (ScriptRequiresPrimaryKey)
			{
				textLines.Add("ALTER TABLE [" + SchemaName + "].[" + this.TableName + "]");
				textLines.Add("ADD CONSTRAINT [pk_" + this.TableName + "] PRIMARY KEY CLUSTERED");
				textLines.Add("(");
				textLines.Add("--------------DEFINE PRIMARY KEY COLUMNS HERE----------------");
				textLines.Add(")");
				textLines.Add("GO");
				textLines.Add(string.Empty);
			}
			textLines.Add("IF OBJECT_ID('[" + SchemaName + "].[" + this.TableName + "]') IS NOT NULL");
			textLines.Add("\tPRINT '<<< CREATED TABLE [" + SchemaName + "].[" + this.TableName + "] >>>'");
			textLines.Add("ELSE");
			textLines.Add("\tPRINT '<<< FAILED CREATING TABLE [" + SchemaName + "].[" + this.TableName + "] >>>'");
			textLines.Add("GO");
			return string.Join(Environment.NewLine, textLines.ToArray());
		}
		#endregion

		#region Protected Properties
		/// <summary>
		/// Flag indicating whether to generate the placeholder for a primary key
		/// </summary>
		protected abstract bool ScriptRequiresPrimaryKey { get; }
		/// <summary>
		/// Flag indicating whether to generate tracking columns
		/// </summary>
		protected abstract bool AddTrackingColumns { get; }
		/// <summary>
		/// Sting array of additonal column definitions to add to the file
		/// </summary>
		protected abstract string[] AdditionalColumnDefinitions { get; }
		#endregion
	}
}