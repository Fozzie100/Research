﻿using System.Collections.Generic;

namespace BloombergTableGenerator.ScriptGeneration.Base
{
	/// <summary>
	/// Base class for script generators
	/// </summary>
	public abstract class ScriptGeneratorBase
	{
		#region Private Instance Fields
		private List<string> _columns;
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new instance of ScriptGeneratorBase
		/// </summary>
		/// <param name="tableName">Name of the table to generate a script for</param>
		public ScriptGeneratorBase(string tableName)
		{
			//todo validate
			string[] tableNameParts = tableName.Split('.');
			this.SchemaName = tableNameParts[0];
			this.TableName = tableNameParts[1];
			_columns = new List<string>();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Name of the Table
		/// </summary>
		public string TableName { get; private set; }

		/// <summary>
		/// Name of the Schema
		/// </summary>
		public string SchemaName { get; private set; }

		/// <summary>
		/// List of column names
		/// </summary>
		public List<string> Columns
		{
			get { return _columns; }
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Adds a column definition to this object
		/// </summary>
		/// <param name="columnDefinition">columnDefinition to add</param>
		public virtual void AddColumn(string columnDefinition)
		{
			_columns.Add(string.Concat("\t", columnDefinition));
		}
		#endregion
	}
}