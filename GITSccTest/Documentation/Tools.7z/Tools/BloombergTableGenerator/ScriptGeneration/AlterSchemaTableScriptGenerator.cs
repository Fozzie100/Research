﻿using BloombergTableGenerator.ScriptGeneration.Base;

namespace BloombergTableGenerator.ScriptGeneration
{
	public class AlterSchemaTableScriptGenerator : AlterTableScriptGeneratorBase
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of AlterSchemaTableScriptGenerator
		/// </summary>
		/// <param name="tableName">Name of the table</param>
		public AlterSchemaTableScriptGenerator(string tableName) : base(tableName)
		{

		}
		#endregion

		#region Overridden Properties
		/// <summary>
		/// Schema Name to alter table within
		/// </summary>
		protected override string SchemaName
		{
			get { return "BLOOMBERG"; }
		}
		#endregion
	}
}