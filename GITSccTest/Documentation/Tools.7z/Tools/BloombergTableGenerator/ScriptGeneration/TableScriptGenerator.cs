﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace BloombergTableGenerator.ScriptGeneration
{
	/// <summary>
	/// Generator for creating script statements
	/// </summary>
	internal class TableScriptGenerator
	{
		#region Private Instance Fields
		private List<string> _columns;
		#endregion

		internal enum ScriptMode
		{
			Create,
			Alter
		}

		private bool _isLoaderTable;

		public ScriptMode Mode { get; set; }
		#region Properties
		/// <summary>
		/// List of columns on the table
		/// </summary>
		public List<string> ExistingColumns { get; private set; }
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new instance of AlterTableScriptGeneratorBase
		/// </summary>
		/// <param name="tableName">Table Name to alter</param>
		public TableScriptGenerator(string tableName)
		{
			string[] tableNameParts = tableName.Split('.');
			this.SchemaName = tableNameParts[0].ToUpper();
			this.TableName = tableNameParts[1].ToLower();
			_columns = new List<string>();

			this.Mode = ScriptMode.Create;
			ExistingColumns = new List<string>();
			LoadTableSchema();
			if (this.Mode == ScriptMode.Create)
			{
				if (string.Compare(this.SchemaName, "loader", true) == 0)
				{
					_isLoaderTable = true;
					Columns.Add("\tident VARCHAR(32)");
					Columns.Add("\tcode INT");
					Columns.Add("\tno_of_fields INT");
				}
				else
				{
					Columns.Add("\tident VARCHAR(32)");
				}
			}
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Creates a script representation of this object
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			if (Columns.Count == 0)
			{
				return "NO NEW COLUMNS REQUIRED";
			}
			else
			{
				List<string> textLines = new List<string>();
				string statementType = this.Mode == ScriptMode.Create ? "CREATE" : "ALTER";
				string action = this.Mode == ScriptMode.Create ? "CREATED" : "ALTERED";
				textLines.Add(statementType + " TABLE [" + SchemaName + "].[" + this.TableName + "]");
				textLines.Add("ADD");
				textLines.Add(string.Join("," + Environment.NewLine, Columns.ToArray()));
				if (this.Mode == ScriptMode.Create && (!_isLoaderTable))
				{
					//add tracking columns
					textLines[textLines.Count - 1] = string.Concat(textLines[textLines.Count - 1], ",");
					textLines.Add(string.Concat("\t", "last_updt_user_nm VARCHAR(30) NOT NULL CONSTRAINT DF_", this.TableName, "_last_updt_user_nm default suser_name(),"));
					textLines.Add(string.Concat("\t", "last_updt_dtime DATETIME NOT NULL CONSTRAINT DF_", this.TableName, "_last_updt_dtime default getdate(),"));
					textLines.Add(string.Concat("\t", "created_date_time DATETIME NOT NULL CONSTRAINT DF_", this.TableName, "_created_date_time default getdate()"));
				}
				textLines.Add("GO");
				textLines.Add(string.Empty);
				textLines.Add("PRINT '<<< " + action + " TABLE [" + SchemaName + "].[" + this.TableName + "] >>>'");
				textLines.Add("GO");
				return string.Join(Environment.NewLine, textLines.ToArray());
			}
		}
		#endregion

		public void AddColumn(string columnDefinition)
		{
			string columnNameToCheck = columnDefinition.ToLower().Split(' ')[0];
			if (!ExistingColumns.Contains(columnNameToCheck))
			{
				_columns.Add(string.Concat("\t", columnDefinition));
			}
		}

		/// <summary>
		/// Load the schema of the existing table
		/// </summary>
		private void LoadTableSchema()
		{
			string sqlStatement = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@SchemaName AND TABLE_NAME = @TableName";
			using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Prime"].ConnectionString))
			{
				connection.Open();
				using (SqlCommand command = connection.CreateCommand())
				{
					command.CommandText = sqlStatement;
					command.CommandType = CommandType.Text;
					command.Parameters.AddWithValue("@SchemaName", this.SchemaName);
					command.Parameters.AddWithValue("@TableName", this.TableName);
					using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
					{
						while (reader.Read())
						{
							this.Mode = ScriptMode.Alter; //if we have found a column then its an alter
							ExistingColumns.Add(reader["COLUMN_NAME"].ToString().ToLower());
						}
						reader.Close();
					}
				}
			}
		}

		#region Properties
		/// <summary>
		/// Name of the Table
		/// </summary>
		public string TableName { get; private set; }

		/// <summary>
		/// Name of the Schema
		/// </summary>
		public string SchemaName { get; private set; }

		/// <summary>
		/// List of column names
		/// </summary>
		public List<string> Columns
		{
			get { return _columns; }
		}
		#endregion
	}
}
