﻿using BloombergTableGenerator.ScriptGeneration.Base;

namespace BloombergTableGenerator.ScriptGeneration
{
	/// <summary>
	/// Generator used to generate scripts for Bloomberg Schema
	/// </summary>
	internal class CreateSchemaScriptGenerator : CreateTableScriptGeneratorBase
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of SchemaScriptGenerator
		/// </summary>
		/// <param name="tableName">Name of the table</param>
		public CreateSchemaScriptGenerator(string tableName) : base(tableName)
		{
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Adds a column to this object
		/// </summary>
		/// <param name="columnDefinition">column definition to add</param>
		public override void AddColumn(string columnDefinition)
		{
			base.AddColumn(columnDefinition.ToLower());
		}
		#endregion

		#region Properties
		/// <summary>
		/// Flag indicating whether to generate the placeholder for a primary key
		/// </summary>
		protected override bool ScriptRequiresPrimaryKey
		{
			get { return true; }
		}

		/// <summary>
		/// Flag indicating whether to add tracking columns
		/// </summary>
		protected override bool AddTrackingColumns
		{
			get { return true; }
		}

		/// <summary>
		/// Returns the list of additional columns to add to the script
		/// </summary>
		protected override string[] AdditionalColumnDefinitions
		{
			get
			{
				return new string[] { "ident VARCHAR(32)" };
			}
		}

		/// <summary>
		/// Name of the schema to create script for
		/// </summary>
		protected string SchemaName
		{
			get { return "BLOOMBERG"; }
		}
		#endregion
	}
}