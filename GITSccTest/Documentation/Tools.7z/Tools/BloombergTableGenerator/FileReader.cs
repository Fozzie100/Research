﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BloombergTableGenerator
{
	/// <summary>
	/// Class Used to read Fields From Files
	/// </summary>
	internal static class BloombergFieldReader
	{
		/// <summary>
		/// Gets the distinct list of fields from a set of files
		/// </summary>
		/// <param name="filePaths">string array of file paths to read</param>
		/// <returns>List of strings</returns>
		public static List<string> GetFieldNames(string[] filePaths)
		{
			List<string> allFields = new List<string>();
			foreach (string filePath in filePaths)
			{
				if (!string.IsNullOrWhiteSpace(filePath))
				{
					if (File.Exists(filePath))
					{
						allFields.AddRange(GetFieldNames(filePath));
					}
				}
			}
			//now we have all fields, get the distinct list
			allFields = allFields.Distinct().ToList();
			return allFields;
		}

		/// <summary>
		/// Gets all Field names from a file
		/// </summary>
		/// <param name="filePath">Path to the file</param>
		/// <returns>List of strings</returns>
		public static List<string> GetFieldNames(string filePath)
		{
			const string StartOfFieldsWord = "START-OF-FIELDS";
			const string EndOfFieldsWord = "END-OF-FIELDS";

			List<string> results = new List<string>();
			using (var reader = new StreamReader(filePath))
			{
				bool inFields = false;
				string line;
				bool finished = false;

				while ((!finished) && (line = reader.ReadLine()) != null)
				{
					switch (line)
					{
						case StartOfFieldsWord:
							inFields = true;
							continue;

						case EndOfFieldsWord:
							finished = true;
							break;

						default:
							if (inFields)
							{
								results.Add(line);
							}
							break;
					}
				}
			}
			return results;
		}
	}
}