﻿using System;
using System.Linq;
using System.Windows.Forms;
using BloombergTableGenerator.ScriptGeneration;

namespace BloombergTableGenerator
{
	public partial class GenerateTableForFieldListForm : Form
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of GenerateTableForFieldListForm
		/// </summary>
		public GenerateTableForFieldListForm()
		{
			InitializeComponent();
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the Generate ToolStripButton is clicked
		/// </summary>
		/// <param name="sender">ToolStripButton raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiGenerateToolStripButton_Click(object sender, EventArgs e)
		{
			CreateAdHocGenerator schemaGenerator = new CreateAdHocGenerator(uiTableNameToolStripTextBox.Text);
			string[] fields = uiFieldsTextBox.Text.Split(Environment.NewLine.ToCharArray());
			using (PrimeEntities entities = new PrimeEntities())
			{
				for (int i = 0; i < fields.Length; i++)
				{
					string field = fields[i];

					if (!string.IsNullOrWhiteSpace(field))
					{
						field = field.Trim();
						BloombergField columnDefinition =
							(from BloombergField column in entities.BloombergFields
							 where column.FieldName == field
							 select column).FirstOrDefault();
						if (columnDefinition != null)
						{
							schemaGenerator.AddColumn(columnDefinition.FieldName + " " + columnDefinition.DataType);
						}
						else
						{
							schemaGenerator.AddColumn("---------------" + field + "----------------------COLUMN NOT FOUND");
						}
					}
				}
				uiScriptTextBox.Text = schemaGenerator.ToString();
			}
		}
		#endregion
	}
}