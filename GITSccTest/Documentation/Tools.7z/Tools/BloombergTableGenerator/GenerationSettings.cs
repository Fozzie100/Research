﻿namespace BloombergTableGenerator
{
	/// <summary>
	/// Class specifying settings for script generation
	/// </summary>
	internal class GenerationSettings
	{
		#region Private Constants
		private const int DefaultEndIndex = 1000; //fairly safe to guess we wont have 1000 columns
		#endregion

		#region Public Properties
		/// <summary>
		/// Flag specifying whether to output VARCHAR(MAX) columns
		/// </summary>
		public bool GenerateVarCharColumns { get; set; }
		/// <summary>
		/// Column index to start from
		/// </summary>
		public int StartIndex { get; private set; }
		/// <summary>
		/// Column index to end at
		/// </summary>
		public int EndIndex { get; private set; }
		#endregion

		#region Constructors
		public GenerationSettings()
		{
			this.StartIndex = 0;
			this.EndIndex = DefaultEndIndex;
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Sets the start and end index of this object
		/// </summary>
		/// <param name="startIndex">Start Index - defaults to Zero</param>
		/// <param name="endIndex">End Index - defaults to 1000</param>
		public void UpdateValues(string startIndex, string endIndex)
		{
			int testValue = 0;
			if (int.TryParse(startIndex, out testValue))
			{
				this.StartIndex = testValue;
			}
			if (int.TryParse(endIndex, out testValue))
			{
				this.EndIndex = testValue;
			}
			else
			{
				this.EndIndex = DefaultEndIndex;
			}
		}
		#endregion
	}
}