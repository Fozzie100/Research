﻿using System.Windows.Forms;

namespace BloombergTableGenerator
{
	/// <summary>
	/// Form used to display a list of fields built from files
	/// </summary>
	public partial class FieldListForm : Form
	{
		#region Constructors
		/// <summary>
		/// Private Constructor to prevent incorrect instantiation
		/// </summary>
		private FieldListForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Creates a new instance of FieldListForm
		/// </summary>
		/// <param name="lines">string array to display</param>
		public FieldListForm(string[] lines) : this()
		{
			uiMainTextBox.Lines = lines;
		}
		#endregion
	}
}