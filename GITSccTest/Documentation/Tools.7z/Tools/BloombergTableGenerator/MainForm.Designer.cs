﻿namespace BloombergTableGenerator
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.uiFilePathsTextBox = new System.Windows.Forms.TextBox();
			this.uiMainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.uiFieldListTextBox = new System.Windows.Forms.TextBox();
			this.uiScriptTextBox = new System.Windows.Forms.TextBox();
			this.uiAdvancedOptionsToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiGenerateVarcharColumnsToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiGenerateVarcharToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiAdvancedToolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
			this.uiStartVarcharAtToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiStartingFromToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
			this.uiUpToToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiUpToToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
			this.uiAdvancedToolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.uiScriptToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiScriptToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiTableNameToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
			this.uiToolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
			this.uiGenerateToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiAdvancedOptionsToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiImageList = new System.Windows.Forms.ImageList(this.components);
			this.uiStatusStrip = new System.Windows.Forms.StatusStrip();
			this.uiToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.uiTopSplitContainer = new System.Windows.Forms.SplitContainer();
			this.button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).BeginInit();
			this.uiMainSplitContainer.Panel1.SuspendLayout();
			this.uiMainSplitContainer.Panel2.SuspendLayout();
			this.uiMainSplitContainer.SuspendLayout();
			this.uiAdvancedOptionsToolStrip.SuspendLayout();
			this.uiScriptToolStrip.SuspendLayout();
			this.uiStatusStrip.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiTopSplitContainer)).BeginInit();
			this.uiTopSplitContainer.Panel1.SuspendLayout();
			this.uiTopSplitContainer.Panel2.SuspendLayout();
			this.uiTopSplitContainer.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiFilePathsTextBox
			// 
			this.uiFilePathsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiFilePathsTextBox.Location = new System.Drawing.Point(0, 0);
			this.uiFilePathsTextBox.Multiline = true;
			this.uiFilePathsTextBox.Name = "uiFilePathsTextBox";
			this.uiFilePathsTextBox.Size = new System.Drawing.Size(652, 60);
			this.uiFilePathsTextBox.TabIndex = 1;
			this.uiFilePathsTextBox.Text = "Enter File paths in here to load field lists";
			// 
			// uiMainSplitContainer
			// 
			this.uiMainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiMainSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.uiMainSplitContainer.Name = "uiMainSplitContainer";
			this.uiMainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiMainSplitContainer.Panel1
			// 
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiTopSplitContainer);
			// 
			// uiMainSplitContainer.Panel2
			// 
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiScriptTextBox);
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiAdvancedOptionsToolStrip);
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiScriptToolStrip);
			this.uiMainSplitContainer.Size = new System.Drawing.Size(775, 632);
			this.uiMainSplitContainer.SplitterDistance = 250;
			this.uiMainSplitContainer.TabIndex = 0;
			// 
			// uiFieldListTextBox
			// 
			this.uiFieldListTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiFieldListTextBox.Location = new System.Drawing.Point(0, 0);
			this.uiFieldListTextBox.Multiline = true;
			this.uiFieldListTextBox.Name = "uiFieldListTextBox";
			this.uiFieldListTextBox.Size = new System.Drawing.Size(775, 186);
			this.uiFieldListTextBox.TabIndex = 2;
			this.uiFieldListTextBox.Text = "Enter field list here or load from file paths";
			// 
			// uiScriptTextBox
			// 
			this.uiScriptTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiScriptTextBox.Location = new System.Drawing.Point(0, 25);
			this.uiScriptTextBox.Multiline = true;
			this.uiScriptTextBox.Name = "uiScriptTextBox";
			this.uiScriptTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiScriptTextBox.Size = new System.Drawing.Size(775, 353);
			this.uiScriptTextBox.TabIndex = 2;
			// 
			// uiAdvancedOptionsToolStrip
			// 
			this.uiAdvancedOptionsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiGenerateVarcharColumnsToolStripLabel,
            this.uiGenerateVarcharToolStripButton,
            this.uiAdvancedToolStripSeparator,
            this.uiStartVarcharAtToolStripLabel,
            this.uiStartingFromToolStripTextBox,
            this.uiUpToToolStripLabel,
            this.uiUpToToolStripTextBox,
            this.uiAdvancedToolStripSeparator2});
			this.uiAdvancedOptionsToolStrip.Location = new System.Drawing.Point(0, 25);
			this.uiAdvancedOptionsToolStrip.Name = "uiAdvancedOptionsToolStrip";
			this.uiAdvancedOptionsToolStrip.Size = new System.Drawing.Size(743, 25);
			this.uiAdvancedOptionsToolStrip.TabIndex = 4;
			this.uiAdvancedOptionsToolStrip.Visible = false;
			// 
			// uiGenerateVarcharColumnsToolStripLabel
			// 
			this.uiGenerateVarcharColumnsToolStripLabel.Name = "uiGenerateVarcharColumnsToolStripLabel";
			this.uiGenerateVarcharColumnsToolStripLabel.Size = new System.Drawing.Size(135, 22);
			this.uiGenerateVarcharColumnsToolStripLabel.Text = "Generate Varchar Columns";
			// 
			// uiGenerateVarcharToolStripButton
			// 
			this.uiGenerateVarcharToolStripButton.CheckOnClick = true;
			this.uiGenerateVarcharToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiGenerateVarcharToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiGenerateVarcharToolStripButton.Image")));
			this.uiGenerateVarcharToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiGenerateVarcharToolStripButton.Name = "uiGenerateVarcharToolStripButton";
			this.uiGenerateVarcharToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiGenerateVarcharToolStripButton.Text = "Generate Varchar Max Columns";
			this.uiGenerateVarcharToolStripButton.ToolTipText = "Select this option if a file wll not import, convert columns to varchar max and g" +
    "radually revert until the offending column is ascertained";
			this.uiGenerateVarcharToolStripButton.Click += new System.EventHandler(this.uiGenerateVarcharToolStripButton_Click);
			// 
			// uiAdvancedToolStripSeparator
			// 
			this.uiAdvancedToolStripSeparator.Name = "uiAdvancedToolStripSeparator";
			this.uiAdvancedToolStripSeparator.Size = new System.Drawing.Size(6, 25);
			// 
			// uiStartVarcharAtToolStripLabel
			// 
			this.uiStartVarcharAtToolStripLabel.Name = "uiStartVarcharAtToolStripLabel";
			this.uiStartVarcharAtToolStripLabel.Size = new System.Drawing.Size(72, 22);
			this.uiStartVarcharAtToolStripLabel.Text = "Starting From";
			// 
			// uiStartingFromToolStripTextBox
			// 
			this.uiStartingFromToolStripTextBox.Name = "uiStartingFromToolStripTextBox";
			this.uiStartingFromToolStripTextBox.Size = new System.Drawing.Size(100, 25);
			this.uiStartingFromToolStripTextBox.Text = "0";
			// 
			// uiUpToToolStripLabel
			// 
			this.uiUpToToolStripLabel.Name = "uiUpToToolStripLabel";
			this.uiUpToToolStripLabel.Size = new System.Drawing.Size(35, 22);
			this.uiUpToToolStripLabel.Text = "Up To";
			// 
			// uiUpToToolStripTextBox
			// 
			this.uiUpToToolStripTextBox.Name = "uiUpToToolStripTextBox";
			this.uiUpToToolStripTextBox.Size = new System.Drawing.Size(100, 25);
			this.uiUpToToolStripTextBox.Text = "Last Column";
			// 
			// uiAdvancedToolStripSeparator2
			// 
			this.uiAdvancedToolStripSeparator2.Name = "uiAdvancedToolStripSeparator2";
			this.uiAdvancedToolStripSeparator2.Size = new System.Drawing.Size(6, 25);
			// 
			// uiScriptToolStrip
			// 
			this.uiScriptToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiScriptToolStripLabel,
            this.uiTableNameToolStripTextBox,
            this.uiToolStripSeparator,
            this.uiGenerateToolStripButton,
            this.uiAdvancedOptionsToolStripButton});
			this.uiScriptToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiScriptToolStrip.Name = "uiScriptToolStrip";
			this.uiScriptToolStrip.Size = new System.Drawing.Size(775, 25);
			this.uiScriptToolStrip.TabIndex = 0;
			this.uiScriptToolStrip.Text = "toolStrip1";
			// 
			// uiScriptToolStripLabel
			// 
			this.uiScriptToolStripLabel.Name = "uiScriptToolStripLabel";
			this.uiScriptToolStripLabel.Size = new System.Drawing.Size(63, 22);
			this.uiScriptToolStripLabel.Text = "Table Name";
			// 
			// uiTableNameToolStripTextBox
			// 
			this.uiTableNameToolStripTextBox.AutoSize = false;
			this.uiTableNameToolStripTextBox.Name = "uiTableNameToolStripTextBox";
			this.uiTableNameToolStripTextBox.Size = new System.Drawing.Size(200, 21);
			// 
			// uiToolStripSeparator
			// 
			this.uiToolStripSeparator.Name = "uiToolStripSeparator";
			this.uiToolStripSeparator.Size = new System.Drawing.Size(6, 25);
			// 
			// uiGenerateToolStripButton
			// 
			this.uiGenerateToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiGenerateToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiGenerateToolStripButton.Image")));
			this.uiGenerateToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiGenerateToolStripButton.Name = "uiGenerateToolStripButton";
			this.uiGenerateToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiGenerateToolStripButton.Text = "Generate";
			this.uiGenerateToolStripButton.ToolTipText = "Generate Script";
			this.uiGenerateToolStripButton.Click += new System.EventHandler(this.uiGenerateToolStripButton_Click);
			// 
			// uiAdvancedOptionsToolStripButton
			// 
			this.uiAdvancedOptionsToolStripButton.CheckOnClick = true;
			this.uiAdvancedOptionsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiAdvancedOptionsToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiAdvancedOptionsToolStripButton.Image")));
			this.uiAdvancedOptionsToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiAdvancedOptionsToolStripButton.Name = "uiAdvancedOptionsToolStripButton";
			this.uiAdvancedOptionsToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiAdvancedOptionsToolStripButton.Text = "Advanced Options";
			this.uiAdvancedOptionsToolStripButton.Click += new System.EventHandler(this.uiAdvancedOptionsToolStripButton_Click);
			// 
			// uiImageList
			// 
			this.uiImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("uiImageList.ImageStream")));
			this.uiImageList.TransparentColor = System.Drawing.Color.Magenta;
			this.uiImageList.Images.SetKeyName(0, "ImportXMLHS.png");
			this.uiImageList.Images.SetKeyName(1, "TableHS.png");
			this.uiImageList.Images.SetKeyName(2, "CheckBoxUnChecked.png");
			this.uiImageList.Images.SetKeyName(3, "CheckBoxChecked.png");
			// 
			// uiStatusStrip
			// 
			this.uiStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiToolStripStatusLabel});
			this.uiStatusStrip.Location = new System.Drawing.Point(0, 632);
			this.uiStatusStrip.Name = "uiStatusStrip";
			this.uiStatusStrip.Size = new System.Drawing.Size(775, 22);
			this.uiStatusStrip.TabIndex = 1;
			this.uiStatusStrip.Text = "statusStrip1";
			// 
			// uiToolStripStatusLabel
			// 
			this.uiToolStripStatusLabel.Name = "uiToolStripStatusLabel";
			this.uiToolStripStatusLabel.Size = new System.Drawing.Size(38, 17);
			this.uiToolStripStatusLabel.Text = "Ready";
			// 
			// uiTopSplitContainer
			// 
			this.uiTopSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiTopSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.uiTopSplitContainer.Name = "uiTopSplitContainer";
			this.uiTopSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiTopSplitContainer.Panel1
			// 
			this.uiTopSplitContainer.Panel1.Controls.Add(this.button1);
			this.uiTopSplitContainer.Panel1.Controls.Add(this.uiFilePathsTextBox);
			// 
			// uiTopSplitContainer.Panel2
			// 
			this.uiTopSplitContainer.Panel2.Controls.Add(this.uiFieldListTextBox);
			this.uiTopSplitContainer.Size = new System.Drawing.Size(775, 250);
			this.uiTopSplitContainer.SplitterDistance = 60;
			this.uiTopSplitContainer.TabIndex = 3;
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.button1.Location = new System.Drawing.Point(658, 3);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(114, 23);
			this.button1.TabIndex = 2;
			this.button1.Text = "Read File Definition";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(775, 654);
			this.Controls.Add(this.uiMainSplitContainer);
			this.Controls.Add(this.uiStatusStrip);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Bloomberg Table Script Generator";
			this.uiMainSplitContainer.Panel1.ResumeLayout(false);
			this.uiMainSplitContainer.Panel2.ResumeLayout(false);
			this.uiMainSplitContainer.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).EndInit();
			this.uiMainSplitContainer.ResumeLayout(false);
			this.uiAdvancedOptionsToolStrip.ResumeLayout(false);
			this.uiAdvancedOptionsToolStrip.PerformLayout();
			this.uiScriptToolStrip.ResumeLayout(false);
			this.uiScriptToolStrip.PerformLayout();
			this.uiStatusStrip.ResumeLayout(false);
			this.uiStatusStrip.PerformLayout();
			this.uiTopSplitContainer.Panel1.ResumeLayout(false);
			this.uiTopSplitContainer.Panel1.PerformLayout();
			this.uiTopSplitContainer.Panel2.ResumeLayout(false);
			this.uiTopSplitContainer.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiTopSplitContainer)).EndInit();
			this.uiTopSplitContainer.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox uiFilePathsTextBox;
		private System.Windows.Forms.SplitContainer uiMainSplitContainer;
		private System.Windows.Forms.StatusStrip uiStatusStrip;
		private System.Windows.Forms.ToolStripStatusLabel uiToolStripStatusLabel;
		private System.Windows.Forms.ToolStrip uiScriptToolStrip;
		private System.Windows.Forms.ToolStripLabel uiScriptToolStripLabel;
		private System.Windows.Forms.ToolStripTextBox uiTableNameToolStripTextBox;
		private System.Windows.Forms.ToolStripButton uiGenerateToolStripButton;
		private System.Windows.Forms.ToolStripSeparator uiToolStripSeparator;
		private System.Windows.Forms.TextBox uiScriptTextBox;
		private System.Windows.Forms.ImageList uiImageList;
		private System.Windows.Forms.ToolStrip uiAdvancedOptionsToolStrip;
		private System.Windows.Forms.ToolStripButton uiAdvancedOptionsToolStripButton;
		private System.Windows.Forms.ToolStripButton uiGenerateVarcharToolStripButton;
		private System.Windows.Forms.ToolStripLabel uiStartVarcharAtToolStripLabel;
		private System.Windows.Forms.ToolStripTextBox uiStartingFromToolStripTextBox;
		private System.Windows.Forms.ToolStripLabel uiUpToToolStripLabel;
		private System.Windows.Forms.ToolStripTextBox uiUpToToolStripTextBox;
		private System.Windows.Forms.ToolStripLabel uiGenerateVarcharColumnsToolStripLabel;
		private System.Windows.Forms.ToolStripSeparator uiAdvancedToolStripSeparator;
		private System.Windows.Forms.ToolStripSeparator uiAdvancedToolStripSeparator2;
		private System.Windows.Forms.TextBox uiFieldListTextBox;
		private System.Windows.Forms.SplitContainer uiTopSplitContainer;
		private System.Windows.Forms.Button button1;
	}
}

