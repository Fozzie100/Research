﻿namespace BloombergTableGenerator
{
	partial class AddFieldsToTableForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddFieldsToTableForm));
			this.uiMainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.uiFieldListTextBox = new System.Windows.Forms.TextBox();
			this.uiFieldListToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiFieldListToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiScriptTextBox = new System.Windows.Forms.TextBox();
			this.uiScriptToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiTableNameToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiTableNameToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
			this.uiGenerateToolStripButton = new System.Windows.Forms.ToolStripButton();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).BeginInit();
			this.uiMainSplitContainer.Panel1.SuspendLayout();
			this.uiMainSplitContainer.Panel2.SuspendLayout();
			this.uiMainSplitContainer.SuspendLayout();
			this.uiFieldListToolStrip.SuspendLayout();
			this.uiScriptToolStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiMainSplitContainer
			// 
			this.uiMainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiMainSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.uiMainSplitContainer.Name = "uiMainSplitContainer";
			this.uiMainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiMainSplitContainer.Panel1
			// 
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiFieldListTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiFieldListToolStrip);
			// 
			// uiMainSplitContainer.Panel2
			// 
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiScriptTextBox);
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiScriptToolStrip);
			this.uiMainSplitContainer.Size = new System.Drawing.Size(708, 545);
			this.uiMainSplitContainer.SplitterDistance = 236;
			this.uiMainSplitContainer.TabIndex = 0;
			// 
			// uiFieldListTextBox
			// 
			this.uiFieldListTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiFieldListTextBox.Location = new System.Drawing.Point(0, 25);
			this.uiFieldListTextBox.Multiline = true;
			this.uiFieldListTextBox.Name = "uiFieldListTextBox";
			this.uiFieldListTextBox.Size = new System.Drawing.Size(708, 211);
			this.uiFieldListTextBox.TabIndex = 1;
			// 
			// uiFieldListToolStrip
			// 
			this.uiFieldListToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiFieldListToolStripLabel});
			this.uiFieldListToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiFieldListToolStrip.Name = "uiFieldListToolStrip";
			this.uiFieldListToolStrip.Size = new System.Drawing.Size(708, 25);
			this.uiFieldListToolStrip.TabIndex = 0;
			this.uiFieldListToolStrip.Text = "toolStrip1";
			// 
			// uiFieldListToolStripLabel
			// 
			this.uiFieldListToolStripLabel.Name = "uiFieldListToolStripLabel";
			this.uiFieldListToolStripLabel.Size = new System.Drawing.Size(48, 22);
			this.uiFieldListToolStripLabel.Text = "Field List";
			// 
			// uiScriptTextBox
			// 
			this.uiScriptTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiScriptTextBox.Location = new System.Drawing.Point(0, 25);
			this.uiScriptTextBox.Multiline = true;
			this.uiScriptTextBox.Name = "uiScriptTextBox";
			this.uiScriptTextBox.Size = new System.Drawing.Size(708, 280);
			this.uiScriptTextBox.TabIndex = 1;
			// 
			// uiScriptToolStrip
			// 
			this.uiScriptToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiTableNameToolStripLabel,
            this.uiTableNameToolStripTextBox,
            this.uiGenerateToolStripButton});
			this.uiScriptToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiScriptToolStrip.Name = "uiScriptToolStrip";
			this.uiScriptToolStrip.Size = new System.Drawing.Size(708, 25);
			this.uiScriptToolStrip.TabIndex = 0;
			this.uiScriptToolStrip.Text = "toolStrip2";
			// 
			// uiTableNameToolStripLabel
			// 
			this.uiTableNameToolStripLabel.Name = "uiTableNameToolStripLabel";
			this.uiTableNameToolStripLabel.Size = new System.Drawing.Size(63, 22);
			this.uiTableNameToolStripLabel.Text = "Table Name";
			// 
			// uiTableNameToolStripTextBox
			// 
			this.uiTableNameToolStripTextBox.Name = "uiTableNameToolStripTextBox";
			this.uiTableNameToolStripTextBox.Size = new System.Drawing.Size(300, 25);
			// 
			// uiGenerateToolStripButton
			// 
			this.uiGenerateToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiGenerateToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiGenerateToolStripButton.Image")));
			this.uiGenerateToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiGenerateToolStripButton.Name = "uiGenerateToolStripButton";
			this.uiGenerateToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiGenerateToolStripButton.Text = "Generate";
			this.uiGenerateToolStripButton.Click += new System.EventHandler(this.uiGenerateToolStripButton_Click);
			// 
			// AddFieldsToTableForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(708, 545);
			this.Controls.Add(this.uiMainSplitContainer);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "AddFieldsToTableForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Add Fields To Table";
			this.uiMainSplitContainer.Panel1.ResumeLayout(false);
			this.uiMainSplitContainer.Panel1.PerformLayout();
			this.uiMainSplitContainer.Panel2.ResumeLayout(false);
			this.uiMainSplitContainer.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).EndInit();
			this.uiMainSplitContainer.ResumeLayout(false);
			this.uiFieldListToolStrip.ResumeLayout(false);
			this.uiFieldListToolStrip.PerformLayout();
			this.uiScriptToolStrip.ResumeLayout(false);
			this.uiScriptToolStrip.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer uiMainSplitContainer;
		private System.Windows.Forms.TextBox uiFieldListTextBox;
		private System.Windows.Forms.ToolStrip uiFieldListToolStrip;
		private System.Windows.Forms.ToolStripLabel uiFieldListToolStripLabel;
		private System.Windows.Forms.TextBox uiScriptTextBox;
		private System.Windows.Forms.ToolStrip uiScriptToolStrip;
		private System.Windows.Forms.ToolStripLabel uiTableNameToolStripLabel;
		private System.Windows.Forms.ToolStripTextBox uiTableNameToolStripTextBox;
		private System.Windows.Forms.ToolStripButton uiGenerateToolStripButton;
	}
}