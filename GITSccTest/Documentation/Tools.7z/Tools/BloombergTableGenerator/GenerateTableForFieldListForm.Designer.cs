﻿namespace BloombergTableGenerator
{
	partial class GenerateTableForFieldListForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GenerateTableForFieldListForm));
			this.uiMainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.uiFieldsToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiScriptToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiFieldsToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiTableNameToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiTableNameToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
			this.uiGenerateToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiFieldsTextBox = new System.Windows.Forms.TextBox();
			this.uiScriptTextBox = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).BeginInit();
			this.uiMainSplitContainer.Panel1.SuspendLayout();
			this.uiMainSplitContainer.Panel2.SuspendLayout();
			this.uiMainSplitContainer.SuspendLayout();
			this.uiFieldsToolStrip.SuspendLayout();
			this.uiScriptToolStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiMainSplitContainer
			// 
			this.uiMainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiMainSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.uiMainSplitContainer.Name = "uiMainSplitContainer";
			this.uiMainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiMainSplitContainer.Panel1
			// 
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiFieldsTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiFieldsToolStrip);
			// 
			// uiMainSplitContainer.Panel2
			// 
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiScriptTextBox);
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiScriptToolStrip);
			this.uiMainSplitContainer.Size = new System.Drawing.Size(759, 641);
			this.uiMainSplitContainer.SplitterDistance = 253;
			this.uiMainSplitContainer.TabIndex = 0;
			// 
			// uiFieldsToolStrip
			// 
			this.uiFieldsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiFieldsToolStripLabel});
			this.uiFieldsToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiFieldsToolStrip.Name = "uiFieldsToolStrip";
			this.uiFieldsToolStrip.Size = new System.Drawing.Size(759, 25);
			this.uiFieldsToolStrip.TabIndex = 0;
			this.uiFieldsToolStrip.Text = "toolStrip1";
			// 
			// uiScriptToolStrip
			// 
			this.uiScriptToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiTableNameToolStripLabel,
            this.uiTableNameToolStripTextBox,
            this.uiGenerateToolStripButton});
			this.uiScriptToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiScriptToolStrip.Name = "uiScriptToolStrip";
			this.uiScriptToolStrip.Size = new System.Drawing.Size(759, 25);
			this.uiScriptToolStrip.TabIndex = 0;
			this.uiScriptToolStrip.Text = "toolStrip1";
			// 
			// uiFieldsToolStripLabel
			// 
			this.uiFieldsToolStripLabel.Name = "uiFieldsToolStripLabel";
			this.uiFieldsToolStripLabel.Size = new System.Drawing.Size(34, 22);
			this.uiFieldsToolStripLabel.Text = "Fields";
			// 
			// uiTableNameToolStripLabel
			// 
			this.uiTableNameToolStripLabel.Name = "uiTableNameToolStripLabel";
			this.uiTableNameToolStripLabel.Size = new System.Drawing.Size(63, 22);
			this.uiTableNameToolStripLabel.Text = "Table Name";
			// 
			// uiTableNameToolStripTextBox
			// 
			this.uiTableNameToolStripTextBox.Name = "uiTableNameToolStripTextBox";
			this.uiTableNameToolStripTextBox.Size = new System.Drawing.Size(100, 25);
			// 
			// uiGenerateToolStripButton
			// 
			this.uiGenerateToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiGenerateToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiGenerateToolStripButton.Image")));
			this.uiGenerateToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiGenerateToolStripButton.Name = "uiGenerateToolStripButton";
			this.uiGenerateToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiGenerateToolStripButton.Text = "Generate";
			this.uiGenerateToolStripButton.Click += new System.EventHandler(this.uiGenerateToolStripButton_Click);
			// 
			// uiFieldsTextBox
			// 
			this.uiFieldsTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiFieldsTextBox.Location = new System.Drawing.Point(0, 25);
			this.uiFieldsTextBox.Multiline = true;
			this.uiFieldsTextBox.Name = "uiFieldsTextBox";
			this.uiFieldsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiFieldsTextBox.Size = new System.Drawing.Size(759, 228);
			this.uiFieldsTextBox.TabIndex = 2;
			// 
			// uiScriptTextBox
			// 
			this.uiScriptTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiScriptTextBox.Location = new System.Drawing.Point(0, 25);
			this.uiScriptTextBox.Multiline = true;
			this.uiScriptTextBox.Name = "uiScriptTextBox";
			this.uiScriptTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiScriptTextBox.Size = new System.Drawing.Size(759, 359);
			this.uiScriptTextBox.TabIndex = 3;
			// 
			// GenerateTableForFieldListForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(759, 641);
			this.Controls.Add(this.uiMainSplitContainer);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "GenerateTableForFieldListForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Generate Table For Field List";
			this.uiMainSplitContainer.Panel1.ResumeLayout(false);
			this.uiMainSplitContainer.Panel1.PerformLayout();
			this.uiMainSplitContainer.Panel2.ResumeLayout(false);
			this.uiMainSplitContainer.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).EndInit();
			this.uiMainSplitContainer.ResumeLayout(false);
			this.uiFieldsToolStrip.ResumeLayout(false);
			this.uiFieldsToolStrip.PerformLayout();
			this.uiScriptToolStrip.ResumeLayout(false);
			this.uiScriptToolStrip.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer uiMainSplitContainer;
		private System.Windows.Forms.ToolStrip uiFieldsToolStrip;
		private System.Windows.Forms.ToolStripLabel uiFieldsToolStripLabel;
		private System.Windows.Forms.ToolStrip uiScriptToolStrip;
		private System.Windows.Forms.ToolStripLabel uiTableNameToolStripLabel;
		private System.Windows.Forms.ToolStripTextBox uiTableNameToolStripTextBox;
		private System.Windows.Forms.ToolStripButton uiGenerateToolStripButton;
		private System.Windows.Forms.TextBox uiFieldsTextBox;
		private System.Windows.Forms.TextBox uiScriptTextBox;
	}
}