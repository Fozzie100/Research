﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
    class SubsequenceE2IDC : SubsequenceE2
    {


        /// <summary>
        /// Delegate construction to base class
        /// no construction setup for sub class
        /// </summary>
        /// <param name="caRef"></param>
        /// <param name="senderRef"></param>
        /// <param name="caOptionNumber"></param>
        /// <param name="number"></param>
        public SubsequenceE2IDC(string caRef, string senderRef, int caOptionNumber, int number)
            : base(caRef, senderRef, caOptionNumber, number)
        {

        }
        internal override void Parse(string code, string text)
        {
            // Parse in Base Class 
            base.Parse(code, text);
            //Allow Overflow cache processing for Tag92, parse out of Q
            if ((code.Substring(0, 2) == "92"))
            {
               base.SequenceTagOverflowProcess(GetType().BaseType.Name, code, text.Split(new[] { "/" }, StringSplitOptions.None)[0], false);
            }
           
        }

        
    }
}

