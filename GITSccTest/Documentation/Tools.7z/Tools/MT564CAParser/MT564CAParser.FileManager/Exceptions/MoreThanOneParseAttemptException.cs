﻿using System;

namespace FTSE.MT564CAParser.FileManager.Exceptions
{
	public class MoreThanOneParseAttemptException : ApplicationException
	{
		public MoreThanOneParseAttemptException() { }
		public MoreThanOneParseAttemptException(string message) : base(message) { }
		public MoreThanOneParseAttemptException(string message, Exception cause) : base(message, cause) { }
		public MoreThanOneParseAttemptException(Exception ex) : base("Unexpected SWIFT tag qualifier", ex) { }
	}
}