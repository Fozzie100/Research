﻿using System;

namespace FTSE.MT564CAParser.FileManager.Exceptions
{
	[Serializable]
	public class UnexpectedFormatException : Exception
	{
		public UnexpectedFormatException() { }
		public UnexpectedFormatException(string message) : base(message) { }
		public UnexpectedFormatException(string message, Exception cause) : base(message, cause) { }
		public UnexpectedFormatException(Exception ex) : base("Unexpected format in the input", ex) { }
	}
}