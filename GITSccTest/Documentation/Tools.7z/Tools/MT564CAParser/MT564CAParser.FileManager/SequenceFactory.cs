﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTSE.MT564CAParser.FileManager
{
    /// <summary>
    /// Switch statement here to create Vendor Specific classes, where Vendor specific
    /// behaviour is required
    /// </summary>
    internal class SequenceFactory
    {
        public static Sequence CreateSequence(CurrentSequence sequenceToCreate, string vendor, string CARef, string senderRef)
        {
            switch (sequenceToCreate)
            {

                
                case CurrentSequence.E:
                    switch (vendor)
                    {
                        case "IDC": return new SequenceEIDC(CARef, senderRef);
                        // break;
                        default: return new SequenceE(CARef, senderRef);
                    }
                case CurrentSequence.B:
                    switch (vendor)
                    {
                        case "IDC": return new SequenceBIDC(CARef, senderRef);
                        // break;
                        default: return new SequenceB(CARef, senderRef);
                    }

                default: throw new NotImplementedException(String.Format("Sequence {0} with CARef/SenderRef constructor not implemented for vendor {1}.", sequenceToCreate.ToString(), vendor));


            }
        }
        public static Sequence CreateSequence(CurrentSequence sequenceToCreate, string vendor)
        {


            switch (sequenceToCreate)
            {

                //case CurrentSequence.B:
                //    switch (vendor)
                //    {
                //        case "IDC": return new SequenceBIDC();
                //        // break;
                //        default: return new SequenceB();
                //    }
                case CurrentSequence.C:
                    switch (vendor)
                    {
                        case "IDC": return new SequenceCIDC();
                        // break;
                        default: return new SequenceC();
                    }
               

                default: throw new NotImplementedException(String.Format("Sequence {0} with default constructor not implemented for vendor {1}.", sequenceToCreate.ToString(), vendor));


            }
        }

        public static Sequence CreateSubSequence(CurrentSubsequence sequenceToCreate, string vendor, string CARef, string SenderRef, int CAOptionNumber, int Counter)
        {


            switch (sequenceToCreate)
            {

                case CurrentSubsequence.E1:
                    switch (vendor)
                    {
                        case "IDC": return new SubsequenceE1IDC(CARef, SenderRef, CAOptionNumber, Counter);
                        // break;
                        default: return new SubsequenceE1(CARef, SenderRef, CAOptionNumber, Counter);
                    }
                case CurrentSubsequence.E2:
                    switch (vendor)
                    {
                        case "IDC": return new SubsequenceE2IDC(CARef, SenderRef, CAOptionNumber, Counter);
                        // break;
                        default: return new SubsequenceE2(CARef, SenderRef, CAOptionNumber, Counter);
                    }

                default: throw new NotImplementedException(String.Format("SubSequence {0} not implemented for vendor {1}.", sequenceToCreate.ToString(), vendor));


            }


        }
    }
}
