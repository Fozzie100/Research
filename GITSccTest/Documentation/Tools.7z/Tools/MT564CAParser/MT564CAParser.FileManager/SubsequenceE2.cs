﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using FTSE.MT564CAParser.FileManager.Exceptions;

/***************************************

 * Add SubsequenceE2Overflow class
 * to manage additional data not conforming to MT564 Spec.
 * Have not made this Vendor specific, as this is a 'generic' style solution
 * to solve the Franked/Partially Franked dividend message from IDC.
 * A similar 'extra' file exists for EDI when processing Franking data
 * 
 * 

****************************************/

namespace FTSE.MT564CAParser.FileManager
{
    /// <summary>
    /// Cash Movement class
    /// 
    /// </summary>
    internal class SubsequenceE2 : Sequence
	{
		#region Fields

               
        protected decimal? _rate = null;
        protected decimal? _amount = null;
        protected string _ccy = null;
        protected string _qualifier = null;
        protected string _typeCode = null;
        protected decimal? _quantity = null;
        protected string _ccy2 = null;
        protected string _dataSourceScheme = null;
        protected string _rateStatus = null;

		internal readonly int _subsequenceNumber;
		#endregion

		#region SWIFT Message attributes
		/// <summary>
		/// 22A
		/// </summary>
        //public string IndicatorType { get; set; }

        ///// <summary>
        ///// 22A
        ///// </summary>
        //public new string Indicator { get; set; }
        internal string IndCreditDebit { get; set; }
        internal string IndContractualPayment { get; set; }
        internal string IndNonEligibleProceeds { get; set; }
        internal string IndNonEligibleProceedsDtaSrcSchme { get; set; }
        internal string IndTypeOfIncome { get; set; }
        internal string IndTypeOfIncomeDtaSrcSchme { get; set; }
        internal string IndIssuerOfferorTaxability { get; set; }


		/// <summary>
		/// 97A
		/// </summary>
		public string CashAccount { get; set; }

		/// <summary>
		/// 19B
		/// </summary>
        //public string AmountType { get; private set; }
        ///// <summary>
        ///// 19B
        ///// </summary>
        //public string AmountCurrency { get; private set; }
        ///// <summary>
        ///// 19B
        ///// </summary>
        //public decimal? Amount { get; private set; }
        internal decimal? AmtEntitled { get; private set; }
        internal string AmtEntitledCcy { get; private set; }
        internal decimal? AmtResulting { get; private set; }
        internal string AmtResultingCcy { get; private set; }
        internal decimal? AmtOrigCcyandOrdered { get; private set; }
        internal string AmtOrigCcyandOrderedCcy { get; private set; }
        internal decimal? AmtCapitalGains { get; private set; }
        internal string AmtCapitalGainsCcy { get; private set; }
        internal decimal? AmtImdemnity { get; private set; }
        internal string AmtImdemnityCcy { get; private set; }
        internal decimal? AmtCashInLieuOfShares { get; private set; }
        internal string AmtCashInLieuOfSharesCcy { get; private set; }
        internal decimal? AmtChargesFees { get; private set; }
        internal string AmtChargesFeesCcy { get; private set; }
        internal decimal? AmtFullyFranked { get; private set; }
        internal string AmtFullyFrankedCcy { get; private set; }
        internal decimal? AmtUnFranked { get; private set; }
        internal string AmtUnFrankedCcy { get; private set; }
        internal decimal? AmtTaxFree { get; private set; }
        internal string AmtTaxFreeCcy { get; private set; }
        internal decimal? AmtTaxDeferred { get; private set; }
        internal string AmtTaxDeferredCcy { get; private set; }
        internal decimal? AmtSundryOtherIncome { get; private set; }
        internal string AmtSundryOtherIncomeCcy { get; private set; }
        internal decimal? AmtGross { get; private set; }
        internal string AmtGrossCcy { get; private set; }
        internal decimal? AmtInterest { get; private set; }
        internal string AmtInterestCcy { get; private set; }
        internal decimal? AmtMarketClaim { get; private set; }
        internal string AmtMarketClaimCcy { get; private set; }
        internal decimal? AmtNetCash { get; private set; }
        internal string AmtNetCashCcy { get; private set; }
        internal decimal? AmtPrincipalOrCorpus { get; private set; }
        internal string AmtPrincipalOrCorpusCcy { get; private set; }
        internal decimal? AmtReInvestment { get; private set; }
        internal string AmtReInvestmentCcy { get; private set; }
        internal decimal? AmtTaxCredit { get; private set; }
        internal string AmtTaxCreditCcy { get; private set; }
        internal decimal? AmtWitholdingTax { get; private set; }
        internal string AmtWitholdingTaxCcy { get; private set; }
        internal decimal? AmtWitholdingForeignTax { get; private set; }
        internal string AmtWitholdingForeignTaxCcy { get; private set; }
        internal decimal? AmtWitholdingLocalTax { get; private set; }
        internal string AmtWitholdingLocalTaxCcy { get; private set; }
        internal decimal? AmtRedemptonOfPremium { get; private set; }
        internal string AmtRedemptonOfPremiumCcy { get; private set; }
        internal decimal? AmtAdditionalTax { get; private set; }
        internal string AmtAdditionalTaxCcy { get; private set; }
        internal decimal? AmtIncomePortion { get; private set; }
        internal string AmtIncomePortionCcy { get; private set; }
        internal decimal? AmtExecutingBroker { get; private set; }
        internal string AmtExecutingBrokerCcy { get; private set; }
        internal decimal? AmtLocalBrokerComm { get; private set; }
        internal string AmtLocalBrokerCommCcy { get; private set; }
        internal decimal? AmtPaySubPayingAgentComm { get; private set; }
        internal string AmtPaySubPayingAgentCommCcy { get; private set; }
        internal decimal? AmtRegulatoryFees { get; private set; }
        internal string AmtRegulatoryFeesCcy { get; private set; }
        internal decimal? AmtShipping { get; private set; }
        internal string AmtShippingCcy { get; private set; }
        internal decimal? AmtSolicitationFee { get; private set; }
        internal string AmtSolicitationFeeCcy { get; private set; }
        internal decimal? AmtStampDuty { get; private set; }
        internal string AmtStampDutyCcy { get; private set; }
        internal decimal? AmtStockExchangeTax { get; private set; }
        internal string AmtStockExchangeTaxCcy { get; private set; }
        internal decimal? AmtVAT { get; private set; }
        internal string AmtVATCcy { get; private set; }
        internal decimal? AmtFiscalStamp { get; private set; }
        internal string AmtFiscalStampCcy { get; private set; }
        internal decimal? AmtManufacturedDivdndPaymnt { get; private set; }
        internal string AmtManufacturedDivdndPaymntCcy { get; private set; }
        internal decimal? AmtReclaimOfTaxes { get; private set; }
        internal string AmtReclaimOfTaxesCcy { get; private set; }
        internal decimal? AmtEUTaxRetention { get; private set; }
        internal string AmtEUTaxRetentionCcy { get; private set; }
        internal decimal? AmtAccruedInterest { get; private set; }
        internal string AmtAccruedInterestCcy { get; private set; }
        internal decimal? AmtEqualisation { get; private set; }
        internal string AmtEqualisationCcy { get; private set; }

		/// <summary>
		/// 98A - PayDate
		/// </summary>
        internal DateTime? PayDate { get; private set; }
        internal string PayDateDtaSrcSchme { get; private set; }
		/// <summary>
		/// 98A - ValueDate
		/// </summary>
        internal DateTime? ValueDate { get; private set; }
        internal string ValueDateDtaSrcSchme { get; private set; }
		/// <summary>
		/// 98A - Earliest Payment Date
		/// </summary>
        internal DateTime? EarliestPayDate { get; private set; }
        internal string EarliestPayDateDtaSrcSchme { get; private set; }
		/// <summary>
		/// 98A - FX Rate Fixing Date
		/// </summary>
        internal DateTime? FxRateFixingDate { get; set; }
        internal string FxRateFixingDateDtaSrcSchme { get; private set; }
		
		/// <summary>
		/// 92A - Rate
		/// </summary>
        internal decimal? AdditionalTaxRate { get; private set; }
        internal decimal? ChangesFeesRate { get; private set; }
        internal decimal? EarlySolicitationRate { get; private set; }
		//public decimal? FinalDividendRate { get; private set; }
        internal decimal? FullyFrankedRate { get; private set; }
        internal decimal? FiscalStampRate { get; private set; }
		internal decimal? ExchangeRate { get; set; }
        internal decimal? CashIncentiveRate { get; private set; }
        internal decimal? InterestRate { get; private set; }
		//public decimal? DividendNetRate { get; private set; }
        internal decimal? NonResidentRate { get; private set; }
		//public new decimal? ProvDividendRate { get; private set; }
        internal decimal? ApplicableRate { get; private set; }
        internal decimal? SolicitationFeeRate { get; private set; }
        internal decimal? TaxCreditRate { get; private set; }
		internal decimal? TaxWithholdingRate { get; private set; }
        internal decimal? TaxOnIncomeRate { get; private set; }
        internal decimal? TaxOnProfitsRate { get; private set; }
        internal decimal? ReclaimTaxRate { get; private set; }
        internal decimal? WithholdingForeignTax { get; private set; }
        internal decimal? WithholdingLocalTax { get; private set; }
		
		/// <summary>
		/// 92
		/// </summary>
        //public decimal? RateQuantity { get; private set; }

        ///// <summary>
        ///// 92A - Rate Note
        ///// </summary>
        //public new string RateCurrency { get; private set; }

        internal string RateAdditionalTaxCcy { get; private set; } 
        internal decimal? RateAdditionalTaxAmt { get; private set; } 
        internal string RateAdditionalTaxCode { get; private set; }
        internal string RateChargesFeesCcy { get; private set; }
        internal decimal? RateChargesFeesAmt { get; private set; }
        internal string RateChargesFeesCode { get; private set; }
        internal string RateEqualisationCcy { get; private set; }
        internal decimal? RateEqualisationAmt { get; private set; }
        internal string RateEqualisationCode { get; private set; }
        internal string RateEarlySolicitationCcy { get; private set; }
        internal decimal? RateEarlySolicitationAmt { get; private set; }
        internal string RateEarlySolicitationCode { get; private set; }
        internal decimal? RateEarlySolicitationQty { get; private set; }
        internal string RateFinalDivCcy { get; private set; }
        internal decimal? RateFinalDivAmt { get; private set; }
        internal string RateFinalDivCode { get; private set; }
        internal string RateFullyFrankedCcy { get; private set; }
        internal decimal? RateFullyFrankedAmt { get; private set; }
        internal string RateFullyFrankedCode { get; private set; }
        internal string RateFiscalStampCode { get; private set; }
        internal string RateGrossCcy { get; private set; }
        internal decimal? RateGrossAmt { get; private set; }
        internal string RateGrossCode { get; private set; }
        internal string RateGrossStatus { get; private set; }
        internal string RateGrossDtaSrcSchme { get; private set; }
        internal string RateExchangeCcy1 { get; private set; }
        internal string RateExchangeCcy2 { get; private set; }
        internal string RateCashIncentiveCcy { get; private set; }
        internal decimal? RateCashIncentiveAmt { get; private set; }
        internal string RateCashIncentiveCode { get; private set; }
        internal string RateInterestCcy { get; private set; }
        internal decimal? RateInterestAmt { get; private set; }
        internal string RateInterestCode { get; private set; }
        internal string RateInterestStatus { get; private set; }
        internal string RateInterestDtaSrcSchme { get; private set; }
        internal string RateNetDivCcy { get; private set; }
        internal decimal? RateNetDivAmt { get; private set; }
        internal string RateNetDivCode { get; private set; }
        internal string RateNetDivStatus { get; private set; }
        internal string RateNetDivDtaSrcSchme { get; private set; }
        internal string RateNonResidentCcy { get; private set; }
        internal decimal? RateNonResidentAmt { get; private set; }
        internal string RateNonResidentCode { get; private set; }
        internal string RateProvisonalDivCcy { get; private set; }
        internal decimal? RateProvisonalDivAmt { get; private set; }
        internal string RateProvisonalDivCode { get; private set; }
        internal string RateApplicableCode { get; private set; }
        internal string RateSolicitationFeeCcy { get; private set; }
        internal decimal? RateSolicitationFeeAmt { get; private set; }
        internal string RateSolicitationFeeCode { get; private set; }
        internal decimal? RateSolicitationFeeQty { get; private set; }
        internal string RateTaxCreditCcy { get; private set; }
        internal decimal? RateTaxCreditAmt { get; private set; }
        internal string RateTaxCreditCode { get; private set; }
        internal string RateTaxCreditDtaSrcSchme { get; private set; }
        internal string RateTaxCreditStatus { get; private set; }
        internal string RateTaxRelatedDtaSrcSchme { get; private set; }
        internal string RateTaxRelatedCode { get; private set; }
        internal string RateTaxRelatedCcy { get; private set; }
        internal decimal? RateTaxRelatedAmt { get; private set; }
        internal string RateTaxRelatedStatus { get; private set; }
        internal string RateTaxWithholdingCode { get; private set; }
        internal string RateTaxOnIncomeCode { get; private set; }
        internal string RateTaxOnProfitsCode { get; private set; }
        internal string RateReclaimTaxCode { get; private set; }
        internal string RateWithholdForeignTaxCcy { get; private set; }
        internal decimal? RateWithholdForeignTaxAmt { get; private set; }
        internal string RateWithholdForeignTaxCode { get; private set; }
        internal string RateWithholdLocalTaxCcy { get; private set; }
        internal decimal? RateWithholdLocalTaxAmt { get; private set; }
        internal string RateWithholdLocalTaxCode { get; private set; }




		/// <summary>
		/// 90A
		/// </summary>
        //public new string PriceCurrency { get; private set; }

        ///// <summary>
        ///// 90A
        ///// </summary>
        //public decimal? Price { get; private set; }


        internal decimal? GenericCashPriceReceived { get; private set; }
        internal decimal? GenericCashPricePaid { get; private set; }
        internal string GenericCashPriceReceivedCcy { get; private set; }
        internal string GenericCashPriceReceivedAmtType { get; private set; }
        internal string GenericCashPriceReceivedPercType { get; private set; }
        internal string GenericCashPriceReceivedCode { get; private set; }
        internal decimal? GenericCashPriceReceivedQty { get; private set; }
        internal string GenericCashPriceReceivedQtyType { get; private set; }
        internal decimal? GenericCashPriceReceivedAmt { get; private set; }
        internal string GenericCashPricePaidCcy { get; private set; }
        internal string GenericCashPricePaidAmtType { get; private set; }
        internal string GenericCashPricePaidPercType { get; private set; }
        internal string GenericCashPricePaidCode { get; private set; }
        internal decimal? GenericCashPricePaidIdxPoints { get; private set; }


		#endregion

        internal string CARef { get; private set; }
        internal string SenderRef { get; private set; }
        internal int CAOptionNumber { get; private set; }

		public SubsequenceE2(string caRef, string senderRef, int caOptionNumber, int number) 
		{
			CAOptionNumber = caOptionNumber;
            CARef = caRef;
            SenderRef = senderRef;
			_subsequenceNumber = number;
		}

		/// <summary>
		/// Main method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
            base.Parse(code, text);
			switch (code)
			{
				case "22H": 
				case "22F":
							ParseField22A(code, text); // Files contain 22H not 22A 
					break;
				case "97A" : 
				case "97E":
							ParseField97A(code, text);
					break;

				case "92J":
				case "92K": ParseField92(code, text);// Our files contain 92K (not in standard)- NO, not true
					break;
				case "19B": ParseField19B(code, text);
					break;
				case "98A":
				case "98B": 
				case "98C":
				case "98E":
							ParseField98B(code, text);
					break;
				case "92A":
				case "92F": // In our files we get 92F instead of 92A!
				case "92B": ParseField92(code, text);
					break;
				case "90A": 
				case "90B":
				case "90E":
				case "90F":
				case "90J": ParseField90A(code, text); break;
				case "16S": // Nop
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}

        /// <summary>
        /// Indicator
        /// Option F :4!c/[8c]/4!c (Qualifier)(Data Source Scheme)(Indicator) 
        /// Option H :4!c//4!c (Qualifier)(Indicator) 
        /// </summary>
        /// <param name="input"></param>
        internal void ParseField22A(string code, string input)
		{
            string dataSourceScheme = String.Empty;
            string indicatorType = String.Empty;
            string indicator = String.Empty;

			// Option H
			if (Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))
			{
				var s = input.Split(new[] { "//" }, StringSplitOptions.None);
				indicatorType = s[0];
                indicator = s[1];
				
			}

			// Option F
			else if (Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z]{4}$"))
			{
                var s = input.Split(new[] { "/" }, StringSplitOptions.None);
                indicatorType = s[0];
                indicator = s[2];
                dataSourceScheme = s[1];
		    }
            else
			    throw new UnexpectedCodeException(String.Format("{0}: The input {1} for 22A does not match any of the options.", GetType().Name, input));

            switch (indicatorType)
            {
                case "CRDB":
                    IndCreditDebit = indicator;
                    break;
                case "CONT":
                    IndContractualPayment = indicator;
                    break;
                case "NELP":
                    IndNonEligibleProceeds = indicator;
                    IndNonEligibleProceedsDtaSrcSchme = dataSourceScheme;
                    break;
                case "ITYP":
                    IndTypeOfIncome = indicator;
                    IndTypeOfIncomeDtaSrcSchme = dataSourceScheme;
                    break;
                case "TXAP":
                    IndIssuerOfferorTaxability = indicator;
                    break;
                default:
                    SequenceTagUnknownProcess(code, input);
                    break;
            }
		}

		/// <summary>
		/// Account: Cash Account
		/// </summary>
		/// <example>	Option A	:4!c//35x	(Qualifier)(Account Number)
		///				Option E	:4!c//34x	(Qualifier)(International Bank Account Number)</example>
        internal void ParseField97A(string code, string input)
		{
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}//.{1,35}$")))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 94", GetType().Name));
            }
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			switch (s[0])
			{
				case "CASH": CashAccount = s[1]; break;
				default:
					SequenceTagUnknownProcess(code, input);
                    break;
			}

         
		}

		/// <summary>
		/// Amount
        /// Option B :4!c//3!a15d (Qualifier)(Currency Code)(Amount) 
		/// </summary>
        internal void ParseField19B(string code, string input)
		{
            if (
                (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}$"))) //option B
               )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 19B.", GetType().Name));
            }

           
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
          
			if (s[1] == "UKWN")
				return;

            switch (s[0])
            {
                case "ENTL":
                    AmtEntitled = ParseDecimalFr(s[1].Substring(3));
                    AmtEntitledCcy = s[1].Substring(0, 3);
                    break;
                case "RESU":
                    AmtResulting = ParseDecimalFr(s[1].Substring(3));
                    AmtResultingCcy = s[1].Substring(0, 3);
                    break;
                case "OCMT":
                    AmtOrigCcyandOrdered = ParseDecimalFr(s[1].Substring(3));
                    AmtOrigCcyandOrderedCcy = s[1].Substring(0, 3);
                    break;
                case "CAPG":
                    AmtCapitalGains = ParseDecimalFr(s[1].Substring(3));
                    AmtCapitalGainsCcy = s[1].Substring(0, 3);
                    break;
                case "INDM":
                    AmtImdemnity = ParseDecimalFr(s[1].Substring(3));
                    AmtImdemnityCcy = s[1].Substring(0, 3);
                    break;
                case "CINL":
                    AmtCashInLieuOfShares = ParseDecimalFr(s[1].Substring(3));
                    AmtCashInLieuOfSharesCcy = s[1].Substring(0, 3);
                    break;
                case "CHAR":
                    AmtChargesFees = ParseDecimalFr(s[1].Substring(3));
                    AmtChargesFeesCcy = s[1].Substring(0, 3);
                    break;
                case "FLFR":
                    AmtFullyFranked = ParseDecimalFr(s[1].Substring(3));
                    AmtFullyFrankedCcy = s[1].Substring(0, 3);
                    break;
                case "UNFR":
                    AmtUnFranked = ParseDecimalFr(s[1].Substring(3));
                    AmtUnFrankedCcy = s[1].Substring(0, 3);
                    break;
                case "TXFR":
                    AmtTaxFree = ParseDecimalFr(s[1].Substring(3));
                    AmtTaxFreeCcy = s[1].Substring(0, 3);
                    break;
                case "TXDF":
                    AmtTaxDeferred = ParseDecimalFr(s[1].Substring(3));
                    AmtTaxDeferredCcy = s[1].Substring(0, 3);
                    break;
                case "SOIC":
                    AmtSundryOtherIncome = ParseDecimalFr(s[1].Substring(3));
                    AmtSundryOtherIncomeCcy = s[1].Substring(0, 3);
                    break;
                case "GRSS":
                    AmtGross = ParseDecimalFr(s[1].Substring(3));
                    AmtGrossCcy = s[1].Substring(0, 3);
                    break;
                case "INTR":
                    AmtInterest = ParseDecimalFr(s[1].Substring(3));
                    AmtInterestCcy = s[1].Substring(0, 3);
                    break;
                case "MKTC":
                    AmtMarketClaim = ParseDecimalFr(s[1].Substring(3));
                    AmtMarketClaimCcy = s[1].Substring(0, 3);
                    break;
                case "NETT":
                    AmtNetCash = ParseDecimalFr(s[1].Substring(3));
                    AmtNetCashCcy = s[1].Substring(0, 3);
                    break;
                case "PRIN":
                    AmtPrincipalOrCorpus = ParseDecimalFr(s[1].Substring(3));
                    AmtPrincipalOrCorpusCcy = s[1].Substring(0, 3);
                    break;
                case "REIN":
                    AmtReInvestment = ParseDecimalFr(s[1].Substring(3));
                    AmtReInvestmentCcy = s[1].Substring(0, 3);
                    break;
                case "TAXC":
                    AmtTaxCredit = ParseDecimalFr(s[1].Substring(3));
                    AmtTaxCreditCcy = s[1].Substring(0, 3);
                    break;
                case "TAXR":
                    AmtWitholdingTax = ParseDecimalFr(s[1].Substring(3));
                    AmtWitholdingTaxCcy = s[1].Substring(0, 3);
                    break;
                case "WITF":
                    AmtWitholdingForeignTax = ParseDecimalFr(s[1].Substring(3));
                    AmtWitholdingForeignTaxCcy = s[1].Substring(0, 3);
                    break;
                case "WITL":
                    AmtWitholdingLocalTax = ParseDecimalFr(s[1].Substring(3));
                    AmtWitholdingLocalTaxCcy = s[1].Substring(0, 3);
                    break;
                case "REDP":
                    AmtRedemptonOfPremium = ParseDecimalFr(s[1].Substring(3));
                    AmtRedemptonOfPremiumCcy = s[1].Substring(0, 3);
                    break;
                case "ATAX":
                    AmtAdditionalTax = ParseDecimalFr(s[1].Substring(3));
                    AmtAdditionalTaxCcy = s[1].Substring(0, 3);
                    break;
                case "INCO":
                    AmtIncomePortion = ParseDecimalFr(s[1].Substring(3));
                    AmtIncomePortionCcy = s[1].Substring(0, 3);
                    break;
                case "EXEC":
                    AmtExecutingBroker = ParseDecimalFr(s[1].Substring(3));
                    AmtExecutingBrokerCcy = s[1].Substring(0, 3);
                    break;
                case "LOCO":
                    AmtLocalBrokerComm = ParseDecimalFr(s[1].Substring(3));
                    AmtLocalBrokerCommCcy = s[1].Substring(0, 3);
                    break;
                case "PAMM":
                    AmtPaySubPayingAgentComm = ParseDecimalFr(s[1].Substring(3));
                    AmtPaySubPayingAgentCommCcy = s[1].Substring(0, 3);
                    break;
                case "REGF":
                    AmtRegulatoryFees = ParseDecimalFr(s[1].Substring(3));
                    AmtRegulatoryFeesCcy = s[1].Substring(0, 3);
                    break;
                case "SHIP":
                    AmtShipping = ParseDecimalFr(s[1].Substring(3));
                    AmtShippingCcy = s[1].Substring(0, 3);
                    break;
                case "SOFE":
                    AmtSolicitationFee = ParseDecimalFr(s[1].Substring(3));
                    AmtSolicitationFeeCcy = s[1].Substring(0, 3);
                    break;
                case "STAM":
                    AmtStampDuty = ParseDecimalFr(s[1].Substring(3));
                    AmtStampDutyCcy = s[1].Substring(0, 3);
                    break;
                case "STEX":
                    AmtStockExchangeTax = ParseDecimalFr(s[1].Substring(3));
                    AmtStockExchangeTaxCcy = s[1].Substring(0, 3);
                    break;
                case "VATA":
                    AmtVAT = ParseDecimalFr(s[1].Substring(3));
                    AmtVATCcy = s[1].Substring(0, 3);
                    break;
                case "FISC":
                    AmtFiscalStamp = ParseDecimalFr(s[1].Substring(3));
                    AmtFiscalStampCcy = s[1].Substring(0, 3);
                    break;
                case "MFDV":
                    AmtManufacturedDivdndPaymnt = ParseDecimalFr(s[1].Substring(3));
                    AmtManufacturedDivdndPaymntCcy = s[1].Substring(0, 3);
                    break;
                case "TXRC":
                    AmtReclaimOfTaxes = ParseDecimalFr(s[1].Substring(3));
                    AmtReclaimOfTaxesCcy = s[1].Substring(0, 3);
                    break;
                case "EUTR":
                    AmtEUTaxRetention = ParseDecimalFr(s[1].Substring(3));
                    AmtEUTaxRetentionCcy = s[1].Substring(0, 3);
                    break;
                case "ACRU":
                    AmtAccruedInterest = ParseDecimalFr(s[1].Substring(3));
                    AmtAccruedInterestCcy = s[1].Substring(0, 3);
                    break;
                case "EQUL":
                    AmtEqualisation = ParseDecimalFr(s[1].Substring(3));
                    AmtEqualisationCcy = s[1].Substring(0, 3);
                    break;

                default:
                    SequenceTagUnknownProcess(code, input);
                    break;
                    //throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 19B.", GetType().Name, s[0]));
            }


		}

       
        /// <summary>
        /// Various Dates
        /// </summary>
        /// <example>Option A	:4!c//8!n	(Qualifier)(Date)
        ///  Option A :4!c//8!n (Qualifier)(Date) 
        ///  Option B :4!c/[8c]/4!c (Qualifier)(Data Source Scheme)(Date Code) 
        ///  Option C :4!c//8!n6!n (Qualifier)(Date)(Time) 
        ///  Option E :4!c//8!n6!n[,3n][/[N]2!n[2!n]] (Qualifier)(Date)(Time)(Decimals)(UTC Indicator) 
       
        /// </example>
        /// <param name="input"></param>
        internal void ParseField98B(string code, string input)
		{
            ParseField98Options(input);
            string[] s  = null;
            s = input.Split(new[] { "/" }, StringSplitOptions.None);
           	
	        //If option E, parse UTC date
            switch (s[0])
			{
				case "PAYD": 
                    PayDate = ParseDateOptionalTime(s[2]);
                    PayDateDtaSrcSchme = s[1];
                    break;
				case "VALU": 
                    ValueDate = ParseDateOptionalTime(s[2]);
                    ValueDateDtaSrcSchme = s[1];
                    break;
				case "EARL":
                    if (s.Length == 4)  //Option E with UTC EarliestPayDate not supported per SMPG Best Practices 2014
                        throw new NotImplementedException(String.Format("{0}: Option {1} encountered in field 98E not implemented.", GetType().Name, input));
                    EarliestPayDate = ParseDateOptionalTime(s[2]);
                    
                    EarliestPayDateDtaSrcSchme = s[1];
                    break;
				case "FXDT": 
                    FxRateFixingDate = ParseDateOptionalTime(s[2]);
                    FxRateFixingDateDtaSrcSchme = s[1];
                    break;

				default: 
                    SequenceTagUnknownProcess(code, input);
                    break;
			}
		}

		/// <summary>
        /// Rate
		/// Parse field 92 (http://www.iso15022.org/uhb/uhb/mt564-92-field-92a.htm)
        ///    Option A :4!c//[N]15d (Qualifier)(Sign)(Rate) 
        ///    Option B :4!c//3!a/3!a/15d (Qualifier)(First Currency Code)(Second Currency Code)(Rate) 
        ///    Option F :4!c//3!a15d (Qualifier)(Currency Code)(Amount) 
        ///    Option J :4!c/[8c]/4!c/3!a15d[/4!c] (Qualifier)(Data Source Scheme)(Rate Type Code)(Currency Code)(Amount)(Rate Status) 
        ///    Option K :4!c//4!c (Qualifier)(Rate Type Code) 
        ///    Option M :4!c//3!a15d/15d (Qualifier)(Currency Code)(Amount)(Quantity) 
		/// </summary>
		/// <param name="code"></param>
		/// <param name="input"></param>
        internal void ParseField92(string code, string input)
		{
            ParseField92E2Options(input);

          
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			decimal? rate = null;
            decimal? amount = null;
            decimal? quantity = null;
            string ccy = null;
            string ccy2 = null;
            string dataSourceScheme = null;
            string typeCode = null;
            string rateStatus = null;
            string qualifier = null;


            qualifier = s[0];
			switch (code.Substring(2, 1))
			{
				case "A": rate = ParseDecimalFr(s[1]);
					break;

				case "B":
                    var s1  = s[1].Split(new[] { "/" }, StringSplitOptions.None);
                    ccy = s1[0];
                    ccy2 = s1[1];
                    rate = ParseDecimalFr(s1[2]);
					break;
				case "F":
                    ccy = s[1].Substring(0, 3);
                    amount = ParseDecimalFr(s[1].Substring(3));
					break;
				case "J":
					var splitJ = input.Split(new[] { "/" }, StringSplitOptions.None);
                    dataSourceScheme = splitJ[1];
                    typeCode = splitJ[2];
                    amount = ParseNumberWithCurrency(splitJ[3], out ccy);
                    rateStatus = (splitJ.Length == 5) ? splitJ[4] : null;
                    qualifier = splitJ[0];
					break;
				case "K":
                    typeCode = s[1];
					break;

				case "M":
					var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
                    quantity = ParseDecimalFr(splitB[1]);
					//ccy = splitB[0].Substring(0, 3);
                    amount = ParseNumberWithCurrency(splitB[0], out ccy);
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unrecognized code option {1} in field 92.", GetType().Name, input.Substring(2, 1)));
			}

            _amount = amount;
            _rate = rate;
            _ccy = ccy;
            _qualifier = qualifier;
            _typeCode = typeCode;
            _quantity = quantity;
            _ccy2 = ccy2;
            _dataSourceScheme = dataSourceScheme;
            _rateStatus = rateStatus;

            
           // SubsequenceE2OverflowProcess();
             //Lazy Initialize SubsequenceE2Overflow
             // 1. Check if qualifier placeholder struct in array of strucs
            //  2. If NOT in list then add with NULL fields, mark as empty, and placeholder = true, exit then run default process(below)
            //  3. If Qualifier IN list then add with code and data , and placeholder = false, exit WITH NO MORE processing  

            switch (qualifier)
			{
				case "ATAX": 
                    AdditionalTaxRate = rate;
                    RateAdditionalTaxCcy = ccy;
                    RateAdditionalTaxAmt = amount;
                    RateAdditionalTaxCode = typeCode;
                    break;
				case "CHAR": 
                    ChangesFeesRate = rate;
                    RateChargesFeesCcy = ccy;
                    RateChargesFeesAmt = amount;
                    RateChargesFeesCode = typeCode;
                    break;
                case "EQUL":
                    RateEqualisationCcy = ccy;
                    RateEqualisationAmt = amount;
                    RateEqualisationCode = typeCode;
                    break;
				case "ESOF": 
                    EarlySolicitationRate = rate;
                    RateEarlySolicitationCcy = ccy;
                    RateEarlySolicitationAmt = amount;
                    RateEarlySolicitationCode = typeCode;
                    RateEarlySolicitationQty = quantity;
                    break;
				// case "FDIV": FinalDividendRate = rate; break;
                case "FDIV":
                    RateFinalDivCcy = ccy;
                    RateFinalDivAmt = amount;
                    RateFinalDivCode = typeCode;
                    break;
				case "FLFR": 
                    FullyFrankedRate = rate;
                    RateFullyFrankedCcy = ccy;
                    RateFullyFrankedAmt = amount;
                    RateFullyFrankedCode = typeCode;
                    break;
				case "FISC": 
                    FiscalStampRate = rate;
                    RateFiscalStampCode = typeCode;
                    break;
				// case "GRSS": DividendGrossRate = rate; break;
                case "GRSS":
                    RateGrossCcy = ccy;
                    RateGrossAmt = amount;
                    RateGrossCode = typeCode;
                    RateGrossStatus = rateStatus;
                    RateGrossDtaSrcSchme = dataSourceScheme;
                    break;
				case "EXCH": 
                    ExchangeRate = rate;
                    RateExchangeCcy1 = ccy;
                    RateExchangeCcy2 = ccy2;
                    break;
				case "INCE": 
                    CashIncentiveRate = rate;
                    RateCashIncentiveCcy = ccy;
                    RateCashIncentiveAmt = amount;
                    RateCashIncentiveCode = typeCode;
                    break;
				case "INTP": 
                    InterestRate = rate;
                    RateInterestAmt = amount;
                    RateInterestCode = typeCode;
                    RateInterestStatus = rateStatus;
                    RateInterestDtaSrcSchme = dataSourceScheme;
                    RateInterestCcy = ccy;
                    break;
				//case "NETT": DividendNetRate = rate; break;
                case "NETT":
                    RateNetDivCcy = ccy;
                    RateNetDivAmt = amount;
                    RateNetDivCode = typeCode;
                    RateNetDivStatus = rateStatus;
                    RateNetDivDtaSrcSchme = dataSourceScheme;
                    break;
				case "NRES": 
                    NonResidentRate = rate;
                    RateNonResidentCcy = ccy;
                    RateNonResidentAmt = amount;
                    RateNonResidentCode = typeCode;
                    break;
				// case "PDIV": ProvDividendRate = rate; break;
                case "PDIV":
                    RateProvisonalDivCcy = ccy;
                    RateProvisonalDivAmt = amount;
                    RateProvisonalDivCode = typeCode;
                    break;
				case "RATE": 
                    ApplicableRate = rate;
                    RateApplicableCode = typeCode;
                    break;
				case "SOFE": 
                    SolicitationFeeRate = rate;
                    RateSolicitationFeeCcy = ccy;
                    RateSolicitationFeeAmt = amount;
                    RateSolicitationFeeCode = typeCode;
                    RateSolicitationFeeQty = quantity;
                    break;
				case "TAXC": 
                    TaxCreditRate = rate;
                    RateTaxCreditCcy = ccy;
                    RateTaxCreditAmt = amount;
                    RateTaxCreditCode = typeCode;
                    RateTaxCreditDtaSrcSchme = dataSourceScheme;
                    RateTaxCreditStatus = rateStatus;
                    break;
				//case "TAXE": TaxRelatedRate = rate; break;
                case "TAXE":
                    RateTaxRelatedDtaSrcSchme = dataSourceScheme;
                    RateTaxRelatedCode = typeCode;
                    RateTaxRelatedCcy = ccy;
                    RateTaxRelatedAmt = amount;
                    RateTaxRelatedStatus = rateStatus;
                    break;
				case "TAXR": 
                    TaxWithholdingRate = rate;
                    RateTaxWithholdingCode = typeCode;
                    break;
				case "TXIN": 
                    TaxOnIncomeRate = rate;
                    RateTaxOnIncomeCode = typeCode;
                    break;
				case "TXPR": 
                    TaxOnProfitsRate = rate;
                    RateTaxOnProfitsCode = typeCode;
                    break;
				case "TXRC": 
                    ReclaimTaxRate = rate;
                    RateReclaimTaxCode = typeCode;
                    break;
				case "WITF": 
                    WithholdingForeignTax = rate;
                    RateWithholdForeignTaxCcy = ccy;
                    RateWithholdForeignTaxAmt = amount;
                    RateWithholdForeignTaxCode = typeCode;
                    break;
				case "WITL": 
                    WithholdingLocalTax = rate;
                    RateWithholdLocalTaxCcy = ccy;
                    RateWithholdLocalTaxAmt = amount;
                    RateWithholdLocalTaxCode = typeCode;
                    break;

                default:
                    {
                        //Instead of error, collect data not currently processed
                        //throw new UnexpectedCodeException(String.Format("{0}: Unexpected code in Field 92.", GetType().Name));
                       // _TagsNotRecognized = _TagsNotRecognized + ":" + code + "::" + input;
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}

           // SequenceTagOverflowProcess(GetType().Name, code, qualifier, false);
		}

		/// <summary>
		/// Price
		/// </summary>
		/// <example>	Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///				Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///				Option E	:4!c//4!c	(Qualifier)(Price Code)
		///				Option F	:4!c//4!c/3!a15d/4!c/15d	(Qualifier)(Amount Type Code)(Currency Code)(Amount)(Quantity Type Code)(Quantity)
		///				Option J	:4!c//4!c/3!a15d/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Amount)(Currency Code)(Amount)
		///				Option K	:4!c//15d	(Qualifier)(Index Points)</example>
		/// <param name="input"></param>
        internal void ParseField90A(string code, string input)
		{

            ParseField90ABEFJKOptions(input);

            var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            var split2 = s[1].Split(new[] { "/" }, StringSplitOptions.None);

            decimal? price = null;
            string percentageTypeCode = null;
            string amountTypeCode = null;
            string quantityTypeCode = null;
            string ccyCode = null;
            string priceCode = null;
            decimal? indexPoints = null;
            decimal? quantity = null;
            decimal? amount = null;



            switch (code.Substring(2, 1))
            {
                case "A":
                    price = ParseDecimalFr(split2[1]);
                    percentageTypeCode = split2[0];
                    break;
                case "B":
                    price = ParseNumberWithCurrency(split2[1], out ccyCode);
                    amountTypeCode = split2[0];
                    break;
                case "E":
                    priceCode = split2[0];
                    break;
                case "F":
                    amountTypeCode = split2[0];
                    amount = ParseNumberWithCurrency(split2[1], out ccyCode);
                    quantityTypeCode = split2[2];
                    quantity = ParseDecimalFr(split2[3]);
                    break;
                case "J":
                    amountTypeCode = split2[0];
                    amount = ParseNumberWithCurrency(split2[1], out ccyCode);
                    break;
                case "K":
                    indexPoints = ParseDecimalFr(split2[0]);
                    break;
                default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
            }

            switch (s[0])
            {
                case "PRPP":
                    GenericCashPricePaid = price;
                    GenericCashPricePaidAmtType = amountTypeCode;
                    GenericCashPricePaidCcy = ccyCode;
                    GenericCashPricePaidPercType = percentageTypeCode;
                    GenericCashPricePaidCode = priceCode;
                    GenericCashPricePaidIdxPoints = indexPoints;
                    break;
                case "OFFR":
                    GenericCashPriceReceivedAmt = amount;
                    GenericCashPriceReceived = price;
                    GenericCashPriceReceivedAmtType = amountTypeCode;
                    GenericCashPriceReceivedCcy = ccyCode;
                    GenericCashPriceReceivedPercType = percentageTypeCode;
                    GenericCashPriceReceivedQty = quantity;
                    GenericCashPriceReceivedQtyType = quantityTypeCode;
                    GenericCashPriceReceivedCode = priceCode;
                    break;
               
                default:
                    SequenceTagUnknownProcess(code, input);
                    break;
            }
            
		}

		public static string GetHeaders()
		{
            return "CARef|SenderRef|CAOptionNumber|SeqNum|CashAccount|PayDate|PayDateDtaSrcSchme|ValueDate|ValueDateDtaSrcSchme|EarliestPayDate|EarliestPayDateDtaSrcSchme|FXRateFixingDate|FxRateFixingDateDtaSrcSchme|AdditionalTaxRate|ChangesFeesRate|EarlySolicitationRate" +
			       "|FullyFrankedRate|FiscalStampRate|ExchangeRate|CashIncentiveRate|InterestRate|NonResidentRate" +
			       "|ApplicableRate|SolicitationFeeRate|TaxCreditRate|TaxWithholdingRate|TaxOnIncomeRate|TaxOnProfitsRate|ReclaimTaxRate|WithholdingForeignTax|WithholdingLocalTax" +
                   "|IndCreditDebit|IndContractualPayment|IndNonEligibleProceeds|IndNonEligibleProceedsDtaSrcSchme|IndTypeOfIncome|IndTypeOfIncomeDtaSrcSchme|IndIssuerOfferorTaxability" +
                   "|AmtEntitled|AmtEntitledCcy|AmtResulting|AmtResultingCcy|AmtOrigCcyandOrdered|AmtOrigCcyandOrderedCcy|AmtCapitalGains|AmtCapitalGainsCcy|AmtImdemnity|AmtImdemnityCcy|AmtCashInLieuOfShares|AmtCashInLieuOfSharesCcy" + 
                   "|AmtChargesFees|AmtChargesFeesCcy|AmtFullyFranked|AmtFullyFrankedCcy|AmtUnFranked|AmtUnFrankedCcy|AmtTaxFree|AmtTaxFreeCcy|AmtTaxDeferred|AmtTaxDeferredCcy|AmtSundryOtherIncome|AmtSundryOtherIncomeCcy|AmtGross|AmtGrossCcy" +
                   "|AmtInterest|AmtInterestCcy|AmtMarketClaim|AmtMarketClaimCcy|AmtNetCash|AmtNetCashCcy|AmtPrincipalOrCorpus|AmtPrincipalOrCorpusCcy|AmtReInvestment|AmtReInvestmentCcy|AmtTaxCredit|AmtTaxCreditCcy|AmtWitholdingTax|AmtWitholdingTaxCcy" +
                   "|AmtWitholdingForeignTax|AmtWitholdingForeignTaxCcy|AmtWitholdingLocalTax|AmtWitholdingLocalTaxCcy|AmtRedemptonOfPremium|AmtRedemptonOfPremiumCcy|AmtAdditionalTax|AmtAdditionalTaxCcy|AmtIncomePortion|AmtIncomePortionCcy" + 
                   "|AmtExecutingBroker|AmtExecutingBrokerCcy|AmtLocalBrokerComm|AmtLocalBrokerCommCcy|AmtPaySubPayingAgentComm|AmtPaySubPayingAgentCommCcy|AmtRegulatoryFees|AmtRegulatoryFeesCcy|AmtShipping|AmtShippingCcy|AmtSolicitationFee" +
                   "|AmtSolicitationFeeCcy|AmtStampDuty|AmtStampDutyCcy|AmtStockExchangeTax|AmtStockExchangeTaxCcy|AmtVAT|AmtVATCcy|AmtFiscalStamp|AmtFiscalStampCcy|AmtManufacturedDivdndPaymnt|AmtManufacturedDivdndPaymntCcy|AmtReclaimOfTaxes|AmtReclaimOfTaxesCcy|AmtEUTaxRetention|AmtEUTaxRetentionCcy|AmtAccruedInterest|AmtAccruedInterestCcy|AmtEqualisation|AmtEqualisationCcy" +
                   "|RateAdditionalTaxCcy|RateAdditionalTaxAmt|RateAdditionalTaxCode|RateChargesFeesCcy|RateChargesFeesAmt|RateChargesFeesCode|RateEqualisationCcy|RateEqualisationAmt|RateEqualisationCode|RateEarlySolicitationCcy|RateEarlySolicitationAmt|RateEarlySolicitationCode|RateEarlySolicitationQty|RateFinalDivCcy|RateFinalDivAmt|RateFinalDivCode" + 
                   "|RateFullyFrankedCcy|RateFullyFrankedAmt|RateFullyFrankedCode|RateFiscalStampCode|RateGrossCcy|RateGrossAmt|RateGrossCode|RateGrossStatus|RateGrossDtaSrcSchme|RateExchangeCcy1|RateExchangeCcy2|RateCashIncentiveCcy|RateCashIncentiveAmt|RateCashIncentiveCode|RateInterestCcy|RateInterestAmt|RateInterestCode|RateInterestStatus|RateInterestDtaSrcSchme" +
                   "|RateNetDivCcy|RateNetDivAmt|RateNetDivCode|RateNetDivStatus|RateNetDivDtaSrcSchme|RateNonResidentCcy|RateNonResidentAmt|RateNonResidentCode|RateProvisonalDivCcy|RateProvisonalDivAmt|RateProvisonalDivCode|RateApplicableCode|RateSolicitationFeeCcy|RateSolicitationFeeAmt|RateSolicitationFeeCode|RateSolicitationFeeQty" +
                   "|RateTaxCreditCcy|RateTaxCreditAmt|RateTaxCreditCode|RateTaxCreditDtaSrcSchme|RateTaxCreditStatus|RateTaxRelatedDtaSrcSchme|RateTaxRelatedCode|RateTaxRelatedCcy|RateTaxRelatedAmt|RateTaxRelatedStatus|RateTaxWithholdingCode|RateTaxOnIncomeCode|RateTaxOnProfitsCode|RateReclaimTaxCode|RateWithholdForeignTaxCcy|RateWithholdForeignTaxAmt|RateWithholdForeignTaxCode|RateWithholdLocalTaxCcy|RateWithholdLocalTaxAmt|RateWithholdLocalTaxCode" +
                   "|GenericCashPricePaid|GenericCashPricePaidAmtType|GenericCashPricePaidCcy|GenericCashPricePaidPercType|GenericCashPricePaidCode|GenericCashPricePaidIdxPoints" +
                   "|GenericCashPriceReceivedAmt|GenericCashPriceReceived|GenericCashPriceReceivedAmtType|GenericCashPriceReceivedCcy|GenericCashPriceReceivedPercType|GenericCashPriceReceivedQty|GenericCashPriceReceivedQtyType|GenericCashPriceReceivedCode|TagsNotRecognized";
		}

		public override string ToString()
		{
            var sb = new StringBuilder(1000);
            sb.Append("|" + IndCreditDebit); sb.Append("|" + IndContractualPayment); sb.Append("|" + IndNonEligibleProceeds); sb.Append("|" + IndNonEligibleProceedsDtaSrcSchme); sb.Append("|" + IndTypeOfIncome); sb.Append("|" + IndTypeOfIncomeDtaSrcSchme); sb.Append("|" + IndIssuerOfferorTaxability); 
            sb.Append("|" + AmtEntitled) ; sb.Append("|" + AmtEntitledCcy); sb.Append("|" + AmtResulting); sb.Append("|" + AmtResultingCcy); sb.Append("|" + AmtOrigCcyandOrdered); sb.Append("|" + AmtOrigCcyandOrderedCcy); sb.Append("|" + AmtCapitalGains) ; sb.Append("|" + AmtCapitalGainsCcy); 
            sb.Append("|" + AmtImdemnity) ; sb.Append("|" + AmtImdemnityCcy) ; sb.Append("|" + AmtCashInLieuOfShares) ; sb.Append("|" + AmtCashInLieuOfSharesCcy) ; sb.Append("|" + AmtChargesFees) ; sb.Append("|" + AmtChargesFeesCcy) ; sb.Append("|" + AmtFullyFranked) ; sb.Append("|" + AmtFullyFrankedCcy) ; 
            sb.Append("|" + AmtUnFranked) ; sb.Append("|" + AmtUnFrankedCcy) ; sb.Append("|" + AmtTaxFree) ; sb.Append("|" + AmtTaxFreeCcy) ; sb.Append("|" + AmtTaxDeferred) ; sb.Append("|" + AmtTaxDeferredCcy) ; sb.Append("|" + AmtSundryOtherIncome) ; sb.Append("|" + AmtSundryOtherIncomeCcy) ; 
            sb.Append("|" + AmtGross) ; sb.Append("|" + AmtGrossCcy) ; sb.Append("|" + AmtInterest) ; sb.Append("|" + AmtInterestCcy) ; sb.Append("|" + AmtMarketClaim) ; sb.Append("|" + AmtMarketClaimCcy) ; sb.Append("|" + AmtNetCash) ; sb.Append("|" + AmtNetCashCcy) ; sb.Append("|" + AmtPrincipalOrCorpus) ; 
            sb.Append("|" + AmtPrincipalOrCorpusCcy) ; sb.Append("|" + AmtReInvestment) ; sb.Append("|" + AmtReInvestmentCcy) ; sb.Append("|" + AmtTaxCredit) ; sb.Append("|" + AmtTaxCreditCcy) ; sb.Append("|" + AmtWitholdingTax) ; sb.Append("|" + AmtWitholdingTaxCcy) ; sb.Append("|" + AmtWitholdingForeignTax) ; 
            sb.Append("|" + AmtWitholdingForeignTaxCcy) ; sb.Append("|" + AmtWitholdingLocalTax) ; sb.Append("|" + AmtWitholdingLocalTaxCcy) ; sb.Append("|" + AmtRedemptonOfPremium) ; sb.Append("|" + AmtRedemptonOfPremiumCcy) ; sb.Append("|" + AmtAdditionalTax) ; sb.Append("|" + AmtAdditionalTaxCcy) ; 
            sb.Append("|" + AmtIncomePortion) ; sb.Append("|" + AmtIncomePortionCcy) ; sb.Append("|" + AmtExecutingBroker) ; sb.Append("|" + AmtExecutingBrokerCcy) ; sb.Append("|" + AmtLocalBrokerComm) ; sb.Append("|" + AmtLocalBrokerCommCcy) ; sb.Append("|" + AmtPaySubPayingAgentComm) ; sb.Append("|" + AmtPaySubPayingAgentCommCcy) ; 
            sb.Append("|" + AmtRegulatoryFees) ; sb.Append("|" + AmtRegulatoryFeesCcy) ; sb.Append("|" + AmtShipping) ; sb.Append("|" + AmtShippingCcy) ; sb.Append("|" + AmtSolicitationFee) ; sb.Append("|" + AmtSolicitationFeeCcy) ; sb.Append("|" + AmtStampDuty) ; sb.Append("|" + AmtStampDutyCcy) ; sb.Append("|" + AmtStockExchangeTax) ; sb.Append("|" + AmtStockExchangeTaxCcy) ; 
            sb.Append("|" + AmtVAT) ; sb.Append("|" + AmtVATCcy) ; sb.Append("|" + AmtFiscalStamp) ; sb.Append("|" + AmtFiscalStampCcy) ; sb.Append("|" + AmtManufacturedDivdndPaymnt) ; sb.Append("|" + AmtManufacturedDivdndPaymntCcy) ; sb.Append("|" + AmtReclaimOfTaxes) ; sb.Append("|" + AmtReclaimOfTaxesCcy) ; sb.Append("|" + AmtEUTaxRetention) ; sb.Append("|" + AmtEUTaxRetentionCcy) ; 
            sb.Append("|" + AmtAccruedInterest) ; sb.Append("|" + AmtAccruedInterestCcy) ; sb.Append("|" + AmtEqualisation) ; sb.Append("|" + AmtEqualisationCcy) ;
            sb.Append("|" + RateAdditionalTaxCcy); sb.Append("|" + RateAdditionalTaxAmt); sb.Append("|" + RateAdditionalTaxCode); sb.Append("|" + RateChargesFeesCcy); sb.Append("|" + RateChargesFeesAmt); sb.Append("|" + RateChargesFeesCode); sb.Append("|" + RateEqualisationCcy); sb.Append("|" + RateEqualisationAmt); sb.Append("|" + RateEqualisationCode); 
            sb.Append("|" + RateEarlySolicitationCcy); sb.Append("|" + RateEarlySolicitationAmt); sb.Append("|" + RateEarlySolicitationCode); sb.Append("|" + RateEarlySolicitationQty); sb.Append("|" + RateFinalDivCcy); sb.Append("|" + RateFinalDivAmt); sb.Append("|" + RateFinalDivCode); sb.Append("|" + RateFullyFrankedCcy); sb.Append("|" + RateFullyFrankedAmt); sb.Append("|" + RateFullyFrankedCode); 
            sb.Append("|" + RateFiscalStampCode); sb.Append("|" + RateGrossCcy); sb.Append("|" + RateGrossAmt); sb.Append("|" + RateGrossCode); sb.Append("|" + RateGrossStatus); sb.Append("|" + RateGrossDtaSrcSchme); sb.Append("|" + RateExchangeCcy1); sb.Append("|" + RateExchangeCcy2); sb.Append("|" + RateCashIncentiveCcy); sb.Append("|" + RateCashIncentiveAmt); sb.Append("|" + RateCashIncentiveCode); 
            sb.Append("|" + RateInterestCcy); sb.Append("|" + RateInterestAmt); sb.Append("|" + RateInterestCode); sb.Append("|" + RateInterestStatus); sb.Append("|" + RateInterestDtaSrcSchme); sb.Append("|" + RateNetDivCcy); sb.Append("|" + RateNetDivAmt); sb.Append("|" + RateNetDivCode); sb.Append("|" + RateNetDivStatus); sb.Append("|" + RateNetDivDtaSrcSchme); sb.Append("|" + RateNonResidentCcy); 
            sb.Append("|" + RateNonResidentAmt); sb.Append("|" + RateNonResidentCode); sb.Append("|" + RateProvisonalDivCcy); sb.Append("|" + RateProvisonalDivAmt); sb.Append("|" + RateProvisonalDivCode); sb.Append("|" + RateApplicableCode); sb.Append("|" + RateSolicitationFeeCcy); sb.Append("|" + RateSolicitationFeeAmt); sb.Append("|" + RateSolicitationFeeCode); sb.Append("|" + RateSolicitationFeeQty); 
            sb.Append("|" + RateTaxCreditCcy); sb.Append("|" + RateTaxCreditAmt); sb.Append("|" + RateTaxCreditCode); sb.Append("|" + RateTaxCreditDtaSrcSchme); sb.Append("|" + RateTaxCreditStatus); sb.Append("|" + RateTaxRelatedDtaSrcSchme); sb.Append("|" + RateTaxRelatedCode); sb.Append("|" + RateTaxRelatedCcy); sb.Append("|" + RateTaxRelatedAmt); sb.Append("|" + RateTaxRelatedStatus); sb.Append("|" + RateTaxWithholdingCode);
            sb.Append("|" + RateTaxOnIncomeCode); sb.Append("|" + RateTaxOnProfitsCode); sb.Append("|" + RateReclaimTaxCode); sb.Append("|" + RateWithholdForeignTaxCcy); sb.Append("|" + RateWithholdForeignTaxAmt); sb.Append("|" + RateWithholdForeignTaxCode); sb.Append("|" + RateWithholdLocalTaxCcy); sb.Append("|" + RateWithholdLocalTaxAmt); sb.Append("|" + RateWithholdLocalTaxCode);
            sb.Append("|" + GenericCashPricePaid); sb.Append("|" + GenericCashPricePaidAmtType); sb.Append("|" + GenericCashPricePaidCcy); sb.Append("|" + GenericCashPricePaidPercType); sb.Append("|" + GenericCashPricePaidCode); sb.Append("|" + GenericCashPricePaidIdxPoints);
            sb.Append("|" + GenericCashPriceReceivedAmt); sb.Append("|" + GenericCashPriceReceived); sb.Append("|" + GenericCashPriceReceivedAmtType); sb.Append("|" + GenericCashPriceReceivedCcy); sb.Append("|" + GenericCashPriceReceivedPercType); sb.Append("|" + GenericCashPriceReceivedQty); sb.Append("|" + GenericCashPriceReceivedQtyType); sb.Append("|" + GenericCashPriceReceivedCode); sb.Append("|" + _TagsNotRecognized);

            return CARef + "|" + SenderRef + "|" + CAOptionNumber + "|" + _subsequenceNumber + "|" + CashAccount + "|" + PayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PayDateDtaSrcSchme + "|" + ValueDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ValueDateDtaSrcSchme + "|" + EarliestPayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EarliestPayDateDtaSrcSchme + "|" + FxRateFixingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + FxRateFixingDateDtaSrcSchme + "|" + AdditionalTaxRate + "|" + ChangesFeesRate + "|" + EarlySolicitationRate +
			       "|" + FullyFrankedRate + "|" + FiscalStampRate + "|" + ExchangeRate + "|" + CashIncentiveRate + "|" + InterestRate + "|" + NonResidentRate +  
			       "|" + ApplicableRate + "|" + SolicitationFeeRate + "|" + TaxCreditRate + "|" + TaxWithholdingRate + "|" + TaxOnIncomeRate + "|" + TaxOnProfitsRate + "|" + ReclaimTaxRate + "|" + WithholdingForeignTax + "|" + WithholdingLocalTax 
			       + sb.ToString();
		}



        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifiers where duplicates not allowed, ELSE cache the duplicate data for qualifiers
            //where overflow values are expected.
            //Called by base Sequence class for placeholder and specialised Vendor classes(if applicable) where duplicates are allowed
            // i.e dividend breakdown partially franked etc
            switch (tag.Substring(0, 2))
            {
                case "92":
                    if (!(placeHolderOnly))
                    {
                        var dataValue = new XmlDocument();
                        dataValue.LoadXml("<TagValue Amount=\"" + _amount.ToString() + "\" Rate=\"" + _rate.ToString() + "\" Ccy= \"" + _ccy + "\" TypeCode=\"" + _typeCode + "\" Quantity=\"" + _quantity.ToString() + "\" Ccy2=\"" + _ccy2 + "\" DSScheme=\"" + _dataSourceScheme + "\" RateStatus=\"" + _rateStatus + "\" />");
                        base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier, dataValue), false);
                    }
                    break;
                default:
                   //PlaceHolder
                    if (placeHolderOnly)
                    {
                        base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), placeHolderOnly);
                    }
                    break;

            }

         }
	}
}