﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ftse.Research.Framework.IO;

namespace FTSE.MT564CAParser.FileManager
{
    internal class Options
    {

        private static readonly Options _instance = new Options();
        private ArgumentParser _options;

        public static Options GetOptions()
        {
            return _instance;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref = "DataCacheManager" /> class.
        /// </summary>
        /// <remarks>
        ///     Being <c>private</c> enforces the singleton pattern.
        /// </remarks>
        private Options()
        {
        }
        public void OptionsInit(ArgumentParser fileOptions)
        {
            _options = fileOptions;
        }
        public string this [string option]
        {
           // get   { return _options.Parameters[option];} 
            get { return _options.Parameters[option]; }
        }
    }
}
