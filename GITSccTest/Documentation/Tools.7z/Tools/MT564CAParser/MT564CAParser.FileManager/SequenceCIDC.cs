﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;


namespace FTSE.MT564CAParser.FileManager
{
    /// <summary>
    /// Class that implements specific behaviour for IDC MT564 Sequence C Messages.
    /// Extend with additional parse methods(if required) specific to  IDC
    /// </summary>
    class SequenceCIDC : SequenceC
    {

        internal override void Parse(string code, string text)
        {
            // Parse in Base Class if not 35B
            if ((code == "35B"))
            {
                base.SequenceTagOverflowProcess(GetType().BaseType.Name, code, text.Split(new[] { "/" }, StringSplitOptions.None)[0], true);
                ParseField35B(text);
            }
            else
                base.Parse(code, text);

        }
        /// <summary>
        /// CRLF removed by generic Parse Code and because no / delimiter
        /// after SEDOL assume first seven chars in 2nd entry of array is SEDOL.
        /// i.e we have no 'end of SEDOL' delimiter to frame the SEDOL field explicitly
        /// </summary>
        /// <param name="input"></param>
        /// <param name="sedol"></param>
        /// <param name="entity"></param>
        private void ParseField35B(string input)
        {
            
            VendorIDCHelper.ParseField35B(input, out _sedol, out _entity, out _ISIN, out _countrycode);


        }
    }
}

