﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Sequence F of MT564 - Additional Information
	/// </summary>
	internal class SequenceF: Sequence
	{
       
		#region SWIFT Message attributes
		// 70E - Narrative
        internal string AdditionalText { get; private set; }
        internal string Narrative { get; private set; }
        internal string InformationConditions { get; private set; }
        internal string InformationComplied { get; private set; }
		
        internal string TextDeclaration { get; private set; }
        internal string TextRegistration { get; private set; }
        internal string TextPartyContact { get; private set; }
        internal string TextDisclaimer { get; private set; }
        internal string TextBasketOrIndex { get; private set; }
        internal string TextTaxationConditions { get; private set; }

		
		// 95A - Party
        internal string PartyOriginator { get; private set; }
        internal string PartyOriginatorType { get; private set; }
        internal string PartyOriginatorDtaSrcSchme { get; private set; }
        internal string PartyRecipient { get; private set; }
        internal string PartyRecipientType { get; private set; }
        internal string PartyRecipientDtaSrcSchme { get; private set; }
        internal string PartyIssueAgnt { get; private set; }
        internal string PartyIssueAgntType { get; private set; }
        internal string PartyIssueAgntDtaSrcSchme { get; private set; }
        internal string PartyPayngAgnt { get; private set; }
        internal string PartyPayngAgntType { get; private set; }
        internal string PartyPayngAgntDtaSrcSchme { get; private set; }
        internal string PartySubPayngAgnt { get; private set; }
        internal string PartySubPayngAgntType { get; private set; }
        internal string PartySubPayngAgntDtaSrcSchme { get; private set; }
        internal string PartyRegistrar { get; private set; }
        internal string PartyRegistrarType { get; private set; }
        internal string PartyRegistrarDtaSrcSchme { get; private set; }
        internal string PartyDropAgnt { get; private set; }
        internal string PartyDropAgntType { get; private set; }
        internal string PartyDropAgntDtaSrcSchme { get; private set; }
        internal string PartyPhysicalSecsAgnt { get; private set; }
        internal string PartyPhysicalSecsAgntType { get; private set; }
        internal string PartyPhysicalSecsAgntDtaSrcSchme { get; private set; }
        internal string PartyResellingAgnt { get; private set; }
        internal string PartyResellingAgntType { get; private set; }
        internal string PartyResellingAgntDtaSrcSchme { get; private set; }
        internal string PartySolicitationAgnt { get; private set; }
        internal string PartySolicitationAgntType { get; private set; }
        internal string PartySolicitationAgntDtaSrcSchme { get; private set; }
        internal string PartyInformationAgnt { get; private set; }
        internal string PartyInformationAgntType { get; private set; }
        internal string PartyInformationAgntDtaSrcSchme { get; private set; }
		#endregion


   
        internal SequenceF() { }
		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
            base.Parse(code, text);
			switch (code)
			{
				case "70E": ParseField70E(code, text); break;
				case "95P":
                case "95R": 
				case "95Q":	ParseField95A(code, text); break;
				case "16R": // Nop
					break;
				case "16S": // Nop
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}

		/// <summary>
		/// Narrative
		/// </summary>
		/// <example>Option E	:4!c//10*35x	(Qualifier)(Narrative)</example>
        internal void ParseField70E(string code, string input)
		{
            ParseField70EOptions(input);
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			switch (s[0])
			{
				case "ADTX": AdditionalText = s[1]; break;
				case "TXNR": Narrative = s[1]; break;
				case "INCO": InformationConditions = s[1]; break;
				case "COMP": InformationComplied = s[1]; break;
                case "DECL": TextDeclaration = s[1]; break;
                case "REGI": TextRegistration = s[1]; break;
                case "PACO": TextPartyContact = s[1]; break;
                case "TAXE": TextTaxationConditions = s[1]; break;
                case "DISC": TextDisclaimer = s[1]; break;
                case "BAIN": TextBasketOrIndex = s[1]; break;

                default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                break;
				
			}

           
		}

		/// <summary>
		/// Party
		/// </summary>
		/// <example>Option P	:4!c//4!a2!a2!c[3!c]	(Qualifier)(Identifier Code)
		///			 Option Q	:4!c//4*35x	(Qualifier)(Name and Address)
		///			 Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)
		/// </example>
		internal void ParseField95A(string code, string input)
		{
			// Option P, Q or R?
 
            if (
              !(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$")) //Option P
              && !(Regex.IsMatch(input, @"^[A-Z]{4}//.{0,160}$", RegexOptions.Singleline)) //Option Q
              && !(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/.{0,34}$", RegexOptions.Singleline)) //Option R

              )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 95A", GetType().Name));
            }

            var s = input.Split(new[] { "/" }, StringSplitOptions.None);

            string partyType = null;
            string dtaSrcSchme = null;

            switch (code.Substring(2,1))
            {
                case "P":
                    partyType = "BIC";
                    break;
                case "Q":
                    partyType = "Name";
                    break;
                case "R":
                    partyType = "Proprietary";
                    dtaSrcSchme = s[1];
                    break;
                default:
                    throw new UnexpectedFormatException(String.Format("{0}: The Party value in field 98 is not valid: {1}. Note that only Option P, Q, R is supported. ", GetType().Name, input));
            }

   
            switch (s[0])
            {
                case "MEOR":
                    PartyOriginator = s[2];
                    PartyOriginatorType = partyType;
                    PartyOriginatorDtaSrcSchme = dtaSrcSchme;
                    break;
                case "MERE":
                    PartyRecipient = s[2];
                    PartyRecipientType = partyType;
                    PartyRecipientDtaSrcSchme = dtaSrcSchme;
                    break;
                case "ISAG":
                    PartyIssueAgnt = s[2];
                    PartyIssueAgntType = partyType;
                    PartyIssueAgntDtaSrcSchme = dtaSrcSchme;
                    break;
                case "PAYA":
                    PartyPayngAgnt = s[2];
                    PartyPayngAgntType = partyType;
                    PartyPayngAgntDtaSrcSchme = dtaSrcSchme;
                    break;
                case "CODO":
                    PartySubPayngAgnt = s[2];
                    PartySubPayngAgntType = partyType;
                    PartySubPayngAgntDtaSrcSchme = dtaSrcSchme;
                    break;
                case "REGR":
                    PartyRegistrar = s[2];
                    PartyRegistrarType = partyType;
                    PartyRegistrarDtaSrcSchme = dtaSrcSchme;
                    break;
                case "DROP":
                    PartyDropAgnt = s[2];
                    PartyDropAgntType = partyType;
                    PartyDropAgntDtaSrcSchme = dtaSrcSchme;
                    break;
                case "PSAG":
                    PartyPhysicalSecsAgnt = s[2];
                    PartyPhysicalSecsAgntType = partyType;
                    PartyPhysicalSecsAgntDtaSrcSchme = dtaSrcSchme;
                    break;
                case "RESA":
                    PartyResellingAgnt = s[2];
                    PartyResellingAgntType = partyType;
                    PartyResellingAgntDtaSrcSchme = dtaSrcSchme;
                    break;
                case "SOLA":
                    PartySolicitationAgnt = s[2];
                    PartySolicitationAgntType = partyType;
                    PartySolicitationAgntDtaSrcSchme = dtaSrcSchme;
                    break;
                case "INFA":
                    PartyInformationAgnt = s[2];
                    PartyInformationAgntType = partyType;
                    PartyInformationAgntDtaSrcSchme = dtaSrcSchme;
                    break;

                default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                    break;

            }

		}

        internal static string GetHeaders()
		{
            return "AdditionalText|Narrative|InformationConditions|InformationComplied|TextDeclaration|TextRegistration|TextPartyContact|TextDisclaimer|TextBasketOrIndex|TextTaxationConditions|PartyOriginator|PartyOriginatorType|PartyOriginatorDtaSrcSchme" +
                "|PartyRecipient|PartyRecipientType|PartyRecipientDtaSrcSchme|PartyIssueAgnt|PartyIssueAgntType|PartyIssueAgntDtaSrcSchme|PartyPayngAgnt|PartyPayngAgntType|PartyPayngAgntDtaSrcSchme|PartySubPayngAgnt|PartySubPayngAgntType|PartySubPayngAgntDtaSrcSchme" +
                "|PartyRegistrar|PartyRegistrarType|PartyRegistrarDtaSrcSchme|PartyDropAgnt|PartyDropAgntType|PartyDropAgntDtaSrcSchme|PartyPhysicalSecsAgnt|PartyPhysicalSecsAgntType|PartyPhysicalSecsAgntDtaSrcSchme" +
                "|PartyResellingAgnt|PartyResellingAgntType|PartySolicitationAgntDtaSrcSchme|PartyInformationAgnt|PartyInformationAgntType|PartyInformationAgntDtaSrcSchme|TagsNotRecognizedSeqF";
		}

		public override string ToString()
		{
            var sb = new StringBuilder(1000);
            sb.Append("|" + PartyOriginator); sb.Append("|" + PartyOriginatorType); sb.Append("|" + PartyOriginatorDtaSrcSchme); sb.Append("|" + PartyRecipient); sb.Append("|" + PartyRecipientType); sb.Append("|" + PartyRecipientDtaSrcSchme); 
            sb.Append("|" + PartyIssueAgnt); sb.Append("|" + PartyIssueAgntType); sb.Append("|" + PartyIssueAgntDtaSrcSchme); sb.Append("|" + PartyPayngAgnt); sb.Append("|" + PartyPayngAgntType); sb.Append("|" + PartyPayngAgntDtaSrcSchme); 
            sb.Append("|" + PartySubPayngAgnt); sb.Append("|" + PartySubPayngAgntType); sb.Append("|" + PartySubPayngAgntDtaSrcSchme); sb.Append("|" + PartyRegistrar); sb.Append("|" + PartyRegistrarType); sb.Append("|" + PartyRegistrarDtaSrcSchme); 
            sb.Append("|" + PartyDropAgnt); sb.Append("|" + PartyDropAgntType); sb.Append("|" + PartyDropAgntDtaSrcSchme); sb.Append("|" + PartyPhysicalSecsAgnt); sb.Append("|" + PartyPhysicalSecsAgntType); sb.Append("|" + PartyPhysicalSecsAgntDtaSrcSchme);
            sb.Append("|" + PartyResellingAgnt); sb.Append("|" + PartyResellingAgntType); sb.Append("|" + PartySolicitationAgntDtaSrcSchme); sb.Append("|" + PartyInformationAgnt); sb.Append("|" + PartyInformationAgntType); sb.Append("|" + PartyInformationAgntDtaSrcSchme); sb.Append("|" + _TagsNotRecognized);

            return AdditionalText + "|" + Narrative + "|" + InformationConditions + "|" + InformationComplied + "|" + TextDeclaration + "|" + TextRegistration + "|" + TextPartyContact + "|" + TextDisclaimer + "|" + TextBasketOrIndex + "|" + TextTaxationConditions + sb.ToString();
		}

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }
	}
}