﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;
using Ftse.Research.Framework.Logging;
using log4net;
using System.Configuration;


namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Current sequence being parsed
	/// </summary>
	public enum CurrentSequence { A, B, C, D, E, F, X};

	public enum CurrentSubsequence { None, B1, E1, E2 };

    

	public class SwiftMessage564
	{
        private static readonly ILog Logger = LogProvider.GetLogger();
		/// <summary>
		/// This list of MT564 codes specifies the messages types required by FTSE's business
		/// </summary>
		//public readonly static string[] RequiredCorporateActionsTypes = new[]{"ACTV", "BIDS", "BONU", "BRUP", "CAPD", "CHAN", "CONV", "DECR", "DLST", "DRIP", "DTCH", "DVCA", "DVOP", "DVSC", "DVSE", "EXOF", "INCR", "LIQU",
		//	                           		"MRGR", "ODLT", "PARI", "PLAC", "PRIO", "REDO", "RHDI", "RHTS", "SHPR", "SOFF", "SPLF", "SPLR", "SUSP", "TEND"};
        //internal readonly static string[] CorporateActionsTypesToExclude;

        //FTSE.MT564CAParser.Main.Properties.Settings.Default.CAEventsToExclude
        //public object xry = Settings.Default.ServiceReportingInterval * 60 * 1000;
        //FTSE.MT564CAParser.Main.Properties.Settings
 
        //Settin
		private bool _isVerboseOutput;
		private readonly List<UnexpectedCodeException> _unexpectedCodeExceptions = new List<UnexpectedCodeException>();


		#region Properties
		public List<UnexpectedCodeException> UnexpectedCodeExceptions
		{
			get { return _unexpectedCodeExceptions; }
		}

		/// <summary>
		/// Contains Section A - General Information of SWIFT message
		/// </summary>
		internal SequenceA SequenceA { get; private set; }
		internal SequenceB SequenceB { get; private set; }
        internal SequenceC SequenceC { get; private set; }
        internal SequenceD SequenceD { get; private set; }
        internal List<SequenceE> SequencesE { get; set; }
        internal SequenceF SequenceF { get; private set; }
		/// <summary>
		/// If set indicates that the message parsed is valid
		/// </summary>
		public bool IsValid { get; set; }
		public bool IsRequiredType
		{
			get { return SequenceA.IsRequiredType; }
		}
		#endregion

		public Exception ProcessingException { get; set; }
		private SequenceE _sequenceE;
		private CurrentSequence _currentSequence = CurrentSequence.X;
		private readonly List<string> _messageLines; // = new List<string>();
        private string _originalMessage;

		internal string OriginalMessage
		{
			get 
			{ 

                return _originalMessage;
			}
		}

		#region Constructors
        public SwiftMessage564(List<string> messageLines, string fileAndPathName)
		{

           	_messageLines = messageLines;

            var sb = new StringBuilder(_messageLines.Count);
            foreach (var messageLine in _messageLines)
                sb.AppendLine(messageLine);
            _originalMessage = sb.ToString();

            
            SequenceA = new SequenceA(fileAndPathName);
	        SequenceC = (SequenceC)SequenceFactory.CreateSequence(CurrentSequence.C, Options.GetOptions()["vendor"]);
			SequenceD = new SequenceD();
			SequencesE = new List<SequenceE>();
			SequenceF = new SequenceF();
		}
		#endregion

		/// <summary>
		/// Parses the message without full message information
		/// </summary>
		public void Parse()
		{
			Parse(false);
		}

		/// <summary>
		/// Parses the message and outputs full message information if true is passed
		/// </summary>
		public void Parse(bool isVerboseOutput)
		{
			_isVerboseOutput = isVerboseOutput;
			var buffer = new StringBuilder();
			var regexCode = new Regex(@":[0-9][0-9][A-Z]:");
			var stackCode = new Stack<bool>();

			string line = string.Empty;
			foreach (string messageLine in _messageLines)
			{
				line = messageLine;
				if (!regexCode.IsMatch(messageLine))
				{
					// Line without code
                    if (!(messageLine.StartsWith("Message") || messageLine.StartsWith("${") || messageLine.StartsWith("{") || messageLine.StartsWith("-}$")))
						buffer.Append(messageLine);
					continue;
				}
				ParseBuffer(buffer, line, stackCode);
			}
			ParseBuffer(buffer, line, stackCode);
		}

		private void ParseBuffer(StringBuilder buffer, string messageLine, Stack<bool> stackCode)
		{
			if (stackCode.Count > 0 && stackCode.Peek())
			{
				if (_isVerboseOutput)
					LogProvider.GetLogger().InfoFormat(buffer.ToString());
				ParseBuffer(buffer.ToString());

				stackCode.Pop();
				buffer.Clear();

				buffer.Append(messageLine);
				stackCode.Push(true);
				return;
			}

			stackCode.Push(true);
			buffer.Clear();
			buffer.Append(messageLine);
		}


		private void ParseBuffer(string input)
		{
			var regexCode = new Regex(@":[0-9][0-9][A-Z]:{1,2}");
			if (regexCode.IsMatch(input))
			{
				MatchCollection matchCollection = regexCode.Matches(input);
				string remainingText = regexCode.Replace(input, string.Empty);

				ParseCode(matchCollection[0].Value, remainingText);
				return;
			}

            if (!input.StartsWith("${") && !input.StartsWith("Message"))
				throw new Exception("The current sequence did not start with a code.");
		}

		private void ParseCode(string code, string text)
		{
			code = code.Replace(":", string.Empty).ToUpperInvariant();

			var regexColon = new Regex(@"^:+");
			text = regexColon.Replace(text, string.Empty);

			var regexTab = new Regex("\t");
			text = regexTab.Replace(text, string.Empty);
			text = text.Trim();

			if (code == "16R")
				switch (text)
				{
					case "GENL":
                        //Created in constructor so remove
						_currentSequence = CurrentSequence.A;
						break;

					case "USECU":
                        //Created in constructor so remove
                        SequenceB = (SequenceB)SequenceFactory.CreateSequence(CurrentSequence.B, Options.GetOptions()["vendor"], SequenceA.CARef, SequenceA.SenderRef);
						_currentSequence = CurrentSequence.B;
						break;

					case "INTSEC":
                        //Created in constructor so remove
						_currentSequence = CurrentSequence.C;
						break;

					case "CAOPTN": 
                        //_sequenceE = new SequenceE(SequenceA.CARef, SequenceA.SenderRef);
                        _sequenceE = (SequenceE)SequenceFactory.CreateSequence(CurrentSequence.E, Options.GetOptions()["vendor"], SequenceA.CARef, SequenceA.SenderRef);
						_currentSequence = CurrentSequence.E;
						break;

					case "CADETL":
                        //Created in constructor so remove
						_currentSequence = CurrentSequence.D;
						break;

					case "ADDINFO":
                       	_currentSequence = CurrentSequence.F;
						break;
				}

			
				switch (_currentSequence)
				{
					case CurrentSequence.A: SequenceA.Parse(code, text);
						break;
					case CurrentSequence.B: SequenceB.Parse(code, text);
						break;
					case CurrentSequence.C: SequenceC.Parse(code, text);
						break;
					case CurrentSequence.D: SequenceD.Parse(code, text);
						break;
					case CurrentSequence.E: _sequenceE.Parse(code, text);
						break;
					case CurrentSequence.F: SequenceF.Parse(code, text);
						break;
                    default: throw new Exception("Current sequence not recognized, check source file is not corrupted.");
				}
			

			if (code == "16S")
				switch(text)
				{
					case "GENL": // NOP
						break;

					case "CAOPTN": // End of E sequence - add to collection
						SequencesE.Add(_sequenceE);
						break;
				}
		}

		public override string ToString()
		{
			var sb = new StringBuilder(_messageLines.Count);
			foreach (var messageLine in _messageLines)
				sb.Append(messageLine);
			return sb.ToString();
		}
	}
}