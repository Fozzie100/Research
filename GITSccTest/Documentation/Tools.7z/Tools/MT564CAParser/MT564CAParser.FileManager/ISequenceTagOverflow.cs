﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTSE.MT564CAParser.FileManager
{
    public interface ISequenceTagOverflow
    {
        //string SequenceName { get; set; }
        //string Tag { get; set; }
        //string Qualifier { get; set; }
        void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly);
    }
}
