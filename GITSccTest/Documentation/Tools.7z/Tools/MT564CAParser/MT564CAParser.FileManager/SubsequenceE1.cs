﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Text;
using System.Xml;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	internal class SubsequenceE1: Sequence
	{
		
		//private bool _isInE1A;
		internal readonly int _subsequenceNumber;


        internal string CARef { get; private set; }
        internal string SenderRef { get; private set; }
        internal int CAOptionNumber { get; private set; }

		public SubsequenceE1(string caRef, string senderRef, int caOptionNumber, int number) 
		{
			CAOptionNumber = caOptionNumber;
            CARef = caRef;
            SenderRef = senderRef;

			_subsequenceNumber = number;
		}

		#region SWIFT Message attributes
        ///// <summary>
        ///// 22 - E1
        ///// </summary>
        //public string IndicatorType { get; set; }
        ///// <summary>
        ///// 22 - E1
        ///// </summary>
        //public new string Indicator { get; set; }
        internal string IndCreditDebit { get; set; }
        internal string IndTemporary { get; set; }
        internal string IndTemporaryDtaSrcSchme { get; set; }
        internal string IndNonEligibleProceeds { get; set; }
        internal string IndNonEligibleProceedsDtaSrcSchme { get; set; }
        internal string IndIssuerTaxability { get; set; }
        internal string IndNewSecuritiesIssuance { get; set; }


        protected internal string _sedol;
        protected internal string _entity;
        protected internal string _ISIN;
        protected internal string _countrycode;

        /// <summary>
        /// 35B - Security SEDOL
        /// </summary>
        internal string InstrTicker
        {
            get { return _sedol; }
        }

        /// <summary>
        /// 35B - Security Description
        /// </summary>
        internal string InstrDescription
        {
            get { return _entity; }
        }
        /// <summary>
        /// 35B - ISIN
        /// </summary>
        internal string InstrISIN
        {
            get { return _ISIN; }
        }
        /// <summary>
        /// 35B - CountryCode
        /// </summary>
        internal string InstrCntryCode
        {
            get { return _countrycode; }
        }

		#region SWIFT Message attributes-E1a
		/// <summary>
		/// 94B - E1a
		/// </summary>
        internal string PlaceListingType { get; set; }
		/// <summary>
		/// 94B - E1a
		/// </summary>
        internal string PlaceListing { get; set; }
        /// <summary>
        /// 94B - E1a
        /// </summary>
        internal string PlaceListingDtaSrcSchme { get; set; }
		/// <summary>
		/// 22F - E1a
		/// </summary>
		protected internal string MICO { get; set; }
        /// <summary>
        /// 22F - E1a
        /// </summary>
        protected internal string MICODtaSrcSchme { get; set; }
		/// <summary>
		/// 12a - E1
		/// </summary>
        // protected internal string InstrTypeCode { get; set; }
        ///// <summary>
        ///// 12a - E1
        ///// </summary>
        // protected internal string InstrType { get; set; }
        /// <summary>
        /// 12a - E1
        /// </summary>
        protected internal string InstrClassification { get; set; }
        protected internal string InstrClassificationDtaSrcSchme { get; set; }

        /// <summary>
        /// 12a - E1
        /// </summary>
        protected internal string InstrOptionStyle { get; set; }
        protected internal string InstrOptionStyleDtaSrcSchme { get; set; }
		/// <summary>
		/// 11a - E1
		/// </summary>
        internal string InstrCurrency { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrCouponDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrFloatingRateDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrMaturityDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrIssueDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrCallDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrPutDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrDatedDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
        internal DateTime? InstrConvDate { get; set; }
		
        /// <summary>
		/// 90A - E1a
		/// </summary>
        internal decimal? InstrIssuPrice { get; set; }
		/// <summary>
		/// 90A - E1a
		/// </summary>
        internal string InstrIssuPriceAmtType { get; set; }
		/// <summary>
		/// 90A - E1a
		/// </summary>
        internal string InstrIssuPriceCcy { get; set; }
        /// <summary>
        /// 90A - E1a
        /// </summary>
        internal string InstrIssuPricePercType { get; set; }


		
        /// <summary>
		/// 92A - E1a
		/// </summary>
        //public string InstrRateType { get; set; }
        ///// <summary>
        ///// 92A - E1a
        ///// </summary>
        //public decimal? InstrRate { get;  set; }

        internal decimal? InstrRatePreviousFactor { get; set; }
        internal decimal? InstrRateNextFactor { get; set; }
        internal decimal? InstrRateInterest { get; set; }
        internal decimal? InstrRateInterestNext { get; set; }
		/// <summary>
		/// 36B - E1a -  Quantity of Financial Instrument
		/// </summary>
		//public string InstrQuantityType { get;  set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
        internal decimal? InstrMinNomQuantity { get; set; }
        internal string InstrMinNomQuantityType { get; set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
        internal decimal? InstrMinExQuantity { get; set; }
        internal string InstrMinExQuantityType { get; set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
        internal decimal? InstrMinExMQuantity { get; set; }
        internal string InstrMinExMQuantityType { get; set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
        internal decimal? InstrContractSize { get; set; }
        internal string InstrContractSizeType { get; set; }
		#endregion
		// *************************************************End of E1a *****************************************************

		/// <summary>
		/// 36B - E1
		/// </summary>
        internal string EntitledQuantityType { get; private set; }

		/// <summary>
		/// 36B - E1
		/// </summary>
        internal decimal? EntitledQuantity { get; private set; }

		/// <summary>
		/// 22F
		/// </summary>
        internal string DispositionFractions { get; private set; }
        internal string DispositionFractionsDtaSrcSchme { get; private set; }

		/// <summary>
		/// 11A
		/// </summary>
        internal string CurrencyOption { get; private set; }

		/// <summary>
		/// 69A - Period
		/// </summary>
        internal DateTime? TradingPeriodStart { get; set; }

		/// <summary>
		/// 69A - Period
		/// </summary>
        internal DateTime? TradingPeriodEnd { get; set; }

		/// <summary>
		/// 90A - E1
		/// </summary>
        internal decimal? IndicativePrice { get; private set; }
		/// <summary>
		/// 90A - E1
		/// </summary>
        internal decimal? MarketPrice { get; private set; }
		/// <summary>
		/// 90A - E1
		/// </summary>
        internal decimal? CashInLieuSharesPrice { get; private set; }

        internal string IndicativePricePercType { get; private set; }
        internal string IndicativePriceAmtType { get; private set; }
        internal string IndicativePriceCcy { get; private set; }
        internal string IndicativePriceCode { get; private set; }
        internal string MarketPricePercType { get; private set; }
        internal string MarketPriceAmtType { get; private set; }
        internal string MarketPriceCcy { get; private set; }
        internal string MarketPriceCode { get; private set; }
        internal string CashInLieuSharesPricePercType { get; private set; }
        internal string CashInLieuSharesPriceAmtType { get; private set; }
        internal string CashInLieuSharesPriceCcy { get; private set; }
        internal string CashInLieuSharesPriceCode { get; private set; }
        internal decimal? GenericCashPriceReceived { get; private set; }
        internal string GenericCashPriceReceivedAmtType { get; private set; }
        internal string GenericCashPriceReceivedCcy { get; private set; }
        internal string GenericCashPriceReceivedPercType { get; private set; }
        internal decimal? GenericCashPriceReceivedQty { get; private set; }
        internal string GenericCashPriceReceivedQtyType { get; private set; }
        internal string GenericCashPriceReceivedCode { get; private set; }
        internal decimal? GenericCashPricePaid { get; private set; }
        internal string GenericCashPricePaidAmtType { get; private set; }
        internal decimal? GenericCashPriceReceivedAmt { get; private set; }
        internal string GenericCashPricePaidCcy { get; private set; }
        internal string GenericCashPricePaidPercType { get; private set; }
        internal string GenericCashPricePaidCode { get; private set; }
        internal decimal? GenericCashPricePaidIdxPoints { get; private set; }
        internal decimal? CashValueTaxPrice { get; private set; }
        internal string CashValueTaxPriceAmtType { get; private set; }
        internal string CashValueTaxPriceCcy { get; private set; }
        internal string CashValueTaxPriceCode { get; private set; }

        ///// <summary>
        ///// 90A
        ///// </summary>
        internal decimal? RateAddtionXistngSecQty1 { get; private set; }
        internal decimal? RateAddtionXistngSecQty2 { get; private set; }
        internal decimal? RateAddtionXistngSecAmt1 { get; private set; }
        internal decimal? RateAddtionXistngSecAmt2 { get; private set; }
        internal string RateAddtionXistngSecCcy1 { get; private set; }
        internal string RateAddtionXistngSecCcy2 { get; private set; }
        internal decimal? RateNewToOldSecQty1 { get; private set; }
        internal decimal? RateNewToOldSecQty2 { get; private set; }
        internal decimal? RateNewToOldSecAmt1 { get; private set; }
        internal decimal? RateNewToOldSecAmt2 { get; private set; }
        internal string RateNewToOldSecCcy1 { get; private set; }
        internal string RateNewToOldSecCcy2 { get; private set; }

        internal decimal? RateAddtionSubscrbedResultntSecQty1 { get; private set; }
        internal decimal? RateAddtionSubscrbedResultntSecQty2 { get; private set; }
        internal decimal? RateAddtionSubscrbedResultntSecAmt1 { get; private set; }
        internal decimal? RateAddtionSubscrbedResultntSecAmt2 { get; private set; }
        internal string RateAddtionSubscrbedResultntSecCcy1 { get; private set; }
        internal string RateAddtionSubscrbedResultntSecCcy2 { get; private set; }

        internal decimal? RateTransformationRate { get; private set; }
        internal decimal? RateChargesFeesRate { get; private set; }
        internal string RateChargesFeesCcy { get; private set; }
        internal decimal? RateChargesFeesAmt { get; private set; }
        internal decimal? RateFiscalStampRate { get; private set; }
        internal decimal? RateApplicable { get; private set; }

        internal decimal? RateTaxCredit { get; private set; }
        internal string RateTaxCreditCcy { get; private set; }
        internal decimal? RateTaxCreditAmt { get; private set; }
        internal string RateTaxCreditDtaSrcSchme { get; private set; }
        internal string RateTaxCreditTypeCode { get; private set; }
        internal string RateTaxCreditStatus { get; private set; }



		/// <summary>
		/// 98A - E1
		/// </summary>
        internal DateTime? PayDate { get; set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
        internal DateTime? AvailableDate { get; private set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
        internal DateTime? DividendRankDate { get; private set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
        internal DateTime? EarliestPayDate { get; private set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
        internal DateTime? PariPassuDate { get; private set; }
        /// <summary>
        /// 98A - E1
        /// </summary>
        internal DateTime? LastTradingDate { get; private set; }
		#endregion

		/// <summary>
		/// Main Parse method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
            switch (code)
            {
                case "16R": ParseField16R(text); return;
                case "16S": ParseField16S(text); return;
            }
            base.Parse(code, text);
            if (_isInE1A)
            {
                //_subsequenceE1A.Parse(code, text);

                //FIA Parse
               
                switch (code)
                {
                    case "94B": FIParseField94B(code, text); break;
                    case "22F": FIParseField22F(code, text); break;
                    case "12A": FIParseField12A(code, text); break;
                    case "11A": FIParseField11A(code, text); break;
                    case "98A": FIParseField98A(code, text); break;

                    case "90E":
                    case "90B":
                    case "90A": FIParseField90A(code, text); break;

                    case "92A":
                    case "92K":
                                FIParseField92A(code, text); break;
                    case "36B": FIParseField36B(code, text); break;

                    default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered in SubsequenceE1a.", GetType().Name, code));
                }


            }

            else
            {
               
                switch (code.Substring(0, 2))
                {
                    case "35": ParseField35B(text, out _sedol, out _entity, out _ISIN, out _countrycode); break;
                    //case "35": ParseField35B(text); break;
                    case "36": ParseField36B(code, text); break;
                    case "22": ParseField22(code, text); break;
                    case "11": ParseField11A(code, text); break;
                    case "69": ParseField69A(code, text); break;
                    case "90": ParseField90A(code, text); break;
                    case "92": ParseField92(code, text); break;
                    case "98": ParseField98A(code, text); break;

                    default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
                }
            }
		}

		private void ParseField16R(string input)
		{
			switch (input)
			{
				case "FIA": 
                            //_subsequenceE1A = new SubsequenceE1A(CARef, SenderRef, CAOptionNumber, _subsequenceNumber);
							_isInE1A = true;
							break;
			}
		}

		private void ParseField16S(string input)
		{
			switch(input)
			{
				case "FIA": 
                    _isInE1A = false; 
					break;
				case "SECMOVE": // Nop
					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unrecognized code in 16S.", GetType().Name));
			}
		}

		/// <summary>
		/// Disposition of Fractions
		/// </summary>
		/// <example></example>
		/// <param name="input"></param>
        //public void ParseField22F(string input)
        //{
        //    var s = input.Split(new[] { "//" }, StringSplitOptions.None);
        //    if (s[0] != "DISF")
        //        throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in Field 22F.", GetType().Name, s[0]));

        //    DispositionFractions = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
        //}

		/// <summary>
		/// Indicator: for fields 67 and 80
		/// </summary>
		/// <example>
		/// Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)
		/// Option H	:4!c//4!c	(Qualifier)(Indicator)
		/// </example>
		internal void ParseField22(string code, string input)
		{
            string dataSourceScheme = null;
            string indicator = null;

			// Option H
			if (Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))
			{
                indicator = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
                var s = input.Split(new[] { "//" }, StringSplitOptions.None);

              
                switch (s[0])
                {
                    
                    case "CRDB":
                        IndCreditDebit = indicator;
                        break;
                    case "TXAP":
                        IndIssuerTaxability = indicator;
                        break;
                    case "NSIS":
                        IndNewSecuritiesIssuance = indicator;
                        break;
                    case "TEMP":
                        IndTemporary = indicator;
                        break;
                    case "NELP":
                        IndNonEligibleProceeds = indicator;
                        break;

                    default: 
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
                }
               

			}			
			// Option F
			else if (Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z]{8}/[A-Z]{4}$"))
			{
                var firstSlash = input.IndexOf("/", StringComparison.Ordinal);
                dataSourceScheme = input.Substring(firstSlash + 1, (input.LastIndexOf("/", StringComparison.Ordinal) - 1 - firstSlash));
                indicator = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);

                var qualifier = input.Substring(0, firstSlash);

                //SequenceTagOverflowProcess(GetType().Name, code, qualifier);

                if (qualifier == "TEMP")
                {
                    IndTemporary = indicator;
                    IndTemporaryDtaSrcSchme = dataSourceScheme;
                }
                else if (qualifier == "NELP")
                {
                    IndNonEligibleProceeds = indicator;
                    IndNonEligibleProceedsDtaSrcSchme = dataSourceScheme;
                }
                else if (qualifier == "DISF")
                {
                    DispositionFractions = indicator;
                    DispositionFractionsDtaSrcSchme = dataSourceScheme;
                }
                else
                {
                    SequenceTagUnknownProcess(code, input);
                }
            
				
			}
            else
			throw new UnexpectedCodeException(String.Format("{0}: The input for 22 does not match any of the options. Either the SWIFT standard has changed or the message is malformed.", GetType().Name));






		}
		
		/// <summary>
		/// Entitled Quantity
		/// </summary>
		/// <example>:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)</example>
		/// <param name="input"></param>
        internal void ParseField36B(string code, string input)
		{
            ParseField36BOptions(input);
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

           	switch (s[0])
			{
				case "ENTL":
					var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					EntitledQuantityType = splitB[0];
					EntitledQuantity = ParseDecimalFr(splitB[1]);
					break;
				default: 
                     {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Currency (option)
		/// </summary>
		/// <example>Option A	:4!c//3!a	(Qualifier)(Currency Code)</example>
		/// <param name="input"></param>
        internal void ParseField11A(string code, string input)
		{
            ParseField11Options(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

            switch (s[0])
			{
				case "OPTN": CurrencyOption = s[1]; break;
				default: 
                     {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Trading Period
		/// </summary>
        /// Option A :4!c//8!n/8!n (Qualifier)(Date)(Date) 
        ///    Option B :4!c//8!n6!n/8!n6!n (Qualifier)(Date)(Time)(Date)(Time) 
        ///    Option C :4!c//8!n/4!c (Qualifier)(Date)(Date Code) 
        ///    Option D :4!c//8!n6!n/4!c (Qualifier)(Date)(Time)(Date Code) 
        ///    Option E :4!c//4!c/8!n (Qualifier)(Date Code)(Date) 
        ///    Option F :4!c//4!c/8!n6!n (Qualifier)(Date Code)(Date)(Time) 
        ///    Option J :4!c//4!c (Qualifier)(Date Code) 
		/// <param name="input"></param>
        internal void ParseField69A(string code, string input)
		{
            ParseField69Options(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "TRDP": // Nop
					break;
					// PRIC ??
				default: 
                {
                    SequenceTagUnknownProcess(code, input);
                    return;
                }
              
			}

            var splitResultB = s[1].Split(new[] { "/" }, StringSplitOptions.None);

			// Option J
			if (splitResultB.Length == 1)
			{
				TradingPeriodStart = null;
				TradingPeriodEnd = null;

				return;
			}

			// Option A
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
			{
				TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				return;
			}

			// Option B
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
			{
				TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				return;
			}

			// Option C, D
			if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN")
			{
				TradingPeriodEnd = null;
				try
				{
					TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
				return;
			}

			// Option E, F
			if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN")
			{
				TradingPeriodStart = null;

				try
				{
					TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}	
		}

		/// <summary>
		/// Price
		/// </summary>
		/// <example></example>
		/// <param name="input"></param>
        internal void ParseField90A(string code, string input)
		{
            //NOTE: Amount and Price doubled up to use Price field.
            // Loo 
            //TODO
            ParseField90ABEFJKOptions(input);
                   
                         

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			var split2 = s[1].Split(new[] { "/" }, StringSplitOptions.None);

			decimal? price = null;
            string percentageTypeCode = null;
            string amountTypeCode = null;
            string quantityTypeCode = null;
            string ccyCode = null;
            string priceCode = null;
            decimal? indexPoints = null;
            decimal? quantity = null;
            decimal? amount = null;
            


            switch (code.Substring(2, 1))
            {
                case "A":
                    price = ParseDecimalFr(split2[1]);
                    percentageTypeCode = split2[0];
                    break;
                case "B":
                    price = ParseNumberWithCurrency(split2[1], out ccyCode);
                    amountTypeCode = split2[0];
                    break;
                case "E":
                    priceCode = split2[0];
                    break;
                case "F":
                    amountTypeCode = split2[0];
                    amount = ParseNumberWithCurrency(split2[1], out ccyCode);
                    quantityTypeCode = split2[2];
                    quantity = ParseDecimalFr(split2[3]);
                    break;
                case "J":
                    amountTypeCode = split2[0];
                    amount = ParseNumberWithCurrency(split2[1], out ccyCode);
                    break;
                case "K":
                    indexPoints = ParseDecimalFr(split2[0]);
                    break;
                default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
            }


			switch (s[0])
			{
				case "INDC": 
                    IndicativePrice = price;
                    IndicativePricePercType = percentageTypeCode;
                    IndicativePriceAmtType = amountTypeCode;
                    IndicativePriceCcy = ccyCode;
                    IndicativePriceCode = priceCode;
                    break;
				case "MRKT": 
                    MarketPrice = price; 
                    MarketPricePercType  = percentageTypeCode;
                    MarketPriceAmtType  = amountTypeCode;
                    MarketPriceCcy = ccyCode;
                    MarketPriceCode = priceCode;
                    break;
				case "CINL": 
                    CashInLieuSharesPrice = price; 
                    CashInLieuSharesPricePercType  = percentageTypeCode;
                    CashInLieuSharesPriceAmtType = amountTypeCode;
                    CashInLieuSharesPriceCcy  = ccyCode;
                    CashInLieuSharesPriceCode = priceCode;
                    break;

				case "PRPP":
                    GenericCashPricePaid = price;
                    GenericCashPricePaidAmtType = amountTypeCode;
                    GenericCashPricePaidCcy = ccyCode;
                    GenericCashPricePaidPercType = percentageTypeCode;
                    GenericCashPricePaidCode = priceCode;
                    GenericCashPricePaidIdxPoints = indexPoints;
                    break;
                case "OFFR":
                    GenericCashPriceReceivedAmt = amount;
                    GenericCashPriceReceived  = price;
                    GenericCashPriceReceivedAmtType = amountTypeCode;
                    GenericCashPriceReceivedCcy = ccyCode;
                    GenericCashPriceReceivedPercType = percentageTypeCode;
                    GenericCashPriceReceivedQty = quantity;
                    GenericCashPriceReceivedQtyType = quantityTypeCode;
                    GenericCashPriceReceivedCode = priceCode;
                    break;
                case "CAVA":
                    CashValueTaxPrice  = price;
                    CashValueTaxPriceAmtType = amountTypeCode;
                    CashValueTaxPriceCcy = ccyCode;
                    CashValueTaxPriceCode = priceCode;
                    break;
				
				default:
					{
                    SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Parses Rate: There can be various types of rates: NB: This field is partially implemented
		/// </summary>
		/// <param name="code"></param>
		/// <param name="input"></param>
        internal void ParseField92(string code, string input)
		{

            ParseField92E1Options(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			
            decimal? rate1 = null;
			string rateType = null;
            string rateStatus = null;
            string rate1Currency = null;
            string rate2Currency = null;
            decimal? quantity1 = null;
            decimal? quantity2 = null;
            decimal? amount1 = null;
            decimal? amount2 = null;
            string dataSourceScheme = null;

            rateType = s[0];
			switch (code.Substring(2,1))
			{
				case "A": 
                    rate1 = ParseDecimalFr(s[1].Replace("N", "-"));
                    rate1Currency = null;
                    rate2Currency = null;
					break;
				case "D":
					var splitRates = s[1].Split(new[] {"/"}, StringSplitOptions.None);
                    quantity1 = ParseDecimalFr(splitRates[0]);
                    quantity2 = ParseDecimalFr(splitRates[1]);
					break;
				case "F":
                    amount1 = ParseNumberWithCurrency(s[1], out rate1Currency);
 					break;
                case "J":
                    //TODO
                    var splitJ = input.Split(new[] { "/" }, StringSplitOptions.None);
                    dataSourceScheme = splitJ[0];
                    rateType = splitJ[1];
                    amount1 = ParseNumberWithCurrency(splitJ[2], out rate1Currency);
                    if (splitJ.Length == 4)
                        rateStatus = splitJ[3];
                    break;
				case "K": // Nop - UKWN
					break;

				case "L": 
                    var splitCurrencies = s[1].Split(new[] { "/" }, StringSplitOptions.None);
                    amount1 = ParseNumberWithCurrency(splitCurrencies[0], out rate1Currency);
                    amount2 = ParseNumberWithCurrency(splitCurrencies[1], out rate2Currency);
                    break;
				case "M":
					var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
                    amount1 = ParseNumberWithCurrency(splitB[0], out rate1Currency);
                    quantity1 = ParseDecimalFr(splitB[1]);
					break;
				case "N":
					var splitN = s[1].Split(new[] {"/"}, StringSplitOptions.None);
                    amount1 = ParseNumberWithCurrency(splitN[1], out rate1Currency);
                    quantity1 = ParseDecimalFr(splitN[0]);
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected Option {1} in field 92.", GetType().Name, code));
			}

            switch (s[0])
			{
				case "ADEX":
                    RateAddtionXistngSecQty1 = quantity1;
                    RateAddtionXistngSecQty2 = quantity2;
                    RateAddtionXistngSecAmt1 = amount1;
                    RateAddtionXistngSecAmt2 = amount2;
                    RateAddtionXistngSecCcy1 = rate1Currency;
                    RateAddtionXistngSecCcy2 = rate2Currency;
                    break;
                case "NEWO":
                    RateNewToOldSecQty1 = quantity1;
                    RateNewToOldSecQty2 = quantity2;
                    RateNewToOldSecAmt1 = amount1;
                    RateNewToOldSecAmt2 = amount2;
                    RateNewToOldSecCcy1 = rate1Currency;
                    RateNewToOldSecCcy2 = rate2Currency;
                    break;
                case "ADSR":
                    RateAddtionSubscrbedResultntSecQty1 = quantity1;
                    RateAddtionSubscrbedResultntSecQty2 = quantity2;
                    RateAddtionSubscrbedResultntSecAmt1 = amount1;
                    RateAddtionSubscrbedResultntSecAmt2 = amount2;
                    RateAddtionSubscrbedResultntSecCcy1 = rate1Currency;
                    RateAddtionSubscrbedResultntSecCcy2 = rate2Currency;
                    break;
                case "TRAT":
                    RateTransformationRate = rate1;
                    break;
                case "CHAR":
                    RateChargesFeesRate = rate1;
                    RateChargesFeesCcy = rate1Currency;
                    RateChargesFeesAmt = amount1;
                    break;
                case "FISC":
                    RateFiscalStampRate = rate1;
                    break;
                case "RATE":
                    RateApplicable = rate1;
                    break;
                case "TAXC":
                    RateTaxCredit = rate1;
                    RateTaxCreditCcy = rate1Currency;
                    RateTaxCreditAmt  = amount1;
                    RateTaxCreditDtaSrcSchme = dataSourceScheme;
                    RateTaxCreditTypeCode = rateType;
                    RateTaxCreditStatus = rateStatus;
                    break;
                default:
                    {
                    SequenceTagUnknownProcess(code, input);
                    }
                    break;
            }

		}

		/// <summary>
		/// DateTime
		/// </summary>
		/// <example>Option A	:4!c//8!n	(Qualifier)(Date)
		///			 Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		///			 Option C	:4!c//8!n6!n	(Qualifier)(Date)(Time)
		///			 Option E	:4!c//8!n6!n[,3n][/[N]2!n[2!n]]	(Qualifier)(Date)(Time)(Decimals)(UTC Indicator)</example>
		/// <param name="input"></param>
        internal void ParseField98A(string code, string input)
		{
            ParseField98Options(input);
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);


            //Option B WITH Data Source Not Implemented
            if (s.Length == 1)
                throw new NotImplementedException(String.Format("{0}: Option {1} encountered in field 98A not implemented.", GetType().Name, input));
            //Option B with no Data Source Scheme.  date is NULL(UKWN)
            if (s[1].Length == 4)
                return;

            switch (s[0]) 
			{
				case "PAYD":
					PayDate = ParseDateOptionalTime(s[1]);
					break;

				case "AVAL":
					AvailableDate = ParseDateOptionalTime(s[1]);
					break;

				case "DIVR":
					DividendRankDate = ParseDateOptionalTime(s[1]);
					break;

				case "EARL":
                    if (s[1].Split(new[] { "/" }, StringSplitOptions.None).Length == 2) //Option E with UTC EarliestPayDate not supported per SMPG Best Practices 2014
                        throw new NotImplementedException(String.Format("{0}: Option {1} encountered in field 98E not implemented.", GetType().Name, input));
					EarliestPayDate = ParseDateOptionalTime(s[1]);
					break;

				case "PPDT":
					PariPassuDate = ParseDateOptionalTime(s[1]);
					break;
                case "LTRD":
                    LastTradingDate = ParseDateOptionalTime(s[1]);
                    break;

                   
				default: 
                    {
                    SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}

           
		}

        internal static string GetHeaders()
		{
            return "CARef|SenderRef|CAOptionNumber|SeqNum|InstrTicker|InstrDescription|PlaceListingType|PlaceListing|PlaceListingDtaSrcSchme|MICO|MICODtaSrcSchme|InstrCurrency|InstrCouponDate|InstrFloatingRateDate" +
                   "|InstrMaturityDate|InstrIssueDate|InstrCallDate|InstrPutDate|InstrDatedDate|InstrConvDate|InstrIssuPrice|InstrIssuPriceAmtType|InstrIssuPriceCcy|InstrIssuPricePercType" +
                   "|InstrMinNomQuantity|InstrMinNomQuantityType|InstrMinExQuantity|InstrMinExQuantityType|InstrMinExMQuantity|InstrMinExMQuantityType|InstrContractSize|InstrContractSizeType|EntitledQuantityType|EntitledQuantity|DispositionFractions" +
			       "|DispositionFractionsDtaSrcSchme|CurrencyOption|TradingPeriodStart|TradingPeriodEnd" +
                   "|PayDate|AvailableDate|DividendRankDate|EarliestPayDate|PariPassuDate|LastTradingDate|InstrISIN|InstrCntryCode" +
                   "|IndCreditDebit|IndTemporary|IndTemporaryDtaSrcSchme|IndNonEligibleProceeds|IndNonEligibleProceedsDtaSrcSchme|IndIssuerTaxability|IndNewSecuritiesIssuance" +
                   "|IndicativePrice|IndicativePricePercType|IndicativePriceAmtType|IndicativePriceCcy|IndicativePriceCode|MarketPrice|MarketPricePercType|MarketPriceAmtType|MarketPriceCcy|MarketPriceCode" +
                   "|CashInLieuSharesPrice|CashInLieuSharesPricePercType|CashInLieuSharesPriceAmtType|CashInLieuSharesPriceCcy|CashInLieuSharesPriceCode" +

                   "|GenericCashPriceReceived|GenericCashPriceReceivedAmtType|GenericCashPriceReceivedCcy|GenericCashPriceReceivedPercType|GenericCashPriceReceivedQty|GenericCashPriceReceivedQtyType|GenericCashPriceReceivedCode|GenericCashPriceReceivedAmt" +
                   "|GenericCashPricePaid|GenericCashPricePaidAmtType|GenericCashPricePaidCcy|GenericCashPricePaidPercType|GenericCashPricePaidCode|GenericCashPricePaidIdxPoints" +
                   "|CashValueTaxPrice|CashValueTaxPriceAmtType|CashValueTaxPriceCcy|CashValueTaxPriceCode" +

                   "|RateAddtionXistngSecQty1|RateAddtionXistngSecQty2|RateAddtionXistngSecAmt1|RateAddtionXistngSecAmt2|RateAddtionXistngSecCcy1|RateAddtionXistngSecCcy2" + 
                   "|RateNewToOldSecQty1|RateNewToOldSecQty2|RateNewToOldSecAmt1|RateNewToOldSecAmt2|RateNewToOldSecCcy1|RateNewToOldSecCcy2" +
                   "|RateAddtionSubscrbedResultntSecQty1|RateAddtionSubscrbedResultntSecQty2|RateAddtionSubscrbedResultntSecAmt1|RateAddtionSubscrbedResultntSecAmt2|RateAddtionSubscrbedResultntSecCcy1|RateAddtionSubscrbedResultntSecCcy2" +
                   "|RateTransformationRate|RateChargesFeesRate|RateChargesFeesCcy|RateChargesFeesAmt|RateFiscalStampRate|RateApplicable" +
                   "|RateTaxCredit|RateTaxCreditCcy|RateTaxCreditAmt|RateTaxCreditDtaSrcSchme|RateTaxCreditTypeCode|RateTaxCreditStatus" +
                   "|InstrClassification|InstrClassificationDtaSrcSchme|InstrOptionStyle|InstrOptionStyleDtaSrcSchme" +
                   "|InstrRatePreviousFactor|InstrRateNextFactor|InstrRateInterest|InstrRateInterestNext|TagsNotRecognized";
		}

		public override string ToString()
		{
            var sb = new StringBuilder(1000);
            sb.Append("|" + IndCreditDebit); sb.Append("|" + IndTemporary); sb.Append("|" + IndTemporaryDtaSrcSchme); sb.Append("|" + IndNonEligibleProceeds); sb.Append("|" + IndNonEligibleProceedsDtaSrcSchme); sb.Append("|" + IndIssuerTaxability); sb.Append("|" + IndNewSecuritiesIssuance);
            sb.Append("|" + IndicativePrice); sb.Append("|" + IndicativePricePercType); sb.Append("|" + IndicativePriceAmtType); sb.Append("|" + IndicativePriceCcy); sb.Append("|" + IndicativePriceCode);
            sb.Append("|" + MarketPrice );  sb.Append("|" + MarketPricePercType); sb.Append("|" + MarketPriceAmtType); sb.Append("|" + MarketPriceCcy); sb.Append("|" + MarketPriceCode);
            sb.Append("|" + CashInLieuSharesPrice); sb.Append("|" + CashInLieuSharesPricePercType); sb.Append("|" + CashInLieuSharesPriceAmtType); sb.Append("|" + CashInLieuSharesPriceCcy); sb.Append("|" + CashInLieuSharesPriceCode);

            sb.Append("|" + GenericCashPriceReceived); sb.Append("|" + GenericCashPriceReceivedAmtType); sb.Append("|" + GenericCashPriceReceivedCcy); sb.Append("|" + GenericCashPriceReceivedPercType); sb.Append("|" + GenericCashPriceReceivedQty); sb.Append("|" + GenericCashPriceReceivedQtyType); sb.Append("|" + GenericCashPriceReceivedCode); sb.Append("|" + GenericCashPriceReceivedAmt); 
            sb.Append("|" + GenericCashPricePaid); sb.Append("|" + GenericCashPricePaidAmtType); sb.Append("|" + GenericCashPricePaidCcy); sb.Append("|" + GenericCashPricePaidPercType); sb.Append("|" + GenericCashPricePaidCode); sb.Append("|" + GenericCashPricePaidIdxPoints);
            sb.Append("|" + CashValueTaxPrice); sb.Append("|" + CashValueTaxPriceAmtType); sb.Append("|" + CashValueTaxPriceCcy); sb.Append("|" + CashValueTaxPriceCode);

            sb.Append("|" + RateAddtionXistngSecQty1); sb.Append("|" + RateAddtionXistngSecQty2); sb.Append("|" + RateAddtionXistngSecAmt1); sb.Append("|" + RateAddtionXistngSecAmt2); sb.Append("|" + RateAddtionXistngSecCcy1); sb.Append("|" + RateAddtionXistngSecCcy2);
            sb.Append("|" + RateNewToOldSecQty1); sb.Append("|" + RateNewToOldSecQty2); sb.Append("|" + RateNewToOldSecAmt1); sb.Append("|" + RateNewToOldSecAmt2); sb.Append("|" + RateNewToOldSecCcy1); sb.Append("|" + RateNewToOldSecCcy2);
            sb.Append("|" + RateAddtionSubscrbedResultntSecQty1); sb.Append("|" + RateAddtionSubscrbedResultntSecQty2); sb.Append("|" + RateAddtionSubscrbedResultntSecAmt1); sb.Append("|" + RateAddtionSubscrbedResultntSecAmt2); sb.Append("|" + RateAddtionSubscrbedResultntSecCcy1); sb.Append("|" + RateAddtionSubscrbedResultntSecCcy2);
            sb.Append("|" + RateTransformationRate); sb.Append("|" + RateChargesFeesRate); sb.Append("|" + RateChargesFeesCcy); sb.Append("|" + RateChargesFeesAmt); sb.Append("|" + RateFiscalStampRate); sb.Append("|" + RateApplicable);
            sb.Append("|" + RateTaxCredit); sb.Append("|" + RateTaxCreditCcy); sb.Append("|" + RateTaxCreditAmt); sb.Append("|" + RateTaxCreditDtaSrcSchme); sb.Append("|" + RateTaxCreditTypeCode); sb.Append("|" + RateTaxCreditStatus);
            sb.Append("|" + InstrClassification); sb.Append("|" + InstrClassificationDtaSrcSchme); sb.Append("|" + InstrOptionStyle); sb.Append("|" + InstrOptionStyleDtaSrcSchme);
            sb.Append("|" + InstrRatePreviousFactor); sb.Append("|" + InstrRateNextFactor); sb.Append("|" + InstrRateInterest); sb.Append("|" + InstrRateInterestNext); sb.Append("|" + _TagsNotRecognized);

            return CARef + "|" + SenderRef + "|" + CAOptionNumber + "|" + _subsequenceNumber + "|" + InstrTicker + "|" + InstrDescription + "|" + PlaceListingType + "|" + PlaceListing + "|" + PlaceListingDtaSrcSchme + "|" + MICO + "|" + MICODtaSrcSchme + "|" + InstrCurrency + "|" + InstrCouponDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrFloatingRateDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
				   "|" + InstrMaturityDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrIssueDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrCallDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrPutDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrDatedDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrConvDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + InstrIssuPrice + "|" + InstrIssuPriceAmtType + "|" + InstrIssuPriceCcy + "|" + InstrIssuPricePercType  +
                   "|" + InstrMinNomQuantity + "|" + InstrMinNomQuantityType + "|" + InstrMinExQuantity + "|" + InstrMinExQuantityType + "|" + InstrMinExMQuantity + "|" + InstrMinExMQuantityType + "|" + InstrContractSize + "|" + InstrContractSizeType + "|" + EntitledQuantityType + "|" + EntitledQuantity + "|" + DispositionFractions + "|" + DispositionFractionsDtaSrcSchme +
				   "|" + CurrencyOption + "|" + TradingPeriodStart.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + TradingPeriodEnd.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + AvailableDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DividendRankDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EarliestPayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PariPassuDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + LastTradingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + InstrISIN + "|" + InstrCntryCode +
                   sb.ToString();
		}

        /// <summary>
        /// Place of listing (not as standard)
        /// </summary>
        /// <example>Option B	:4!c/[8c]/4!c[/30x]	(Qualifier)(Data Source Scheme)(Place Code)(Narrative)</example>
        /// <param name="input"></param>
        internal void FIParseField94B(string code, string input)
        {
            // 4!c//4!c[/30x]
            ParseField94BOptions(input);
            var s = input.Split(new[] { "/" }, StringSplitOptions.None);

            if (!s[0].Equals("PLIS"))
            {
                SequenceTagUnknownProcess(code, input);
                return;
            }

            PlaceListingDtaSrcSchme = s[1];
            PlaceListingType = s[2];

            if (s.Length == 4)
                PlaceListing = s[3];
        }

        /// <summary>
        /// Method of interest computation indicator
        /// </summary>
        /// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
        /// <param name="input"></param>
        internal void FIParseField22F(string code, string input)
        {
            ParseField22Options(input);
            var s = input.Split(new[] { "/" }, StringSplitOptions.None);
            if (!s[0].Equals("MICO"))
            {

                SequenceTagUnknownProcess(code, input);
                return;
            }

            MICODtaSrcSchme = s[1];
            MICO = s[2];
        }

        /// <summary>
        /// CFI Code; Option C is impl. only
        /// </summary>
        /// <example>Option A	:4!c/[8c]/30x	(Qualifier)(Data Source Scheme)(Instrument Code or Description)
        ///			 Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Instrument Type Code)
        ///			 Option C	:4!c//6!c		(Qualifier)(CFI Code)</example>
        /// <param name="input"></param>
        internal void FIParseField12A(string code, string input)
        {

            ParseField12Options(input);
            var s = input.Split(new[] { "/" }, 3, StringSplitOptions.None);

            var regexClas = new Regex("^CLAS");
            var regexOPST = new Regex("^OPST");

            if (regexClas.IsMatch(s[0]))
            {
                InstrClassification = s[2];
                InstrClassificationDtaSrcSchme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];
            }
            else if (regexOPST.IsMatch(s[0]))
            {
                InstrOptionStyleDtaSrcSchme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                InstrOptionStyle = s[2];
            }
            else
            {

                SequenceTagUnknownProcess(code, input);
            }



        }

        /// <summary>
        /// Currency of denomination
        /// </summary>
        /// <param name="input"></param>
        internal void FIParseField11A(string code, string input)
        {
            ParseField11Options(input);
            var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            if (s[0] != "DENO")
            {
                
                SequenceTagUnknownProcess(code, input);
                return;
            }
                  
            InstrCurrency = s[1];

        }

        /// <summary>
        /// DateTime (various)
        /// </summary>
        /// <example>Option A	:4!c//8!n	(Qualifier)(Date)</example>
        /// <param name="input"></param>
        internal void FIParseField98A(string code, string input)
        {

            ParseField98AOptions(input);
              
            var s = input.Split(new[] { "//" }, StringSplitOptions.None);

            switch (s[0])
            {
                case "COUP": InstrCouponDate = ParseDateOptionalTime(s[1]); break;
                case "FRNR": InstrFloatingRateDate = ParseDateOptionalTime(s[1]); break;
                case "MATU": InstrMaturityDate = ParseDateOptionalTime(s[1]); break;
                case "ISSU": InstrIssueDate = ParseDateOptionalTime(s[1]); break;
                case "CALD": InstrCallDate = ParseDateOptionalTime(s[1]); break;
                case "PUTT": InstrPutDate = ParseDateOptionalTime(s[1]); break;
                case "DDTE": InstrDatedDate = ParseDateOptionalTime(s[1]); break;
                case "CONV": InstrConvDate = ParseDateOptionalTime(s[1]); break;

                default: 
                 {
                        SequenceTagUnknownProcess(code, input);
                 }
                 break;
            }

           
        }

        /// <summary>
        /// Issue Price
        /// 
        /// Option A :4!c//4!c/15d (Qualifier)(Percentage Type Code)(Price) 
        ///     Option B :4!c//4!c/3!a15d (Qualifier)(Amount Type Code)(Currency Code)(Price) 
        ///    Option E :4!c//4!c (Qualifier)(Price Code) 
        /// </summary>
        /// <param name="code"></param>
        /// <param name="input"></param>
        internal void FIParseField90A(string code, string input)
        {

            ParseField90Options(input);
            if (!Regex.IsMatch(input, @"ISSU"))
            {
                SequenceTagUnknownProcess(code, input);
                return;
            }

            InstrIssuPrice = null;
            InstrIssuPriceAmtType = null;
            InstrIssuPriceCcy = null;
            InstrIssuPricePercType = null;
            var ccyCode = String.Empty;

            //Option E - UKWN
            if (input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1) == "UKWN")
            {
                return;
            }

            var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            var s1 = s[1].Split(new[] { "/" }, StringSplitOptions.None);

           
            switch (code.Substring(2, 1))
            {
                case "A":
                    InstrIssuPricePercType = s1[0];
                    InstrIssuPrice = ParseDecimalFr(s1[1]);
                    break;
                case "B":
                    InstrIssuPriceAmtType = s1[0];
                    InstrIssuPrice = ParseNumberWithCurrency(s1[1], out ccyCode);
                    InstrIssuPriceCcy = ccyCode;
                    break;

                default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 90A.", GetType().Name, code));
            }

        }

        /// <summary>
        /// Rate
        /// 
        /// Option A :4!c//[N]15d (Qualifier)(Sign)(Rate) 
        /// Option K :4!c//4!c (Qualifier)(Rate Type Code) 
        /// </summary>
        /// <param name="input"></param>
        internal void FIParseField92A(string code, string input)
        {

             if (
                   (!(Regex.IsMatch(input, @"^[A-Z]{4}//[N]{0,1}\d{1,15},\d{0,15}$")))  // option A
                     && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //Option K
                  )
             {
                 throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 92A.", GetType().Name));
             }
            //Option K - UKWN
            if (input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1) == "UKWN")
            {
                return;
            }
            var s = input.Split(new[] { "//" }, StringSplitOptions.None);

            switch (s[0])
            {
                case "PRFC":
                    InstrRatePreviousFactor = ParseDecimalFr(s[1]);
                    break;
                case "NWFC":
                    InstrRateNextFactor = ParseDecimalFr(s[1]);
                    break;
                case "INTR":
                    InstrRateInterest = ParseDecimalFr(s[1]);
                    break;
                case "NXRT":
                    InstrRateInterestNext = ParseDecimalFr(s[1]);
                    break;
                default:
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
            }
        }

        /// <summary>
        /// Quantity of Financial Instrument
        /// </summary>
        /// <example>Option B	:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)</example>
        /// <param name="input"></param>
        internal void FIParseField36B(string code, string input)
        {

            ParseField36BOptions(input);
           
            var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            var splitB = s[1].Split(new[] { "/" }, StringSplitOptions.None);

            switch (s[0])
            {
                case "MINO":
                    InstrMinNomQuantity = ParseDecimalFr(splitB[1]);
                    InstrMinNomQuantityType = splitB[0];
                    break;
                case "MIEX":
                    InstrMinExQuantity = ParseDecimalFr(splitB[1]);
                    InstrMinExQuantityType = splitB[0];
                    break;
                case "MILT":
                    InstrMinExMQuantity = ParseDecimalFr(splitB[1]);
                    InstrMinExMQuantityType = splitB[0];
                    break;
                case "SIZE":
                    InstrContractSize = ParseDecimalFr(splitB[1]);
                    InstrContractSizeType = splitB[0];
                    break;

                default:
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
            }
        }

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);

                      
        }
	}
}