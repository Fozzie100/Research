﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Sequence B - Underlying Securities. The Optional Subsequence B1 (Financial Instrument Attributes) has been incorporated into sequence B.
	/// </summary>
	internal class SequenceB : Sequence
	{
		#region Fields
        private int _B2No;
		protected SubsequenceB2 _subSequenceB2;
		private readonly List<SubsequenceB2> _subsequenceB2S = new List<SubsequenceB2>();

		protected internal string _sedol;
        protected internal string _entity;
        protected internal string _ISIN;
        protected internal string _countrycode;

        protected internal string _caRef;
        protected internal string _senderRef;      
		#endregion

		#region SWIFT Message attributes
		/// <summary>
		/// Repetitive Mandatory Subsequence B2 Account Information
		/// </summary>
		internal List<SubsequenceB2> SubsequenceB2S { get { return _subsequenceB2S; } }

		/// <summary>
		/// 35B
		/// </summary>
        internal string SecTickerUnderly { get { return _sedol; } }

		/// <summary>
		/// 35B
		/// </summary>
        internal string SecDescrptionUnderly { get { return _entity; } }
        internal string SecISINUnderly { get { return _ISIN; } }
        internal string SecCntryCodeUnderly { get { return _countrycode; } }

		// Optional subsequence  B1 - Financial Instrument Attributes
		#region Financial Instruments Attributes

		/// <summary>
		/// 94B
		/// </summary>
		internal string PlaceListing { get; set; }
        internal string PlaceListingDtaSrcSchme { get; set; }
        internal string PlaceCode { get; set; }
    
		/// <summary>
		/// 22F
		/// </summary>
        internal string MICO { get; set; }
        internal string MICODtaSrcSchme { get; set; }
		
		/// <summary>
		/// 12A
		/// </summary>
        internal string FIClassification { get; set; }
        internal string FIClassificationDtaSrcSchme { get; set; }
		/// <summary>
		/// 12A
		/// </summary>
        internal string OptionStyle { get; set; }
        internal string OptionStyleDtaSrcSchme { get; set; }

		/// <summary>
		/// 11A
		/// </summary>
        internal string CcyDenomination { get; set; }

        internal DateTime? CallDate { get; set; }
        internal DateTime? ConversionDate { get; set; }
        internal DateTime? CouponDate { get; set; }
        internal DateTime? DatedDate { get; set; }
        internal DateTime? SecExpiryDate { get; set; }
        internal DateTime? FloatingRateFixingDate { get; set; }
        internal DateTime? IssueDate { get; set; }
        internal DateTime? MaturityDate { get; set; }
        internal DateTime? PutDate { get; set; }

		/// <summary>
		/// 92A - Percentage of Debt Claims
		/// </summary>
        internal decimal? InstrPercentageDebtClaims { get; set; }
		/// <summary>
		/// 92A - Interest Rate
		/// </summary>
        internal decimal? InstrInterestRate { get; set; }
        internal decimal? InstrNextFactor { get; set; }
        internal decimal? InstrNextInterestRate { get; set; }
        internal decimal? InstrPrevFactor { get; set; }

        /// <summary>
        /// 92A - Warrant Parity
        /// </summary>
        internal decimal? InstrWarrantParityQuantity1 { get; set; }
        internal decimal? InstrWarrantParityQuantity2 { get; set; }

	
		/// <summary>
		/// 36B: Minimum quantity of financial instrument or lot of rights/warrants that must be exercised
		/// </summary>
        internal decimal? InstrMinimumExercisableQuantity { get; set; }
        internal string InstrMinimumExercisableQuantityType { get; set; }
		/// <summary>
		/// 36B: Minimum multiple quantity of financial instrument or lot of rights/warrants that must be exercised.
		/// </summary>
        internal decimal? InstrMinimumExercisableMultipleQuantity { get; set; }
        internal string InstrMinimumExercisableMultipleQuantityType { get; set; }
		/// <summary>
		/// 36B: Minimum nominal quantity of financial instrument that must be purchased/sold.
		/// </summary>
        internal decimal? InstrMinimumNominalQuantity { get; set; }
        internal string InstrMinimumNominalQuantityType { get; set; }

		/// <summary>
		/// 36B: Ratio or multiplying factor used to convert one contract into a financial instrument quantity.
		/// </summary>
        internal decimal? InstrContractSize { get; set; }
        internal string InstrContractSizeType { get; set; }

		#endregion
		#endregion


        /// <summary>
		/// Instantiates Sequence B
		/// </summary>
		internal SequenceB(string caRef, string senderRef)
		{
			_caRef = caRef;
			_senderRef = senderRef;
			
		}
        internal SequenceB()
        {
          
        }
		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
            if (_subSequenceB2 == null)
            {
                base.Parse(code, text);
                switch (code)
                {
                    case "16R": ParseField16R(text); break;
                    case "35B": ParseField35B(text, out _sedol, out _entity, out _ISIN, out _countrycode); break;
                    case "94B":
                        {
                           ParseField94B(code,  text);
                           break;
                        }
                    case "22F": ParseField22F(code, text); break;

                    case "12A":
                    case "12B":
                    case "12C": ParseField12A(code, text); break;
                    case "11A": ParseField11A(code, text); break;
                    case "98A": ParseField98A(code, text); break;
                    case "92A":
                    case "92K":
                    case "92D":
                        ParseField92A(code, text); break;
                    case "36B": ParseField36B(code, text); break;
                    case "16S": ParseField16S(text); break;

                    
                    default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} for this sequence.", GetType().Name, code));

                }
            }
            else
            {
                //Add SubsequenceB2 to list
                if (code == "16S")
                    ParseField16S(text);
                else if (code == "16R")
                    ParseField16R(text);
                else
                    _subSequenceB2.Parse(code, text);
            }
		}

		/// <summary>
		/// CcyDenomination of denomination
		/// </summary>
		/// <param name="input"></param>
		internal void ParseField11A(string code, string input)
		{
            ParseField11Options(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch(s[0])
			{
				case "DENO": CcyDenomination = s[1];
					break;
				default: 
                    	{
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Types of Financial Instrument
		/// </summary>
		/// <example>:4!c/[8c]/30x
		/// :4!c/[8c]/4!c
		/// :4!c//6!c
		/// </example>
		/// <param name="input"></param>
        internal void ParseField12A(string code, string input)
		{
            ParseField12Options(input);
            var s = input.Split(new[] { "/" },  3, StringSplitOptions.None);
           
            var regexClas = new Regex("^CLAS");
            var regexOPST = new Regex("^OPST");
            if (regexClas.IsMatch(s[0]))
            {
                FIClassification = s[2];
                FIClassificationDtaSrcSchme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];
            }
            else if (regexOPST.IsMatch(s[0]))
            {
                OptionStyleDtaSrcSchme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                OptionStyle = s[2];
            }
            else
            {
                SequenceTagUnknownProcess(code, input);
            }
        
		}

        internal void ParseField16R(string input)
		{
			// USECU
			// ACCTINFO
			// FIA
            
			switch (input)
			{
				case "FIA": // NOP 
							// SubsequenceB1 = new SubsequenceB1(); 
							break;
                case "ACCTINFO":
                            _B2No++;
                            _subSequenceB2 = new SubsequenceB2(_caRef, _senderRef, _B2No);
							break;
			}
		}

        internal void ParseField16S(string input)
		{
			//	ACCTINFO
			//	USECU
			switch (input)
			{
				case "FIA": // Nop
					break;
				case "ACCTINFO":	// Add Account Information only if the Account value is not "NONREF" as Market Data Providers do not act in the capacity of Securities Account Servicers
					// therefor SafeKeeping account is not needed (The field is mandatory though, according to ISO)
					/*
					if (_subSequenceB2.SafeKeepingAccount != "NONREF")
					{
						// TEMP
						throw new ApplicationException("Thrown because a subsequence B2 contains safekeepingaccount different that NONREF.");
						_subsequenceB2S.Add(_subSequenceB2);
					}
					 */
                    _subsequenceB2S.Add(_subSequenceB2);
					break;
				case "USECU": // Nop ; Validate?
					break;
			}
		}

        internal void ParseField22F(string code, string input)
		{
            ParseField22Options(input);
            var s = input.Split(new[] { "/" }, StringSplitOptions.None);
            var dataSourceScheme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];

			switch(s[0])
			{
				case "MICO":
					string res = string.Empty;
                    for (int i =  2; i < s.Length; i++)
						res += s[i];

					MICO = res;
                    MICODtaSrcSchme = dataSourceScheme;
					break;

				//case "DIVI": // TODO
					//break;
				default: 
                   	{
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Quantity of Financial Instrument
		/// </summary>
		/// <example>:4!c//4!c/15d</example>
		/// <param name="input"></param>
        internal void ParseField36B(string code, string input)
		{
            ParseField36BOptions(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
			var value = ParseDecimalFr(splitB[1]);

			switch(s[0])
			{
				case "MIEX": // Minimum Exercisable Quantity
					InstrMinimumExercisableQuantity = value;
                    InstrMinimumExercisableQuantityType = splitB[0];
					break;

				case "MILT": // Minimum Exercisable Multiple Quantity
					InstrMinimumExercisableMultipleQuantity = value;
                    InstrMinimumExercisableMultipleQuantityType = splitB[0];
					break;

				case "MINO": // Minimum Nominal Quantity
					InstrMinimumNominalQuantity = value;
                    InstrMinimumNominalQuantityType = splitB[0];
					break;

				case "SIZE": // Contract Size
					InstrContractSize = value;
                    InstrContractSizeType = splitB[0];
					break;
                default:	
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}


		/// <summary>
		/// Rate (Subsequence B1)
        /// Option A :4!c//[N]15d (Qualifier)(Sign)(Rate) 
        /// Option D :4!c//15d/15d (Qualifier)(Quantity)(Quantity) 
        /// Option K :4!c//4!c (Qualifier)(Rate Type Code) 
		/// </summary>
		/// <param name="input"></param>
        internal void ParseField92A(string code, string input)
		{
            ParseField92ADKOptions(input);

			if (Regex.IsMatch(input, "UKWN"))
				return;

			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
            var s2 = s[1].Split(new[] { "/" }, StringSplitOptions.None);
            decimal? rate = null;

            if (!(s2.Length == 2))
            {
                rate = ParseDecimalFr(s[1].Replace("N", "-"));
            }
           
			switch (s[0])
			{
				case "PRFC": InstrPrevFactor = rate; break;
				case "DECL": InstrPercentageDebtClaims = rate; break;
				case "INTR": InstrInterestRate = rate; break;
				case "NWFC": InstrNextFactor = rate; break;
				case "NXRT": InstrNextInterestRate = rate ; break;
                case "WAPA":
                    {
                        InstrWarrantParityQuantity1 = ParseDecimalFr(s2[0].Replace("N", "-"));
                        InstrWarrantParityQuantity2 = ParseDecimalFr(s2[1].Replace("N", "-")); 
                    }
                    break;
				
				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Place of listing
		/// </summary>
		/// <example>PLIS//EXCH/XLON</example>
        /// Option B :4!c/[8c]/4!c[/30x] (Qualifier)(Data Source Scheme)(Place Code)(Narrative) 
		/// <param name="input"></param>
        internal void ParseField94B(string code, string input)
		{
            ParseField94BOptions(input);
            var s = input.Split(new[] { "/" }, StringSplitOptions.None);
            var dataSourceScheme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];

			//var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch(s[0])
			{
				case "PLIS":
                    PlaceCode = string.IsNullOrWhiteSpace(s[2]) ? null : s[2];
                    PlaceListing =  s[3];
                    PlaceListingDtaSrcSchme = dataSourceScheme;
                    break;
				default:
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Optional Subsequence B1 - Underlying securities
        /// Option A :4!c//8!n (Qualifier)(Date) 
		/// </summary>
		/// <param name="input"></param>
        internal void ParseField98A(string code, string input)
		{
            ParseField98AOptions(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch(s[0])
			{
				case "CALD": CallDate = ParseDateOptionalTime(s[1]);
					break;

				case "CONV": ConversionDate = ParseDateOptionalTime(s[1]);
					break;

				case "COUP": CouponDate = ParseDateOptionalTime(s[1]);
					break;

				case "DDTE": DatedDate = ParseDateOptionalTime(s[1]);
					break;

				case "EXPI": SecExpiryDate = ParseDateOptionalTime(s[1]);
					break;

				case "FRNR": FloatingRateFixingDate = ParseDateOptionalTime(s[1]);
					break;

				case "ISSU": IssueDate = ParseDateOptionalTime(s[1]);
					break;

				case "MATU": MaturityDate = ParseDateOptionalTime(s[1]);
					break;

				case "PUTT": PutDate = ParseDateOptionalTime(s[1]);
					break;

				default: 
                   	{
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

        internal static string GetHeaders()
		{
            return "SecTickerUnderly|SecDescrptionUnderly|PlaceListing|MICO|FIClassification|OptionStyle|CcyDenomination|CallDate|ConversionDate" +
			       "|CouponDate|DatedDate|SecExpiryDate|FloatingRateFixingDate|IssueDate|MaturityDate|PutDate" +
			       "|InstrPercentageDebtClaims|InstrInterestRate|InstrNextFactor|InstrNextInterestRate|InstrPrevFactor" +
                   "|InstrMinimumExercisableQuantity|InstrMinimumExercisableQuantityType|InstrMinimumExercisableMultipleQuantity|InstrMinimumExercisableMultipleQuantityType|InstrMinimumNominalQuantity|InstrMinimumNominalQuantityType|InstrContractSize|InstrContractSizeType" +
                   "|SecISINUnderly|SecCntryCodeUnderly|PlaceCode|PlaceListingDtaSrcSchme|MICODtaSrcSchme|OptionStyleDtaSrcSchme|FIClassificationDtaSrcSchme|InstrWarrantParityQuantity1|InstrWarrantParityQuantity2|TagsNotRecognizedSeqB";
		}

		public override string ToString()
		{
            return SecTickerUnderly + "|" + SecDescrptionUnderly + "|" + PlaceListing + "|" + MICO + "|" + FIClassification + "|" + OptionStyle + "|" + CcyDenomination + "|" + CallDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ConversionDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" +
                   CouponDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DatedDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + SecExpiryDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + FloatingRateFixingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + IssueDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MaturityDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PutDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" +
                   InstrPercentageDebtClaims + "|" + InstrInterestRate + "|" + InstrNextFactor + "|" + InstrNextInterestRate + "|" + InstrPrevFactor + "|" +
                   InstrMinimumExercisableQuantity + "|" + InstrMinimumExercisableQuantityType + "|" + InstrMinimumExercisableMultipleQuantity + "|" + InstrMinimumExercisableMultipleQuantityType + "|" + InstrMinimumNominalQuantity + "|" + InstrMinimumNominalQuantityType + "|" + InstrContractSize + "|" + InstrContractSizeType +
                   "|" + SecISINUnderly + "|" + SecCntryCodeUnderly + "|" + PlaceCode + "|" + PlaceListingDtaSrcSchme + "|" + MICODtaSrcSchme + "|" + OptionStyleDtaSrcSchme + "|" + FIClassificationDtaSrcSchme + "|" + InstrWarrantParityQuantity1 + "|" + InstrWarrantParityQuantity2 + "|" + _TagsNotRecognized;
			
			// SubsequenceB2S is not exported as it contains safekeeping account information
		}

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }               
	}
}