﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
    /// <summary>
    /// Helper class for IDC for specific
    /// processing of MT564 tags which different from the default implementation
    /// </summary>
    internal static class VendorIDCHelper
    {

        internal static void ParseField35B(string input, out string sedol, out string entity, out string ISIN, out string countrycode)
        {
            var regexISIN = new Regex("^ISIN");
            string[] sISIN;
            ISIN = null;

            //Remove first / if present
            var regexFwdSlash = new Regex(@"^\s*/");
            input = regexFwdSlash.Replace(input, string.Empty);

            
            if (regexISIN.IsMatch(input))
            {
                sISIN = input.Split(new[] { "/" }, 4, StringSplitOptions.None);
                ISIN = sISIN[0].Substring(5, 12);
                if (sISIN.Length == 1) // No country and sedol
                {
                    entity = String.IsNullOrWhiteSpace(sISIN[0].Substring(17)) ? null : sISIN[0].Substring(17);
                    sedol = null;
                    countrycode = null;
                }
                else
                {
                    sedol = String.IsNullOrWhiteSpace(sISIN[2]) ? null : sISIN[2];
                    countrycode = String.IsNullOrWhiteSpace(sISIN[1]) ? null : sISIN[1];
                    entity = String.IsNullOrWhiteSpace(sISIN[3]) ? null : sISIN[3];
                }
            }
            else
            {
                sISIN = input.Split(new[] { "/" }, 2, StringSplitOptions.None);

                // Could be 35B::UKWN
                if (sISIN[0] == "UKWN")
                {
                    sedol = sISIN[0];
                    entity = null;
                    countrycode = null;
                }
                else
                {
                    sedol = String.IsNullOrWhiteSpace(sISIN[1].Substring(0, 7)) ? null : sISIN[1].Substring(0, 7);
                    //Get entity from rest of occurrances, note this will potentially include SecurityIdentification
                    // code, as entity could contain / delimiter characters. i.e 'NAMEOfSECURITY 11/05/2014 CLASS A'

                    entity = String.IsNullOrWhiteSpace(sISIN[1].Substring(7)) ? null : sISIN[1].Substring(7);
                    countrycode = String.IsNullOrWhiteSpace(sISIN[0]) ? null : sISIN[0];
                }
            }
            
        }
    }
}
