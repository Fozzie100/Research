﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
    class SubsequenceE1IDC : SubsequenceE1
    {


        /// <summary>
        /// Delegate construction to base class
        /// no construction setup for sub class
        /// </summary>
        /// <param name="caRef"></param>
        /// <param name="senderRef"></param>
        /// <param name="caOptionNumber"></param>
        /// <param name="number"></param>
        public SubsequenceE1IDC(string caRef, string senderRef, int caOptionNumber, int number)
            : base(caRef, senderRef, caOptionNumber, number)
		{
			
		}
        internal override void Parse(string code, string text)
        {
            // Parse in Base Class if not 35B
            if ((code == "35B"))
            {
                base.SequenceTagOverflowProcess(GetType().BaseType.Name, code, text.Split(new[] { "/" }, StringSplitOptions.None)[0], true);
                ParseField35B(text);
            }
            else
                base.Parse(code, text);

        }

        private void ParseField35B(string input)
        {

            VendorIDCHelper.ParseField35B(input, out _sedol, out _entity, out _ISIN, out _countrycode);
                    
           
        }
    }
}
