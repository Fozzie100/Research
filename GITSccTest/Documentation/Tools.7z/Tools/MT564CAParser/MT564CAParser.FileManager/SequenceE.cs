﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Repetitive Optional Sequence E - Corporate Actions Options
	/// </summary>
    internal class SequenceE : Sequence
	{
		
		private readonly StringBuilder _sbDetails = new StringBuilder();
		protected internal string _sedol;
        protected internal string _entity;
        protected internal string _ISIN;
        protected internal string _countrycode;
       	private readonly string _caRef;
		private readonly string _senderRef;
		private SubsequenceE1 _subsequenceE1;
		private SubsequenceE2 _subsequenceE2;
        protected CurrentSubsequence _currentSubsequence;

		private int _e1Counter;
		private int _e2Counter;

		internal List<SubsequenceE1> SubsequenceE1S  = new List<SubsequenceE1>();
        internal List<SubsequenceE2> SubsequenceE2S = new List<SubsequenceE2>();

        		
		#region SWIFT Message attributes
        internal string CARef { get { return _caRef; } }
        internal string SenderRef { get { return _senderRef; } }

		/// <summary>
		/// 13A
		/// </summary>
        internal int CAOptionNumber { get; set; }

		/// <summary>
		/// 22F
		/// </summary>
        internal string CorpActionOptionCode { get; set; }
        internal string DispFractionsInd { get; set; }
        internal string OfferType { get; set; }

        internal string OptionFeaturesInd { get; set; }
        internal string OptionStatus { get; set; }
        internal string CrtficationBrkdwnType { get; set; }

        internal string OptionFeaturesIndDtaSrcSchme { get; set; }
        internal string OptionStatusDtaSrcSchme { get; set; }
        internal string CrtficationBrkdwnTypeDtaSrcSchme { get; set; }
        internal string CorpActionOptionCodeDtaSrcSchme { get; set; }
        internal string DispFractionsIndDtaSrcSchme { get; set; }
        internal string OfferTypeDtaSrcSchme { get; set; }

		/// <summary>
		/// 94C
		/// </summary>
        internal string CountryDomicile { get; private set; }

		/// <summary>
		/// 94C
		/// </summary>
        internal string CountryNonDomicile { get; private set; }

		/// <summary>
		/// 11A
		/// </summary>
        internal string Currency { get; set; }

		/// <summary>
		/// 17B
		/// </summary>
        internal string IsDefault { get; private set; }
        internal string IsStandingInstruction { get; private set; }
        internal string IsCharges { get; private set; }
        internal string IsCertificationBreakdown { get; private set; }
        internal string IsWithdrawalAllowed { get; private set; }
        internal string IsChangeAllowed { get; private set; }

		/// <summary>
		/// 35B
		/// </summary>
        internal string InstrTicker { get { return _sedol; } }

		/// <summary>
		/// 35B
		/// </summary>
        internal string InstrDescription { get { return _entity; } }

        /// <summary>
        /// 35B
        /// </summary>
        internal string InstrISIN { get { return _ISIN; } }
        /// <summary>
        /// 35B
        /// </summary>
        internal string InstrCntryCode { get { return _countrycode; } }

		/// <summary>
		/// 98A
		/// </summary>
        internal DateTime? DepositoryCoverExpiration { get; private set; }
        internal DateTime? EarlyResponseDeadlineDate { get; private set; }
        internal string EarlyResponseDeadlineDateUTCOffsetHHmmss { get; private set; }
        internal DateTime? ExpiryDate { get; private set; }
        internal DateTime? MarketDeadlineDate { get; private set; }
        internal string MarketDeadlineDateUTCOffsetHHmmss { get; private set; }
        internal DateTime? ProtectDate { get; private set; }
        internal DateTime? SubscriptionCostDebit { get; private set; }
        internal DateTime? ResponseDeadlineDate { get; private set; }
        internal string ResponseDeadlineDateUTCOffsetHHmmss { get; private set; }
        internal DateTime? CoverExpiration { get; private set; }

        /// <summary>
        /// 69A - Period
        /// </summary>

        internal DateTime? PeriodPriceCalculationStrtDte { get; private set; }
        internal DateTime? PeriodPriceCalculationEndDte { get; private set; }
        internal DateTime? PeriodRevocabilityStrtDte { get; private set; }
        internal DateTime? PeriodRevocabilityEndDte { get; private set; }
        internal DateTime? PeriodActionStrtDte { get; private set; }
        internal DateTime? PeriodActionEndDte { get; private set; }
        internal DateTime? PeriodParallelTradingStrtDte { get; private set; }
        internal DateTime? PeriodParallelTradingEndDte { get; private set; }
        internal DateTime? PeriodSuspnsinOfPrvelgeStrtDte { get; private set; }
        internal DateTime? PeriodSuspnsinOfPrvelgeEndDte { get; private set; }
        internal DateTime? PeriodAccSrvcerRevocabilityStrtDte { get; private set; }
        internal DateTime? PeriodAccSrvcerRevocabilityEndDte { get; private set; }
        internal DateTime? PeriodDepoSuspWithdrwlStreetNamOutSecStrtDte { get; private set; }
        internal DateTime? PeriodDepoSuspWithdrwlStreetNamOutSecEndDte { get; private set; }


		/// <summary>
		/// 92A - Rate
		/// </summary>
        internal decimal? DividendGrossRate { get; private set; }
        internal decimal? TaxRelatedRate { get; private set; }
        internal decimal? WithholdingTaxRate { get; private set; }
        internal decimal? AdditionalTax { get; private set; }
        internal decimal? IndexFactor { get; private set; }
        internal decimal? MaximumAllowedOversubRate { get; private set; }
        internal decimal? ProRationRate { get; private set; }
        internal decimal? InterestPaymentRate { get; private set; }
        internal decimal? TaxableIncomePerDS { get; private set; }
        internal decimal? ForeignTaxWithholding { get; private set; }

        internal decimal? NetRateShare { get; private set; }

        internal string DividendGrossRateCcy { get; private set; }
        internal decimal? DividendGrossRateAmt { get; private set; }
        internal string DividendGrossRateRateTypeCode { get; private set; }
        internal string DividendGrossRateRateStatus { get; private set; }
        internal string DividendGrossRateDtaSrcSchme { get; private set; }

        internal string TaxRelatedRateCcy { get; private set; }
        internal decimal? TaxRelatedRateAmt { get; private set; }
        internal string TaxRelatedRateRateTypeCode { get; private set; }
        internal string TaxRelatedRateRateStatus { get; private set; }
        internal string TaxRelatedRateDtaSrcSchme { get; private set; }

        internal string WithholdingTaxRateRateTypeCode { get; private set; }

        internal string AdditionalTaxRateTypeCode { get; private set; }
        internal string AdditionalTaxCcy { get; private set; }
        internal decimal? AdditionalTaxAmt { get; private set; }

        internal string IndexFactorRateTypeCode { get; private set; }
        internal string IndexFactorCcy { get; private set; }
        internal decimal? IndexFactorAmt { get; private set; }

        internal string MaximumAllowedOversubRateRateTypeCode { get; private set; }
        internal string ProRationRateRateTypeCode { get; private set; }

        internal string InterestPaymentRateCcy { get; private set; }
        internal decimal? InterestPaymentRateAmt { get; private set; }
        internal string InterestPaymentRateRateTypeCode { get; private set; }
        internal string InterestPaymentRateRateStatus { get; private set; }
        internal string InterestPaymentRateDtaSrcSchme { get; private set; }

        internal string TaxableIncomePerDSCcy { get; private set; }
        internal decimal? TaxableIncomePerDSAmt { get; private set; }
        internal string TaxableIncomePerDSRateTypeCode { get; private set; }
        internal string TaxableIncomePerDSRateStatus { get; private set; }
        internal string TaxableIncomePerDSDtaSrcSchme { get; private set; }

        internal string NetRateShareCcy { get; private set; }
        internal decimal? NetRateShareAmt { get; private set; }
        internal string NetRateShareRateTypeCode { get; private set; }
        internal string NetRateShareRateStatus { get; private set; }
        internal string NetRateShareDtaSrcSchme { get; private set; }

        internal string ForeignTaxWithholdingCcy { get; private set; }
        internal decimal? ForeignTaxWithholdingAmt { get; private set; }
        internal string ForeignTaxWithholdingRateTypeCode { get; private set; }

        internal string IssuerDeclaredExchRateCcy { get; private set; }
        internal string IssuerDeclaredExchRateCcy2 { get; private set; }
        internal decimal? IssuerDeclaredExchRate { get; private set; }
        

			
		/// <summary>
		/// 90 A - Price amount Type
		/// </summary>
        //public string PriceAmountType { get; set; }

        ///// <summary>
        ///// 90A
        ///// </summary>
        //public string PriceCurrency { get; set; }

		/// <summary>
		/// 90A
		/// </summary>

        internal decimal? CashinLieuSharesPrice { get; private set; }
        internal decimal? OverSubDepositPrice { get; private set; }


        internal string CashinLieuSharesPriceCcy { get; private set; }
        internal string CashinLieuSharesPriceAmtType { get; private set; }
        internal string CashinLieuSharesPricePercType { get; private set; }

        internal string OverSubDepositPriceCcy { get; private set; }
        internal string OverSubDepositPriceAmtType { get; private set; }
        internal string OverSubDepositPricePercType { get; private set; }

       
		/// <summary>
		/// 36A
		/// </summary>

        internal decimal? InstrMinXercisableQty { get; set; }
        internal decimal? InstrMaxXercisableQty { get; set; }
        internal decimal? InstrMinXercisableMultiQty { get; set; }
        internal decimal? InstrNewBoardLotQty { get; set; }
        internal decimal? InstrNewDenominatonQty { get; set; }
        internal decimal? InstrBackEndLotQty { get; set; }
        internal decimal? InstrFrontEndLotQty { get; set; }

        internal string InstrMinXercisableQtyCodeOrTypeCode { get; set; }
        internal string InstrMaxXercisableQtyCodeOrTypeCode { get; set; }
        internal string InstrMinXercisableMultiQtyCodeOrTypeCode { get; set; }
        internal string InstrNewBoardLotQtyCodeOrTypeCode { get; set; }
        internal string InstrNewDenominatonQtyCodeOrTypeCode { get; set; }
        internal string InstrBackEndLotQtyCodeOrTypeCode { get; set; }
        internal string InstrFrontEndLotQtyCodeOrTypeCode { get; set; }


		/// <summary>
		/// 70E - Narrative
		/// </summary>
		//public string AdditionalDetails { get { return _sbDetails.ToString(); } }
        internal string TextAdditionalDetails { get; set; }
        internal string TextNarrativeVersion { get; set; }
        internal string TextInfoConditions { get; set; }
        internal string TextInfoToComplyWith { get; set; }
        internal string TextSecurityRestriction { get; set; }
        internal string TextTaxationConditions { get; set; }
        internal string TextDisclaimer { get; set; }
        internal string TextCertificationBreakdown { get; set; }
		#endregion

		/// <summary>
		/// Instantiates Sequence E
		/// </summary>
		public SequenceE(string caRef, string senderRef)
		{
			_caRef = caRef;
			_senderRef = senderRef;
			_currentSubsequence = CurrentSubsequence.None;
            
		}

		private bool SubsequenceExistsInList(SubsequenceE1 subsequenceE1)
		{
            return SubsequenceE1S.Any(seqE1 => seqE1.CARef == subsequenceE1.CARef && seqE1.SenderRef == subsequenceE1.SenderRef && seqE1.CAOptionNumber == subsequenceE1.CAOptionNumber && seqE1._subsequenceNumber == subsequenceE1._subsequenceNumber);
		}
        private bool SubsequenceE2ExistsInList(SubsequenceE2 subsequenceE2)
        {
            return SubsequenceE2S.Any(seqE2 => seqE2.CARef == subsequenceE2.CARef && seqE2.SenderRef == subsequenceE2.SenderRef && seqE2.CAOptionNumber == subsequenceE2.CAOptionNumber && seqE2._subsequenceNumber == subsequenceE2._subsequenceNumber);
        }

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
			switch (_currentSubsequence)
			{
				case CurrentSubsequence.E1: 
                    _subsequenceE1.Parse(code, text);
					if (code == "16S" && text == "SECMOVE")
					{
						// Before adding it - check if such a sequence exists (to avoid PK violations)
						if (!SubsequenceExistsInList(_subsequenceE1))
							SubsequenceE1S.Add(_subsequenceE1);

						_currentSubsequence = CurrentSubsequence.None;
					}
					break;
				case CurrentSubsequence.E2: 
                    _subsequenceE2.Parse(code, text);
					if (code == "16S" && text == "CASHMOVE")
					{
						// Before adding it - check if such a sequence exists (to avoid PK violations)
                        if (!SubsequenceE2ExistsInList(_subsequenceE2))
							SubsequenceE2S.Add(_subsequenceE2);

						_currentSubsequence = CurrentSubsequence.None;
					}
					break;
				
				case CurrentSubsequence.None:
					switch (code)
					{
						case "16R": ParseField16R(text); return;
						case "16S": ParseField16S(text); return;
					}

                    base.Parse(code, text);
					switch (code.Substring(0,2))
					{
						case "13": ParseField13A(code, text); break;
						case "22": ParseField22(code, text); break;
						case "94": ParseField94C(code, text); break;
						case "11": ParseField11A(code, text); break;
						case "17": ParseField17B(code, text); break;
                        case "35": ParseField35B(text, out _sedol, out _entity, out _ISIN, out _countrycode); break;
						case "98": ParseField98A(code, text); break;
						case "69": ParseField69A(code, text); break;
						case "92": ParseField92A(code, text); break;
						case "90": ParseField90A(code, text); break;
						case "36": ParseField36A(code, text); break;
						case "70": ParseField70E(code, text); break;
						
						default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected field type {1} encountered.", GetType().Name, code));
					}
					break;
				default: throw new Exception(String.Format("{0}: Wrong control flow. This is most likely means that the message is malformed and the parser could not parse it. You may rerun with -ignorefailure as an alternative.", GetType().Name));
			}
		}

		public void ParseField16R(string input)
		{

         
			switch (input)
			{
				case "SECMOVE":
					_e1Counter++;
                    //subsequenceE1 = new SubsequenceE1(CARef, SenderRef, CAOptionNumber, _e1Counter);
                    _subsequenceE1 = (SubsequenceE1)SequenceFactory.CreateSubSequence(CurrentSubsequence.E1, Options.GetOptions()["vendor"], CARef, SenderRef, CAOptionNumber, _e1Counter);
					_currentSubsequence = CurrentSubsequence.E1;
					break;
				case "CASHMOVE":
					_e2Counter++;
					//_subsequenceE2 = new SubsequenceE2(CARef, SenderRef, CAOptionNumber, _e2Counter);
                    _subsequenceE2 = (SubsequenceE2)SequenceFactory.CreateSubSequence(CurrentSubsequence.E2, Options.GetOptions()["vendor"], CARef, SenderRef, CAOptionNumber, _e2Counter);
					_currentSubsequence = CurrentSubsequence.E2;
					break;
				case "CAOPTN":
					_currentSubsequence = CurrentSubsequence.None;
					break;
			}
		}

		public void ParseField16S(string input)
		{
			switch (input)
			{
				//case "SECMOVE":	// Add the just parsed subsequence E1 to list
				         //   SubsequenceE1S.Add(_subsequenceE1);
				         //   _currentSubsequence = CurrentSubsequence.None;
				         //   break;
				//case "CASHMOVE":
				        //    SubsequenceE2S.Add(_subsequenceE2);
				        //    _currentSubsequence = CurrentSubsequence.None;
				         //   break;
				case "CAOPTN": // Nop
					// was for when no 16S is encountered; ok, add but only if the same object is not already in the list
					/*
							if (_subsequenceE1 != null)
								SubsequenceE1S.Add(_subsequenceE1);
							if (_subsequenceE2 != null)
								SubsequenceE2S.Add(_subsequenceE2);
					 */ 
					break;
			}
		}

		/// <summary>
		/// 13A
		/// </summary>
		/// <example></example>
		/// <param name="input"></param>
		public void ParseField13A(string code, string input)
		{
            if ((!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{3}$"))))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 13A.", GetType().Name));
            }

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "CAON": CAOptionNumber = int.Parse(s[1]); break;

				default: 
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
		/// <param name="input"></param>
		internal void ParseField22(string code, string input)
		{
            
            ParseField22Options(input);
			var s = input.Split(new[] { "/" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "CAOP":
                    CorpActionOptionCode = s[2];
                    CorpActionOptionCodeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "DISF": 
                    DispFractionsInd = s[2];
                    DispFractionsIndDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "OFFE": 
                    OfferType =  s[2];
                    OfferTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "OPTF":
                    OptionFeaturesInd = s[2];
                    OptionFeaturesIndDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "OSTA":
                    OptionStatus = s[2];
                    OptionStatusDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "CETI":
                    CrtficationBrkdwnType = s[2];
                    CrtficationBrkdwnTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
					break;

				case "CRDB": // NOP: This is not part of the standard but sometimes 22H:CRDB//CRED does appear in Sequence E
					break;

				default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                break;
			}
		}

		/// <summary>
		/// Place
		/// </summary>
		/// <example>Option C	:4!c//2!a	(Qualifier)(Country Code)</example>
		/// <param name="input"></param>
		public void ParseField94C(string code, string input)
		{
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{2}$")))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 94C", GetType().Name));
            }
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "DOMI": CountryDomicile = s[1];  break;
				case "NDOM": CountryNonDomicile = s[1]; break;

				default: 
                     {
                    SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Currency
		/// </summary>
		/// <example>Option A	:4!c//3!a	(Qualifier)(Currency Code)</example>
		/// <param name="input"></param>
        internal void ParseField11A(string code, string input)
		{

            ParseField11Options(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "OPTN": Currency = s[1]; break;
				default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                    break;
			}
		}

		/// <summary>
		/// Flag
		/// </summary>
		/// <example>Option B	:4!c//1!a	(Qualifier)(Flag)</example>
		/// <param name="input"></param>
        internal void ParseField17B(string code, string input)
		{
		
            //if not Option B raise error
            //
            ParseField17Options(input);
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
            if (!( s[1] == "N" || s[1] == "Y"))
                throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} at field 17B. Flag must be Y or N", GetType().Name, input));
			switch (s[0])
			{
                case "DFLT": IsDefault = s[1] ; break;
                case "STIN": IsStandingInstruction = s[1]; break;
                case "RCHG": IsCharges = s[1] ; break;
                case "CERT": IsCertificationBreakdown = s[1]; break;
                case "CHAN": IsChangeAllowed = s[1]; break;
                case "WTHD": IsWithdrawalAllowed = s[1];
					break;

				default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                break;
                   
					
			}
		}

		/// <summary>
		/// DateTime. Option A supported only
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n	(Qualifier)(Date)
		/// Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		/// Option C	:4!c//8!n6!n	(Qualifier)(Date)(Time)
		/// Option E	:4!c//8!n6!n[,3n][/[N]2!n[2!n]]	(Qualifier)(Date)(Time)(Decimals)(UTC Indicator)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField98A(string code, string input)
		{
          
            DateTimeOffset? workHHMMOffSet2 = null;
              
            
            ParseField98Options(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

            //Option B WITH Data Source Not Implemented
            if (s.Length == 1)
                throw new NotImplementedException(String.Format("{0}: Option B {1} encountered in field 98A not implemented.", GetType().Name, input));

            //UKWN date
			if (s[1].Length == 4)
				return;
            //Optons supported
            //A and C and E
            //Option B when no Data Source Scheme
            //
            
            var s1 = s[1].Split(new[] { "/" }, StringSplitOptions.None);
            switch (code.Substring(2, 1))
            {

                case "E":
                    if ((s1.Length == 2) && (s[0] == "CVPR" || s[0] == "PODT")) //Option E with UTC EarliestPayDate not supported per SMPG Best Practices 2014
                        throw new NotImplementedException(String.Format("{0}: Option {1} encountered in field 98E not implemented.", GetType().Name, input));
                    if (s1.Length == 2)
                        workHHMMOffSet2 = ParseDateTimeOffset(s1[0] + "/" + s1[1]);
                    else
                        workHHMMOffSet2 = ParseDateTimeOffset(s1[0]);
                   
                    break;
            }
        
    
			switch (s[0])
			{
				case "DVCP": 
                    DepositoryCoverExpiration = ParseDateOptionalTime(s[1]); 
                    break;
				case "EARD":
                    EarlyResponseDeadlineDate = (workHHMMOffSet2 == null) ? (DateTime)ParseDateOptionalTime(s[1]) : workHHMMOffSet2.Value.DateTime;
                    EarlyResponseDeadlineDateUTCOffsetHHmmss = (workHHMMOffSet2 == null) ? "00:00:00" : workHHMMOffSet2.Value.Offset.ToString();
                     break;
				case "EXPI": 
                    ExpiryDate = ParseDateOptionalTime(s[1]); 
                    break;
				case "MKDT":
                    MarketDeadlineDate = (workHHMMOffSet2 == null) ? (DateTime)ParseDateOptionalTime(s[1]) : workHHMMOffSet2.Value.DateTime;
                    MarketDeadlineDateUTCOffsetHHmmss = (workHHMMOffSet2 == null) ? "00:00:00" : workHHMMOffSet2.Value.Offset.ToString();
                    break;
				case "PODT": 
                    ProtectDate = ParseDateOptionalTime(s[1]); 
                    break;
				case "SUBS": 
                    SubscriptionCostDebit = ParseDateOptionalTime(s[1]); 
                    break;
				case "RDDT": 
                    ResponseDeadlineDate = (workHHMMOffSet2 == null) ? (DateTime)ParseDateOptionalTime(s[1]) : workHHMMOffSet2.Value.DateTime;
                    ResponseDeadlineDateUTCOffsetHHmmss = (workHHMMOffSet2 == null) ? "00:00:00" : workHHMMOffSet2.Value.Offset.ToString();
                    break;
				case "CVPR": 
                    CoverExpiration = ParseDateOptionalTime(s[1]); 
                    break;

				/*
				// From the Chinese Site: older version of the standard - this is now in SECMOVE / CASHMOVE
				case "PAYD":
					if (_subsequenceE1 == null)
						_subsequenceE1 = new SubsequenceE1();
						_subsequenceE1.PayDate = ParseDateOptionalTime(s[1]);
					break;
				case "FXDT":
					if (_subsequenceE2 == null)
						_subsequenceE2 = new SubsequenceE2();
					_subsequenceE2.FXRateFixingDate = ParseDateOptionalTime(s[1]);
					break;
				case "SPLT": // TODO
					break;
					*/

				default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                break;
			}
		}

		/// <summary>
		/// Period
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n/8!n	(Qualifier)(Date)(Date)
		/// Option B	:4!c//8!n6!n/8!n6!n	(Qualifier)(Date)(Time)(Date)(Time)
		/// Option C	:4!c//8!n/4!c	(Qualifier)(Date)(Date Code)
		/// Option D	:4!c//8!n6!n/4!c	(Qualifier)(Date)(Time)(Date Code)
		/// Option E	:4!c//4!c/8!n	(Qualifier)(Date Code)(Date)
		/// Option F	:4!c//4!c/8!n6!n	(Qualifier)(Date Code)(Date)(Time)
		/// Option J	:4!c//4!c	(Qualifier)(Date Code)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField69A(string code, string input)
		{
            string periodType;
            DateTime? periodStart = null;
            DateTime? periodEnd = null;


            ParseField69Options (input);
            
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			if (!Regex.IsMatch(s[0], "PRIC|REVO|PWAL|PARL|SUSP|AREV|DSWO"))
				//throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 69A.", GetType().Name, s[0]));
            {
                SequenceTagUnknownProcess(code, input);
                return;
            }

            periodType = s[0];
			
            
           	var splitResultB = s[1].Split(new[] {"/"}, StringSplitOptions.None);

			// Option J
			if (splitResultB.Length == 1)
			{
				periodStart = null;
				periodEnd = null;

				return;
			}

			// Option A
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
			{
                periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
			}

			// Option B
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
			{
				periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
                periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
			}

			// Option C, D
			if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN")
			{
				periodEnd = null;
				try
				{
					periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}

			// Option E, F
			if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN")
			{
				periodStart = null;

				try
				{
					periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}

            switch (s[0])
				{
					case "PRIC":
                        PeriodPriceCalculationStrtDte = periodStart;
                        PeriodPriceCalculationEndDte = periodEnd;
                        break;
                    case "REVO":
                        PeriodRevocabilityStrtDte = periodStart;
                        PeriodRevocabilityEndDte = periodEnd;
                        break;
                    case "PWAL":
                        PeriodActionStrtDte = periodStart;
                        PeriodActionEndDte = periodEnd;
                        break;
                    case "PARL":
                        PeriodParallelTradingStrtDte = periodStart;
                        PeriodParallelTradingEndDte = periodEnd;
                        break;
                    case "SUSP":
                        PeriodSuspnsinOfPrvelgeStrtDte = periodStart;
                        PeriodSuspnsinOfPrvelgeEndDte = periodEnd;
                        break;
                    case "AREV":
                        PeriodAccSrvcerRevocabilityStrtDte = periodStart;
                        PeriodAccSrvcerRevocabilityEndDte = periodEnd;
                        break;
                    case "DSWO":
                        PeriodDepoSuspWithdrwlStreetNamOutSecStrtDte = periodStart;
                        PeriodDepoSuspWithdrwlStreetNamOutSecEndDte = periodEnd;
                        break;

                    default: 
                         {
                                SequenceTagUnknownProcess(code, input);
                         }
                    break;
                }
		}

		/// <summary>
		/// Rate
		/// </summary>
		/// <example>Option A	:4!c//[N]15d				(Qualifier)(Sign)(Rate)
        ///          Option B   :4!c//3!a/3!a/15d (Qualifier)(First Currency Code)(Second Currency Code)(Rate) 
		///			 Option F	:4!c//3!a15d				(Qualifier)(Currency Code)(Amount)
		///			 Option J	:4!c/[8c]/4!c/3!a15d[/4!c]	(Qualifier)(Data Source Scheme)(Rate Type Code)(Currency Code)(Amount)(Rate Status)
		///			 Option K	:4!c//4!c					(Qualifier)(Rate Type Code)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField92A(string code, string input)
		{
            decimal? rate = null;
            decimal? amount = null;
            string ccyCode1 = null;
            string ccyCode2 = null;
            string rateTypeCode = null;
            string rateStatus = null;
            string dtaSrcSchme = null;

            ParseField92ABFJKOptions(input);
           
			//var s = input.Contains("//") ? input.Split(new[] {"//"}, StringSplitOptions.None) : input.Split(new[] {"/"}, StringSplitOptions.None);
            var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            
			string currency = null;
            switch (code)
            {
                case "92A":
                    rate = ParseDecimalFr(s[1]);
                    break;
                case "92B":
                    var s1 = s[1].Split(new[] { "/" }, StringSplitOptions.None);
                    rate = ParseDecimalFr(s1[2]);
                    ccyCode1 = s1[0];
                    ccyCode2 = s1[1];
                    break;
                case "92F":
                    amount = ParseNumberWithCurrency(s[1], out currency);
                    ccyCode1 = currency;
                    break;
                case "92J":
                    s = input.Split(new[] { "/" }, StringSplitOptions.None);
                    dtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];;
                    rateTypeCode = s[2];
                    amount = ParseNumberWithCurrency(s[3], out currency);
                    ccyCode1 = currency;
                    if (s.Length == 5)
                        rateStatus = s[4];
                    break;
                case "92K":
                    rateTypeCode = s[1];
                    break;
                   
            }
			switch (s[0])
			{
				case "GRSS":
                    DividendGrossRate = rate;
                    DividendGrossRateCcy = ccyCode1;
                    DividendGrossRateAmt = amount;
                    DividendGrossRateRateTypeCode = rateTypeCode;
                    DividendGrossRateRateStatus = rateStatus;
                    DividendGrossRateDtaSrcSchme = dtaSrcSchme;
                    break;
				case "TAXE":
                    TaxRelatedRate = rate;
                    TaxRelatedRateCcy = ccyCode1;
                    TaxRelatedRateAmt = amount;
                    TaxRelatedRateRateTypeCode = rateTypeCode;
                    TaxRelatedRateRateStatus = rateStatus;
                    TaxRelatedRateDtaSrcSchme = dtaSrcSchme;
                    break;
				case "TAXR": 
                    WithholdingTaxRate = rate;
                    WithholdingTaxRateRateTypeCode = rateTypeCode;
                    break;
				case "ATAX": 
                    AdditionalTax = rate;
                    AdditionalTaxRateTypeCode = rateTypeCode;
                    AdditionalTaxAmt = amount;
                    AdditionalTaxCcy = ccyCode1;
                    break;
				case "INDX":
                    IndexFactor = rate;
                    IndexFactorRateTypeCode = rateTypeCode;
                    IndexFactorAmt = amount;
                    IndexFactorCcy = ccyCode1;
                    break;
				case "OVEP":
                    MaximumAllowedOversubRate = rate;
                    MaximumAllowedOversubRateRateTypeCode = rateTypeCode;
                    break;
				case "PROR": 
                    ProRationRate = rate;
                    ProRationRateRateTypeCode = rateTypeCode;
                    break;
				case "INTP": 
                    InterestPaymentRate= rate;
                    InterestPaymentRateCcy = ccyCode1;
                    InterestPaymentRateAmt = amount;
                    InterestPaymentRateRateTypeCode = rateTypeCode;
                    InterestPaymentRateRateStatus = rateStatus;
                    InterestPaymentRateDtaSrcSchme = dtaSrcSchme;
                    break;
				case "TDMT": 
                    TaxableIncomePerDS = rate;
                    TaxableIncomePerDSCcy = ccyCode1;
                    TaxableIncomePerDSAmt = amount;
                    TaxableIncomePerDSRateTypeCode = rateTypeCode;
                    TaxableIncomePerDSRateStatus = rateStatus;
                    TaxableIncomePerDSDtaSrcSchme = dtaSrcSchme;
                    break;
				
				case "WITF": 
                    ForeignTaxWithholding = rate;
                    ForeignTaxWithholdingCcy = ccyCode1;
                    ForeignTaxWithholdingAmt = amount;
                    ForeignTaxWithholdingRateTypeCode = rateTypeCode;
                    break;
				
				case "NETT": 
                    NetRateShare = rate;
                    NetRateShareCcy = ccyCode1;
                    NetRateShareAmt = amount;
                    NetRateShareRateTypeCode = rateTypeCode;
                    NetRateShareRateStatus = rateStatus;
                    NetRateShareDtaSrcSchme = dtaSrcSchme;
                    break;	// Net Dividend Rate
                case "IDFX":
                    IssuerDeclaredExchRateCcy = ccyCode1;
                    IssuerDeclaredExchRateCcy2 = ccyCode2;
                    IssuerDeclaredExchRate = rate;
                    break;
   
				default: 
                     {
                    SequenceTagUnknownProcess(code, input);
                    }
                break;
			}
			
		}


		/// <summary>
		/// Price
		/// </summary>
		/// <example>
		///		Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///		Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///		Option E	:4!c//4!c	(Qualifier)(Price Code)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField90A(string code, string input)
		{

            ParseField90Options(input);

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            string priceAmountType = null;
            string pricePercentageType = null;
            decimal? price = null;
            string currency = null;

			if (!Regex.IsMatch(input, "CINL|OSUB")) //MRKT
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 90A.", GetType().Name, s[0]));

			// Option A: 4!c/15d
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}/\d+,\d*$"))
			{
				var splitA = s[1].Split(new[] { "/" }, StringSplitOptions.None);
                pricePercentageType = splitA[0];
                price = ParseDecimalFr(splitA[1]);
				//SetPrice90A(splitA[1], s[0]);
				
			}

			// Option B: 4!c/3!a15d
			else if (Regex.IsMatch(s[1], @"^[A-Z]{4}/[A-Z]{3}\d+,\d*$"))
			{
				var splitA = s[1].Split(new[] { "/" }, StringSplitOptions.None);

                priceAmountType = splitA[0];
                price = ParseNumberWithCurrency(splitA[1], out currency);

			}

			// Option E
			else if (Regex.IsMatch(s[1], @"^[A-Z]{4}$"))
			{
				price = null;
				
			}

			
            else
			throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 90A.", GetType().Name));

            //set Values
            switch (s[0])
            {
               
                case "CINL": 
                    CashinLieuSharesPrice = price;
                    CashinLieuSharesPriceAmtType = priceAmountType;
                    CashinLieuSharesPriceCcy = currency;
                    CashinLieuSharesPricePercType = pricePercentageType;
                    break;
                case "OSUB": 
                    OverSubDepositPrice = price;
                    OverSubDepositPriceAmtType = priceAmountType;
                    OverSubDepositPriceCcy = currency;
                    OverSubDepositPricePercType = pricePercentageType;
                    break;
                
                default: 
                     {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
            }


		}


		/// <summary>
		/// Quantity of Financial Instrument
		/// </summary>
		/// <example>Option B	:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)
		///			 Option C	:4!c//4!c		(Qualifier)(Quantity Code)</example>
		/// <param name="input"></param>
		internal void ParseField36A(string code, string input)
		{
            decimal? instrumentQuantity = null;
            string instrumentQuantityType = null;
            string instrumentQuantityTypeCode = null;

            ParseField36BCOptions(input);

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            instrumentQuantityType = s[0];

			// Option B
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}/\d+,\d*$"))
			{
				var splitB = s[1].Split(new[] { "/" }, StringSplitOptions.None);
                instrumentQuantityTypeCode = splitB[0];
                instrumentQuantity = ParseDecimalFr(splitB[1]);

			}
			// Option C
			else if (Regex.IsMatch(s[1], @"^[A-Z]{4}$"))
			{
                instrumentQuantityTypeCode = s[1];
				
			}
            else
			    throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in field 36A.", GetType().Name));


            //set Values
            switch (instrumentQuantityType)
            {
                case "MAEX":
                    InstrMaxXercisableQty = instrumentQuantity;
                    InstrMaxXercisableQtyCodeOrTypeCode = instrumentQuantityTypeCode;
                    break;
                case "MIEX":
                    InstrMinXercisableQty = instrumentQuantity;
                    InstrMinXercisableQtyCodeOrTypeCode = instrumentQuantityTypeCode;
                    break;
                case "MILT":
                    InstrMinXercisableMultiQty = instrumentQuantity;
                    InstrMinXercisableMultiQtyCodeOrTypeCode = instrumentQuantityTypeCode;
                    break;
                case "NBLT":
                    InstrNewBoardLotQty = instrumentQuantity;
                    InstrNewBoardLotQtyCodeOrTypeCode = instrumentQuantityTypeCode;
                    break;
                case "NEWD":
                    InstrNewDenominatonQty = instrumentQuantity;
                    InstrNewDenominatonQtyCodeOrTypeCode = instrumentQuantityTypeCode;
                    break;
                case "BOLQ":
                    InstrBackEndLotQty = instrumentQuantity;
                    InstrBackEndLotQtyCodeOrTypeCode = instrumentQuantityTypeCode;
                    break;
                case "FOLQ":
                    InstrFrontEndLotQty = instrumentQuantity;
                    InstrFrontEndLotQtyCodeOrTypeCode = instrumentQuantityTypeCode;

                    break;
                default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                   break;
            }


		}

		/// <summary>
		/// Narrative
		/// </summary>
		/// <example>Option E	:4!c//10*35x	(Qualifier)(Narrative)</example>
        internal void ParseField70E(string code, string input)
		{
            ParseField70EOptions(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			//_sbDetails.Append(s[1] + ";");
            switch (s[0])
            {
                case "ADTX":
                    TextAdditionalDetails = s[1];
                    break;
                case "TXNR":
                    TextNarrativeVersion = s[1];
                    break;
                case "INCO":
                    TextInfoConditions = s[1];
                    break;
                case "COMP":
                    TextInfoToComplyWith = s[1];
                    break;
                case "NSER":
                    TextSecurityRestriction = s[1];
                    break;
                case "TAXE":
                    TextTaxationConditions = s[1];
                    break;
                case "DISC":
                    TextDisclaimer = s[1];
                    break;
                case "CETI":
                    TextCertificationBreakdown = s[1];
                    break;


                default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                   break;
            }
		}

        internal static string GetHeaders()
		{
            return "CARef|SenderRef|CAOptionNumber|CountryDomicile|CountryNonDomicile|Currency|IsDefault|InstrTicker|InstrDescription" +
                   "|DepositoryCoverExpiration|EarlyResponseDeadlineDate|EarlyResponseDeadlineDateUTCOffsetHHmmss|ExpiryDate|MarketDeadlineDate|MarketDeadlineDateUTCOffsetHHmmss|ProtectDate|SubscriptionCostDebit|ResponseDeadlineDate|ResponseDeadlineDateUTCOffsetHHmmss|CoverExpiration" +
			       "|DividendGrossRate|TaxRelatedRate|WithholdingTaxRate|AdditionalTax|IndexFactor|MaximumAllowedOversubRate|ProRationRate" +
			       "|InterestPaymentRate|TaxableIncomePerDS|ForeignTaxWithholding|NetRateShare" +
                   "|CashinLieuSharesPrice|CashinLieuSharesPriceAmtType|CashinLieuSharesPriceCcy|CashinLieuSharesPricePercType" +
                   "|OverSubDepositPrice|OverSubDepositPriceAmtType|OverSubDepositPriceCcy|OverSubDepositPricePercType" +
                   "|TextAdditionalDetails|TextNarrativeVersion|TextInfoConditions|TextInfoToComplyWith|TextSecurityRestriction|TextTaxationConditions|TextDisclaimer|TextCertificationBreakdown|InstrISIN|InstrCntryCode" +

                   "|CorpActionOptionCode|CorpActionOptionCodeDtaSrcSchme|DispFractionsInd|DispFractionsIndDtaSrcSchme|OfferType|OfferTypeDtaSrcSchme" +
                   "|OptionFeaturesInd|OptionFeaturesIndDtaSrcSchme|OptionStatus|OptionStatusDtaSrcSchme|CrtficationBrkdwnType|CrtficationBrkdwnTypeDtaSrcSchme" +
                   "|IsStandingInstruction|IsCharges|IsCertificationBreakdown|IsChangeAllowed|IsWithdrawalAllowed" +
                   "|PeriodPriceCalculationStrtDte|PeriodPriceCalculationEndDte|PeriodRevocabilityStrtDte|PeriodRevocabilityEndDte" +
                   "|PeriodActionStrtDte|PeriodActionEndDte|PeriodParallelTradingStrtDte|PeriodParallelTradingEndDte|PeriodSuspnsinOfPrvelgeStrtDte|PeriodSuspnsinOfPrvelgeEndDte" +
                   "|PeriodAccSrvcerRevocabilityStrtDte|PeriodAccSrvcerRevocabilityEndDte|PeriodDepoSuspWithdrwlStreetNamOutSecStrtDte|PeriodDepoSuspWithdrwlStreetNamOutSecEndDte" +  
                   "|DividendGrossRateCcy|DividendGrossRateAmt|DividendGrossRateRateTypeCode|DividendGrossRateRateStatus|DividendGrossRateDtaSrcSchme" +
                   "|TaxRelatedRateCcy|TaxRelatedRateAmt|TaxRelatedRateRateTypeCode|TaxRelatedRateRateStatus|TaxRelatedRateDtaSrcSchme|WithholdingTaxRateRateTypeCode" +
                   "|AdditionalTaxRateTypeCode|AdditionalTaxCcy|AdditionalTaxAmt|IndexFactorRateTypeCode|IndexFactorCcy|IndexFactorAmt" +
                   "|MaximumAllowedOversubRateRateTypeCode|ProRationRateRateTypeCode|InterestPaymentRateCcy|InterestPaymentRateAmt|InterestPaymentRateRateTypeCode|InterestPaymentRateRateStatus" +
                   "|InterestPaymentRateDtaSrcSchme|TaxableIncomePerDSCcy|TaxableIncomePerDSAmt|TaxableIncomePerDSRateTypeCode|TaxableIncomePerDSRateStatus|TaxableIncomePerDSDtaSrcSchme " +
                   "|NetRateShareCcy|NetRateShareAmt|NetRateShareRateTypeCode|NetRateShareRateStatus|NetRateShareDtaSrcSchme" +
                   "|ForeignTaxWithholdingCcy|ForeignTaxWithholdingAmt|ForeignTaxWithholdingRateTypeCode|IssuerDeclaredExchRateCcy|IssuerDeclaredExchRateCcy2|IssuerDeclaredExchRate" +
                   "|InstrMaxXercisableQty|InstrMaxXercisableQtyCodeOrTypeCode|InstrMinXercisableQty|InstrMinXercisableQtyCodeOrTypeCode|InstrMinXercisableMultiQty|InstrMinXercisableMultiQtyCodeOrTypeCode" +
                   "|InstrNewBoardLotQty|InstrNewBoardLotQtyCodeOrTypeCode|InstrNewDenominatonQty|InstrNewDenominatonQtyCodeOrTypeCode" +
                   "|InstrBackEndLotQty|InstrBackEndLotQtyCodeOrTypeCode|InstrFrontEndLotQty|InstrFrontEndLotQtyCodeOrTypeCode|TagsNotRecognized";
		}

		public override string ToString()
		{
            var sb = new StringBuilder(1000);
            sb.Append("|" + CorpActionOptionCode); sb.Append("|" + CorpActionOptionCodeDtaSrcSchme); sb.Append("|" + DispFractionsInd); sb.Append("|" + DispFractionsIndDtaSrcSchme);
            sb.Append("|" + OfferType); sb.Append("|" + OfferTypeDtaSrcSchme); sb.Append("|" + OptionFeaturesInd); sb.Append("|" + OptionFeaturesIndDtaSrcSchme);
            sb.Append("|" + OptionStatus); sb.Append("|" + OptionStatusDtaSrcSchme); sb.Append("|" + CrtficationBrkdwnType); sb.Append("|" + CrtficationBrkdwnTypeDtaSrcSchme);
            sb.Append("|" + IsStandingInstruction); sb.Append("|" + IsCharges); sb.Append("|" + IsCertificationBreakdown); sb.Append("|" + IsChangeAllowed); sb.Append("|" + IsWithdrawalAllowed);
            sb.Append("|" + PeriodPriceCalculationStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodPriceCalculationEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodRevocabilityStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodRevocabilityEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss"));
            sb.Append("|" + PeriodActionStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodActionEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodParallelTradingStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodParallelTradingEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss"));
            sb.Append("|" + PeriodSuspnsinOfPrvelgeStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodSuspnsinOfPrvelgeEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodAccSrvcerRevocabilityStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodAccSrvcerRevocabilityEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss"));
            sb.Append("|" + PeriodDepoSuspWithdrwlStreetNamOutSecStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss")); sb.Append("|" + PeriodDepoSuspWithdrwlStreetNamOutSecEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss"));
            sb.Append("|" + DividendGrossRateCcy); sb.Append("|" + DividendGrossRateAmt); sb.Append("|" + DividendGrossRateRateTypeCode); sb.Append("|" + DividendGrossRateRateStatus); sb.Append("|" + DividendGrossRateDtaSrcSchme);
            sb.Append("|" + TaxRelatedRateCcy); sb.Append("|" + TaxRelatedRateAmt); sb.Append("|" + TaxRelatedRateRateTypeCode); sb.Append("|" + TaxRelatedRateRateStatus); sb.Append("|" + TaxRelatedRateDtaSrcSchme); sb.Append("|" + WithholdingTaxRateRateTypeCode);
            sb.Append("|" + AdditionalTaxRateTypeCode); sb.Append("|" + AdditionalTaxCcy); sb.Append("|" + AdditionalTaxAmt); sb.Append("|" + IndexFactorRateTypeCode); sb.Append("|" + IndexFactorCcy); sb.Append("|" + IndexFactorAmt);
            sb.Append("|" + MaximumAllowedOversubRateRateTypeCode); sb.Append("|" + ProRationRateRateTypeCode); sb.Append("|" + InterestPaymentRateCcy); sb.Append("|" + InterestPaymentRateAmt); sb.Append("|" + InterestPaymentRateRateTypeCode); sb.Append("|" + InterestPaymentRateRateStatus);
            sb.Append("|" + InterestPaymentRateDtaSrcSchme); sb.Append("|" + TaxableIncomePerDSCcy); sb.Append("|" + TaxableIncomePerDSAmt); sb.Append("|" + TaxableIncomePerDSRateTypeCode); sb.Append("|" + TaxableIncomePerDSRateStatus); sb.Append("|" + TaxableIncomePerDSDtaSrcSchme);
            sb.Append("|" + NetRateShareCcy); sb.Append("|" + NetRateShareAmt); sb.Append("|" + NetRateShareRateTypeCode); sb.Append("|" + NetRateShareRateStatus); sb.Append("|" + NetRateShareDtaSrcSchme);
            sb.Append("|" + ForeignTaxWithholdingCcy); sb.Append("|" + ForeignTaxWithholdingAmt); sb.Append("|" + ForeignTaxWithholdingRateTypeCode); sb.Append("|" + IssuerDeclaredExchRateCcy); sb.Append("|" + IssuerDeclaredExchRateCcy2); sb.Append("|" + IssuerDeclaredExchRate);
            sb.Append("|" + InstrMaxXercisableQty); sb.Append("|" + InstrMaxXercisableQtyCodeOrTypeCode); sb.Append("|" + InstrMinXercisableQty); sb.Append("|" + InstrMinXercisableQtyCodeOrTypeCode); sb.Append("|" + InstrMinXercisableMultiQty); sb.Append("|" + InstrMinXercisableMultiQtyCodeOrTypeCode);
            sb.Append("|" + InstrNewBoardLotQty); sb.Append("|" + InstrNewBoardLotQtyCodeOrTypeCode); sb.Append("|" + InstrNewDenominatonQty); sb.Append("|" + InstrNewDenominatonQtyCodeOrTypeCode);
            sb.Append("|" + InstrBackEndLotQty); sb.Append("|" + InstrBackEndLotQtyCodeOrTypeCode); sb.Append("|" + InstrFrontEndLotQty); sb.Append("|" + InstrFrontEndLotQtyCodeOrTypeCode);
            sb.Append("|" + _TagsNotRecognized);

            return CARef + "|" + SenderRef + "|" + CAOptionNumber + "|" + CountryDomicile + "|" + CountryNonDomicile + "|" + Currency + "|" + IsDefault + "|" + InstrTicker + "|" + InstrDescription +
                    "|" + DepositoryCoverExpiration.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EarlyResponseDeadlineDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EarlyResponseDeadlineDateUTCOffsetHHmmss + "|" + ExpiryDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MarketDeadlineDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MarketDeadlineDateUTCOffsetHHmmss + "|" + ProtectDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + SubscriptionCostDebit.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ResponseDeadlineDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ResponseDeadlineDateUTCOffsetHHmmss + "|" + CoverExpiration.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
					"|" + DividendGrossRate + "|" + TaxRelatedRate + "|" + WithholdingTaxRate + "|" + AdditionalTax + "|" + IndexFactor + "|" + MaximumAllowedOversubRate + "|" + ProRationRate +
					"|" + InterestPaymentRate + "|" + TaxableIncomePerDS + "|" + ForeignTaxWithholding + "|" + NetRateShare + 
                    "|" + CashinLieuSharesPrice + "|" + CashinLieuSharesPriceAmtType + "|" + CashinLieuSharesPriceCcy + "|" + CashinLieuSharesPricePercType + "|" + OverSubDepositPrice + "|" + OverSubDepositPriceAmtType + "|" + OverSubDepositPriceCcy + "|" + OverSubDepositPricePercType +
                   "|" + TextAdditionalDetails + "|" + TextNarrativeVersion + "|" + TextInfoConditions + "|" + TextInfoToComplyWith + "|" + TextSecurityRestriction + "|" + TextTaxationConditions + "|" + TextDisclaimer + "|" + TextCertificationBreakdown + "|" + InstrISIN + "|" + InstrCntryCode +
                   sb.ToString();
		}

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }
	}
}