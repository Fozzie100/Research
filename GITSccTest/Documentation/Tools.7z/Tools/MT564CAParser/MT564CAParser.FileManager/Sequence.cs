﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Runtime.CompilerServices;
using FTSE.MT564CAParser.FileManager.Exceptions;
using System.Collections;
using System.Collections.Generic;
[assembly: InternalsVisibleTo("FTSE.MT564CAParser.Test")]

namespace FTSE.MT564CAParser.FileManager
{
	internal abstract class Sequence : ISequenceTagOverflow
	{
       
        protected internal string _TagsNotRecognized;
        protected bool _isInE1A  = false;
        internal List<SequenceTagOverflow> _sequenceTagOverflowCache = new List<SequenceTagOverflow>();

        public abstract void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly);
        internal void SeqTagOverflowBase(SequenceTagOverflow sequenceOverflow, bool errorOnDuplicate)
        {
            
            //Get Placeholder(if it exists) frortag AND Qualifier and update to False as new PlaceHolder to be added
             List<SequenceTagOverflow> lastitem = _sequenceTagOverflowCache.FindAll(x => (bool)x.PlaceHolder == true && x.OverflowSequence == sequenceOverflow.OverflowSequence
                                                                && x.OverflowTag.Substring(0, 2) == sequenceOverflow.OverflowTag.Substring(0, 2)
                                                                && x.OverflowQualifier == sequenceOverflow.OverflowQualifier
                                                                );

    
             if ((lastitem.Count == 1) && (errorOnDuplicate))
             {
                 var mess = String.Format("Sequence:= {0} Tag:= {1} Qualifier: = {2} already parsed, cannot be parsed again", sequenceOverflow.OverflowSequence, sequenceOverflow.OverflowTag, sequenceOverflow.OverflowQualifier);
                 throw new MoreThanOneParseAttemptException(mess);
             }

            SequenceTagOverflow workFlow;
            if (lastitem.Count > 1)
                throw new Exception("Unexpected error - call IT");
            if (lastitem.Count == 1)
            {
                workFlow = lastitem[0];
                workFlow.PlaceHolder = false;
               
            }
            
            _sequenceTagOverflowCache.Add(sequenceOverflow);

   
        }

        internal virtual void Parse(string code, string text)
        {
            
             //quit if sequence delimiter code = 16R or 16S
            if ((code == "16R") || (code == "16S"))
                return;

            var s = text.Split(new[] { "/" }, StringSplitOptions.None);
                       
            SequenceTagOverflowProcess(GetTypeName(), code, s[0], true);
           
        }

        internal void SequenceTagUnknownProcess(string code, string text)
        {
            _TagsNotRecognized = _TagsNotRecognized + ":::" + GetTypeName() + ":" + code + "::" + text;
        }

        private string GetTypeName()
        {
            //For E1a sequence processed along with E1 in SubsequenceE1 class
            //For specialiased Vendor Sequence types, get base name
            if (_isInE1A)
                return "SubsequenceE1a";
            else if (GetType().BaseType.Name == "Sequence")
                return GetType().Name;
            else
                return GetType().BaseType.Name;
        }
		private static CultureInfo CultureFr
		{
			get { return CultureInfo.CreateSpecificCulture("fr-FR"); }
		}

        internal static decimal? ParseDecimalFr(string input)
		{
			if (string.IsNullOrWhiteSpace(input))
				return null;

			if (input == "UKWN" || input == "OPEN" || input == "ANYA")
				return null;

			return Decimal.Parse(input.Replace("N", "-"), CultureFr);
		}

        internal static decimal? ParseNumberWithCurrency(string input, out string currency)
		{
            //currency = null;
            //if (string.IsNullOrWhiteSpace(input))
            //    return null;

            //// Option A
            //if (Regex.IsMatch(input, @"^N*\d+,\d*$"))
            //    return Decimal.Parse(input.Replace("N", "-"), CultureFr);

			// Option F
			if (Regex.IsMatch(input, @"^[A-Z]{3}\d+,\d*$"))
			{
				currency = input.Substring(0, 3);
				return Decimal.Parse(input.Substring(3).Replace("N", "-"), CultureFr);
			}

            //// Option K
            //if (Regex.IsMatch(input, @"^[A-Z]{4}$"))
            //{
            //    // In this case the rate is either NILP (nil) or UKWN - unknown
            //    return null;
            //}
			throw new ArgumentOutOfRangeException(String.Format("Could not parse the input {0} as a date /with or without hh:mm:ss/.", input));
		}

        internal static DateTime? ParseDateOptionalTime(string input, bool throwExceptionBadInput = false)
		{
			if (String.IsNullOrWhiteSpace(input))
				return null;

			if (input == "ONGO" || input == "UKWN" || input == "OPEN")
				return null;

			try
			{
				return DateTime.ParseExact(input, "yyyyMMdd", CultureInfo.InvariantCulture);
			}
			catch (FormatException)
			{
				try
				{
					return DateTime.ParseExact(input, "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{

                    try
                    {
                        return DateTime.ParseExact(input, "yyyyMMddHHmmss,fff", CultureInfo.InvariantCulture);
                    }
                    catch (FormatException)
                    {
                        if (throwExceptionBadInput)
                            throw;
                    }

					return null;
				}
			}
		}

        protected internal  DateTimeOffset ParseDateTimeOffset(string input)
        {
            DateTime workUTCDate;
            string workUTCDateOffSet;
              if (
             (!(Regex.IsMatch(input, @"^\d{14}(,\d{3})?(/(N)?\d{2}(\d{2})?)?$")))
                 )
              {
                  throw new UnexpectedCodeException(String.Format("{0}: Incorrect UTC Data format. {1}", GetType().Name, input));
              }

            //Must be in format
            char pad = '0';
            var s1 = input.Split(new[] { "/" }, StringSplitOptions.None);
            var sign = 1;
            workUTCDateOffSet = "0000";

            workUTCDate = (DateTime)ParseDateOptionalTime(s1[0], true);
            if (s1.Length == 2)
            {
                sign = s1[1].Contains("N") ? -1 : 1;
                workUTCDateOffSet = s1[1].Replace("N", String.Empty).PadRight(4, pad).Substring(0, 4);
             }
       
           return new DateTimeOffset(workUTCDate.Year, workUTCDate.Month, workUTCDate.Day, workUTCDate.Hour, workUTCDate.Minute, workUTCDate.Second, workUTCDate.Millisecond, new TimeSpan(sign * Convert.ToInt32(workUTCDateOffSet.Substring(0, 2)), sign * Convert.ToInt32(workUTCDateOffSet.Substring(2, 2)), 0));
        }
        internal static string ParseAmountTypeCode(string input)
		{
			if (input.Contains("/ACTU/"))
				return "ACTU";
			if (input.Contains("/DISC/"))
				return "DISC";
			if (input.Contains("/PLOT/"))
				return "PLOT";
			if (input.Contains("/PREM/"))
				return "PREM";

			return null;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <example>/GB/B43GVJ8
		/// /HAZEL RENEWABLE ENERGY 
		/// VCT 2 PLC/ORD GBP0.001</example>
		/// <param name="input"></param>
		/// <param name="sedol"> </param>
		/// <param name="entity"> </param>
        internal void ParseField35B(string input, out string sedol, out string entity, out string ISIN, out string countrycode)
        {
            //var regexDash = new Regex(@"^\s*/");
            //input = regexDash.Replace(input, string.Empty);
            //var s = input.Split(new[] { "/" }, 3, StringSplitOptions.None);
            //sedol = entity = null;
            //sedol = s[1].Substring(0, 7);
            //if (s.GetUpperBound(0) == 2)
            //    entity = s[1].Substring(7) + s[2].ToString();
            //else
            //    entity = s[1].Substring(7);

            //TODO - Get IDC to add delimiter chracter, then uncomment


            var regexISIN = new Regex("^ISIN");
            string[] sISIN;
            //var arrayOffset = 0;
            ISIN = null;


            //Remove first / if present
            var regexFwdSlash = new Regex(@"^\s*/");
            input = regexFwdSlash.Replace(input, string.Empty);
                       
            if (regexISIN.IsMatch(input))
            {
                sISIN = input.Split(new[] { "/" }, 4, StringSplitOptions.None);
                ISIN = sISIN[0].Substring(5);
                sedol = String.IsNullOrWhiteSpace(sISIN[2]) ? null : sISIN[2];
                entity = String.IsNullOrWhiteSpace(sISIN[3]) ? null : sISIN[3];
                countrycode = String.IsNullOrWhiteSpace(sISIN[1]) ? null : sISIN[1];

            }
            else
            {
                sISIN = input.Split(new[] { "/" }, 3, StringSplitOptions.None);
                countrycode = String.IsNullOrWhiteSpace(sISIN[0]) ? null : sISIN[0];
                sedol = String.IsNullOrWhiteSpace(sISIN[1]) ? null : sISIN[1];
                entity = String.IsNullOrWhiteSpace(sISIN[2]) ? null : sISIN[2];
            }

                      
           
        }

        protected void ParseField69Options(string input)
        {
            if (
               (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{8}/[0-9]{8}$")))  // option A
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{14}/[0-9]{14}$"))) //option B
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{8}/[A-Z]{4}$")))  // Option C
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{14}/[A-Z]{4}$")))          //Option D
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/([0-9]{8}|[0-9]{14})$"))) //OPtion E & F
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //Option J
               )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 69. {1}", GetType().Name, input));
            }
        }
        protected void ParseField69ABCDEFOptions(string input)
        {
            if (
               (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{8}/[0-9]{8}$")))  // option A
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{14}/[0-9]{14}$"))) //option B
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{8}/[A-Z]{4}$")))  // Option C
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{14}/[A-Z]{4}$")))          //Option D
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/([0-9]{8}|[0-9]{14})$"))) //OPtion E & F
              
               )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 69. {1}", GetType().Name, input));
            }
        }

        protected void ParseField17Options(string input)
        {
            //if not Option B raise error
            //
            if ((!(Regex.IsMatch(input, @"^[A-Z]{4}//(Y|N){1}"))))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 17B. {1}", GetType().Name, input));
            }
        }


        protected void ParseField22Options(string input)
        {
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z0-9]{4}$")))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 22. {1}", GetType().Name, input));
            }
        }

        protected void ParseField36BCOptions(string input)
        {
            //if not Option B or C, raise error
            //
            if ((!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/\d{1,15},\d{0,15}$"))) && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 36. {1}", GetType().Name, input));
            }
        }
        protected void ParseField36BOptions(string input)
        {
            //if not Option B raise error
            //
            if ((!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/\d{1,15},\d{0,15}$"))) )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 36B. {1}", GetType().Name, input));
            }
        }
        protected void ParseField36BEOptions(string input)
        {
            //if not Option B or E, raise error
            //
            if ((!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/(N)?\d{1,15},\d{0,15}$")))  //Option E
                && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))))      //Option B
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 36. {1}", GetType().Name, input));
            }
        }

        protected void ParseField90Options(string input)
        {
            if (

                     (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/\d{1,15},\d{0,15}$")))  // option A
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}$"))) //option B
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //option E

                   )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 90. {1}", GetType().Name, input));
            }
        }

        protected void ParseField90ABEFJKOptions(string input)
        {
            if (
                             (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/\d{1,15},\d{0,15}$")))  // option A
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}$"))) //option B
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //option E
                       && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}/[A-Z]{4}/\d{1,15},\d{0,15}$"))) //option F
                              && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}/[A-Z]{3}\d{1,15},\d{0,15}$"))) //option J
                              && (!(Regex.IsMatch(input, @"^[A-Z]{4}//\d{1,15},\d{0,15}$"))) //option K
                           )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 90. {1}", GetType().Name, input));
            }
        }
        protected  void ParseField92E1Options(string input)
        {
            if (
                   (!(Regex.IsMatch(input, @"^[A-Z]{4}//[N]{0,1}\d{1,15},\d{0,15}$")))  // option A
                    
                   && (!(Regex.IsMatch(input, @"^[A-Z]{4}//\d{1,15},\d{0,15}/\d{1,15},\d{0,15}$"))) //option D
                    && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}$"))) //option F
                    && (!(Regex.IsMatch(input, @"^[A-Z]{4}/([A-Z]{8}|[A-Z]{0})/[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}(/{0}[A-Z]{0}|/{1}[A-Z]{4})$"))) //option J
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //Option K
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}/[A-Z]{3}\d{1,15},\d{0,15}$"))) //option L
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}/\d{1,15},\d{0,15}$"))) //option M
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//\d{1,15},\d{0,15}/[A-Z]{3}\d{1,15},\d{0,15}$"))) //option N

                   )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 92. {1}", GetType().Name, input));
            }
        }

        protected void ParseField92ADKOptions(string input)
        {
            if (
                   (!(Regex.IsMatch(input, @"^[A-Z]{4}//[N]{0,1}\d{1,15},\d{0,15}$")))  // option A
                   && (!(Regex.IsMatch(input, @"^[A-Z]{4}//\d{1,15},\d{0,15}/\d{1,15},\d{0,15}$"))) //option D
                   && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //Option K
                     
                   )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 92. {1}", GetType().Name, input));
            }
        }
        protected void ParseField92E2Options(string input)
        {
            if (
                   (!(Regex.IsMatch(input, @"^[A-Z]{4}//[N]{0,1}\d{1,15},\d{0,15}$")))  // option A
                    && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}/[A-Z]{3}/\d{1,15},\d{0,15}$"))) //option B
                    && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}$"))) //option F
                    // && (!(Regex.IsMatch(input, @"^[A-Z]{4}/([A-Z]{8}|[A-Z]{0})/[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}(/{0}[A-Z]{0}|/{1}[A-Z]{4})$"))) //option J
                    && (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}(/[A-Z0-9]{4})?$"))) //option J
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //Option K
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}/\d{1,15},\d{0,15}$"))) //option M
                )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 92. {1}", GetType().Name, input));
            }
        }
        protected void ParseField92ABFJKOptions(string input)
        {
            if (
                      (!(Regex.IsMatch(input, @"^[A-Z]{4}//[N]{0,1}\d{1,15},\d{0,15}$")))  // option A
                        && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}/[A-Z]{3}/\d{1,15},\d{0,15}$"))) //option B
                        && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}$"))) //option F
                        && (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}(/[A-Z0-9]{4})?$"))) //option J
                          && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //Option K
                    )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 92. {1}", GetType().Name, input));
            }
        }
        protected void ParseField98Options(string input)
        {
            if (
                  (!(Regex.IsMatch(input, @"^[A-Z0-9]{4}//[0-9]{8}$")))  // option A
                        && (!(Regex.IsMatch(input, @"^[A-Z0-9]{4}/[A-Z]{0,8}/[A-Z]{4}$"))) //option B
                        && (!(Regex.IsMatch(input, @"^[A-Z0-9]{4}//[0-9]{14}$")))  // Option C
                        && (!(Regex.IsMatch(input, @"^[A-Z0-9]{4}//\d{14}(,\d{3})?(/(N)?\d{2}(\d{2})?)?$")))  //Option E
                      )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 98. {1}", GetType().Name, input));
            }
        }
        protected void ParseField98ABOptions(string input)
        {
            if (
                  (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{8}$")))  // option A
                        && (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z0-9]{4}$"))) //option B
                       
                      )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 98. {1}", GetType().Name, input));
            }
        }

        protected void ParseField11Options(string input)
        {
        if ((!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}$"))))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 11A. {1}", GetType().Name, input));
            }
        }
    
        protected void ParseField12Options(string input)
        {
            if (
                  (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z]{0,8}/.{0,40}$", RegexOptions.Singleline)))  // option A
                        && (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z]{0,8}/[A-Z0-9]{4}$"))) //option B
                        && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z0-9]{6}$")))  // Option C
                      )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 12. {1}", GetType().Name, input));
            }
        }

        protected void ParseField94BOptions(string input)
        {
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z]{0,8}/[A-Z]{4}(/.{1,30})?$", RegexOptions.Singleline)))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 94B.  {1}", GetType().Name, input));
            }
        }
        protected void ParseField94BCFOptions(string code, string input)
        {
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z0-9]{4}(/.{1,30})?$", RegexOptions.Singleline) && (code == "94B")) //Option B
                && !(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{2}$")) //Option C
                && !(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z0-9]{4}/[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$") && (code == "94F")) //Option F
                )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 94.  {1}", GetType().Name, input));
            }
        }

        protected void ParseField70EOptions(string input)
        {
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}//.{0,400}$", RegexOptions.Singleline)))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 70E.  {1}", GetType().Name, input));
            }
        }

        protected void ParseField93Options(string input)
        {
            if (
                  (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z]{4}/(N)?\d{1,15},\d{0,15}$")))  // option B

                        && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/[A-Z]{4}/(N)?\d{1,15},\d{0,15}$")))  // Option C
                      )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 93. {1}", GetType().Name, input));
            }
        }

        protected void ParseField98AOptions(string input)
        {
            if (
                     (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{8}$")))  // option A
                    )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 98A. {1}", GetType().Name, input));
            }
        }
        protected void ParseField98ACOptions(string input)
        {
            if (
                     (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{8}$")))  // option A
                      && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[0-9]{14}$")))  // option C
                    )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 98. {1}", GetType().Name, input));
            }
        }


        protected void ParseField20COptions(string input)
        {
            if (
                     (!(Regex.IsMatch(input, @"^[A-Z]{4}//.{1,16}$")))  // option C
                    )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 20C. {1}", GetType().Name, input));
            }
        }
	}
}