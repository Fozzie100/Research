﻿using System.Text.RegularExpressions;
using System;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	internal class SubsequenceA1 : Sequence
	{
		private readonly int _a1No;
      
		#region SWIFT Message attributes
		public string LinkType { get; set; }
        public string LinkTypeDtaSrcSchme { get; set; }
		public string LinkedMessage { get; set; }
        public string LinkedMessageDtaSrcSchme { get; set; }
		//public string Reference { get; set; }

		public string LinkCARef { get; private set; }
		public string PrevMessageRef { get; private set; }
		public string CaseNo { get; private set; }
        public string LinkOfficialCARef { get; private set; }
        public string RelatedMessageRef { get; private set; }
        internal string CARef { get; private set; }
        internal string SenderRef { get; private set; }
		#endregion

      
		public SubsequenceA1(string caRef, string senderRef, int a1No)
		{
			CARef = caRef;
			SenderRef = senderRef;
			_a1No = a1No;
          
		}

		/// <summary>
		/// Main method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
            base.Parse(code, text);
			switch (code)
			{
				case "22F": ParseField22F(code, text);
					break;
				case "13A": ParseField13A(code, text);
					break;
				case "20C": ParseField20C(code, text);
					break;
					
				case "16S": // Nop
					//base.Parse(code, text);
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}
        /// <summary>
        /// Linked Message
        /// Option A :4!c//3!c (Qualifier)(Number Id) 
        /// Option B :4!c/[8c]/30x (Qualifier)(Data Source Scheme)(Number) 
        /// </summary>
        /// <param name="input"></param>
		private void ParseField13A(string code, string input)
		{
            //ParseField13A(input);
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z]{0,8}/.{1,30}$")) //Option B
                 && !(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z0-9]{3}$")) //Option A
             
                 )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 13a", GetType().Name));
            }

			var s = input.Split(new[] { "/" }, StringSplitOptions.None);
            var dataSourceScheme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];

            
			switch (s[0])
			{
				case "LINK": 
                    LinkedMessage = s[2];
                    LinkedMessageDtaSrcSchme = dataSourceScheme;
                    break;
                default:
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Indicator: Corporate Action Type
        /// Option F :4!c/[8c]/4!c (Qualifier)(Data Source Scheme)(Indicator) 
		/// </summary>
		/// <param name="input"></param>
		private  void ParseField22F(string code, string input)
		{
            ParseField22Options(input);
			var s = input.Split(new[] { "/" }, StringSplitOptions.None);
            var dataSourceScheme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];

            
			switch (s[0])
			{
				case "LINK": 
					LinkType = s[2];
                    LinkTypeDtaSrcSchme = dataSourceScheme;
					break;


				default: 
                {
                    SequenceTagUnknownProcess(code, input);
                }
                break;
			}
		}

		private void ParseField20C(string code, string input)
		{
            ParseField20COptions(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            
            
			switch (s[0])
			{
                case "COAF": LinkOfficialCARef = s[1]; break;
				case "CORP": LinkCARef = s[1]; break;
                case "RELA": RelatedMessageRef = s[1]; break;
				case "PREV": PrevMessageRef = s[1]; break;
				case "CACN": CaseNo = s[1]; break;

				default: 
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                break;
			}
		}

		internal static string GetHeaders()
		{
            return "CARef|SenderRef|SeqNum|LinkType|LinkTypeDtaSrcSchme|LinkedMessage|LinkedMessageDtaSrcSchme|LinkCARef|LinkOfficialCARef|PrevMessageRef|RelatedMessageRef|CaseNo|TagsNotRecognized";
		}

		public override string ToString()
		{
            return CARef + "|" + SenderRef + "|" + _a1No + "|" + LinkType + "|" + LinkTypeDtaSrcSchme + "|" + LinkedMessage + "|" + LinkedMessageDtaSrcSchme + "|" + LinkCARef + "|" + LinkOfficialCARef + "|" + PrevMessageRef + "|" + RelatedMessageRef + "|" + CaseNo + "|" + _TagsNotRecognized;
		}


        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }
          
	}
}