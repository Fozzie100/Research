﻿using System;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Sequence D of MT564 - Corporate Action Details
	/// </summary>
    internal class SequenceD : Sequence
	{
		private readonly StringBuilder _sbDetails = new StringBuilder();
		
					
		#region SWIFT Message attributes
	
		
		/// <summary>
		/// 98A
		/// </summary>
		internal DateTime? AnnouncementDate { get; private set; }
        internal DateTime? ExDate { get; private set; }
        internal DateTime? EffectiveDate { get; private set; }
        internal DateTime? DeadlineSplitDate { get; private set; }
        internal DateTime? MeetingDate { get; private set; }
        internal DateTime? MeetingDate2 { get; private set; }
        internal DateTime? MeetingDate3 { get; private set; }
        internal DateTime? RecordDate { get; private set; }
        internal DateTime? ExDateSpecial { get; private set; }
        internal DateTime? PayDate { get; private set; }
        internal DateTime? FurtherDetailedAnnouncementDate { get; private set; }
        internal DateTime? CourtApprovalDate { get; private set; }
        internal DateTime? TradingSuspendedDate { get; private set; }
        internal DateTime? ProrationDate { get; private set; }
        internal DateTime? DeadlineToRegister { get; private set; }
        internal DateTime? WhollyUnconditionalDate { get; private set; }
        internal DateTime? ResultsPublicationDate { get; private set; }
        internal DateTime? NewMaturityDate { get; private set; }
        internal DateTime? UnconditionalDate { get; private set; }

        internal DateTime? CertificationDeadlineDate { get; private set; }
        internal DateTime? TaxBreakdownInstructionsDeadlineDate { get; private set; }
        internal DateTime? LotteryDate { get; private set; }
        internal DateTime? EqualizationDate { get; private set; }
        internal DateTime? EarlyClosingDate { get; private set; }
        internal DateTime? FixingDate { get; private set; }
        internal DateTime? MarginFixingDate { get; private set; }
        internal DateTime? OfficialAnnoucementDate { get; private set; }
        internal DateTime? GuaranteedParticipationDate { get; private set; }
        internal DateTime? ElectiontoCounterpartyDate { get; private set; }
        internal DateTime? LapsedDate { get; private set; }
        internal DateTime? MarketClaimTrackingEndDate { get; private set; }
        internal DateTime? ThirdPartyDeadlineDate { get; private set; }
        internal DateTime? LeadPlaintiffDeadlineDate { get; private set; }
        internal string LeadPlaintiffDeadlineDateUTCOffsetHHmmss { get; private set; }
        internal DateTime? FilingDate { get; private set; }
        internal DateTime? HearingDate { get; private set; }

		/// <summary>
		/// 69A - Period Type
		/// </summary>
        //public string PeriodType { get; set; }
        ///// <summary>
        ///// 69A - Period Start
        ///// </summary>
        //public DateTime? PeriodStart { get; private set; }
        ///// <summary>
        ///// 69A - Period End
        ///// </summary>
        //public DateTime? PeriodEnd { get; private set; }

        internal DateTime? PeriodPriceCalculationStrtDte { get; private set; }
        internal DateTime? PeriodPriceCalculationEndDte { get; private set; }
        internal DateTime? PeriodInterestStrtDate { get; private set; }
        internal DateTime? PeriodInterestEndDte { get; private set; }
        internal DateTime? PeriodCompulsoryPurchaseStrtDte { get; private set; }
        internal DateTime? PeriodCompulsoryPurchaseEndDte { get; private set; }
        internal DateTime? PeriodBlockingStrtDte { get; private set; }
        internal DateTime? PeriodBlockingEndDte { get; private set; }
        internal DateTime? PeriodClaimStrtDte { get; private set; }
        internal DateTime? PeriodClaimEndDte { get; private set; }
        internal DateTime? PeriodDepSuspWthdralNomineeNameStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspWthdralNomineeNameEndDte { get; private set; }
        internal DateTime? PeriodDepSuspDepositStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspDepositEndDte { get; private set; }
        internal DateTime? PeriodDepSuspBookEntryXferStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspBookEntryXferEndDte { get; private set; }
        internal DateTime? PeriodDepSuspDepositAgentStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspDepositAgentEndDte { get; private set; }
        internal DateTime? PeriodDepSuspWthdralAgentStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspWthdralAgentEndDte { get; private set; }
        internal DateTime? PeriodDepSuspPledgeStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspPledgeEndDte { get; private set; }
        internal DateTime? PeriodDepSuspSegregationStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspSegregationEndDte { get; private set; }
        internal DateTime? PeriodDepSuspWthdralStreetNameStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspWthdralStreetNameEndDte { get; private set; }
        internal DateTime? PeriodDepSuspBookClosureStrtDte { get; private set; }
        internal DateTime? PeriodDepSuspBookClosureEndDte { get; private set; }
        internal DateTime? PeriodCoDepositoriesSuspStrtDte { get; private set; }
        internal DateTime? PeriodCoDepositoriesSuspEndDte { get; private set; }

		/// <summary>
		/// 99A - Days accrued
		/// </summary>
        internal int? DaysAccrued { get; set; }

		/// <summary>
		/// 92A - Interest Rate
		/// </summary>
        internal decimal? InterestRate { get; private set; }
        internal decimal? BidIntervalRate { get; private set; }
        internal decimal? PercentageSought { get; private set; }
		// public string RateCurrency { get; private set; }

		/// <summary>
		/// 92A - Rate Types
		/// </summary>
        internal string InterestRateCcy { get; private set; }
        internal decimal? InterestRateAmt { get; private set; }
        internal string BidIntervalRateCcy { get; private set; }
        internal decimal? BidIntervalRateAmt { get; private set; }
        internal string PercentageSoughtRateTypeCode { get; private set; }

        internal decimal? RateReInvestmentDiscToMrkt { get; private set; }

        internal decimal? RateNextFactor { get; private set; }
        internal decimal? RatePrevFactor { get; private set; }
        internal decimal? RateRelatedIndex { get; private set; }
        internal decimal? RateSpread { get; private set; }

        internal decimal? RateIntrstShrtFall { get; private set; }
        internal string RateIntrstShrtFallCcy { get; private set; }
        internal decimal? RateIntrstShrtFallAmt { get; private set; }

        internal decimal? RateRealisedLoss { get; private set; }
        internal string RateRealisedLossCcy { get; private set; }
        internal decimal? RateRealisedLossAmt { get; private set; }

        internal decimal? RateDeclared { get; private set; }
        internal string RateDeclaredCcy { get; private set; }
        internal decimal? RateDeclaredAmt { get; private set; }


        


		/// <summary>
		/// 90A - Maximum Price
		/// </summary>
        internal decimal? PriceMax { get; set; }
		/// <summary>
		/// 90A - Minimum Price
		/// </summary>
        internal decimal? PriceMin { get; set; }
		/// <summary>
		/// 90A - Price Currency
		/// </summary>
        internal string PriceMaxCurrency { get; set; }
        internal string PriceMaxPercentType { get; private set; }
        internal string PriceMaxAmountType { get; private set; }
        internal string PriceMinCurrency { get; set; }
        internal string PriceMinPercentType { get; private set; }
        internal string PriceMinAmountType { get; private set; }
		
		/// <summary>
		/// 36A - Fin Instr Quantity Type
		/// </summary>
        //public string FIQuantityType { get; set; }

        ///// <summary>
        ///// 36A - Fin Instr Quantity
        ///// </summary>
        //public decimal? FIQuantity { get; set; }
        
        /// <summary>
        /// 36A - Fin Instr Quantity Type
        /// </summary>
        internal decimal? FIQtyMinXercisble { get; set; }
        internal string FIQtyMinXercisbleCodeOrTypeCode { get; set; }
        internal decimal? FIQtyMinMultiXercisble { get; set; }
        internal string FIQtyMinMultiXercisbleCodeOrTypeCode { get; set; }
        internal decimal? FIQtyMaxSecurities { get; set; }
        internal string FIQtyMaxSecuritiesCodeOrTypeCode { get; set; }
        internal decimal? FIQtyMinSought { get; set; }
        internal string FIQtyMinSoughtCodeOrTypeCode { get; set; }
        internal decimal? FIQtyNewBoardLot { get; set; }
        internal string FIQtyNewBoardLotCodeOrTypeCode { get; set; }
        internal decimal? FIQtyNewDenomination { get; set; }
        internal string FIQtyNewDenominationCodeOrTypeCode { get; set; }
        internal decimal? FIQtyBaseDenomination { get; set; }
        internal string FIQtyBaseDenominationCodeOrTypeCode { get; set; }
        internal decimal? FIQtyIncDenomination { get; set; }
        internal string FIQtyIncDenominationCodeOrTypeCode { get; set; }
		/// <summary>
        /// 13A - Coupon Number
		/// </summary>
        internal string CouponNumber { get; set; }
        internal string CouponNumberDtaSrcSchme { get; set; }

		/// <summary>
		/// 17B - Certification Flag
		/// </summary>
        internal string IsCertification { get; private set; }
		/// <summary>
		/// 17 B - Charges Flag
		/// </summary>
        internal string IsChargesApply { get; private set; }
		/// <summary>
		/// 17B - Certification Flag
		/// </summary>
        internal string IsComplianceInfo { get; private set; }
		/// <summary>
		/// 17B - Accrued Interest Indicator
		/// </summary>
        internal string IsEntitledAccruedInterest { get; private set; }
        internal string IsLetterOfGuaranteed { get; private set; }
		
		/// <summary>
		/// 22F - Dividend Type
		/// </summary>
        internal string DividendType { get; private set; }

        internal string DistributionType { get; private set; }
        internal string OfferType { get; private set; }

        internal string CorpActionEventStage { get; private set; }
        internal string AdditionalBusinessProcess { get; private set; }

        internal string RenounceStatusEntitlement { get; private set; }
        internal string IntermSecDistrib { get; private set; }

        internal string DividendTypeDtaSrcSchme { get; private set; }
        internal string DistributionTypeDtaSrcSchme { get; private set; }
        internal string OfferTypeDtaSrcSchme { get; private set; }
        internal string CorpActionEventStageDtaSrcSchme { get; private set; }
        internal string AdditionalBusinessProcessDtaSrcSchme { get; private set; }
        internal string RenounceStatusEntitlementDtaSrcSchme { get; private set; }
        internal string IntermSecDistribDtaSrcSchme { get; private set; }

        internal string ConversionType { get; private set; }
        internal string ConversionTypeDtaSrcSchme { get; private set; }
        internal string ChangeType { get; private set; }
        internal string ChangeTypeDtaSrcSchme { get; private set; }
        internal string CapitalGainType { get; private set; }
        internal string CapitalGainTypeDtaSrcSchme { get; private set; }
        internal string TIDTISCalcType { get; private set; }
        internal string TIDTISCalcTypeDtaSrcSchme { get; private set; }
        internal string ElectionType { get; private set; }
        internal string ElectionTypeDtaSrcSchme { get; private set; }
        internal string LotteryType { get; private set; }
        internal string LotteryTypeDtaSrcSchme { get; private set; }
        internal string CertificationType { get; private set; }
        internal string CertificationTypeDtaSrcSchme { get; private set; }
		/// <summary>
		/// 22F - Indicator Type
		/// </summary>
        //public string IndicatorType { get; set; }
        ///// <summary>
        ///// 22F - IndicatorValue
        ///// </summary>
        //public string IndicatorValue { get; set; }

		/// <summary>
		/// 94E - Place (of meeting / New Place of Incorp.)
		/// </summary>
        internal string PlaceMeeting { get; set; }
        internal string Place2Meeting { get; set; }
        internal string Place3Meeting { get; set; }
        internal string PlaceofOfIncorporation { get; set; }

		/// <summary>
		/// 70 - Other Details
		/// </summary>
		//public string OtherDetails { get { return _sbDetails.ToString(); } }

		/// <summary>
		/// 70A - Website new Company name or Offeror Name
		/// </summary>
        internal string NarrativeWebsite { get; private set; }
        internal string NarrativeOfferor { get; private set; }
        internal string NarrativeNewName { get; private set; }
		#endregion


        public SequenceD()
        {
            AdditionalBusinessProcess = String.Empty;
            AdditionalBusinessProcessDtaSrcSchme = String.Empty;

        }
		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
            base.Parse(code, text);
			switch (code)
			{
				case "16R": // NOP
					break;
				case "16S":
					break;

				case "98A": 
				case "98B":
				case "98C":	
				case "98E": ParseField98A(code, text); break;

				case "69A":
				case "69B":
				case "69C":
				case "69D":
				case "69E":
				case "69F":
				case "69J": ParseField69A(code,text); break;

				case "99A": ParseField99A(code, text); break;

				case "92A": 
				case "92F":
				case "92K": ParseField92(code, text); break;
				case "90A": 
				case "90B":
				case "90E": ParseField90A(code, text); break;

				case "36A": 
				case "36B":
				case "36C": ParseField36A(code, text); break;

				case "13A": 
				case "13B": ParseField13A(code, text); break;

				case "17B": ParseField17B(code, text); break;
				case "22F": ParseField22F(code, text); break;
				case "94E": ParseField94E(code, text); break;
				case "70A": 
				case "70E": 
				case "70G": ParseField70A(code, text); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected field {1} encountered in this sequence.", GetType().Name, code));
			}
		}

		/// <summary>
		/// DateTime. Option A supported only
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n	(Qualifier)(Date)
		/// Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		/// Option C	:4!c//8!n6!n	(Qualifier)(Date)(Time)
		/// Option E	:4!c//8!n6!n[,3n][/[N]2!n[2!n]]	(Qualifier)(Date)(Time)(Decimals)(UTC Indicator)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField98A(string code, string input)
		{

            DateTimeOffset? workHHMMOffSet2 = null;
            ParseField98Options(input);
            
                     
            //Check for unknown date
            if ((Regex.IsMatch(input, @"ONGO$")) || (Regex.IsMatch(input, @"UKWN$")))
                return;

			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

            if ((s.Length == 1) && (code.Substring(2,1) == "B"))
                throw new NotImplementedException(String.Format("{0}: Option 98B with Data Source Scheme is not supported.", GetType().Name));

            //Option B - Check for unknown date with DataSource Scheme and throw error
            var s1 = s[1].Split(new[] { "/" }, StringSplitOptions.None);
            switch (code.Substring(2,1))
            {
                
                case "E":
                    {
                        if ((s[0] == "MEET" || s[0] == "MET2" || s[0] == "MET3" || s[0] == "MCTD") && (s1.Length == 2))
                        {
                            throw new NotImplementedException(String.Format("{0}: Option {1} encountered in field 98E not implemented.", GetType().Name, input));
   
                        }
                      

                        if (s1.Length == 2)
                            workHHMMOffSet2 = ParseDateTimeOffset(s1[0] + "/" + s1[1]);
                        else
                            workHHMMOffSet2 = ParseDateTimeOffset(s1[0]);
                    }
                    break;
            }
            

			
				// Note: There are many types of dates. Not all of them are implemented.
				switch (s[0])
				{
					case "ANOU": AnnouncementDate = ParseDateOptionalTime(s[1], true); break;
					case "XDTE": ExDate = ParseDateOptionalTime(s[1], true); break;
					case "EFFD": EffectiveDate = ParseDateOptionalTime(s[1], true); break;
					case "SPLT": DeadlineSplitDate = ParseDateOptionalTime(s[1], true); break;
					case "MEET": MeetingDate = ParseDateOptionalTime(s[1], true); break;
					case "MET2": MeetingDate2 = ParseDateOptionalTime(s[1], true); break;
					case "MET3": MeetingDate3 = ParseDateOptionalTime(s[1], true); break;
					case "RDTE": RecordDate = ParseDateOptionalTime(s[1], true); break;
					case "SXDT": ExDateSpecial = ParseDateOptionalTime(s[1], true); break;
					case "PAYD": PayDate = ParseDateOptionalTime(s[1], true); break;
					case "PROD": ProrationDate = ParseDateOptionalTime(s[1], true); break;
					case "FDAT": FurtherDetailedAnnouncementDate = ParseDateOptionalTime(s[1], true); break;
					case "COAP": CourtApprovalDate = ParseDateOptionalTime(s[1], true); break;
					case "TSDT": TradingSuspendedDate = ParseDateOptionalTime(s[1], true); break;
					case "REGI": DeadlineToRegister = ParseDateOptionalTime(s[1], true);  break;
					case "WUCO": WhollyUnconditionalDate = ParseDateOptionalTime(s[1], true); break;
					case "RESU": ResultsPublicationDate = ParseDateOptionalTime(s[1], true); break;
					case "MATU": NewMaturityDate = ParseDateOptionalTime(s[1], true); break;
					case "UNCO": UnconditionalDate = ParseDateOptionalTime(s[1], true); break;
                    case "CERT": CertificationDeadlineDate = ParseDateOptionalTime(s[1], true); break;
                    case "TAXB": TaxBreakdownInstructionsDeadlineDate = ParseDateOptionalTime(s[1], true); break;
                    case "LOTO": LotteryDate = ParseDateOptionalTime(s[1], true); break;
                    case "EQUL": EqualizationDate = ParseDateOptionalTime(s[1], true); break;
                    case "ECDT": EarlyClosingDate = ParseDateOptionalTime(s[1], true); break;
                    case "IFIX": FixingDate = ParseDateOptionalTime(s[1], true); break;
                    case "MFIX": MarginFixingDate = ParseDateOptionalTime(s[1], true); break;
                    case "OAPD": OfficialAnnoucementDate = ParseDateOptionalTime(s[1], true); break;
                    case "GUPA": GuaranteedParticipationDate = ParseDateOptionalTime(s[1], true); break;
                    case "ECPD": ElectiontoCounterpartyDate = ParseDateOptionalTime(s[1], true); break;
                    case "LAPD": LapsedDate = ParseDateOptionalTime(s[1], true); break;
                    case "MCTD": MarketClaimTrackingEndDate = ParseDateOptionalTime(s[1], true); break;
                    case "TPDT": ThirdPartyDeadlineDate = ParseDateOptionalTime(s[1], true); break;
                    case "PLDT":
                        LeadPlaintiffDeadlineDate = (workHHMMOffSet2 == null) ? (DateTime)ParseDateOptionalTime(s[1]) : workHHMMOffSet2.Value.DateTime;
                        LeadPlaintiffDeadlineDateUTCOffsetHHmmss = (workHHMMOffSet2 == null) ? "00:00:00" : workHHMMOffSet2.Value.Offset.ToString();
                        break;
                    case "FILL": FilingDate = ParseDateOptionalTime(s[1], true); break;
                    case "HEAR": HearingDate = ParseDateOptionalTime(s[1], true); break;
   
                    default: 
                         {
                            SequenceTagUnknownProcess(code, input);
                        }
                    break;
				}
			
		}

		/// <summary>
		/// Period
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n/8!n	(Qualifier)(Date)(Date)
		/// Option B	:4!c//8!n6!n/8!n6!n	(Qualifier)(Date)(Time)(Date)(Time)
		/// Option C	:4!c//8!n/4!c	(Qualifier)(Date)(Date Code)
		/// Option D	:4!c//8!n6!n/4!c	(Qualifier)(Date)(Time)(Date Code)
		/// Option E	:4!c//4!c/8!n	(Qualifier)(Date Code)(Date)
		/// Option F	:4!c//4!c/8!n6!n	(Qualifier)(Date Code)(Date)(Time)
		/// Option J	:4!c//4!c	(Qualifier)(Date Code)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField69A(string code, string input)
		{
            string      periodType;
            DateTime? periodStart = null;
            DateTime? periodEnd = null;

            ParseField69Options(input);
                 

		
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
            periodType = s[0];

			var splitResultB = s[1].Split(new[] { "/" }, StringSplitOptions.None);

			// Option J
			if (splitResultB.Length == 1)
			{
                periodStart = null;
                periodEnd = null;
				return;
			}

			// Option A
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
			{
                periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
                periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
			}

			// Option B
			else if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
			{
                periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
                periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
			}

			// Option C, D
			else if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN")
			{
                periodEnd = null;
				try
				{
                    periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
                    periodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}

			// Option E, F
			else if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN")
			{
                periodStart = null;

				try
				{
                    periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
                    periodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}
            else
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 69A.", GetType().Name));
          
				switch (s[0])
				{
					case "PRIC":
                        PeriodPriceCalculationStrtDte = periodStart;
                        PeriodPriceCalculationEndDte = periodEnd;break;
                    case "INPE":
                        PeriodInterestStrtDate = periodStart;
                        PeriodInterestEndDte = periodEnd; break;
                    case "CSPD":
                        PeriodCompulsoryPurchaseStrtDte = periodStart;
                        PeriodCompulsoryPurchaseEndDte = periodEnd; break;
                    case "BLOK":
                        PeriodBlockingStrtDte = periodStart;
                        PeriodBlockingEndDte = periodEnd; break;
                    case "CLCP":
                        PeriodClaimStrtDte = periodStart;
                        PeriodClaimEndDte = periodEnd; break;
                    case "DSWN":
                        PeriodDepSuspWthdralNomineeNameStrtDte = periodStart;
                        PeriodDepSuspWthdralNomineeNameEndDte = periodEnd; break;
                    case "DSDE":
                        PeriodDepSuspDepositStrtDte = periodStart;
                        PeriodDepSuspDepositEndDte = periodEnd; break;
                    case "DSBT":
                        PeriodDepSuspBookEntryXferStrtDte = periodStart;
                        PeriodDepSuspBookEntryXferEndDte = periodEnd; break;
                    case "DSDA":
                        PeriodDepSuspDepositAgentStrtDte = periodStart;
                        PeriodDepSuspDepositAgentEndDte = periodEnd; break;
                    case "DSWA":
                        PeriodDepSuspWthdralAgentStrtDte = periodStart;
                        PeriodDepSuspWthdralAgentEndDte = periodEnd; break;
                    case "DSPL":
                        PeriodDepSuspPledgeStrtDte = periodStart;
                        PeriodDepSuspPledgeEndDte = periodEnd; break;
                    case "DSSE":
                        PeriodDepSuspSegregationStrtDte = periodStart;
                        PeriodDepSuspSegregationEndDte = periodEnd; break;
                    case "DSWS":
                        PeriodDepSuspWthdralStreetNameStrtDte = periodStart;
                        PeriodDepSuspWthdralStreetNameEndDte = periodEnd; break;
                    case "BOCL":
                        PeriodDepSuspBookClosureStrtDte = periodStart;
                        PeriodDepSuspBookClosureEndDte = periodEnd; break;
                    case "CODS":
                        PeriodCoDepositoriesSuspStrtDte = periodStart;
                        PeriodCoDepositoriesSuspEndDte = periodEnd; break;
                    default: 
                         {
                            SequenceTagUnknownProcess(code, input);
                         }
                    break;
                }
		}

		/// <summary>
		/// Days Accrued
		/// </summary>
		/// <example>
		/// Option A	:4!c//[N]3!n	(Qualifier)(Sign)(Number)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField99A(string code, string input)
		{
            if ( (!(Regex.IsMatch(input, @"^[A-Z]{4}//[N]{0,1}\d{3}$"))) )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 99A.", GetType().Name));
            }


			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			switch (s[0])
			{
                case "DAAC": DaysAccrued = (int)ParseDecimalFr(s[1]); break;
				default:
					{
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Rate - note (most of the rates are given in Option E; hence the lean implementation of rates here)
		/// </summary>
		/// <example>
		/// Option A	:4!c//[N]15d	(Qualifier)(Sign)(Rate)
		/// Option F	:4!c//3!a15d	(Qualifier)(Currency Code)(Amount) (Not supported)
		/// Option K	:4!c//4!c	(Qualifier)(Rate Type Code)
		/// </example>
		/// <param name="code"> </param>
		/// <param name="input"></param>
        internal void ParseField92(string code, string input)
		{
            string rateCurrency = null;
            string rateType = null;
            decimal? rateAmount = null;
            decimal? rate = null;

            if (

               (!(Regex.IsMatch(input, @"^[A-Z]{4}//[N]{0,1}\d{1,15},\d{0,15}$")))  // option A
                 && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{3}\d{1,15},\d{0,15}$"))) //option F
                 && (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))) //option K

              )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 92.", GetType().Name));
            }


            var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			switch(code.Substring(2,1))
			{
				case "A": 
                    rate = ParseDecimalFr(s[1]);
					break;

				case "F":
					rateCurrency = s[1].Substring(0, 3);
                    rateAmount = ParseDecimalFr(s[1].Substring(3));
					break;

				case "K":
                    rateType = s[1];
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected option in field 92. Only A,F,K are expected.", GetType().Name));
			}
            switch (s[0])
            {
                case "INTR": 
                    InterestRate = rate;
                    InterestRateCcy = rateCurrency;
                    InterestRateAmt = rateAmount;
                    break;
                case "BIDI": 
                    BidIntervalRate = rate;
                    BidIntervalRateCcy = rateCurrency;
                    BidIntervalRateAmt = rateAmount;
                    break;
                case "PTSC": 
                    PercentageSought = rate;
                    PercentageSoughtRateTypeCode = rateType;
                    break;
                case "RDIS":
                    RateReInvestmentDiscToMrkt = rate;
                    break;
                case "NWFC":
                    RateNextFactor = rate;
                    break;
                case "PRFC":
                    RateNextFactor = rate;
                    break;
                case "RINR":
                    RateRelatedIndex = rate;
                    break;
                case "RSPR":
                    RateSpread = rate;
                    break;
                case "SHRT":
                    RateIntrstShrtFall = rate;
                    RateIntrstShrtFallAmt = rateAmount;
                    RateIntrstShrtFallCcy = rateCurrency;
                    break;
                case "RLOS":
                    RateRealisedLoss = rate;
                    RateRealisedLossAmt = rateAmount;
                    RateRealisedLossCcy = rateCurrency;
                    break;
                case "DEVI":
                    RateDeclared = rate;
                    RateDeclaredAmt = rateAmount;
                    RateDeclaredCcy = rateCurrency;
                    break;
                default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
            }
		}

        
		/// <summary>
		/// Price. Most of the prices will be in Sequence E
		/// </summary>
		/// <example>Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///			 Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///			 Option E	:4!c//4!c	(Qualifier)(Price Code)</example>
		///<param name="code"> </param>
		///<param name="input"></param>
		internal void ParseField90A(string code, string input)
		{
           
            ParseField90Options(input);

			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			var split2 = s[1].Split(new[] { "/" }, StringSplitOptions.None);
			decimal? price = null;
            string pricePercentType = null;
            string priceAmountType = null;
            string priceCurrency = null;

			switch (code.Substring(2, 1))
			{
				case "A":
					//PricePercentType = split2[0];
                    pricePercentType = split2[0];
					price = ParseDecimalFr(split2[1]);
					break;

				case "B":
					priceAmountType = split2[0];
					priceCurrency = split2[1].Substring(0, 3);
					price = ParseDecimalFr(split2[1].Substring(3));
					break;

				case "E": // UKWN
					price = ParseDecimalFr(split2[0]);
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unrecognized code {1} in field 90.", GetType().Name, input.Substring(2, 1)));
			}

			switch (s[0])
			{
				case "MAXP":
					PriceMax = price;
                    PriceMaxCurrency = priceCurrency;
                    PriceMaxPercentType = pricePercentType;
                    PriceMaxAmountType = priceAmountType;
					break;

				case "MINP":
					PriceMin = price;
                    PriceMinCurrency = priceCurrency;
                    PriceMinPercentType = pricePercentType;
                    PriceMinAmountType = priceAmountType;
					break;

				default:
					{
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Quantity of Financial Instrument
        /// Option B :4!c//4!c/15d (Qualifier)(Quantity Type Code)(Quantity) 
        /// Option C :4!c//4!c (Qualifier)(Quantity Code) 
		/// </summary>
		/// <param name="input"></param>
		internal void ParseField36A(string code, string input)
		{
            
            ParseField36BCOptions(input);
           
            string quantityCodeOrTypeCode = null;
            decimal? quantity = null;

			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

            // Get details
            var s1 = s[1].Split(new[] { "/" }, StringSplitOptions.None);

            if (s1.Length == 1)    // option c
                quantityCodeOrTypeCode = s1[0];
            else
            {
                quantityCodeOrTypeCode = s1[0];
                quantity = ParseDecimalFr(s1[1]);
            }

            switch (s[0])
            {
                case "MIEX":
                    FIQtyMinXercisble = quantity;
                    FIQtyMinXercisbleCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;
                case "MILT":
                    FIQtyMinMultiXercisble = quantity;
                    FIQtyMinMultiXercisbleCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;
                case "MQSO": 
                    FIQtyMaxSecurities = quantity;
                    FIQtyMaxSecuritiesCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;
                case "QTSO": 
                    FIQtyMinSought = quantity;
                    FIQtyMinSoughtCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;
                case "NBLT":
                    FIQtyNewBoardLot = quantity;
                    FIQtyNewBoardLotCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;
                case "NEWD":
                    FIQtyNewDenomination = quantity;
                    FIQtyNewDenominationCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;
                case "BASE":
                    FIQtyBaseDenomination = quantity;
                    FIQtyBaseDenominationCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;
                    
                case "INCR":
                    FIQtyIncDenomination = quantity;
                    FIQtyIncDenominationCodeOrTypeCode = quantityCodeOrTypeCode;
                    break;

                default:
                     {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
            }


                        
		}

		/// <summary>
		/// Coupon
		/// </summary>
		/// <example>
		/// Option A	:4!c//3!c		(Qualifier)(Number Id)
		/// Option B	:4!c/[8c]/30x	(Qualifier)(Data Source Scheme)(Number)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField13A(string code, string input)
		{
            if (
                 (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z0-9]{3}$")))  // option A
               && (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z]{0,8}/.{0,30}$"))) //option B
              
               )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 13A.", GetType().Name));
            }
            
			if (Regex.IsMatch(input, @"//"))
			{
				// Option A
				var s = input.Split(new[] { "//" }, StringSplitOptions.None);
				switch (s[0])
				{
					case "COUP":
						CouponNumber = s[1];
						break;
					default: 
                         {
                            SequenceTagUnknownProcess(code, input);
                        }
                    break;
				}
				return;
			}

			// Option B
			var s2 = input.Split(new[] {"/"}, StringSplitOptions.None);
            if (s2[0] != "COUP")
                SequenceTagUnknownProcess(code, input);
            else
            {
                CouponNumber = s2[2];
                CouponNumberDtaSrcSchme = s2[1];
            }
		}

		/// <summary>
		/// Flag
		/// </summary>
		/// <example>
		/// Option B	:4!c//1!a	(Qualifier)(Flag)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField17B(string code, string input)
		{
           
            ParseField17Options(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            if (!(s[1] == "N" || s[1] == "Y"))
                throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} at field 17B. Flag must be Y or N", GetType().Name, input));
			switch(s[0])
			{
				case "CERT":
					IsCertification = s[1];
					break;
				case "RCHG": 
					IsChargesApply = s[1];
					break;
				case "COMP":
					IsComplianceInfo = s[1];
					break;
				case "ACIN":
					IsEntitledAccruedInterest = s[1];
					break;
                case "LEOG":
                    IsLetterOfGuaranteed = s[1];
                    break;
				default:
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Indicator
		/// </summary>
		/// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
		/// <param name="input"></param>
        internal void ParseField22F(string code, string input)
		{
			// Here what we get in file does not match the standard - "//" instead of "/"
            //var qualifier = input.Substring(0, input.IndexOf("/", StringComparison.Ordinal));
            //var value = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);

            ParseField22Options(input);

            var s = input.Split(new[] { "/" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "DIVI": 
                    DividendType = s[2];
                    DividendTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "DITY":
                    DistributionType = s[2];
                    DistributionTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "OFFE": 
                    OfferType = s[2];
                    OfferTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "ESTA":
                    CorpActionEventStage = s[2];
                    CorpActionEventStageDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
				case "ADDB":
                    //Potential for successive ADDB tags
                    AdditionalBusinessProcess = AdditionalBusinessProcess + s[2] + ";";
                    AdditionalBusinessProcessDtaSrcSchme =  AdditionalBusinessProcessDtaSrcSchme + s[1] + ";";
                    break;
				case "SELL": 
                    RenounceStatusEntitlement = s[2];
                    RenounceStatusEntitlementDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                   	break;
				case "RHDI":
                    IntermSecDistrib = s[2];
                    IntermSecDistribDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
					break;
                case "CONV":
                    ConversionType = s[2];
                    ConversionTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
                case "CHAN":
                    ChangeType = s[2];
                    ChangeTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
                case "ECIO":
                    CapitalGainType = s[2];
                    CapitalGainTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
                case "TDTA":
                    TIDTISCalcType = s[2];
                    TIDTISCalcTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
                case "ELCT":
                    ElectionType = s[2];
                    ElectionTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
                case "LOTO":
                    LotteryType = s[2];
                    LotteryTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;
                case "CEFI":
                    CertificationType = s[2];
                    CertificationTypeDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    break;

                default: 
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
                
			}

            
		}

		/// <summary>
		/// Place
		/// </summary>
        /// <example>Option E :4!c//10*35x (Qualifier)(Address)</example>
		/// <param name="input"></param>
        internal void ParseField94E(string code, string input)
		{
            // option A
            if (!(Regex.IsMatch(input, @"^[A-Z0-9]{4}//.{1,400}$", RegexOptions.Singleline)))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 94E.", GetType().Name));
            }

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
                case "MEET": 
                    PlaceMeeting = s[1]; 
                    break;
                case "MET2": 
                    Place2Meeting = s[1];
                    break;
                case "MET3": 
                    Place3Meeting = s[1];
                    break;
                case "NPLI": 
                    PlaceofOfIncorporation = s[1];
					break;
				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Narrative
		/// </summary>
		/// <example>	Option E	:4!c//10*35x	(Qualifier)(Narrative)
		///				Option G	:4!c//10*35z	(Qualifier)(Narrative)</example>
		/// <param name="input"></param>
        internal void ParseField70A(string code, string input)
		{
            // option E & G
            if  (!(Regex.IsMatch(input, @"^[A-Z]{4}//\.*")))        
             {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 70A.", GetType().Name));
             }

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
                case "OFFO": NarrativeOfferor = s[1]; break;
                case "NAME": NarrativeNewName = s[1]; break;
                case "WEBB": NarrativeWebsite = s[1]; break;

                default: 
                   {
                            SequenceTagUnknownProcess(code, input);
                   }
                   break;
				
			}
		}

		internal static string GetHeaders()
		{
			return "AnnouncementDate|ExDate|EffectiveDate|DeadlineSplitDate|MeetingDate|MeetingDate2|MeetingDate3|RecordDate|ExDateSpecial" +
			       "|PayDate|FurtherDetailedAnnouncementDate|CourtApprovalDate|TradingSuspendedDate|ProrationDate|DeadlineToRegister" +
			       "|WhollyUnconditionalDate|ResultsPublicationDate|NewMaturityDate|UnconditionalDate|DaysAccrued" +
                   "|InterestRate|BidIntervalRate|PercentageSought|PriceMax|PriceMin|PriceMaxCurrency|PriceMaxPercentType|PriceMaxAmountType|PriceMinCurrency|PriceMinPercentType|PriceMinAmountType" +
			       "|CouponNumber|IsCertification|IsChargesApply|IsComplianceInfo|IsEntitledAccruedInterest|DividendType|DistributionType" +
                   "|OfferType|CorpActionEventStage|AdditionalBusinessProcess|RenounceStatusEntitlement|IntermSecDistrib" +
                   "|CertificationDeadlineDate|TaxBreakdownInstructionsDeadlineDate|LotteryDate|EqualizationDate|EarlyClosingDate|FixingDate|MarginFixingDate" +
                   "|OfficialAnnoucementDate|GuaranteedParticipationDate|ElectiontoCounterpartyDate|LapsedDate|MarketClaimTrackingEndDate|ThirdPartyDeadlineDate" +
                   "|LeadPlaintiffDeadlineDate|LeadPlaintiffDeadlineDateUTCOffsetHHmmss|FilingDate|HearingDate" + 
                   "|PeriodPriceCalculationStrtDte|PeriodPriceCalculationEndDte|PeriodInterestStrtDate|PeriodInterestEndDte" +
                   "|PeriodCompulsoryPurchaseStrtDte|PeriodCompulsoryPurchaseEndDte|PeriodBlockingStrtDte|PeriodBlockingEndDte" +
                   "|PeriodClaimStrtDte|PeriodClaimEndDte|PeriodDepSuspWthdralNomineeNameStrtDte|PeriodDepSuspWthdralNomineeNameEndDte" +
                   "|PeriodDepSuspDepositStrtDte|PeriodDepSuspDepositEndDte|PeriodDepSuspBookEntryXferStrtDte|PeriodDepSuspBookEntryXferEndDte" +
                   "|PeriodDepSuspDepositAgentStrtDte|PeriodDepSuspDepositAgentEndDte|PeriodDepSuspWthdralAgentStrtDte|PeriodDepSuspWthdralAgentEndDte" +
                   "|PeriodDepSuspPledgeStrtDte|PeriodDepSuspPledgeEndDte|PeriodDepSuspSegregationStrtDte|PeriodDepSuspSegregationEndDte" +
                   "|PeriodDepSuspWthdralStreetNameStrtDte|PeriodDepSuspWthdralStreetNameEndDte|PeriodDepSuspBookClosureStrtDte|PeriodDepSuspBookClosureEndDte" +
                   "|PeriodCoDepositoriesSuspStrtDte|PeriodCoDepositoriesSuspEndDte" +
                   "|InterestRateCcy|InterestRateAmt|BidIntervalRateCcy|BidIntervalRateAmt|PercentageSoughtRateTypeCode|RateReInvestmentDiscToMrkt|RateNextFactor|RatePrevFactor|RateRelatedIndex|RateSpread|RateIntrstShrtFall|RateIntrstShrtFallCcy" +
                   "|RateIntrstShrtFallAmt|RateRealisedLoss|RateRealisedLossCcy|RateRealisedLossAmt|RateDeclared|RateDeclaredCcy|RateDeclaredAmt" +
                   "|FIQtyMinXercisble|FIQtyMinXercisbleCodeOrTypeCode|FIQtyMinMultiXercisble|FIQtyMinMultiXercisbleCodeOrTypeCode|FIQtyMaxSecurities|FIQtyMaxSecuritiesCodeOrTypeCode" +
                   "|FIQtyMinSought|FIQtyMinSoughtCodeOrTypeCode|FIQtyNewBoardLot|FIQtyNewBoardLotCodeOrTypeCode|FIQtyNewDenomination|FIQtyNewDenominationCodeOrTypeCode" +
                   "|FIQtyBaseDenomination|FIQtyBaseDenominationCodeOrTypeCode|FIQtyIncDenomination|FIQtyIncDenominationCodeOrTypeCode|CouponNumberDtaSrcSchme|IsLetterOfGuaranteed" +
                   "|DividendTypeDtaSrcSchme|DistributionTypeDtaSrcSchme|OfferTypeDtaSrcSchme|CorpActionEventStageDtaSrcSchme" +
                   "|AdditionalBusinessProcessDtaSrcSchme|RenounceStatusEntitlementDtaSrcSchme|IntermSecDistribDtaSrcSchme|ConversionType|ConversionTypeDtaSrcSchme" +
                   "|ChangeType|ChangeTypeDtaSrcSchme|CapitalGainType|CapitalGainTypeDtaSrcSchme|TIDTISCalcType|TIDTISCalcTypeDtaSrcSchme" +
                   "|ElectionType|ElectionTypeDtaSrcSchme|LotteryType|LotteryTypeDtaSrcSchme|CertificationType|CertificationTypeDtaSrcSchme" +
                   "|PlaceMeeting|Place2Meeting|Place3Meeting|PlaceofOfIncorporation" +
                   "|NarrativeOfferor|NarrativeWebsite|NarrativeNewName|TagsNotRecognizedSeqD";
		}

		public override string ToString()
		{
            var sb = new StringBuilder(160);
          
            sb.Append("|" + DividendTypeDtaSrcSchme); sb.Append("|" + DistributionTypeDtaSrcSchme); sb.Append("|" + OfferTypeDtaSrcSchme); sb.Append("|" + CorpActionEventStageDtaSrcSchme);
            sb.Append("|" + AdditionalBusinessProcessDtaSrcSchme.TrimEnd(';')); sb.Append("|" + RenounceStatusEntitlementDtaSrcSchme); sb.Append("|" + IntermSecDistribDtaSrcSchme); sb.Append("|" + ConversionType);
            sb.Append("|" + ConversionTypeDtaSrcSchme); sb.Append("|" + ChangeType); sb.Append("|" + ChangeTypeDtaSrcSchme); sb.Append("|" + CapitalGainType);
            sb.Append("|" + CapitalGainTypeDtaSrcSchme); sb.Append("|" + TIDTISCalcType); sb.Append("|" + TIDTISCalcTypeDtaSrcSchme); sb.Append("|" + ElectionType);
            sb.Append("|" + ElectionTypeDtaSrcSchme); sb.Append("|" + LotteryType); sb.Append("|" + LotteryTypeDtaSrcSchme); sb.Append("|" + CertificationType);
            sb.Append("|" + CertificationTypeDtaSrcSchme); sb.Append("|" + PlaceMeeting); sb.Append("|" + Place2Meeting); sb.Append("|" + Place3Meeting); sb.Append("|" + PlaceofOfIncorporation);
            sb.Append("|" + NarrativeOfferor); sb.Append("|" + NarrativeWebsite); sb.Append("|" + NarrativeNewName); sb.Append("|" + _TagsNotRecognized);

            return AnnouncementDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ExDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EffectiveDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DeadlineSplitDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MeetingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MeetingDate2.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MeetingDate3.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + RecordDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ExDateSpecial.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" +
                   PayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + FurtherDetailedAnnouncementDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + CourtApprovalDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + TradingSuspendedDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ProrationDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DeadlineToRegister.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" +
                   WhollyUnconditionalDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ResultsPublicationDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + NewMaturityDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + UnconditionalDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DaysAccrued + "|" +
                   InterestRate + "|" + BidIntervalRate + "|" + PercentageSought + "|" + PriceMax + "|" + PriceMin + "|" + PriceMaxCurrency + "|" + PriceMaxPercentType + "|" + PriceMaxAmountType + "|" + PriceMinCurrency + "|" + PriceMinPercentType + "|" + PriceMinAmountType + "|" +
                   CouponNumber + "|" + IsCertification + "|" + IsChargesApply + "|" + IsComplianceInfo + "|" + IsEntitledAccruedInterest + "|" + DividendType + "|" + DistributionType + "|" +
                   OfferType + "|" + CorpActionEventStage + "|" + AdditionalBusinessProcess.TrimEnd(';') + "|" + RenounceStatusEntitlement + "|" + IntermSecDistrib + 
                   "|" + CertificationDeadlineDate + "|" + TaxBreakdownInstructionsDeadlineDate + "|" + LotteryDate + "|" + EqualizationDate + "|" + EarlyClosingDate + "|" + FixingDate + "|" + MarginFixingDate + "|" + OfficialAnnoucementDate +
                   "|" + GuaranteedParticipationDate + "|" + ElectiontoCounterpartyDate + "|" + LapsedDate + "|" + MarketClaimTrackingEndDate + "|" + ThirdPartyDeadlineDate + "|" + LeadPlaintiffDeadlineDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + LeadPlaintiffDeadlineDateUTCOffsetHHmmss + "|" + FilingDate + "|" + HearingDate +
                   "|" + PeriodPriceCalculationStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodPriceCalculationEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodInterestStrtDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodInterestEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PeriodCompulsoryPurchaseStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodCompulsoryPurchaseEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodBlockingStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodBlockingEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PeriodClaimStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodClaimEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspWthdralNomineeNameStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspWthdralNomineeNameEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PeriodDepSuspDepositStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspDepositEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspBookEntryXferStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspBookEntryXferEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PeriodDepSuspDepositAgentStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspDepositAgentEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspWthdralAgentStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspWthdralAgentEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PeriodDepSuspPledgeStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspPledgeEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspSegregationStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspSegregationEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PeriodDepSuspWthdralStreetNameStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspWthdralStreetNameEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspBookClosureStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodDepSuspBookClosureEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + PeriodCoDepositoriesSuspStrtDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodCoDepositoriesSuspEndDte.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
                   "|" + InterestRateCcy + "|" + InterestRateAmt + "|" + BidIntervalRateCcy + "|" + BidIntervalRateAmt + "|" + PercentageSoughtRateTypeCode + "|" + RateReInvestmentDiscToMrkt + "|" + RateNextFactor + "|" + RatePrevFactor + "|" + RateRelatedIndex + "|" + RateSpread + "|" + RateIntrstShrtFall + "|" + RateIntrstShrtFallCcy +
                   "|" + RateIntrstShrtFallAmt + "|" + RateRealisedLoss + "|" + RateRealisedLossCcy + "|" + RateRealisedLossAmt + "|" + RateDeclared + "|" + RateDeclaredCcy + "|" + RateDeclaredAmt +
                   "|" + FIQtyMinXercisble + "|" + FIQtyMinXercisbleCodeOrTypeCode + "|" + FIQtyMinMultiXercisble + "|" + FIQtyMinMultiXercisbleCodeOrTypeCode + "|" + FIQtyMaxSecurities + "|" + FIQtyMaxSecuritiesCodeOrTypeCode +
                   "|" + FIQtyMinSought + "|" + FIQtyMinSoughtCodeOrTypeCode + "|" + FIQtyNewBoardLot + "|" + FIQtyNewBoardLotCodeOrTypeCode + "|" + FIQtyNewDenomination + "|" + FIQtyNewDenominationCodeOrTypeCode +
                   "|" + FIQtyBaseDenomination + "|" + FIQtyBaseDenominationCodeOrTypeCode + "|" + FIQtyIncDenomination + "|" + FIQtyIncDenominationCodeOrTypeCode + "|" + CouponNumberDtaSrcSchme + "|" + IsLetterOfGuaranteed +
                   sb.ToString();
		}

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }
	}
}