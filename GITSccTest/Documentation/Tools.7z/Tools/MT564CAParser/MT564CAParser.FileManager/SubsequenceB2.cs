﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Repetitive Mandatory Subsequence B2 Account Information
	/// </summary>
	internal class SubsequenceB2: Sequence
	{
		/// <summary>
		/// 95A
		/// </summary>
		internal string AccountOwner { get; set; }
        internal string AccountOwnerDtaSrcSchme { get; set; }
		/// <summary>
		/// 97A
		/// </summary>
        internal string SafeKeepingAccount { get; set; }
		/// <summary>
		/// 94A
		/// </summary>
        internal string SafeKeepingPlaceCntryCode { get; set; }
        internal string SafeKeepingPlaceCode { get; set; }
        internal string SafeKeepingPlaceDtaSrcSchme { get; set; }
        internal string SafeKeepingPlaceNarrative { get; set; }
        internal string SafeKeepingPlaceIdentCode { get; set; }
		/// <summary>
		/// 93A
		/// </summary>
        //public string BalanceType { get; set; }
        ///// <summary>
        ///// 93A
        ///// </summary>
        //public string BalanceQuantityType { get; set; }
        ///// <summary>
        ///// 93A
        ///// </summary>
        //public decimal? Balance { get; set; }
        //public string BalanceTypeCode { get; set; }
        //public string BalanceDtaSrcSchme { get; set; }
        /// <summary>
        /// 93A Balance
        /// </summary>
        internal decimal? BalanceTotalEligible { get; set; }
        internal decimal? BalanceBlocked { get; set; }
        internal decimal? BalanceBorrowed { get; set; }
        internal decimal? BalanceCollateralIn { get; set; }
        internal decimal? BalanceCollateralOut { get; set; }
        internal decimal? BalanceOnLoan { get; set; }
        internal decimal? BalancePendingDelivery { get; set; }
        internal decimal? BalancePendingReceipt { get; set; }
        internal decimal? BalanceOutForRegistration { get; set; }
        internal decimal? BalanceSettlementPosition { get; set; }
        internal decimal? BalanceStreetPosition { get; set; }
        internal decimal? BalanceTradeDatePosition { get; set; }
        internal decimal? BalanceInTransshipmentPosition { get; set; }
        internal decimal? BalanceRegistered { get; set; }
        internal decimal? BalanceUninstructed { get; set; }
        internal decimal? BalanceInstructed { get; set; }
        internal decimal? BalanceObligated { get; set; }
        internal decimal? BalanceAffected { get; set; }
        internal decimal? BalanceUnaffected { get; set; }

        internal string BalanceTotalEligibleQtyType { get; set; }
        internal string BalanceBlockedQtyType { get; set; }
        internal string BalanceBorrowedQtyType { get; set; }
        internal string BalanceCollateralInQtyType { get; set; }
        internal string BalanceCollateralOutQtyType { get; set; }
        internal string BalanceOnLoanQtyType { get; set; }
        internal string BalancePendingDeliveryQtyType { get; set; }
        internal string BalancePendingReceiptQtyType { get; set; }
        internal string BalanceOutForRegistrationQtyType { get; set; }
        internal string BalanceSettlementPositionQtyType { get; set; }
        internal string BalanceStreetPositionQtyType { get; set; }
        internal string BalanceTradeDatePositionQtyType { get; set; }
        internal string BalanceInTransshipmentPositionQtyType { get; set; }
        internal string BalanceRegisteredQtyType { get; set; }
        internal string BalanceUninstructedQtyType { get; set; }
        internal string BalanceInstructedQtyType { get; set; }
        internal string BalanceObligatedQtyType { get; set; }
        internal string BalanceAffectedQtyType { get; set; }
        internal string BalanceUnaffectedQtyType { get; set; }

        internal string BalanceTotalEligibleBalType { get; set; }
        internal string BalanceBlockedBalType { get; set; }
        internal string BalanceBorrowedBalType { get; set; }
        internal string BalanceCollateralInBalType { get; set; }
        internal string BalanceCollateralOutBalType { get; set; }
        internal string BalanceOnLoanBalType { get; set; }
        internal string BalancePendingDeliveryBalType { get; set; }
        internal string BalancePendingReceiptBalType { get; set; }
        internal string BalanceOutForRegistrationBalType { get; set; }
        internal string BalanceSettlementPositionBalType { get; set; }
        internal string BalanceStreetPositionBalType { get; set; }
        internal string BalanceTradeDatePositionBalType { get; set; }
        internal string BalanceInTransshipmentPositionBalType { get; set; }
        internal string BalanceRegisteredBalType { get; set; }
        internal string BalanceUninstructedBalType { get; set; }
        internal string BalanceInstructedBalType { get; set; }
        internal string BalanceObligatedBalType { get; set; }
        internal string BalanceAffectedBalType { get; set; }
        internal string BalanceUnaffectedBalType { get; set; }

        internal string BalanceTotalEligibleDtaSrcSchme { get; set; }
        internal string BalanceBlockedDtaSrcSchme { get; set; }
        internal string BalanceBorrowedDtaSrcSchme { get; set; }
        internal string BalanceCollateralInDtaSrcSchme { get; set; }
        internal string BalanceCollateralOutDtaSrcSchme { get; set; }
        internal string BalanceOnLoanDtaSrcSchme { get; set; }
        internal string BalancePendingDeliveryDtaSrcSchme { get; set; }
        internal string BalancePendingReceiptDtaSrcSchme { get; set; }
        internal string BalanceOutForRegistrationDtaSrcSchme { get; set; }
        internal string BalanceSettlementPositionDtaSrcSchme { get; set; }
        internal string BalanceStreetPositionDtaSrcSchme { get; set; }
        internal string BalanceTradeDatePositionDtaSrcSchme { get; set; }
        internal string BalanceInTransshipmentPositionDtaSrcSchme { get; set; }
        internal string BalanceRegisteredDtaSrcSchme { get; set; }
        internal string BalanceUninstructedDtaSrcSchme { get; set; }
        internal string BalanceInstructedDtaSrcSchme { get; set; }
        internal string BalanceObligatedDtaSrcSchme { get; set; }
        internal string BalanceAffectedDtaSrcSchme { get; set; }
        internal string BalanceUnaffectedDtaSrcSchme { get; set; }

        internal string CARef { get; private set; }
        internal string SenderRef { get; private set; }

        internal int _seqNum;
        internal SubsequenceB2(string caRef, string senderRef, int seqNum)
            //: base(CARef, senderRef)
        {
            CARef = caRef;
            SenderRef = senderRef;
            _seqNum = seqNum;
        }
        internal SubsequenceB2()
        {
        }

        internal override void Parse(string code, string text)
        {
            base.Parse(code, text);
            switch (code)
            {

            // 95P  95R 
                case "95R":
                case "95P": ParseField95A(code, text); break;
				
				case "97A":
				case "97C":
							ParseField97A(code, text); break;

                case "94B":
				case "94C":
				case "94F":
							ParseField94A(code, text); break;
                case "93B":
                case "93C":
				case "93A": ParseField93A(code, text); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} for this sequence.", GetType().Name, code));
               
			}
        }
		/// <summary>
		/// 95A: Account Owner
		/// </summary>
		/// <example>:4!c//4!a2!a2!c[3!c]
		/// :4!c/8c/34x
		/// </example>
		/// <param name="input"></param>
        internal void ParseField95A(string code, string input)
		{
            if (
               !(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$")) //Option P
               && !(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/.{0,34}$", RegexOptions.Singleline)) //Option R
               )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 95A", GetType().Name));
            }

            string[] s;

            if (Regex.IsMatch(input, @"//"))
                     s = input.Split(new[] { "//" }, StringSplitOptions.None);
            else
                     s = input.Split(new[] { "/" }, StringSplitOptions.None);

           	switch(s[0])
			{
                case "ACOW":
                    {
                        if (s.Length == 2)
                            AccountOwner = s[1];
                        else
                        {
                            AccountOwner = s[2];
                            AccountOwnerDtaSrcSchme = s[1];
                        }
                    }
                    break;
				default: 
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// SafeKeeping Account
		/// </summary>
		/// <example>Option A	:4!c//35x	(Qualifier)(Account Number)
		///			 Option C	:4!c//4!c	(Qualifier)(Account Code)</example>
		/// <param name="input"></param>
        internal void ParseField97A(string code, string input)
		{
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}//.{1,35}$"))
               && !(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z0-9]{4}$"))
                )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 94", GetType().Name));
            }

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
           	switch (s[0])
			{
				case "SAFE": SafeKeepingAccount = s[1];
					break;

				default: 
                    {
                        SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Place of safekeeping
		/// </summary>
		/// <example>	Option B	:4!c/[8c]/4!c[/30x]	(Qualifier)(Data Source Scheme)(Place Code)(Narrative)
		///				Option C	:4!c//2!a	(Qualifier)(Country Code)
		///				Option F	:4!c//4!c/4!a2!a2!c[3!c]	(Qualifier)(Place Code)(Identifier Code)</example>
		/// <param name="input"></param>
        internal void ParseField94A(string code, string input)
		{
            ParseField94BCFOptions(code, input);
            string[] s = null;
         
            SafeKeepingPlaceCode = null;
            SafeKeepingPlaceNarrative = null;
            SafeKeepingPlaceDtaSrcSchme = null;
            SafeKeepingPlaceCntryCode = null;
            SafeKeepingPlaceIdentCode = null;
           

            switch (Regex.IsMatch(input, "^SAFE"))
			{
                case true:
                {
                    
                        s = input.Split(new[] { "/" }, StringSplitOptions.None);
                       
                        switch (code)
                        {
                            case "94B":
                            {
                                SafeKeepingPlaceDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                                SafeKeepingPlaceCode = String.IsNullOrWhiteSpace(s[2]) ? null : s[2];
                                SafeKeepingPlaceNarrative = (s.Length == 4) ? s[3] : null;
                            } break;
                            case "94C":
                            {
                                SafeKeepingPlaceCntryCode = s[2];
                            } break;
                            case "94F":
                            {
                                SafeKeepingPlaceCode = s[2];
                                SafeKeepingPlaceIdentCode = s[3];
                            } break;

                        }
                                

                }
                    break;

				default: 
                    {
                    SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Balance
		/// </summary>
		/// <example>
		/// Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
		/// Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField93A(string code, string input)
		{
            ParseField93Options(input);
			string[] s = input.Contains("//") ? input.Split(new[] {"//"}, StringSplitOptions.None) : input.Split(new[] {"/"}, StringSplitOptions.None);
            string[] s1 = null;
            decimal? balance;
            string balanceTypeCode = null;
            string quantityTypeCode;
            string balanceDtaSrcSchme = null;

            if (s.Length == 2) // option C or option B
            {
                s1 = s[1].Split(new[] { "/" }, StringSplitOptions.None);
                if (s1.Length == 2) //option B no data source scheme
                {
                    balance = ParseDecimalFr(s1[1].Replace("N", "-"));
                }
                else
                {
                    //option C
                    balanceTypeCode = s1[1];
                    balance = ParseDecimalFr(s1[2].Replace("N", "-"));
                }
                quantityTypeCode = s1[0];
                                              
            }
            else // option B
            {
                quantityTypeCode = s[2];
                balance = ParseDecimalFr(s[3].Replace("N", "-"));
                balanceDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
            }

            switch (s[0])
			{
				case "ELIG":
                    BalanceTotalEligible = balance;
                    BalanceTotalEligibleQtyType = quantityTypeCode;
                    BalanceTotalEligibleBalType = balanceTypeCode;
                    BalanceTotalEligibleDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "BLOK":
                    BalanceBlocked = balance;
                    BalanceBlockedQtyType = quantityTypeCode;
                    BalanceBlockedBalType = balanceTypeCode;
                    BalanceBlockedDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "BORR":
                    BalanceBorrowed = balance;
                    BalanceBorrowedQtyType = quantityTypeCode;
                    BalanceBorrowedBalType = balanceTypeCode;
                    BalanceBorrowedDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "COLI":
                    BalanceCollateralIn = balance;
                    BalanceCollateralInQtyType = quantityTypeCode;
                    BalanceCollateralInBalType = balanceTypeCode;
                    BalanceCollateralInDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "COLO":
                    BalanceCollateralOut = balance;
                    BalanceCollateralOutQtyType = quantityTypeCode;
                    BalanceCollateralOutBalType = balanceTypeCode;
                    BalanceCollateralOutDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "LOAN":
                    BalanceOnLoan = balance;
                    BalanceOnLoanQtyType = quantityTypeCode;
                    BalanceOnLoanBalType = balanceTypeCode;
                    BalanceOnLoanDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "PEND":
                    BalancePendingDelivery = balance;
                    BalancePendingDeliveryQtyType = quantityTypeCode;
                    BalancePendingDeliveryBalType = balanceTypeCode;
                    BalancePendingDeliveryDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "PENR":
                    BalancePendingReceipt = balance;
                    BalancePendingReceiptQtyType = quantityTypeCode;
                    BalancePendingReceiptBalType = balanceTypeCode;
                    BalancePendingReceiptDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "REGO":
                    BalanceOutForRegistration = balance;
                    BalanceOutForRegistrationQtyType = quantityTypeCode;
                    BalanceOutForRegistrationBalType = balanceTypeCode;
                    BalanceOutForRegistrationDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "SETT":
                    BalanceSettlementPosition = balance;
                    BalanceSettlementPositionQtyType = quantityTypeCode;
                    BalanceSettlementPositionBalType = balanceTypeCode;
                    BalanceSettlementPositionDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "SPOS":
                    BalanceStreetPosition = balance;
                    BalanceStreetPositionQtyType = quantityTypeCode;
                    BalanceStreetPositionBalType = balanceTypeCode;
                    BalanceStreetPositionDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "TRAD":
                    BalanceTradeDatePosition = balance;
                    BalanceTradeDatePositionQtyType = quantityTypeCode;
                    BalanceTradeDatePositionBalType = balanceTypeCode;
                    BalanceTradeDatePositionDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "TRAN":
                    BalanceInTransshipmentPosition = balance;
                    BalanceInTransshipmentPositionQtyType = quantityTypeCode;
                    BalanceInTransshipmentPositionBalType = balanceTypeCode;
                    BalanceInTransshipmentPositionDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "NOMI":
                    BalanceRegistered = balance;
                    BalanceRegisteredQtyType = quantityTypeCode;
                    BalanceRegisteredBalType = balanceTypeCode;
                    BalanceRegisteredDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "UNBA":
                    BalanceUninstructed = balance;
                    BalanceUninstructedQtyType = quantityTypeCode;
                    BalanceUninstructedBalType = balanceTypeCode;
                    BalanceUninstructedDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "INBA":
                    BalanceInstructed = balance;
                    BalanceInstructedQtyType = quantityTypeCode;
                    BalanceInstructedBalType = balanceTypeCode;
                    BalanceInstructedDtaSrcSchme = balanceDtaSrcSchme;
                    break;
 				case "OBAL":
                    BalanceObligated = balance;
                    BalanceObligatedQtyType = quantityTypeCode;
                    BalanceObligatedBalType = balanceTypeCode;
                    BalanceObligatedDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "AFFB":
                    BalanceAffected = balance;
                    BalanceAffectedQtyType = quantityTypeCode;
                    BalanceAffectedBalType = balanceTypeCode;
                    BalanceAffectedDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				case "UNAF":
                    BalanceUnaffected = balance;
                    BalanceUnaffectedQtyType = quantityTypeCode;
                    BalanceUnaffectedBalType = balanceTypeCode;
                    BalanceUnaffectedDtaSrcSchme = balanceDtaSrcSchme;
                    break;
				default: 
                    {
                    SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

        internal static string GetHeaders()
        {
            return "CARef|SenderRef|SeqNum|AccountOwner|AccountOwnerDtaSrcSchme|BalanceAffected|BalanceAffectedBalType|BalanceAffectedDtaSrcSchme|BalanceAffectedQtyType|BalanceBlocked|BalanceBlockedBalType|BalanceBlockedDtaSrcSchme|BalanceBlockedQtyType" + 
            "|BalanceBorrowed|BalanceBorrowedBalType|BalanceBorrowedDtaSrcSchme|BalanceBorrowedQtyType|BalanceCollateralIn|BalanceCollateralInBalType|BalanceCollateralInDtaSrcSchme|BalanceCollateralInQtyType|BalanceCollateralOut|BalanceCollateralOutBalType|BalanceCollateralOutDtaSrcSchme|BalanceCollateralOutQtyType" + 
            "|BalanceInstructed|BalanceInstructedBalType|BalanceInstructedDtaSrcSchme|BalanceInstructedQtyType|BalanceInTransshipmentPosition|BalanceInTransshipmentPositionBalType|BalanceInTransshipmentPositionDtaSrcSchme|BalanceInTransshipmentPositionQtyType" + 
            "|BalanceObligated|BalanceObligatedBalType|BalanceObligatedDtaSrcSchme|BalanceObligatedQtyType|BalanceOnLoan|BalanceOnLoanBalType|BalanceOnLoanDtaSrcSchme|BalanceOnLoanQtyType|BalanceOutForRegistration|BalanceOutForRegistrationBalType|BalanceOutForRegistrationDtaSrcSchme|BalanceOutForRegistrationQtyType" +
            "|BalancePendingDelivery|BalancePendingDeliveryBalType|BalancePendingDeliveryDtaSrcSchme|BalancePendingDeliveryQtyType|BalancePendingReceipt|BalancePendingReceiptBalType|BalancePendingReceiptDtaSrcSchme|BalancePendingReceiptQtyType|BalanceRegistered|BalanceRegisteredBalType|BalanceRegisteredDtaSrcSchme|BalanceRegisteredQtyType" + 
            "|BalanceSettlementPosition|BalanceSettlementPositionBalType|BalanceSettlementPositionDtaSrcSchme|BalanceSettlementPositionQtyType|BalanceStreetPosition|BalanceStreetPositionBalType|BalanceStreetPositionDtaSrcSchme|BalanceStreetPositionQtyType|BalanceTotalEligible|BalanceTotalEligibleBalType|BalanceTotalEligibleDtaSrcSchme|BalanceTotalEligibleQtyType" +
            "|BalanceTradeDatePosition|BalanceTradeDatePositionBalType|BalanceTradeDatePositionDtaSrcSchme|BalanceTradeDatePositionQtyType|BalanceUnaffected|BalanceUnaffectedBalType|BalanceUnaffectedDtaSrcSchme|BalanceUnaffectedQtyType|BalanceUninstructed|BalanceUninstructedBalType|BalanceUninstructedDtaSrcSchme|BalanceUninstructedQtyType" +
            "|SafeKeepingAccount|SafeKeepingPlaceCntryCode|SafeKeepingPlaceCode|SafeKeepingPlaceDtaSrcSchme|SafeKeepingPlaceNarrative|SafeKeepingPlaceIdentCode|TagsNotRecognized";
        }

        public override string ToString()
        {
            var sb = new StringBuilder(1000);
            sb.Append(CARef); sb.Append("|" + SenderRef); sb.Append("|" + _seqNum);
            sb.Append("|" + AccountOwner); sb.Append("|" + AccountOwnerDtaSrcSchme); sb.Append("|" + BalanceAffected); sb.Append("|" + BalanceAffectedBalType); sb.Append("|" + BalanceAffectedDtaSrcSchme); sb.Append("|" + BalanceAffectedQtyType); sb.Append("|" + BalanceBlocked); sb.Append("|" + BalanceBlockedBalType); sb.Append("|" + BalanceBlockedDtaSrcSchme); sb.Append("|" + BalanceBlockedQtyType); 
            sb.Append("|" + BalanceBorrowed); sb.Append("|" + BalanceBorrowedBalType); sb.Append("|" + BalanceBorrowedDtaSrcSchme); sb.Append("|" + BalanceBorrowedQtyType); sb.Append("|" + BalanceCollateralIn); sb.Append("|" + BalanceCollateralInBalType); sb.Append("|" + BalanceCollateralInDtaSrcSchme); sb.Append("|" + BalanceCollateralInQtyType); 
            sb.Append("|" + BalanceCollateralOut); sb.Append("|" + BalanceCollateralOutBalType); sb.Append("|" + BalanceCollateralOutDtaSrcSchme); sb.Append("|" + BalanceCollateralOutQtyType); sb.Append("|" + BalanceInstructed); sb.Append("|" + BalanceInstructedBalType); sb.Append("|" + BalanceInstructedDtaSrcSchme); sb.Append("|" + BalanceInstructedQtyType); 
            sb.Append("|" + BalanceInTransshipmentPosition); sb.Append("|" + BalanceInTransshipmentPositionBalType); sb.Append("|" + BalanceInTransshipmentPositionDtaSrcSchme); sb.Append("|" + BalanceInTransshipmentPositionQtyType); sb.Append("|" + BalanceObligated); sb.Append("|" + BalanceObligatedBalType); sb.Append("|" + BalanceObligatedDtaSrcSchme); sb.Append("|" + BalanceObligatedQtyType); 
            sb.Append("|" + BalanceOnLoan); sb.Append("|" + BalanceOnLoanBalType); sb.Append("|" + BalanceOnLoanDtaSrcSchme); sb.Append("|" + BalanceOnLoanQtyType); sb.Append("|" + BalanceOutForRegistration); sb.Append("|" + BalanceOutForRegistrationBalType); sb.Append("|" + BalanceOutForRegistrationDtaSrcSchme); sb.Append("|" + BalanceOutForRegistrationQtyType); 
            sb.Append("|" + BalancePendingDelivery); sb.Append("|" + BalancePendingDeliveryBalType); sb.Append("|" + BalancePendingDeliveryDtaSrcSchme); sb.Append("|" + BalancePendingDeliveryQtyType); sb.Append("|" + BalancePendingReceipt); sb.Append("|" + BalancePendingReceiptBalType); sb.Append("|" + BalancePendingReceiptDtaSrcSchme); sb.Append("|" + BalancePendingReceiptQtyType); 
            sb.Append("|" + BalanceRegistered); sb.Append("|" + BalanceRegisteredBalType); sb.Append("|" + BalanceRegisteredDtaSrcSchme); sb.Append("|" + BalanceRegisteredQtyType); sb.Append("|" + BalanceSettlementPosition); sb.Append("|" + BalanceSettlementPositionBalType); sb.Append("|" + BalanceSettlementPositionDtaSrcSchme); sb.Append("|" + BalanceSettlementPositionQtyType); 
            sb.Append("|" + BalanceStreetPosition); sb.Append("|" + BalanceStreetPositionBalType); sb.Append("|" + BalanceStreetPositionDtaSrcSchme); sb.Append("|" + BalanceStreetPositionQtyType); sb.Append("|" + BalanceTotalEligible); sb.Append("|" + BalanceTotalEligibleBalType); sb.Append("|" + BalanceTotalEligibleDtaSrcSchme); sb.Append("|" + BalanceTotalEligibleQtyType); 
            sb.Append("|" + BalanceTradeDatePosition); sb.Append("|" + BalanceTradeDatePositionBalType); sb.Append("|" + BalanceTradeDatePositionDtaSrcSchme); sb.Append("|" + BalanceTradeDatePositionQtyType); sb.Append("|" + BalanceUnaffected); sb.Append("|" + BalanceUnaffectedBalType); sb.Append("|" + BalanceUnaffectedDtaSrcSchme); sb.Append("|" + BalanceUnaffectedQtyType); 
            sb.Append("|" + BalanceUninstructed); sb.Append("|" + BalanceUninstructedBalType); sb.Append("|" + BalanceUninstructedDtaSrcSchme); sb.Append("|" + BalanceUninstructedQtyType);
            sb.Append("|" + SafeKeepingAccount); sb.Append("|" + SafeKeepingPlaceCntryCode); sb.Append("|" + SafeKeepingPlaceCode); sb.Append("|" + SafeKeepingPlaceDtaSrcSchme); sb.Append("|" + SafeKeepingPlaceNarrative); sb.Append("|" + SafeKeepingPlaceIdentCode); sb.Append("|" + _TagsNotRecognized);
            return sb.ToString();
        }

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }
	}
}