﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Configuration;
using System.Collections.Specialized;
using FTSE.MT564CAParser.FileManager.Exceptions;
using Ftse.Research.Framework.IO;
using Ftse.Research.Framework.Logging;
using log4net;


namespace FTSE.MT564CAParser.FileManager
{
	public class SwiftMessage564File
	{
		private List<SwiftMessage564> _swiftMessage564S = new List<SwiftMessage564>();
		private List<SwiftMessage564> _swiftMessage564SWithErrors = new List<SwiftMessage564>();
		private readonly List<SwiftMessage564> _swiftMessage564SWarnings = new List<SwiftMessage564>();
        private string _filename;
		public int MessagesCount
		{
			get { return _swiftMessage564S.Count; }
		}
		public int MessagesBadCount
		{
			get { return _swiftMessage564SWithErrors.Count; }
		}
		public int MessagesWithWarningsCount
		{
			get { return _swiftMessage564SWarnings.Count; }
		}

		/// <summary>
		/// Indicates if certain exceptions are to be raised
		/// </summary>

        private bool _isIgnoreFailure;
        private ArgumentParser _args;
        //private object _settings;
        internal static string[] CorporateActionsTypesToExclude;


        public SwiftMessage564File(bool isIgnoreFailure, ArgumentParser args)
        {
            _isIgnoreFailure = isIgnoreFailure;
            _args = args;
            
            //Get CA's to exclude
          
            var appSettings = System.Configuration.ConfigurationManager.AppSettings["CAEventsExcluded"];
            CorporateActionsTypesToExclude = appSettings.Split(new[] { ";" }, StringSplitOptions.None);

        }
		public void ParseFile(string fileName, bool isVerboseOutput, string targetDirectoryName)
		{
            //Initialise options
            Options.GetOptions().OptionsInit(_args);

            //Delete existing files
            DeleteOutputFiles(targetDirectoryName, fileName);
            _filename = fileName;
			_swiftMessage564S = new List<SwiftMessage564>();
			_swiftMessage564SWithErrors = new List<SwiftMessage564>();

           
            LogProvider.GetLogger().InfoFormat("Parsing messages from file {0} ...", fileName);
			using (var sr = new StreamReader(fileName))
			{
				String line;
				var messageLines = new List<string>(100);

				// Read and display lines from the file until the end of the file is reached
				while ((line = sr.ReadLine()) != null)
				{
					if (String.IsNullOrEmpty(line))
						continue;

                    // Check if adding a header that one does not already exist
                    if (line.StartsWith("${") || line.StartsWith("{"))
                    {
                       if (! (messageLines.Find(x => x.Contains("${") || x.Contains("{"))== null))
                            throw new Exception("New MT564 header row encountered, before trailer row of previous message, check source file is not corrupted.");

                    }

					messageLines.Add(line);

					// End of message
                    if ((line != "-}$")) 
						    continue;

					// End of message -> Parse
					var swiftMessage564 = new SwiftMessage564(messageLines, fileName);
                    LogProvider.GetLogger().InfoFormat("Parsing message...");
									
					try
					{
						swiftMessage564.Parse(isVerboseOutput);
						swiftMessage564.IsValid = true;

						// If such message (CARef,SenderRef) already exists -> Update
						SwiftMessage564 messageFound = _swiftMessage564S.FirstOrDefault(m => m.SequenceA.CARef == swiftMessage564.SequenceA.CARef && m.SequenceA.SenderRef == swiftMessage564.SequenceA.SenderRef);
						if (messageFound != null)
							_swiftMessage564S.Remove(messageFound);

						_swiftMessage564S.Add(swiftMessage564);

                        LogProvider.GetLogger().InfoFormat("Message [CORP:{0} SEME:{1}] parsed ok.", swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef);	
                     						
						messageLines.Clear();
                       
					}
					catch (NotRequiredMessageException)
					{
                        LogProvider.GetLogger().InfoFormat("Message [CORP:{0} SEME:{1}] is of type {2} and it is NOT required. Skipping.", swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef, swiftMessage564.SequenceA.CAType);
						messageLines.Clear();
					}
					catch (Exception ex)
					{
						// Rethrow exception if message is in set of required types and we haven't put a parameter to ignore
                        if (swiftMessage564.IsRequiredType)
                        {
                            LogProvider.GetLogger().InfoFormat("One or more errors rendered message [CORP:{0} SEME:{1}] invalid. Invalid messages are not output in the output files but placed in .bad files(ONLY if ignoreFailure=True). More Info: {2}",
                                              swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef, ex.Message);
                            swiftMessage564.IsValid = false;

                            swiftMessage564.ProcessingException = ex; // ?
                            _swiftMessage564SWithErrors.Add(swiftMessage564);

                            if (!_isIgnoreFailure)
                                throw;
                        }
                        else
                        {
                            LogProvider.GetLogger().InfoFormat("One or more errors rendered message [CORP:{0} SEME:{1}] invalid but it is not required and will be ignored. More Info: {2} ",
                                              swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef, ex.Message);
                           
                        }
                        messageLines.Clear();
					}
				}
			}
            LogProvider.GetLogger().InfoFormat("Finished parsing messages in file {0}", fileName);

            string destFileName = fileName + ".bad";
            // //Delete 'bad' messages file
            //File.Delete(destFileName);

			if (_swiftMessage564SWithErrors.Count <= 0)
				return;
            			
            LogProvider.GetLogger().InfoFormat("There are {0} messages with errors. Writing them in file {1}", _swiftMessage564SWithErrors.Count, destFileName);

			using (var writer = new StreamWriter(destFileName))
				foreach (var swiftMessage564SWithError in _swiftMessage564SWithErrors)
				{
					writer.WriteLine("The following exception was encountered while parsing this message: {0}", swiftMessage564SWithError.ProcessingException.Message);
					writer.WriteLine(swiftMessage564SWithError.OriginalMessage);
					writer.WriteLine();
				}
		}

		/// <summary>
		/// Write out files - flat delimited files. In case of no valid messages files contain headers only
		/// </summary>
		/// <param name="targetDirectoryName"></param>
		/// <param name="sourceFileName"></param>
		public void WriteFiles(string targetDirectoryName, string sourceFileName)
		{
			var validMessages = _swiftMessage564S.Where(swiftMessage564 => swiftMessage564.IsValid).ToList();

            var vendor = Options.GetOptions()["vendor"];
           
			// F1
			var targetF1 = GetTargetFileName(targetDirectoryName, sourceFileName, "F1");
			using (var writer = new StreamWriter(targetF1))
			{
               
				// Headers
				writer.WriteLine("Vendor" + "|" + SequenceA.GetHeaders() + "|" + SequenceB.GetHeaders() + "|" + SequenceC.GetHeaders() + "|" + SequenceD.GetHeaders() + "|" + SequenceF.GetHeaders());

				foreach (var swiftMessage564 in validMessages)
                    writer.WriteLine(vendor + "|" + swiftMessage564.SequenceA + "|" + swiftMessage564.SequenceB + "|" + swiftMessage564.SequenceC + "|" + swiftMessage564.SequenceD + "|" + swiftMessage564.SequenceF);
			}

            var cnt = (from message in validMessages
                       where message.SequenceA != null
                       select message).Count();
            //   select new {Cntzz=g} ; 
            LogProvider.GetLogger().InfoFormat("There are {0} Sequence A;B;B1;C;D;F rows. Written to file {1}", cnt, targetF1);



			// F2
			var targetF2 = GetTargetFileName(targetDirectoryName, sourceFileName, "F2");
			using (var writer = new StreamWriter(targetF2))
			{
				// Headers
                writer.WriteLine("Vendor|FileAndPathName|" + SequenceE.GetHeaders());
				// Lines
				foreach (var seqE in from message in validMessages where message.SequencesE != null 
									 from seqE in message.SequencesE where seqE != null 
									 select seqE)
                    writer.WriteLine(vendor + "|" + _filename + "|" + seqE);
               
			}
           
 
            cnt = (from message in validMessages
                      where message.SequencesE != null
                   from seqE in message.SequencesE
                   where seqE != null 
                      select message).Count();
                 //   select new {Cntzz=g} ; 
            LogProvider.GetLogger().InfoFormat("There are {0} Sequence E rows. Written to file {1}", cnt, targetF2);

            var cnt2 = (from seqE  in validMessages  
                           select seqE).Count();
                    
                    

			// F3
			var targetF3 = GetTargetFileName(targetDirectoryName, sourceFileName, "F3");
			using (var writer = new StreamWriter(targetF3))
			{
				// Headers
                writer.WriteLine("Vendor|FileAndPathName|" + SubsequenceE1.GetHeaders());

				// Lines
				foreach (var subE1 in from message in validMessages where message.SequencesE != null 
									  from seqE in message.SequencesE where seqE != null 
									  from subE1 in seqE.SubsequenceE1S select subE1)
                    writer.WriteLine(vendor + "|" + _filename + "|" + subE1);
			}

            cnt = (from message in validMessages
                   where message.SequencesE != null
                   from seqE in message.SequencesE
                   where seqE != null
                    from subE1 in seqE.SubsequenceE1S
                   select subE1).Count();
            LogProvider.GetLogger().InfoFormat("There are {0} SubSequence E1;E1A rows. Written to file {1}", cnt, targetF3);


			// F4
			var targetF4 = GetTargetFileName(targetDirectoryName, sourceFileName, "F4");
			using (var writer = new StreamWriter(targetF4))
			{
				// Headers
                writer.WriteLine("Vendor|FileAndPathName|" + SubsequenceE2.GetHeaders());
				
				// Lines
                foreach (var subE2 in from message in validMessages 
                                      from seqE in message.SequencesE where seqE != null 
                                      from subE2 in seqE.SubsequenceE2S select subE2)
                    writer.WriteLine(vendor + "|" + _filename + "|" + subE2);

               
			}

            cnt = (from message in validMessages
                   where message.SequencesE != null
                   from seqE in message.SequencesE
                   where seqE != null
                   from subE2 in seqE.SubsequenceE2S
                   select subE2).Count();
            LogProvider.GetLogger().InfoFormat("There are {0} SubSequence E2 rows. Written to file {1}", cnt, targetF4);

			// F5
			var targetF5 = GetTargetFileName(targetDirectoryName, sourceFileName, "F5");
			using (var writer = new StreamWriter(targetF5))
			{
				// Headers
                writer.WriteLine("Vendor|FileAndPathName|" + SubsequenceA1.GetHeaders());
	
				// Lines
				foreach (var subsA in from message in validMessages where message.SequenceA != null 
									  from subsA in message.SequenceA.SubsequenceA1S where subsA != null 
									  select subsA)
                    writer.WriteLine(vendor + "|" + _filename + "|" + subsA);
			}

            cnt = (from message in validMessages
                   where message.SequenceA!= null
                   from seqA1 in message.SequenceA.SubsequenceA1S
                   where seqA1 != null
                   select seqA1).Count();
            LogProvider.GetLogger().InfoFormat("There are {0} SubSequence A1 rows. Written to file {1}", cnt, targetF5);


            // F6
            var targetF6 = GetTargetFileName(targetDirectoryName, sourceFileName, "F6");
            using (var writer = new StreamWriter(targetF6))
            {
                // Headers
                writer.WriteLine("Vendor|FileAndPathName|" + SubsequenceB2.GetHeaders());

                // Lines
                foreach (var subsB2 in from message in validMessages
                                      where message.SequenceB != null
                                      from subsB2 in message.SequenceB.SubsequenceB2S
                                       where subsB2 != null
                                       select subsB2)
                    writer.WriteLine(vendor + "|" + _filename + "|" + subsB2);
            }
            cnt = (from message in validMessages
                   where message.SequenceB != null
                   from seqB2 in message.SequenceB.SubsequenceB2S
                   where seqB2 != null
                   select seqB2).Count();
            LogProvider.GetLogger().InfoFormat("There are {0} SubSequence B2 rows. Written to file {1}", cnt, targetF6);


            //F7  Overflow processing E2 and 
            var targetF7 = GetTargetFileName(targetDirectoryName, sourceFileName, "F7");
            using (var writer = new StreamWriter(targetF7))
            {
                // Headers
                writer.WriteLine("Vendor|FileAndPathName|CARef|SenderRef|CAOptionNumber|SeqNum|" + SequenceTagOverflow.GetHeaders());

                //E2 CashMovement
                var matches = from message in validMessages
                              from seqE in message.SequencesE
                              where seqE != null
                              from sub in seqE.SubsequenceE2S
                              from over in sub._sequenceTagOverflowCache
                              where over.PlaceHolder == false
                              select new { over, sub };

                //E1 Security Movement
                var matchesSM = from message in validMessages
                              from seqE in message.SequencesE
                              where seqE != null
                              from sub in seqE.SubsequenceE1S
                              from over in sub._sequenceTagOverflowCache
                              where over.PlaceHolder == false
                              select new { over, sub };
                
                var overflowSeqNumWork = 0;
                var CARef = "";
                var senderRef = "";
                var CAOptionNumber = 0;
                var seqNum = 0;
                var overflowTag = "0";
                foreach (var match in matches)
                {
                    GetNextOverflowSeqNum(match, ref CARef, ref senderRef, ref CAOptionNumber, ref seqNum, ref overflowTag, ref overflowSeqNumWork);
                       
                    writer.WriteLine(vendor + "|" + _filename + "|" + match.sub.CARef + "|" + match.sub.SenderRef + "|" + match.sub.CAOptionNumber + "|" + match.sub._subsequenceNumber + "|" + match.over);
                }

                
                overflowSeqNumWork = 0;   CARef = ""; senderRef = ""; CAOptionNumber = 0; seqNum = 0; overflowTag = "0";
                foreach (var match in matchesSM)
                {
                    GetNextOverflowSeqNum(match, ref CARef, ref senderRef, ref CAOptionNumber, ref seqNum, ref overflowTag, ref overflowSeqNumWork);
                    writer.WriteLine(vendor + "|" + _filename + "|" + match.sub.CARef + "|" + match.sub.SenderRef + "|" + match.sub.CAOptionNumber + "|" + match.sub._subsequenceNumber + "|" + match.over);
                }

                cnt = (from message in validMessages
                       from seqE in message.SequencesE
                       where seqE != null
                       from sub in seqE.SubsequenceE2S
                       from over in sub._sequenceTagOverflowCache
                       where over.PlaceHolder == false
                       select over).Count();
                LogProvider.GetLogger().InfoFormat("There are {0} Cash Movement Tag Overflow rows. Written to file {1}", cnt, targetF7);
            }

		}
        /// <summary>
        /// Calculates OverflowSequence Number from Anonymous Type (
        /// </summary>
        /// <param name="match"></param>
        /// <param name="CARef"></param>
        /// <param name="SenderRef"></param>
        /// <param name="CAOptionNumber"></param>
        /// <param name="seqNum"></param>
        /// <param name="overflowTag"></param>
        /// <param name="overflowSeqNumWork"></param>
        private void GetNextOverflowSeqNum(dynamic match, ref string CARef, ref string SenderRef, ref int CAOptionNumber, ref int seqNum, ref string overflowTag, ref int overflowSeqNumWork)
        {
            if (
                             (match.sub.CARef == CARef)
                             && (match.sub.SenderRef == SenderRef)
                             && (match.sub.CAOptionNumber == CAOptionNumber)
                             && (match.sub._subsequenceNumber == seqNum)
                             && (match.over.OverflowTag.Substring(0, 2) == overflowTag)
                             )
            {
                overflowSeqNumWork++;
            }
            else
            {
                overflowSeqNumWork = 1;
                CARef = match.sub.CARef;
                SenderRef = match.sub.SenderRef;
                CAOptionNumber = match.sub.CAOptionNumber;
                seqNum = match.sub._subsequenceNumber;
                overflowTag = match.over.OverflowTag.Substring(0, 2);
            }

            match.over.OverflowSeqNumber = overflowSeqNumWork; 
        }
		private static string GetTargetFileName(string targetdirectoryName, string sourcefileName, string fileType)
		{
			var i = sourcefileName.LastIndexOf(".", StringComparison.Ordinal);
			var newFileName = sourcefileName.Substring(0, i) + fileType + sourcefileName.Substring(i);
			var target = Path.Combine(targetdirectoryName, new FileInfo(newFileName).Name);
			return target;
		}

        private static void DeleteOutputFiles(string targetdirectoryName, string sourcefileName)
        {

            File.Delete(GetTargetFileName(targetdirectoryName, sourcefileName, "F1"));
            File.Delete(GetTargetFileName(targetdirectoryName, sourcefileName, "F2"));
            File.Delete(GetTargetFileName(targetdirectoryName, sourcefileName, "F3"));
            File.Delete(GetTargetFileName(targetdirectoryName, sourcefileName, "F4"));
            File.Delete(GetTargetFileName(targetdirectoryName, sourcefileName, "F5"));
            File.Delete(GetTargetFileName(targetdirectoryName, sourcefileName, "F6"));
            File.Delete(GetTargetFileName(targetdirectoryName, sourcefileName, "F7"));

            //Delete 'bad' messages file
            File.Delete(sourcefileName + ".bad");

        }
	}
}