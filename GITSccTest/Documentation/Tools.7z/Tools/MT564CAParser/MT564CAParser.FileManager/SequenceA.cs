﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;
/***********************************************************
 * 
 * History:
 * 
 * Date:                Pgmr                      Description  
 * 14.05.2014           P.Pulling                 Capture and expose ALL MT564 data points
 * 
 ***********************************************************/
namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Sequence A of MT564 - General Information
	/// </summary>
    internal class SequenceA : Sequence
	{
		private bool _isInA1;
		private int _a1No;
		private SubsequenceA1 _subsequenceA1;
        private string _fileAndPathName;
        internal bool IsRequiredType
		{
            get { return (!(SwiftMessage564File.CorporateActionsTypesToExclude.Any(p => p == CAType))); }
		}

		#region SWIFT Message attributes
		/// <summary>
		/// Contains A1 subsection - linkages
		/// </summary>
        internal List<SubsequenceA1> SubsequenceA1S = new List<SubsequenceA1>();

		// 20C
        internal string CARef { get; set; }
        internal string SenderRef { get; set; }
        internal string OfficialCARef { get; set; }

		/// <summary>
		/// 23G Message Type/Sub Type
		/// </summary>
        internal string MessageType { get; private set; }
        internal string MessageSubType { get; private set; }

		/// <summary>
		/// 22F - Type of CorpAction
		/// </summary>
        internal string CAType { get; private set; }
        internal string CATypeDtaSrcSchme { get; private set; }

		/// <summary>
		/// 22F - Processing Type
		/// </summary>
        internal string CAProcessingType { get; private set; }
        internal string CAProcessingTypeDtaSrcSchme { get; private set; }

		/// <summary>
		/// 22F
		/// </summary>
        internal string MVFlag { get; private set; }
        internal string MVFlagDtaSrcSchme { get; private set; }

		/// <summary>
		/// 98 C - Message Preparation Date
		/// </summary>
        internal DateTime? MessageDate { get; private set; }

		// 25D
        internal string CAProcessingStatus { get; private set; }
        internal string CAProcessingStatusDtaSrcSchme { get; private set; }
		#endregion


        internal SequenceA(string fileAndPathName)
        {
            _fileAndPathName = fileAndPathName;
           
        }
        internal SequenceA()
        {
           
        }

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{

            if (_isInA1)
            {
                if (_subsequenceA1 == null)
                    throw new Exception(String.Format("{0}: unexpected reference to subsequence A1 before encountering code 16R", GetType().Name));

                //Add SubsequenceB2 to list
                if (code == "16S")
                    ParseField16S(text);
                else if (code == "16R")
                    ParseField16R(text);
                else
                    _subsequenceA1.Parse(code, text);

            }
            else
            {
                base.Parse(code, text);
                switch (code)
                {
                    case "20C": ParseField20C(code, text); break;
                    case "23G": ParseField23(code, text); break;
                    case "22F": ParseField22F(code, text); break;

                    case "98A":
                    case "98C": ParseField98A(code, text); break;
                    case "25D": ParseField25D(code, text); break;

                    case "16R": ParseField16R(text); break;
                    case "16S": ParseField16S(text); break;

                    default:
                        throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
                }
            }
		}


		private void ParseField16R(string input)
		{
			switch (input)
			{
				case "LINK":
					_a1No++;
					_subsequenceA1 = new SubsequenceA1(CARef, SenderRef, _a1No);
					_isInA1 = true;
					break;
				case "GENL": // NOP
					break;

				default:
					throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 16R", GetType().Name, input));
			}
		}

        private void ParseField16S(string input)
		{
			switch (input)
			{
				case "LINK":
					SubsequenceA1S.Add(_subsequenceA1);
					_isInA1 = false;
					break;

					//A1Linkages.Add(_subsequenceA1); break;
			}
		}

        private void ParseField20C(string code, string input)
		{
            ParseField20COptions(input);
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			switch (s[0])
			{
				case "COAF":
                    OfficialCARef = s[1];
                    break;
				case "CORP":
					CARef = s[1];
					break;
				case "SEME":
					SenderRef = s[1];
					break;

					// case "PREV": _subsequenceA1.Reference = s[1]; break;

				default:
					 {
                    SequenceTagUnknownProcess(code, input);
                    }
                break;
			}
		}

		/// <summary>
		/// Function Type of message
		/// </summary>
		/// <param name="input"></param>
		private void ParseField23(string code, string input)
		{
            
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}(/[A-Z]{4})?$")))
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 23G", GetType().Name));
            }
            var s = input.Split(new[] { "/" }, StringSplitOptions.None);
            switch (s[0])
            {
                case "ADDB":
                case "CANC":
                case "NEWM":
                case "REPE":
                case "REPL":
                case "RMDR":
                case "WITH":

                    {
			            MessageType = s[0];
                        MessageSubType = s.Length == 2 ? s[1] : null;
                    }
                break;
                default:
                     {
                    SequenceTagUnknownProcess(code, input);
                    }
                break;
            }
		}

		/// <summary>
		/// Indicator: Corporate Action Type
		/// </summary>
		/// <param name="input"></param>
		private void ParseField22F(string code, string input)
		{
            ParseField22Options(input);
			var s = input.Split(new[] {"/"}, StringSplitOptions.None);
            var dataSourceScheme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];
			switch (s[0])
			{
				case "CAEV":
					CAType = s[2];
                    CATypeDtaSrcSchme = dataSourceScheme;
					break;
				case "CAMV":
					MVFlag = s[2];
                    MVFlagDtaSrcSchme = dataSourceScheme;
					break;
				case "CAEP":
					CAProcessingType = s[2];
                    CAProcessingTypeDtaSrcSchme = dataSourceScheme;
					break;

				default:
					{
                    SequenceTagUnknownProcess(code, input);
                    return;
                    }
               
			}

			// Check if message is of set of required types if CAType has been populated
			if (!String.IsNullOrEmpty(CAType) && !IsRequiredType)
				throw new NotRequiredMessageException(String.Format("{0}: The message of type {1} is not required to be parsed.", GetType().Name, CAType));
		}
        /// <summary>
        /// Processing Status
        /// Option D :4!c/[8c]/4!c (Qualifier)(Data Source Scheme)(Status Code) 
        /// </summary>
        /// <param name="input"></param>
		private void ParseField25D(string code, string input)
		{
            if (!(Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z0-9]{0,8}/[A-Z]{4}$"))) 
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 25D", GetType().Name));
            }
			var s = input.Split(new[] {"/"}, StringSplitOptions.None);
            var dataSourceScheme = string.IsNullOrWhiteSpace(s[1]) ? null : s[1];
			switch (s[0])
			{
				case "PROC":
					CAProcessingStatus = s[2];
                    CAProcessingStatusDtaSrcSchme = dataSourceScheme;
					break;

				default:
					{
                    SequenceTagUnknownProcess(code, input);
                    }
                break;
			}
		}

		private void ParseField98A(string code, string input)
		{

            ParseField98ACOptions(input);
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			switch (s[0])
			{
				case "PREP":
					MessageDate = ParseDateOptionalTime(s[1]);
					break;

				default:
					{
                    SequenceTagUnknownProcess(code, input);
                    }
                break;
			}
		}

		internal static string GetHeaders()
		{
            return "FileAndPathName|CARef|OfficialCARef|SenderRef|MessageType|MessageSubType|CAType|CATypeDtaSrcSchme|CAProcessingType|CAProcessingTypeDtaSrcSchme|MVFlag|MVFlagDtaSrcSchme|MessageDate|CAProcessingStatus|CAProcessingStatusDtaSrcSchme|TagsNotRecognizedSeqA";
		}

		public override string ToString()
		{
            return _fileAndPathName + "|" + CARef + "|" + OfficialCARef + "|" + SenderRef + "|" + MessageType + "|"
                    + MessageSubType + "|" + CAType + "|" + CATypeDtaSrcSchme + "|" + CAProcessingType + "|" + CAProcessingTypeDtaSrcSchme + "|" + MVFlag + "|" + MVFlagDtaSrcSchme + "|" + MessageDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + CAProcessingStatus + "|" + CAProcessingStatusDtaSrcSchme + "|" + _TagsNotRecognized;
		}

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }
	}
}