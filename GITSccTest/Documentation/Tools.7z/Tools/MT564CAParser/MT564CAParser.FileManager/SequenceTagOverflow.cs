﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace FTSE.MT564CAParser.FileManager
{
    /// <summary>
    /// Cannot be immutable struct, due to requirement to update 'Placeholder'
    /// </summary>
    internal class SequenceTagOverflow
    {

           
            internal string OverflowQualifier { get; set; }
            internal string OverflowTag { get; set; }
            internal string OverflowSequence { get; set; }
            internal XmlDocument OverflowValueXML { get; set; }
            internal bool PlaceHolder { get; set; }
            
            //internal string CARef { get; set; }
            //internal string SenderRef { get; set; }
            //internal Int32 CAOptionNumber { get; set; }
            //internal Int32 SeqNumber { get; set; }
            internal Int32 OverflowSeqNumber { get; set; }
            //internal Sequence workSequence { get; set; }

            /// <summary>
            /// Placeholder Key for Qualifier, no data passed
            /// </summary>
            /// <param name="rateExtraQualifier"></param>
            internal SequenceTagOverflow( string overflowSequence, string overflowTag, string overflowQualifier)
                : this(overflowSequence, overflowTag, overflowQualifier, null, true, 1)
            {
            }
            internal SequenceTagOverflow( string overflowSequence, string overflowTag, string overflowQualifier, XmlDocument overflowValue)
                : this(overflowSequence, overflowTag, overflowQualifier, overflowValue, true, 0)
            {
            }
            private SequenceTagOverflow( string overflowSequence, string overflowTag, string overflowQualifier, XmlDocument overflowValue, bool placeHolder, Int32 overflowSeq)
        
            {
                //Generate XML Name/Value pairs here 
                OverflowSequence = overflowSequence;
                OverflowQualifier = overflowQualifier;
                OverflowTag = overflowTag;
                OverflowValueXML = overflowValue;
                PlaceHolder = placeHolder;
                OverflowSeqNumber = overflowSeq;

                //workSequence = candidateSequence;
            }

            public override string ToString()
            {
                var sb = new StringBuilder(256);
                sb.Append(OverflowSequence); sb.Append("|" + OverflowTag); sb.Append("|" + OverflowQualifier); sb.Append("|" + OverflowSeqNumber.ToString()); sb.Append("|" + OverflowValueXML.OuterXml);
                return sb.ToString();
            }

            public static string GetHeaders()
            {
                return "OverflowSequence|OverflowTag|OverflowQualifier|OverflowSeqNum|OverflowValue";
                      
                       
            }
    }
}
