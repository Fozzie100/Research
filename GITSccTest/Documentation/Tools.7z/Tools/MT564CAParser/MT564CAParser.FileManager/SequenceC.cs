﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using FTSE.MT564CAParser.FileManager.Exceptions;

namespace FTSE.MT564CAParser.FileManager
{
	/// <summary>
	/// Sequence C of MT564 represents Intermediate Securities
	/// </summary>
	internal class SequenceC : Sequence
	{
	
		protected internal  string _sedol;
        protected internal string _entity;
        protected internal string _ISIN;
        protected internal string _countrycode;
       
		#region SWIFT Message attributes
		/// <summary>
		/// 35B - Security SEDOL
		/// </summary>
        internal string SecTickerIntrmediate
		{
			get { return _sedol; }
		}

		/// <summary>
		/// 35B - Security Description
		/// </summary>
        internal string SecDescrptionIntrmediate
		{
			get { return _entity; }
		}
        /// <summary>
        /// 35B - ISIN
        /// </summary>
        internal string SecISINIntrmediate
        {
            get { return _ISIN; }
        }
        /// <summary>
        /// 35B - CountryCode
        /// </summary>
        internal string SecCntryCodeIntrmediate
        {
            get { return _countrycode; }
        }

		/// <summary>
		/// 36A - Security Quantity
		/// </summary>
        internal decimal? SecurityQuantity { get; set; }
        internal string SecurityQuantityTypeCode { get; set; }

		/// <summary>
		/// 93A - Balance
		/// </summary>

        internal decimal? BalanceUninstructed { get; set; }
        internal string BalanceUninstructedQuantityType { get; set; }
        internal string BalanceUninstructedBalanceType { get; set; }
        internal string BalanceUninstructedDtaSrcSchme { get; set; }
        internal decimal? BalanceInstructed { get; set; }
        internal string BalanceInstructedQuantityType { get; set; }
        internal string BalanceInstructedBalanceType { get; set; }
        internal string BalanceInstructedDtaSrcSchme { get; set; }

        ///// <summary>
        ///// 22F - Indicator Type
        ///// </summary>
        //public string SecIndicatorType { get; set; }
        ///// <summary>
        ///// 22F - Indicator
        ///// </summary>
        //public string SecIndicator { get; set; }
        /// <summary>
        /// 22F Indicator
        /// </summary>
        internal string DispOfFractionsInd { get; set; }
        internal string DispOfFractionsIndDtaSrcSchme { get; set; }
        internal string RenounceEntitlementInd { get; set; }
        internal string RenounceEntitlementIndDtaSrcSchme { get; set; }

		/// <summary>
		/// 92D - Intermediate Securities to Underlying
		/// </summary>
        internal decimal? QuantitySecurityUnderlying { get; set; }
        internal decimal? QuantitySecurityRight { get; set; }
		/// <summary>
		/// 90B - Market Price
		/// </summary>
        internal decimal? MarketPrice { get; set; }
		/// <summary>
		/// 90B - Market Price Currency
		/// </summary>
        internal string MarketPriceCurrency { get; set; }
        internal string MarketPriceAmountType { get; set; }

		/// <summary>
		/// 98A - Expiry Date
		/// </summary>
        internal DateTime? ExpiryDate { get; set; }
        internal string ExpiryDateDtaSrcSchme { get; set; }
      		/// <summary>
		/// 98A - Posting Date 
		/// </summary>
        internal DateTime? PostingDate { get; set; }
        internal string PostingDateDtaSrcSchme { get; set; }
        

		/// <summary>
		/// 69A - Trading Period
		/// </summary>
        internal DateTime? TradingPeriodStart { get; set; }

		/// <summary>
		/// 69A - Trading Period
		/// </summary>
        internal DateTime? TradingPeriodEnd { get; set; }
		#endregion

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
        internal override void Parse(string code, string text)
		{
            base.Parse(code, text);
			switch (code)
			{
				case "16R": ParseField16R(text); break;

                case "35B": ParseField35B(text, out _sedol, out _entity, out _ISIN, out _countrycode); break;

				case "36A": 
				case "36B":
				case "36E": ParseField36A(code, text); break;

				case "93A": 
				case "93B":
				case "93C": ParseField93A(code, text); break;

				case "22F": ParseField22F(code, text); break;
				case "92D": ParseField92D(code, text); break;
				case "90B": ParseField90B(code, text); break;

				case "98A": 
				case "98B": ParseField98A(code, text); break;

				case "69A":
				case "69B":
				case "69C":
				case "69D":
				case "69E":
				case "69F": ParseField69A(code, text); break;

				case "16S": // NOP
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered in this sequence.", GetType().Name, code));
			}
		}


        internal void ParseField16R(string input)
		{
			if (!Regex.IsMatch(input, "INTSEC"))
				throw new UnexpectedCodeException(String.Format("{0}: Code 16R is not properly formed. Expected value INTSEC.", GetType().Name));
		}

		/// <summary>
		/// Quantity of Financial Intrument
		/// </summary>
		/// <example>Option B	:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)
		///			 Option E	:4!c//4!c/[N]15d	(Qualifier)(Quantity Type Code)(Sign)(Quantity)
		///</example>
		/// <param name="input"></param>
        internal void ParseField36A(string code,string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "QINT":
					var spRes = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					SecurityQuantity = ParseDecimalFr(spRes[1].Replace("N", "-"));
                    SecurityQuantityTypeCode = spRes[0];
					break;

				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Balance
		/// </summary>
		/// <example>Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
		///			 Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)</example>
		/// <param name="input"></param>
		/// NOTE: This is partially implemented
        internal void ParseField93A(string code, string input)
		{
            ParseField93Options(input);
            var s = input.Split(new[] { "/" }, StringSplitOptions.None);

			switch (s[0])
			{
                case "UNBA":
                    {
                        if (s.Length == 5) // option C
                        {
                            BalanceUninstructedQuantityType = s[2];
                            BalanceUninstructedBalanceType = s[3];
                            BalanceUninstructed = ParseDecimalFr(s[4]);
                        }
                        else
                        {
                            BalanceUninstructedDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                            BalanceUninstructedQuantityType = s[2];
                            BalanceUninstructed = ParseDecimalFr(s[3]);
                        }
                    }break;

                case "INBA":
                    {
                        if (s.Length == 5) // option C
                        {
                            BalanceInstructedQuantityType = s[2];
                            BalanceInstructedBalanceType = s[3];
                            BalanceInstructed = ParseDecimalFr(s[4]);
                        }
                        else
                        {
                            BalanceInstructedDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                            BalanceInstructedQuantityType = s[2];
                            BalanceInstructed = ParseDecimalFr(s[3]);
                        }
                    }break;
				default: 
                     {
                            SequenceTagUnknownProcess(code, input);
                     }
                    break;
			}
		}

		/// <summary>
		/// Indicator
		/// </summary>
		/// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
		/// <param name="input"></param>
        internal void ParseField22F(string code, string input)
		{

            ParseField22Options(input);
			var s = input.Split(new[] {"/"}, 3, StringSplitOptions.None);

			switch (s[0])
			{
				case "DISF":
                    DispOfFractionsIndDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    DispOfFractionsInd = s[2];
                    break;
				case "SELL":
                    RenounceEntitlementIndDtaSrcSchme = String.IsNullOrWhiteSpace(s[1]) ? null : s[1];
                    RenounceEntitlementInd = s[2];
                    break;
						
				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		
		}

		/// <summary>
		/// Rate
		/// </summary>
		/// <example>:4!c//15d/15d	(Qualifier)(Quantity)(Quantity)</example>
		/// <param name="input"></param>
        internal void ParseField92D(string code, string input)
		{

            if (
                  (!(Regex.IsMatch(input, @"^[A-Z]{4}//\d{1,15},\d{0,15}/\d{1,15},\d{0,15}$"))) //option D
                  
                  )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 92D", GetType().Name));
            }
			// Not sure why 15d/15d ??		// There is also ADSR ? (http://www.10588.com/pub_web/swift/books/us5mc/)
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
            var s1 = s[1].Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "RTUN":
                    QuantitySecurityRight = ParseDecimalFr(s1[0]);
                    QuantitySecurityUnderlying = ParseDecimalFr(s1[1]);
					break;
				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Market Price
		/// </summary>
		/// <example>Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)</example>
		/// <param name="input"></param>
        internal void ParseField90B(string code, string input)
		{
            if (
                      (!(Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}/[A-Z]{3}\d{1,15},\d{0,15}$"))) //option B
                   
                   )
            {
                throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 90B.", GetType().Name));
            }
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "MRKT":
					var splitResult2 = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					var regexCurrency = new Regex("[A-Z]{3}");
					Match match = regexCurrency.Match(splitResult2[splitResult2.Length - 1]);
					MarketPriceCurrency = match.Value;

					MarketPrice = ParseDecimalFr(regexCurrency.Replace(splitResult2[splitResult2.Length - 1], string.Empty));
                    MarketPriceAmountType = splitResult2[0];
					break;

				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// DateTime
		/// </summary>
		/// <example>Option A	:4!c//8!n	(Qualifier)(Date)
		///			 Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField98A(string code, string input)
		{
            //Option A supported.
            //Option B with no data source scheme supported.
            //TODO Throw error if option B with Data source scheme

            ParseField98ABOptions(input);
			var s = input.Split(new[] {"/"}, StringSplitOptions.None);
			switch (s[0])
			{
				case "EXPI":
                    ExpiryDateDtaSrcSchme = s[1];
                    ExpiryDate = ParseDateOptionalTime(input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1));
                    break;
				case "POST":
                    PostingDateDtaSrcSchme = s[1];
                    PostingDate = ParseDateOptionalTime(input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1));
                    break;

				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

		/// <summary>
		/// Trading Period (Start, End)
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n/8!n	(Qualifier)(Date)(Date)
		/// Option B	:4!c//8!n6!n/8!n6!n	(Qualifier)(Date)(Time)(Date)(Time)
		/// Option C	:4!c//8!n/4!c	(Qualifier)(Date)(Date Code)
		/// Option D	:4!c//8!n6!n/4!c	(Qualifier)(Date)(Time)(Date Code)
		/// Option E	:4!c//4!c/8!n	(Qualifier)(Date Code)(Date)
		/// Option F	:4!c//4!c/8!n6!n	(Qualifier)(Date Code)(Date)(Time)
		/// </example>
		/// <param name="input"></param>
        internal void ParseField69A(string code, string input)
		{
            ParseField69ABCDEFOptions(input);
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "TRDP":
					var splitResultB = s[1].Split(new[] {"/"}, StringSplitOptions.None);

					// Option A
					if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
					{
						TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
						TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
						break;
					}

					// Option B
					if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
					{
						TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						break;
					}

					// Option C, D
					if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN" || splitResultB[1] == "OPEN")
					{
						TradingPeriodEnd = null;
						try
						{
							TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						}
						catch (FormatException)
						{
							TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);							
						}
						break;
					}

					// Option E, F
					if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN" || splitResultB[1] == "OPEN")
					{
						TradingPeriodStart = null;
						try
						{
							TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						}
						catch (FormatException)
						{
							TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
						}
						break;
					}
					break;

				default: 
                    {
                            SequenceTagUnknownProcess(code, input);
                    }
                    break;
			}
		}

        internal static string GetHeaders()
		{
            return "SecTickerIntrmediate|SecDescrptionIntrmediate|SecurityQuantity|QuantitySecurityUnderlying|QuantitySecurityRight" +
                   "|MarketPrice|MarketPriceCurrency|ExpiryDate|ExpiryDateDtaSrcSchme|PostingDate|PostingDateDtaSrcSchme|TradingPeriodStart|TradingPeriodEnd|SecISINIntrmediate|SecCntryCodeIntrmediate|SecurityQuantityTypeCode" +
                   "|BalanceInstructed|BalanceInstructedQuantityType|BalanceInstructedDtaSrcSchme|BalanceInstructedBalanceType" +
                   "|BalanceUninstructed|BalanceUninstructedQuantityType|BalanceUninstructedDtaSrcSchme|BalanceUninstructedBalanceType" +
                   "|DispOfFractionsInd|DispOfFractionsIndDtaSrcSchme|RenounceEntitlementInd|RenounceEntitlementIndDtaSrcSchme|MarketPriceAmountType|TagsNotRecognizedSeqC";
		}

		public override string ToString()
		{
            return SecTickerIntrmediate + "|" + SecDescrptionIntrmediate + "|" + SecurityQuantity + "|" + QuantitySecurityUnderlying + "|" + QuantitySecurityRight + "|" +
                   MarketPrice + "|" + MarketPriceCurrency + "|" + ExpiryDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ExpiryDateDtaSrcSchme + "|" + PostingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PostingDateDtaSrcSchme + "|" +
                   TradingPeriodStart.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + TradingPeriodEnd.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + SecISINIntrmediate + "|" + SecCntryCodeIntrmediate + "|" +
                   SecurityQuantityTypeCode + "|" + BalanceInstructed + "|" + BalanceInstructedQuantityType + "|" + BalanceInstructedDtaSrcSchme + "|" + BalanceInstructedBalanceType + "|" +
                   BalanceUninstructed + "|" + BalanceUninstructedQuantityType + "|" + BalanceUninstructedDtaSrcSchme + "|" + BalanceUninstructedBalanceType + "|" +
                   DispOfFractionsInd + "|" + DispOfFractionsIndDtaSrcSchme + "|" + RenounceEntitlementInd + "|" + RenounceEntitlementIndDtaSrcSchme + "|" + MarketPriceAmountType + "|" + _TagsNotRecognized;
		}

        public override void SequenceTagOverflowProcess(string sequenceName, string tag, string qualifier, bool placeHolderOnly)
        {
            //Create Placeholder for qualifier
            base.SeqTagOverflowBase(new SequenceTagOverflow(sequenceName, tag, qualifier), true);
        }
	}
}