﻿using System;
using System.Reflection;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Ftse.Research.Framework.IO;
using FTSE.MT564CAParser.FileManager;
using Ftse.Research.Framework.Logging;
using log4net;

namespace FTSE.MT564CAParser.Main
{
	class Program
	{
		private static string _fileName;
		private static string _sourcedirectoryName;
		private static string _outputDirectoryName;
		private static bool _isVerboseOutput;
		private static bool _isIgnoreFailure;
        private static ArgumentParser _argumentsParser;

        private static readonly ILog Logger = LogProvider.GetLogger();

		static int Main(string[] args)
		{
            try
            {

              
                if (!Initialize(args))
                {
                    UsageInfo();
                    return 0;
                }

                string sourcePath;
                List<FileInfo> filesCollection;
                if (!String.IsNullOrEmpty(_fileName))
                {
                    var file = new FileInfo(_fileName);
                    filesCollection = new List<FileInfo> { file };
                    sourcePath = file.DirectoryName;
                }
                else
                {
                    var directoryInfo = new DirectoryInfo(_sourcedirectoryName);
                    filesCollection = directoryInfo.EnumerateFiles("*.txt", SearchOption.TopDirectoryOnly).ToList();
                    sourcePath = directoryInfo.FullName;
                }
                DirectoryInfo targetDirectory = !String.IsNullOrEmpty(_outputDirectoryName) ? new DirectoryInfo(_outputDirectoryName) : new DirectoryInfo(sourcePath);

                Assembly assembly = Assembly.GetExecutingAssembly();
                Logger.Info("**************************************************************");
                Logger.Info("Title: " + ((AssemblyTitleAttribute)assembly.GetCustomAttributes(typeof(AssemblyTitleAttribute), false)[0]).Title);
                Logger.Info("Company: " + ((AssemblyCompanyAttribute)assembly.GetCustomAttributes(typeof(AssemblyCompanyAttribute), false)[0]).Company);
                Logger.Info("Product: " + ((AssemblyProductAttribute)assembly.GetCustomAttributes(typeof(AssemblyProductAttribute), false)[0]).Product);
                Logger.Info("Copyright: " + ((AssemblyCopyrightAttribute)assembly.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false)[0]).Copyright);
                Logger.Info("File Version: " + ((AssemblyFileVersionAttribute)assembly.GetCustomAttributes(typeof(AssemblyFileVersionAttribute), false)[0]).Version);

                Logger.Info("");
                Logger.Info("Arguments START:");
                foreach (var subsA in from r in args select r)
                    Logger.Info(subsA.ToString());
                Logger.Info("Arguments END:");
                Logger.Info("**************************************************************");
                Logger.Info("**************************************************************");


                foreach (var file in filesCollection)
                {

                    Logger.Info(String.Format("Parsing file {0}  ...", file.FullName));
                   
                    var swiftMessageFile = new SwiftMessage564File (_isIgnoreFailure, _argumentsParser);

                    swiftMessageFile.ParseFile(file.FullName, _isVerboseOutput, targetDirectory.FullName);

                    Logger.Info(String.Format("Parsing COMPLETED: valid messages: {0}, invalid: {1}, messages with warnings: {2}", swiftMessageFile.MessagesCount, swiftMessageFile.MessagesBadCount, swiftMessageFile.MessagesWithWarningsCount));

                    Logger.Info(String.Format("Writing output files to {0}...", targetDirectory));
                    swiftMessageFile.WriteFiles(targetDirectory.FullName, file.FullName);
                    Logger.Info(String.Format("Parsing of file {0} COMPLETE", file.FullName)); 
                }

                return 0;
            }
            catch (Exception ex)
            {
                String errorMessages = "";
                String stackTrace = "";

                Logger.Error("Error Start");
                Logger.Error(ex.Message);

                stackTrace = ex.StackTrace;
                //Loop for Inner Exceptions
                Exception innerEx = ex.InnerException;
                while (!(innerEx == null))
                {
                    errorMessages += innerEx.Message;
                    stackTrace = innerEx.StackTrace;
                    innerEx = innerEx.InnerException;
                }

                errorMessages += stackTrace;
                Logger.Error(errorMessages);
                Logger.Error("Error End");

                return -1;
            }
		}

		/// <summary>
		/// Reads command line arguments
		/// </summary>
		/// <param name="args"></param>
		/// <returns></returns>
		private static bool Initialize(string[] args)
		{
			// Return false if -? help requested
			if (args.Length > 0 && (args[0] == "-?" || args[0] == "/?"))
				return false;

			
            _argumentsParser = new ArgumentParser(args);
			foreach (var entry in _argumentsParser.Parameters)
				switch (entry.Key)
				{
					case "file": _fileName = entry.Value;
						break;
					case "dir":
					case "directory": _sourcedirectoryName = entry.Value;
						break;
					case "output": _outputDirectoryName = entry.Value;
						break;
                   	case "v": _isVerboseOutput = true;
						break;
					case "ignorefailure": _isIgnoreFailure = true;
						break;
				}

            
            //Default Vendor if required
            //if (!( _argumentsParser.Parameters.ContainsKey("vendor")))
            //        _argumentsParser.Parameters.Add("vendor", "DEFAULT");
            
            return (!String.IsNullOrWhiteSpace(_fileName) || !String.IsNullOrWhiteSpace(_sourcedirectoryName))
                && ( _argumentsParser.Parameters["vendor"] == "IDC");
		}

		/// <summary>
		/// Write usage info to the console
		/// </summary>
		private static void UsageInfo()
		{
			Console.WriteLine();
            Console.WriteLine("FTSE SWIFT MT564 Messages (Corporate Actions) Copyright. © - {0:yyyy}", DateTime.Now);
			Console.WriteLine("Parses files with messages adhering to the SWIFT ISO 15022 MT564 and outputs delimited files.");
			Console.WriteLine("Usage: caparser.exe (-file ShortFileName | -directory path) [-output path] -vendor vendorname\r\n");

			Console.WriteLine("-file fullfilename\n\t\tparses and converts a single file");
			Console.WriteLine("-dir path\n\t\tparses all text files in directory");
			Console.WriteLine("-output path\n\t\tOptional parameter specifying output directory.");
            Console.WriteLine("\t\tIf -output is not specified the output files go to the source directory.");
			Console.WriteLine("-v\n\t\tSpecifies that full message information is output while parsing.");
			Console.WriteLine("-ignorefailure\n\t\tAllows to ignore some expections in messages and parse the rest successfully. Any unrecognized messages will be placed in .bad file(s).");
            Console.WriteLine("-vendor\n\t\tVendor whose file is to be processed. There may be vendor specific processing.");
            Console.WriteLine("\t\tValid values IDC");
		}
	}
}