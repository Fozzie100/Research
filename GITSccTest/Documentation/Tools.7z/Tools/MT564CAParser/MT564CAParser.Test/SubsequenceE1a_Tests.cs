﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class SubsequenceE1a_Tests
	{
		[TestMethod]
		public void Can_ParseField_94B()
		{
			var subsequenceE1A = new SubsequenceE1("", "", 0, 0);
			string input = "PLIS//EXCH/XNYS";
			subsequenceE1A.FIParseField94B("94B", input);

			Assert.AreEqual("EXCH", subsequenceE1A.PlaceListingType);
			Assert.AreEqual("XNYS", subsequenceE1A.PlaceListing);
		}

		[TestMethod]
		public void Can_ParseField_22F()
		{
			var subsequenceE1A = new SubsequenceE1("", "", 0, 0);
			string input = "MICO//A001";
			subsequenceE1A.FIParseField22F("22F", input);

			Assert.AreEqual("A001", subsequenceE1A.MICO);
		}

		[TestMethod]
		public void Can_ParseField12A()
		{
			var subsequenceE1A = new SubsequenceE1("", "", 0, 0);
			string input = "CLAS//ESVUFA";
			subsequenceE1A.FIParseField12A("12C", input);
            subsequenceE1A.FIParseField12A("12B", "OPST/DSCH/XYSQ");

			Assert.IsNull(subsequenceE1A.InstrClassificationDtaSrcSchme);
			Assert.AreEqual("ESVUFA", subsequenceE1A.InstrClassification);

            Assert.AreEqual("XYSQ", subsequenceE1A.InstrOptionStyle);
            Assert.AreEqual("DSCH", subsequenceE1A.InstrOptionStyleDtaSrcSchme);
		}

		[TestMethod]
		public void Can_ParseField11A()
		{
			var subsequenceE1A = new SubsequenceE1("", "", 0, 0);
			string input = "DENO//BGL";
			subsequenceE1A.FIParseField11A("11A", input);

			Assert.AreEqual("BGL", subsequenceE1A.InstrCurrency);
		}

		//[TestMethod]
		//public void Can_ParseField98A()
		//{
		//    var subsequenceE1A = new SubsequenceE1a();
		//    string input = "COUP//20120315";
		//    subsequenceE1A.FIParseField98A(input);

		//    Assert.AreEqual("COUP", subsequenceE1A.DateType);
		//    Assert.AreEqual(DateTime.ParseExact("20120315", "yyyyMMdd", CultureInfo.InvariantCulture), subsequenceE1A.Date);
		//}

		[TestMethod]
		public void Can_ParseField90A()
		{
			var subsequenceE1A = new SubsequenceE1("", "", 0, 0);

			// Option A
			string input = "ISSU//DISC/123456789,";
			subsequenceE1A.FIParseField90A("90A", input);

			Assert.AreEqual("DISC", subsequenceE1A.InstrIssuPricePercType);
			Assert.AreEqual(123456789m, subsequenceE1A.InstrIssuPrice);
			

			// Option B:	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
			input = "ISSU//ACTU/EUR4,5";
			subsequenceE1A = new SubsequenceE1("", "", 0, 0);
			subsequenceE1A.FIParseField90A("90B", input);
			Assert.AreEqual("ACTU", subsequenceE1A.InstrIssuPriceAmtType);
			Assert.AreEqual("EUR", subsequenceE1A.InstrIssuPriceCcy);
            Assert.AreEqual(4.5m, subsequenceE1A.InstrIssuPrice);


			// Option E
			input = "ISSU//UKWN";
			subsequenceE1A = new SubsequenceE1("", "", 0, 0);
			subsequenceE1A.FIParseField90A("90E", input);
            Assert.IsNull(subsequenceE1A.InstrIssuPrice);
            Assert.IsNull(subsequenceE1A.InstrIssuPriceCcy);
            Assert.IsNull(subsequenceE1A.InstrIssuPriceAmtType);
            Assert.IsNull(subsequenceE1A.InstrIssuPricePercType);
		}

		// Rate
		[TestMethod]
		public void Can_ParseField92A()
		{
			var subsequenceE1A = new SubsequenceE1("", "", 0, 0);

			// Option A
			string input = "INTR//N45,";
			subsequenceE1A.FIParseField92A("92A", input);
            input = "NXRT//1,234";
            subsequenceE1A.FIParseField92A("92A", input);
            input = "PRFC//UKWN";
            subsequenceE1A.FIParseField92A("92A", input);
            Assert.AreEqual(1.234m, subsequenceE1A.InstrRateInterestNext);
		    Assert.AreEqual(-45m, subsequenceE1A.InstrRateInterest);
            Assert.IsNull(subsequenceE1A.InstrRatePreviousFactor);

			// Option K
			input = "PRFC//UKWN";
			subsequenceE1A = new SubsequenceE1("", "", 0, 0);
			subsequenceE1A.FIParseField92A("92K",input);
            Assert.IsNull(subsequenceE1A.InstrRateInterest);
            Assert.IsNull(subsequenceE1A.InstrRateInterestNext);
            Assert.IsNull(subsequenceE1A.InstrRateNextFactor);
            Assert.IsNull(subsequenceE1A.InstrRatePreviousFactor);
		}

		[TestMethod]
		public void Can_ParseField36B()
		{
			var subsequenceE1A = new SubsequenceE1("", "", 0, 0);

			// Option B
			string input = "MINO//AMOR/3,";
			subsequenceE1A.FIParseField36B("36B", input);

            Assert.AreEqual("AMOR", subsequenceE1A.InstrMinNomQuantityType);
			Assert.AreEqual(3m, subsequenceE1A.InstrMinNomQuantity);

			// There are other properties  / cases
		}
	}
}