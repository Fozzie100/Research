﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;
using Ftse.Research.Framework.IO;

namespace capParserTest
{
	[TestClass]
	public class SwiftMessage564Test
	{ 
		[TestMethod]
		public void TestMethod1()
		{


            //-file C:\zDataFiles\IDC\a06l55\20140519.srvx -output C:\zDataFiles\IDC\output -vendor IDC

            string[] args = new[] {"-file", "dummyfilename", "-output", "dummyouput", "-vendor", "IDC"};
            ArgumentParser _args;
            _args = new ArgumentParser(args);
            Options.GetOptions().OptionsInit(_args);

            //List<string> lines = new List<string> {"${1:F01XLONGB2LASMD1234123456}{2:I564XXXXXXXX0XXXXN}{4:", 
            //    ":16R:GENL", 
            //    ":20C::CORP//600049278", 
            //    "/GUARANTY TRUST BANK/GDR",
            //    ":20C::SEME//LSE60026", 
            //    ":23G:REPL", 
            //    ":22F::CAEV//DVCA", 
            //    ":22F::CAMV//MAND",
            //    ":98C::PREP//20120328082703",
            //    ":25D::PROC//PREC",
            //    ":16R:LINK",
            //    ":22F::LINK//INFO",
            //    ":13A::LINK//564",
            //    ":20C::PREV//LSE60016",
            //    ":16S:LINK",
            //    ":16S:GENL"
            //};

            List<string> lines = new List<string>{"{1:F01FTIRGB2LAXXX0000000000}{2:I564XXXXXXXX0XXXXN}{4:",
":16R:GENL",
":20C::CORP//2000000041406912",
":20C::SEME//2000000000345783",
":23G:NEWM",
":22F::CAEP//REOR",
":22F::CAEV//PARI",
":22F::CAMV//MAND",
":25D::PROC//COMP",
":16S:GENL",
":16R:USECU",
":35B:/GB/BL25K65",
"SYCOM PROPERTY FD ",
"NPV (SYCOM RECEIPTS)",       
":16R:FIA",
":94B::PLIS//EXCH/XJSE",
":16S:FIA",
":16R:ACCTINFO",
":97A::SAFE//NONREF",
":16S:ACCTINFO",
":16S:USECU",
":16R:CADETL",
":98A::RDTE//20140620",
":16S:CADETL",
":16R:CAOPTN",
":13A::CAON//001",
":22F::CAOP//SECU",
":17B::DFLT//Y",
":16R:SECMOVE",
":22H::CRDB//CRED",
":35B:/GB/6517441",
"ACUCAP PROPERTIES", 
"LKD UNT(ORDZAR0.001&DEBZAR9",
":16R:FIA",
":94B::PLIS//EXCH/XJSE",
":16S:FIA",
":92D::NEWO//1,/1,",
":98A::PAYD//20140623",
":98A::PPDT//20140623",
":16S:SECMOVE",
":16S:CAOPTN",
"-}$"};

            //Get Settings
            var filedummy = new SwiftMessage564File(false, _args);
			var message = new SwiftMessage564(lines, "DummyFileName");
			message.Parse();
           
		}
	}
}
