﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using FTSE.MT564CAParser.FileManager;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace capParserTest
{
	[TestClass]
	public class SubsequenceB2_Tests
	{
		//Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
		// Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)
		[TestMethod]
		public void Can_ParseField93A()
		{
			// Option B
			string input = "ELIG//FAMT/N12,9";
			var subsequenceB2 = new SubsequenceB2();
			subsequenceB2.ParseField93A("93B", input);

			Assert.AreEqual("FAMT", subsequenceB2.BalanceTotalEligibleQtyType);
            Assert.AreEqual(-12.9m, subsequenceB2.BalanceTotalEligible);
            Assert.AreEqual(null, subsequenceB2.BalanceTotalEligibleDtaSrcSchme);
            Assert.AreEqual(null, subsequenceB2.BalanceTotalEligibleBalType);

            // Option B with Data Source Scheme
            subsequenceB2 = new SubsequenceB2();
            input = "PENR/DSC/AMOR/15,4";
            subsequenceB2.ParseField93A("93B", input);

            Assert.AreEqual("AMOR", subsequenceB2.BalancePendingReceiptQtyType);
            Assert.AreEqual(15.4m, subsequenceB2.BalancePendingReceipt);
            Assert.AreEqual("DSC", subsequenceB2.BalancePendingReceiptDtaSrcSchme);
            Assert.AreEqual(null, subsequenceB2.BalancePendingReceiptBalType);

			// Option C
            subsequenceB2 = new SubsequenceB2();
			input = "PEND//FAMT/ELIG/12,4";
			subsequenceB2.ParseField93A("93C", input);

            Assert.AreEqual("FAMT", subsequenceB2.BalancePendingDeliveryQtyType);
			Assert.AreEqual(12.4m, subsequenceB2.BalancePendingDelivery);
            Assert.AreEqual("ELIG", subsequenceB2.BalancePendingDeliveryBalType);
            Assert.AreEqual(null, subsequenceB2.BalanceTotalEligibleDtaSrcSchme);
		}

        [TestMethod]
        public void Can_ParseField94A()
        {
            // Option B no data source
            string input = "SAFE//ALLP/SOME NARRATIVE";
            var subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField94A("94B", input);

            Assert.AreEqual("ALLP", subsequenceB2.SafeKeepingPlaceCode);
            Assert.AreEqual("SOME NARRATIVE", subsequenceB2.SafeKeepingPlaceNarrative);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceDtaSrcSchme);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceCntryCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceIdentCode);

            input = "SAFE//SHHE";
            subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField94A("94B", input);

            Assert.AreEqual("SHHE", subsequenceB2.SafeKeepingPlaceCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceNarrative);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceDtaSrcSchme);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceCntryCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceIdentCode);

            //Option B with Data Source
            input = "SAFE/DSD/SHHE";
            subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField94A("94B", input);

            Assert.AreEqual("SHHE", subsequenceB2.SafeKeepingPlaceCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceNarrative);
            Assert.AreEqual("DSD", subsequenceB2.SafeKeepingPlaceDtaSrcSchme);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceCntryCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceIdentCode);

            input = "SAFE/DSD/XYZ1/NARRATIVE 2";
            subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField94A("94B", input);

            Assert.AreEqual("XYZ1", subsequenceB2.SafeKeepingPlaceCode);
            Assert.AreEqual("NARRATIVE 2", subsequenceB2.SafeKeepingPlaceNarrative);
            Assert.AreEqual("DSD", subsequenceB2.SafeKeepingPlaceDtaSrcSchme);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceCntryCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceIdentCode);

            //Option C
            input = "SAFE//GB";
            subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField94A("94C", input);

            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceNarrative);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceDtaSrcSchme);
            Assert.AreEqual("GB", subsequenceB2.SafeKeepingPlaceCntryCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceIdentCode);


            //Option F
            input = "SAFE//ALLP/BICCOX34S12";
            subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField94A("94F", input);

            Assert.AreEqual("ALLP", subsequenceB2.SafeKeepingPlaceCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceNarrative);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceDtaSrcSchme);
            Assert.AreEqual("BICCOX34S12", subsequenceB2.SafeKeepingPlaceIdentCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceCntryCode);



            input = "SAFE//SHHE/BICCOD3X";
            subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField94A("94F", input);

            Assert.AreEqual("SHHE", subsequenceB2.SafeKeepingPlaceCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceNarrative);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceDtaSrcSchme);
            Assert.AreEqual("BICCOD3X", subsequenceB2.SafeKeepingPlaceIdentCode);
            Assert.AreEqual(null, subsequenceB2.SafeKeepingPlaceCntryCode);

        }

        [TestMethod]
        public void Can_ParseField95A()
        {
            // Option P no data source scheme
            string input = "ACOW//ACC123456";
            var subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField95A("95P", input);

            Assert.AreEqual("ACC123456", subsequenceB2.AccountOwner);
            Assert.AreEqual(null, subsequenceB2.AccountOwnerDtaSrcSchme);


            input = "ACOW/DSD/ACC123999";
            subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField95A("95R", input);

            Assert.AreEqual("ACC123999", subsequenceB2.AccountOwner);
            Assert.AreEqual("DSD", subsequenceB2.AccountOwnerDtaSrcSchme);
          
        }


        [TestMethod]
        public void Can_ParseField97A()
        {
            // Option P no data source scheme
            string input = "SAFE//ACC888456";
            var subsequenceB2 = new SubsequenceB2();
            subsequenceB2.ParseField97A("97A", input);

            Assert.AreEqual("ACC888456", subsequenceB2.SafeKeepingAccount);
         

           

        }
	}
}