﻿using System;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class SequenceC_Tests
	{
		[TestMethod]
		public void Can_ParseField36A_Negative()
		{
			const string input = "QINT//UNIT/N1234546543,"; // 4!c//4!c/[N]15d

			var sequenceC = new SequenceC();
			sequenceC.ParseField36A("36E", input);

			Assert.AreEqual(-1234546543.0M, sequenceC.SecurityQuantity);
		}

		[TestMethod]
		public void Can_ParseField36A_Positive()
		{
			const string input = "QINT//UNIT/1234546543,"; // 4!c//4!c/15d

			var sequenceC = new SequenceC();
			sequenceC.ParseField36A("36B", input);

			Assert.AreEqual(1234546543.0M, sequenceC.SecurityQuantity);
		}

		[TestMethod]
		public void Can_ParseField22F_NoDataSourceScheme()
		{
			string input = "DISF//RDDN"; // 4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)

			var sequenceC = new SequenceC();
			sequenceC.ParseField22F("22F", input);

			Assert.AreEqual(null, sequenceC.DispOfFractionsIndDtaSrcSchme);
			Assert.AreEqual("RDDN", sequenceC.DispOfFractionsInd);

            input = "SELL//RENO";
            sequenceC = new SequenceC();
            sequenceC.ParseField22F("22F", input);
            Assert.AreEqual(null, sequenceC.RenounceEntitlementIndDtaSrcSchme);
            Assert.AreEqual("RENO", sequenceC.RenounceEntitlementInd);

		}

		[TestMethod]
		public void Can_ParseField22F_WithDataSourceScheme()
		{
			string input = "DISF/ABCDEFGH/STAN"; // 4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)

			var sequenceC = new SequenceC();
            sequenceC.ParseField22F("22F", input);
            Assert.AreEqual("ABCDEFGH", sequenceC.DispOfFractionsIndDtaSrcSchme);
            Assert.AreEqual("STAN", sequenceC.DispOfFractionsInd);

            input = "SELL/DSC/NREN";
            sequenceC = new SequenceC();
            sequenceC.ParseField22F("22F", input);
            Assert.AreEqual("DSC", sequenceC.RenounceEntitlementIndDtaSrcSchme);
            Assert.AreEqual("NREN", sequenceC.RenounceEntitlementInd);
		}
       

		[TestMethod]
		public void Can_ParseField90B()
		{
			const string input = "MRKT//ACTU/USD3,";
			
			var sequenceC = new SequenceC();
			sequenceC.ParseField90B("90B", input);

			Assert.AreEqual(3M, sequenceC.MarketPrice);
			Assert.AreEqual("USD", sequenceC.MarketPriceCurrency);
            Assert.AreEqual("ACTU", sequenceC.MarketPriceAmountType);
		}

		[TestMethod]
		public void Can_ParseField98A()
		{
			var sequenceC = new SequenceC();
			string input = "EXPI//20120302";
			sequenceC.ParseField98A("98A", input);

			Assert.AreEqual(DateTime.ParseExact("20120302", "yyyyMMdd", CultureInfo.InvariantCulture), sequenceC.ExpiryDate);

			input = "POST/SMTH/ONGO";
			sequenceC.ParseField98A("98B", input);

			Assert.AreEqual(null, sequenceC.PostingDate);
		}

		[TestMethod]
		public void Can_ParseField93A()
		{
			var sequenceC = new SequenceC();
			//Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
			string input = "UNBA/ABCEDFGH/AMOR/N12,3";
			sequenceC.ParseField93A("93B", input);

			Assert.AreEqual(-12.3m, sequenceC.BalanceUninstructed);
            Assert.AreEqual("ABCEDFGH", sequenceC.BalanceUninstructedDtaSrcSchme);
            Assert.AreEqual("AMOR", sequenceC.BalanceUninstructedQuantityType);

            input = "INBA//UNIT/94,35";
            sequenceC.ParseField93A("93C",input);
            Assert.AreEqual(94.35m, sequenceC.BalanceInstructed);
            Assert.AreEqual("UNIT", sequenceC.BalanceInstructedQuantityType);
            Assert.AreEqual(null, sequenceC.BalanceInstructedBalanceType);


			// Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)
			input = "INBA//FAMT/ELIG/N47,5";
            sequenceC = new SequenceC();
			sequenceC.ParseField93A("93C", input);

            Assert.AreEqual(-47.5m, sequenceC.BalanceInstructed);
            Assert.AreEqual("FAMT", sequenceC.BalanceInstructedQuantityType);
            Assert.AreEqual("ELIG", sequenceC.BalanceInstructedBalanceType);
		}

		[TestMethod]
		public void Can_ParseField69A()
		{
			var sequenceC = new SequenceC();

			// Option A
			string input = "TRDP//20120419/20120420";
			sequenceC.ParseField69A("69A", input);
			Assert.AreEqual(DateTime.ParseExact("20120419", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120420", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);

			// Option B
			input = "TRDP//20120419120000/20120420120000";
            sequenceC.ParseField69A("69B", input);
			Assert.AreEqual(DateTime.ParseExact("20120419120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120420120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);

			// Option C
			input = "TRDP//20120419/ONGO";
            sequenceC.ParseField69A("69C", input);
			Assert.AreEqual(DateTime.ParseExact("20120419", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(null, sequenceC.TradingPeriodEnd);

			// Option D
			input = "TRDP//20120419120000/ONGO";
            sequenceC.ParseField69A("69D", input);
			Assert.AreEqual(DateTime.ParseExact("20120419120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(null, sequenceC.TradingPeriodEnd);

			// Option E
			input = "TRDP//ONGO/20120419";
            sequenceC.ParseField69A("69E", input);
			Assert.AreEqual(null, sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120419", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);

			// Option F
			input = "TRDP//ONGO/20120419120000";
            sequenceC.ParseField69A("69F", input);
			Assert.AreEqual(null, sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120419120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);
		}
	}
}