﻿using System;
using System.Globalization;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class SequenceB_Tests
	{
        [TestMethod]
        public void Can_ParseField98A()
        {
            var sequenceB = new SequenceB();
            string input = "CALD//20131123";
            sequenceB.ParseField98A("98A", input);

            Assert.AreEqual(DateTime.ParseExact("20131123", "yyyyMMdd", CultureInfo.InvariantCulture), sequenceB.CallDate);

            input = "PUTT//20120507";
            sequenceB.ParseField98A("98A", input);
            Assert.AreEqual(DateTime.ParseExact("20120507", "yyyyMMdd", CultureInfo.InvariantCulture), sequenceB.PutDate);

            input = "ISXX//20130917";
            sequenceB.ParseField98A("98A", input);
            Assert.AreEqual(":::SequenceB:98A::ISXX//20130917", sequenceB._TagsNotRecognized);


        }
        [TestMethod]
        public void Can_ParseField11A()
        {
            var sequenceB = new SequenceB();
            string input = "DENO//USD";
            sequenceB.ParseField11A("11A", input);

            Assert.AreEqual("USD", sequenceB.CcyDenomination);

            input = "DXXX//AUD";
            sequenceB.ParseField11A("11A", input);

            Assert.AreEqual(":::SequenceB:11A::DXXX//AUD", sequenceB._TagsNotRecognized);


        }
		[TestMethod]
		public void Can_ParseField36B()
		{
			var sequenceB = new SequenceB();
			string input = "MINO//FAMT/12,4";
			sequenceB.ParseField36B("36B", input);

            Assert.AreEqual("FAMT", sequenceB.InstrMinimumNominalQuantityType);
			Assert.AreEqual(12.4m, sequenceB.InstrMinimumNominalQuantity);

			input = "SIZE//AMOR/12,5";
			sequenceB.ParseField36B("36B", input);

			Assert.AreEqual(12.5m, sequenceB.InstrContractSize);
            Assert.AreEqual("AMOR", sequenceB.InstrContractSizeType);

            input = "MIXX//AMOR/12,5";
            sequenceB.ParseField36B("36B", input);

            Assert.AreEqual(":::SequenceB:36B::MIXX//AMOR/12,5", sequenceB._TagsNotRecognized);


            


		}

        [TestMethod]
        public void Can_ParseField22F()
        {
            var sequenceB2 = new SequenceB();
            string input2 = "MICO/DSSCHEME/B002";
            sequenceB2.ParseField22F("22F", input2);
            Assert.AreEqual("B002", sequenceB2.MICO);
            Assert.AreEqual("DSSCHEME", sequenceB2.MICODtaSrcSchme);

            sequenceB2 = new SequenceB();
            input2 = "MICO//A002";
            sequenceB2.ParseField22F("22F", input2);
            Assert.AreEqual("A002", sequenceB2.MICO);
            Assert.AreEqual(null, sequenceB2.MICODtaSrcSchme);

        }


        [TestMethod]
        public void Can_ParseField12A()
        {
            var sequenceB3 = new SequenceB();
            string input2 = "CLAS//A005";
            sequenceB3.ParseField12A("12B", input2);
            Assert.AreEqual("A005", sequenceB3.FIClassification);
            Assert.AreEqual(null, sequenceB3.FIClassificationDtaSrcSchme);

            sequenceB3 = new SequenceB();
            input2 = "CLAS/DSCHEMEZ/EV99";
            sequenceB3.ParseField12A("12B", input2);
            Assert.AreEqual("EV99", sequenceB3.FIClassification);
            Assert.AreEqual("DSCHEMEZ", sequenceB3.FIClassificationDtaSrcSchme);

            sequenceB3 = new SequenceB();
            input2 = "OPST//AMER12";
            sequenceB3.ParseField12A("12C", input2);
            Assert.AreEqual("AMER12", sequenceB3.OptionStyle);
            Assert.AreEqual(null, sequenceB3.OptionStyleDtaSrcSchme);

          

        }

        [TestMethod]
        public void Can_ParseField92A()
        {
            var sequenceB3 = new SequenceB();
            string input2 = "WAPA//5,34/8,21";
            sequenceB3.ParseField92A("92D", input2);
            Assert.AreEqual((decimal)5.34, sequenceB3.InstrWarrantParityQuantity1);
            Assert.AreEqual((decimal)8.21, sequenceB3.InstrWarrantParityQuantity2);


            sequenceB3 = new SequenceB();
            input2 = "INTR//2,";
            sequenceB3.ParseField92A("92A", input2);
            Assert.AreEqual((decimal)2, sequenceB3.InstrInterestRate);


            input2 = "NWFC//UKWN";
            sequenceB3.ParseField92A("92K", input2);
            Assert.AreEqual(null, sequenceB3.InstrNextFactor);

            input2 = "DXXX//N3,56";
            sequenceB3.ParseField92A("92A", input2);
            Assert.AreEqual(":::SequenceB:92A::DXXX//N3,56", sequenceB3._TagsNotRecognized);
            
        }


       
	}
}
