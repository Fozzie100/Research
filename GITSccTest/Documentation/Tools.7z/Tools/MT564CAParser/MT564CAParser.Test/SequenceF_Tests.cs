﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class SequenceF_Tests
	{
		[TestMethod]
		public void Can_ParseField95A_OptionPQ()
		{
			// Option P	:4!c//4!a2!a2!c[3!c]	(Qualifier)(Identifier Code)
			// Option Q	:4!c//4*35x	(Qualifier)(Name and Address)
			// Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)
			const string input = "REGR//FGTRTYGHERTRGH";
            const string code = "95Q";
			var sequenceF = new SequenceF();
            sequenceF.ParseField95A(code, input);

            sequenceF.ParseField95A("95P", "RESA//ABCDUS99XXXX");
            sequenceF.ParseField95A("95P", "DROP//ZQWEGB88");

			Assert.AreEqual("FGTRTYGHERTRGH", sequenceF.PartyRegistrar);
			Assert.IsNull( sequenceF.PartyRegistrarDtaSrcSchme);
            Assert.AreEqual("Name", sequenceF.PartyRegistrarType);


            Assert.AreEqual("ABCDUS99XXXX", sequenceF.PartyResellingAgnt);
            Assert.IsNull(sequenceF.PartyResellingAgntDtaSrcSchme);
            Assert.AreEqual("BIC", sequenceF.PartyResellingAgntType);

            Assert.AreEqual("ZQWEGB88", sequenceF.PartyDropAgnt);
            Assert.IsNull(sequenceF.PartyDropAgntDtaSrcSchme);
            Assert.AreEqual("BIC", sequenceF.PartyResellingAgntType);
		}

		[TestMethod]
		public void Can_ParseField95A_OptionR()
		{
			// Option P	:4!c//4!a2!a2!c[3!c]	(Qualifier)(Identifier Code)
			// Option Q	:4!c//4*35x	(Qualifier)(Name and Address)
			// Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)

			const string input = "PAYA/ABCERDFG/azxcvbnmzxcvbnmzxcvbnmzxcvbnmnbvcx";
			var sequenceF = new SequenceF();
			sequenceF.ParseField95A("95R", input);

            sequenceF.ParseField95A("95R", "PSAG/DTASRC99/DFDTYTYT565987955FDSEW");

			Assert.AreEqual("azxcvbnmzxcvbnmzxcvbnmzxcvbnmnbvcx", sequenceF.PartyPayngAgnt);
            Assert.AreEqual("ABCERDFG", sequenceF.PartyPayngAgntDtaSrcSchme);
            Assert.AreEqual("Proprietary", sequenceF.PartyPayngAgntType);

            Assert.AreEqual("DFDTYTYT565987955FDSEW", sequenceF.PartyPhysicalSecsAgnt);
            Assert.AreEqual("DTASRC99", sequenceF.PartyPhysicalSecsAgntDtaSrcSchme);
            Assert.AreEqual("Proprietary", sequenceF.PartyPhysicalSecsAgntType);
		}
	}
}