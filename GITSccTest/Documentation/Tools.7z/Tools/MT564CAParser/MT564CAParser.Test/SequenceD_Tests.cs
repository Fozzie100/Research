﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Globalization;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class SequenceD_Tests
	{
		///			Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///			Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///			Option E	:4!c//4!c	(Qualifier)(Price Code)
		
		[TestMethod]
		public void Can_ParseField90A()
		{
			var sequenceD = new SequenceD();

			// Option A
			var input = "MAXP//DISC/12,";
			sequenceD.ParseField90A("90A", input);

			Assert.AreEqual("DISC", sequenceD.PriceMaxPercentType);
			Assert.AreEqual(12m, sequenceD.PriceMax);

			// Option B
			sequenceD = new SequenceD();
			input = "MINP//DISC/EUR12,3";
			sequenceD.ParseField90A("90B", input);

			Assert.AreEqual("DISC", sequenceD.PriceMinAmountType);
			Assert.AreEqual(12.3m, sequenceD.PriceMin);
            Assert.AreEqual("EUR", sequenceD.PriceMinCurrency);

			// Option E
			sequenceD = new SequenceD();
			input = "MINP//UKWN";
			sequenceD.ParseField90A("90E", input);

			Assert.AreEqual(null, sequenceD.PriceMinAmountType);
			Assert.AreEqual(null, sequenceD.PriceMinPercentType);
            Assert.AreEqual(null, sequenceD.PriceMinCurrency);
			Assert.AreEqual(null, sequenceD.PriceMin);
		}

		[TestMethod]
		public void Can_ParseField22F()
		{
			var sequenceD = new SequenceD();
			string input = "DIVI//REGL";

			sequenceD.ParseField22F("22F", input);
	
			Assert.AreEqual("REGL", sequenceD.DividendType);
            Assert.AreEqual(null, sequenceD.DistributionTypeDtaSrcSchme);


			input = "CONV//FINL";
            sequenceD = new SequenceD();
			sequenceD.ParseField22F("22F", input);

			Assert.AreEqual("FINL", sequenceD.ConversionType);
            Assert.AreEqual(null, sequenceD.ConversionTypeDtaSrcSchme);

            Console.WriteLine(sequenceD.ToString());

            input = "ADDB//CAPA";
            //sequenceD = new SequenceD();
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPA;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual(";", sequenceD.AdditionalBusinessProcessDtaSrcSchme);
            input = "ADDB//CNTR";
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPA;CNTR;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual(";;", sequenceD.AdditionalBusinessProcessDtaSrcSchme);


            input = "ADDB/TRU/CAPX";
            sequenceD = new SequenceD();
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPX;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual("TRU;", sequenceD.AdditionalBusinessProcessDtaSrcSchme);
            input = "ADDB/CVR/CNTZ";
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPX;CNTZ;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual("TRU;CVR;", sequenceD.AdditionalBusinessProcessDtaSrcSchme);
             // input = "ADDB/SVR/CNTY";
            input = "ADDB//CNTY";
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPX;CNTZ;CNTY;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual("TRU;CVR;;", sequenceD.AdditionalBusinessProcessDtaSrcSchme);
            input = "ADDB//CNTA";
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPX;CNTZ;CNTY;CNTA;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual("TRU;CVR;;;", sequenceD.AdditionalBusinessProcessDtaSrcSchme);


            input = "ADDB/SDEW/YNTA";
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPX;CNTZ;CNTY;CNTA;YNTA;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual("TRU;CVR;;;SDEW;", sequenceD.AdditionalBusinessProcessDtaSrcSchme);



            input = "ADDB//CAPX";
            sequenceD = new SequenceD();
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPX;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual(";", sequenceD.AdditionalBusinessProcessDtaSrcSchme);

            input = "ADDB/XCD/CAPZ";
            sequenceD.ParseField22F("22F", input);
            Assert.AreEqual("CAPX;CAPZ;", sequenceD.AdditionalBusinessProcess);
            Assert.AreEqual(";XCD;", sequenceD.AdditionalBusinessProcessDtaSrcSchme);
		
		}

		[TestMethod]
		public void Can_ParseField92()
		{
			var sequenceD = new SequenceD();
			string input = "INTR//N15,5";

			sequenceD.ParseField92("92A", input);

			Assert.AreEqual(-15.5m, sequenceD.InterestRate);



			input = "BIDI//EUR12,4";
			sequenceD = new SequenceD();
			sequenceD.ParseField92("92F", input);
            Assert.AreEqual("EUR", sequenceD.BidIntervalRateCcy);
			Assert.AreEqual(12.4m, sequenceD.BidIntervalRateAmt);
            Assert.AreEqual(null, sequenceD.BidIntervalRate);


            input = "BIDI//11,56";
            sequenceD = new SequenceD();
            sequenceD.ParseField92("92A", input);
            Assert.AreEqual(11.56m, sequenceD.BidIntervalRate);




			input = "PTSC//ANYA";
			sequenceD = new SequenceD();
			sequenceD.ParseField92("92K", input);
			Assert.AreEqual(null, sequenceD.PercentageSought);
			Assert.AreEqual("ANYA", sequenceD.PercentageSoughtRateTypeCode);

            input = "RINR//N23,56";
            sequenceD.ParseField92("92A", input);
            Assert.AreEqual(-23.56m, sequenceD.RateRelatedIndex);
		}


        [TestMethod]
        public void Can_ParseField98()
        {
            var sequenceD = new SequenceD();
            string input = "CERT//20141213";

            sequenceD.ParseField98A("98A", input);
            Assert.AreEqual(DateTime.ParseExact("20141213", "yyyyMMdd", CultureInfo.InvariantCulture), sequenceD.CertificationDeadlineDate);

            input = "GUPA//20130506231249";

            sequenceD = new SequenceD();
            sequenceD.ParseField98A("98B", input);
            Assert.AreEqual(DateTime.ParseExact("20130506231249", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), sequenceD.GuaranteedParticipationDate);

            input = "PLDT//20101221170534,123/N0530";
             sequenceD = new SequenceD();
            sequenceD.ParseField98A("98E", input);
            Assert.AreEqual(DateTime.ParseExact("20101221170534,123", "yyyyMMddHHmmss,fff", CultureInfo.InvariantCulture), sequenceD.LeadPlaintiffDeadlineDate);
            Assert.AreEqual("-05:30:00", sequenceD.LeadPlaintiffDeadlineDateUTCOffsetHHmmss);

        }
        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void Can_ParseField98_UTCDate_Throws()
        {
            string input = "MET2//20101221170534,123/N0530";
            var sequenceD = new SequenceD();
            sequenceD.ParseField98A("98E", input);
            Assert.AreEqual(DateTime.ParseExact("20101221170534123 -05:30", "yyyyMMddHHmmssfff zzz", CultureInfo.InvariantCulture), sequenceD.MeetingDate2);
           // Assert.AreEqual("", sequenceD.EarliestPayDateDtaSrcSchme);
        }
        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void Can_ParseField98_OptionBDSC_Throws()
        {
            string input = "RDTE/DSCX/XYXS";
            var sequenceD = new SequenceD();
            sequenceD.ParseField98A("98B", input);

        }
        [TestMethod]
        public void Can_ParseField69()
        {
            var sequenceD = new SequenceD();
            string input = "PRIC//20141213/ONGO";

            sequenceD.ParseField69A("69C", input);
            Assert.AreEqual(DateTime.ParseExact("20141213", "yyyyMMdd", CultureInfo.InvariantCulture), sequenceD.PeriodPriceCalculationStrtDte);
            Assert.AreEqual(null, sequenceD.PeriodPriceCalculationEndDte);

            input = "CODS//20140506081249/20141106222531";

            sequenceD = new SequenceD();
            sequenceD.ParseField69A("69B", input);
            Assert.AreEqual(DateTime.ParseExact("20140506081249", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), sequenceD.PeriodCoDepositoriesSuspStrtDte);
            Assert.AreEqual(DateTime.ParseExact("20141106222531", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), sequenceD.PeriodCoDepositoriesSuspEndDte);



        }
        [TestMethod]
        public void Can_ParseField99A()
        {
            var sequenceD = new SequenceD();
            sequenceD = new SequenceD();
            string input = "DAAC//034";
            sequenceD.ParseField99A("99A", input);
            Assert.AreEqual(34, sequenceD.DaysAccrued);
            
            sequenceD = new SequenceD();
            input = "DAAC//N046";
            sequenceD.ParseField99A("99A", input);
            Assert.AreEqual(-46, sequenceD.DaysAccrued);
           
        }


        [TestMethod]
        public void Can_ParseField36A()
        {
            var sequenceD = new SequenceD();
            string input = "MIEX//XYZB";
            sequenceD.ParseField36A("36C", input);
            Assert.AreEqual(null, sequenceD.FIQtyMinXercisble);
            Assert.AreEqual("XYZB", sequenceD.FIQtyMinXercisbleCodeOrTypeCode);

            sequenceD = new SequenceD();
            input = "NEWD//ABCT/123456,";
            sequenceD.ParseField36A("36B", input);
            Assert.AreEqual(123456m, sequenceD.FIQtyNewDenomination);
            Assert.AreEqual("ABCT", sequenceD.FIQtyNewDenominationCodeOrTypeCode);

            

        }

        [TestMethod]
        public void Can_ParseField13A()
        {
            var sequenceD = new SequenceD();
            string input = "COUP//987";
            sequenceD.ParseField13A("13A", input);
            Assert.AreEqual("987", sequenceD.CouponNumber);
            Assert.AreEqual(null, sequenceD.CouponNumberDtaSrcSchme);

            sequenceD = new SequenceD();
            input = "COUP/DSC/12345699";
            sequenceD.ParseField13A("13B", input);
            Assert.AreEqual("12345699", sequenceD.CouponNumber);
            Assert.AreEqual("DSC", sequenceD.CouponNumberDtaSrcSchme);

        }

        [TestMethod]
        public void Can_ParseField94E()
        {
            var sequenceD = new SequenceD();
           
            string input = "MEET//Meeting 1";
            sequenceD.ParseField94E("94E", input);
            input = "MET2//Meeting 2";
            sequenceD.ParseField94E("94E", input);
            input = "MET3//Meeting 3";
            sequenceD.ParseField94E("94E", input);
            input = "NPLI//New place of incorp";
            sequenceD.ParseField94E("94E", input);



            Assert.AreEqual("Meeting 1", sequenceD.PlaceMeeting);
            Assert.AreEqual("Meeting 2", sequenceD.Place2Meeting);
            Assert.AreEqual("Meeting 3", sequenceD.Place3Meeting);
            Assert.AreEqual("New place of incorp", sequenceD.PlaceofOfIncorporation);
           

        }

        [TestMethod]
        public void Can_ParseField70()
        {
            var sequenceD = new SequenceD();

            string input = "OFFO//Offeror name";
            sequenceD.ParseField70A("70E", input);
            input = "WEBB//Web address1";
            sequenceD.ParseField70A("70G", input);
            input = "NAME//New name";
            sequenceD.ParseField70A("70E", input);

            Assert.AreEqual("Offeror name", sequenceD.NarrativeOfferor);
            Assert.AreEqual("Web address1", sequenceD.NarrativeWebsite);
            Assert.AreEqual("New name", sequenceD.NarrativeNewName);
           
        }
	}
}