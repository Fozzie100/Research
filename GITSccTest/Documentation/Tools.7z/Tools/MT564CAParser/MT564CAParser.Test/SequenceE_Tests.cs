﻿using System;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class SequenceE_Tests
	{

        [TestMethod]
        public void Can_ParseField70E()
        {
            string input = "ADTX//TEXT ADDITIONAL DETAILS TEXT";
            var sequenceE = new SequenceE("", "");
            sequenceE.ParseField70E("70E", input);

           
            Assert.AreEqual("TEXT ADDITIONAL DETAILS TEXT", sequenceE.TextAdditionalDetails);

            input = "CETI//TEXT CertificationBreakdown TEXT LINE1" + "\r" + " LINE2";
            sequenceE = new SequenceE("", "");
            sequenceE.ParseField70E("70E", input);

            Assert.AreEqual("TEXT CertificationBreakdown TEXT LINE1" + "\r" + " LINE2", sequenceE.TextCertificationBreakdown);

        }

		[TestMethod]
		public void Can_ParseField22F()
		{
			string input = "CAOP//SECU";
			var sequenceE = new SequenceE("", "");
			sequenceE.ParseField22("22F", input);

			Assert.AreEqual("SECU", sequenceE.CorpActionOptionCode);
            Assert.AreEqual(null, sequenceE.CorpActionOptionCodeDtaSrcSchme);

			input = "OSTA/XYS/BSPL";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField22("22F", input);
            Assert.AreEqual("BSPL", sequenceE.OptionStatus);
            Assert.AreEqual("XYS", sequenceE.OptionStatusDtaSrcSchme);


            input = "DISF//STAN";
            sequenceE = new SequenceE("", "");
            sequenceE.ParseField22("22F", input);
            Assert.AreEqual("STAN", sequenceE.DispFractionsInd);
            Assert.AreEqual(null, sequenceE.DispFractionsIndDtaSrcSchme);
		}

		[TestMethod]
		public void Can_ParseField92A()
		{
			var sequenceE = new SequenceE("", "");

			// Option A
			string input = "GRSS//N12,3";
			sequenceE.ParseField92A("92A", input);

			Assert.AreEqual(-12.3m, sequenceE.DividendGrossRate);
			Assert.IsNull(sequenceE.DividendGrossRateCcy);
            Assert.IsNull(sequenceE.DividendGrossRateDtaSrcSchme);
            Assert.IsNull(sequenceE.DividendGrossRateRateStatus);
            Assert.IsNull(sequenceE.DividendGrossRateRateTypeCode);
            Assert.IsNull(sequenceE.DividendGrossRateAmt);

			// Option F
			input = "GRSS//BEL12,3";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField92A("92F", input);

			Assert.AreEqual(12.3m, sequenceE.DividendGrossRateAmt);
			Assert.AreEqual("BEL", sequenceE.DividendGrossRateCcy);

			//Option K
			input = "GRSS//UKWN";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField92A("92K", input);

			Assert.IsNull(sequenceE.DividendGrossRate);
            Assert.IsNull(sequenceE.DividendGrossRateCcy);
            Assert.IsNull(sequenceE.DividendGrossRateDtaSrcSchme);
            Assert.IsNull(sequenceE.DividendGrossRateRateStatus);
            Assert.AreEqual("UKWN", sequenceE.DividendGrossRateRateTypeCode);
            Assert.IsNull(sequenceE.DividendGrossRateAmt);
		}

        //[TestMethod]
        //[ExpectedException(typeof(ArgumentOutOfRangeException))]
        //public void ThEx_ParseField92A()
        //{
        //    var sequenceE = new SequenceE("", "");
        //    string input = "GRSS/abcdfgtr/RTEW/BEL12345678987";
        //    sequenceE.ParseField92A(input);
        //}

		[TestMethod]
		public void Can_ParseField90A()
		{
            var sequenceE = new SequenceE("", "");

			// Option A
			string input = "OSUB//DISC/12,3";
			sequenceE.ParseField90A("90A", input);

            Assert.AreEqual(null, sequenceE.OverSubDepositPriceCcy);
            Assert.AreEqual(12.3m, sequenceE.OverSubDepositPrice);
            Assert.AreEqual("DISC", sequenceE.OverSubDepositPricePercType);

			// Option B
			input = "CINL//ACTU/BEL12,4";
            sequenceE = new SequenceE("", "");
			sequenceE.ParseField90A("90B", input);

			Assert.AreEqual("BEL", sequenceE.CashinLieuSharesPriceCcy);
			Assert.AreEqual(12.4m, sequenceE.CashinLieuSharesPrice);
			Assert.AreEqual("ACTU", sequenceE.CashinLieuSharesPriceAmtType);

			// Option E
			input = "OSUB//UKWN";
            sequenceE = new SequenceE("", "");
			sequenceE.ParseField90A("90E", input);

			Assert.AreEqual(null, sequenceE.OverSubDepositPriceCcy);
			Assert.AreEqual(null, sequenceE.OverSubDepositPrice);
			Assert.AreEqual(null, sequenceE.OverSubDepositPriceAmtType);
            Assert.AreEqual(null, sequenceE.OverSubDepositPricePercType);
            Assert.AreEqual(null, sequenceE.CashinLieuSharesPriceCcy);
            Assert.AreEqual(null, sequenceE.CashinLieuSharesPrice);
            Assert.AreEqual(null, sequenceE.CashinLieuSharesPriceAmtType);
            Assert.AreEqual(null, sequenceE.CashinLieuSharesPricePercType);

			// Option B
            input = "OSUB//DISC/CHF4512,967";
            sequenceE = new SequenceE("", "");
			sequenceE.ParseField90A("90B", input);

            Assert.AreEqual("CHF", sequenceE.OverSubDepositPriceCcy);
            Assert.AreEqual(4512.967m, sequenceE.OverSubDepositPrice);
            Assert.AreEqual("DISC", sequenceE.OverSubDepositPriceAmtType);


			// Option J
			// Not implemented
		}

		[TestMethod]
		public void Can_ParseField36A()
		{
            var sequenceE = new SequenceE("", "");

			string input = "MAEX//FAMT/15,2";
			sequenceE.ParseField36A("36B", input);

			//Assert.AreEqual("MAEX", sequenceE.InstrumentQuantityType);
            Assert.AreEqual("FAMT", sequenceE.InstrMaxXercisableQtyCodeOrTypeCode);
            Assert.AreEqual(15.2m, sequenceE.InstrMaxXercisableQty);

			input = "MILT//UNIT";
            sequenceE = new SequenceE("", "");
			sequenceE.ParseField36A("36C", input);

			//Assert.AreEqual("MILT", sequenceE.InstrumentQuantityType);
            Assert.AreEqual("UNIT", sequenceE.InstrMinXercisableMultiQtyCodeOrTypeCode);
            Assert.AreEqual(null, sequenceE.InstrMinXercisableMultiQty);
		}

		[TestMethod]
		public void Can_Parse94C()
		{
            var sequenceE = new SequenceE("", "");
			string input = "NDOM//BE";
			sequenceE.ParseField94C("94C", input);
			Assert.AreEqual("BE", sequenceE.CountryNonDomicile);

			input = "DOMI//GR";
			sequenceE.ParseField94C("94C", input);
			Assert.AreEqual("GR", sequenceE.CountryDomicile);
		}

		[TestMethod]
		public void Can_Parse98A()
		{
            var sequence = new SequenceE("", "");
			string input = "DVCP//20120101";
			sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.DepositoryCoverExpiration);

			input = "EARD//20120101";
            sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.EarlyResponseDeadlineDate);

			input = "EXPI//20120101";
            sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.ExpiryDate);

			input = "MKDT//20120101120000";
            sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101120000", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), sequence.MarketDeadlineDate);

			input = "PODT//20120101";
            sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.ProtectDate);

			input = "SUBS//20120101";
            sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.SubscriptionCostDebit);

			input = "RDDT//20120101";
            sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.ResponseDeadlineDate);

			input = "CVPR//20120101";
            sequence.ParseField98A("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.CoverExpiration);

            input = "MKDT//20101221170533,123/N0420";
            sequence.ParseField98A("98E", input);
            Assert.AreEqual(DateTime.ParseExact("20101221170533,123", "yyyyMMddHHmmss,fff", CultureInfo.InvariantCulture), sequence.MarketDeadlineDate);
            Assert.AreEqual("-04:20:00", sequence.MarketDeadlineDateUTCOffsetHHmmss);


            input = "RDDT//20131221170533,123/0745";
            sequence.ParseField98A("98E", input);
            Assert.AreEqual(DateTime.ParseExact("20131221170533,123", "yyyyMMddHHmmss,fff", CultureInfo.InvariantCulture), sequence.ResponseDeadlineDate);
            Assert.AreEqual("07:45:00", sequence.ResponseDeadlineDateUTCOffsetHHmmss);
		}

        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void Can_ParseField98A_UTCDate1_Throws()
        {
            string input = "CVPR//20101221170534,123/N0530";
            var sequenceE = new SequenceE("","");
            sequenceE.ParseField98A("98E", input);
            //Assert.AreEqual(DateTime.ParseExact("20101221170534123 -05:30", "yyyyMMddHHmmssfff zzz", CultureInfo.InvariantCulture), sequenceD.MeetingDate2);
            // Assert.AreEqual("", sequenceD.EarliestPayDateDtaSrcSchme);
        }
        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void Can_ParseField98A_UTCDate2_Throws()
        {
            string input = "PODT//20101221170534,123/N0530";
            var sequenceE = new SequenceE("", "");
            sequenceE.ParseField98A("98E", input);
            //Assert.AreEqual(DateTime.ParseExact("20101221170534123 -05:30", "yyyyMMddHHmmssfff zzz", CultureInfo.InvariantCulture), sequenceD.MeetingDate2);
            // Assert.AreEqual("", sequenceD.EarliestPayDateDtaSrcSchme);
        }
        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void Can_ParseField98_OptionBDSC_Throws()
        {
            string input = "EXPI/DSCE/XAXS";
            var sequenceE = new SequenceE("", "");
            sequenceE.ParseField98A("98B", input);

        }
	}
}