﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class Sequence_Tests
	{
		[TestMethod]
		public void Can_ParseSEDOL_Entity_35B()
		{
            //DEFAULT
			string input = "/GB/B45M5X6/FORESIGHT VCT PLC/INFRASTRUCTURE SHS GBP0.01";

			string sedol, entity, ISIN, countrycode;
            var sequenceE = new SequenceE("", "");
			sequenceE.ParseField35B(input, out sedol, out entity, out ISIN, out countrycode);

			Assert.AreEqual("B45M5X6", sedol);
			Assert.AreEqual("FORESIGHT VCT PLC/INFRASTRUCTURE SHS GBP0.01", entity);
            Assert.AreEqual("GB", countrycode);

            input = "/XK/B45M599/PPPESIGHT VCT PLC/INFRASTRUCTURE SHS GBP0.01";
            var subsequenceE1 = new SubsequenceE1("", "", 0, 0);
            subsequenceE1.ParseField35B(input, out sedol, out entity, out ISIN, out countrycode);

            Assert.AreEqual("B45M599", sedol);
            Assert.AreEqual("PPPESIGHT VCT PLC/INFRASTRUCTURE SHS GBP0.01", entity);
            Assert.AreEqual("XK", countrycode);

            input = "ISIN GB9995405286/ZT/B45M5ZZ/PORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01";
            var sequenceB = new SequenceB();
            sequenceB.ParseField35B(input, out sedol, out entity, out ISIN, out countrycode);
            Assert.AreEqual("B45M5ZZ", sedol);
            Assert.AreEqual("PORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01", entity);
            Assert.AreEqual("ZT", countrycode);
            Assert.AreEqual("GB9995405286", ISIN);


            //IDC IDC IDC
            //IDC IDC IDC
            //IDC IDC IDC
            //
            string input2 = "/GB/B45M5X7XORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01";
            var sequenceE1IDC = new SubsequenceE1IDC("", "", 0, 0);
            sequenceE1IDC.Parse("35B", input2);
            Assert.AreEqual("B45M5X7", sequenceE1IDC.InstrTicker);
            Assert.AreEqual("XORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01", sequenceE1IDC.InstrDescription);
            Assert.AreEqual("GB", sequenceE1IDC.InstrCntryCode);


            var sequenceBIDC = new SequenceBIDC();
            sequenceBIDC.Parse("35B", input2);
            Assert.AreEqual("B45M5X7", sequenceBIDC.SecTickerUnderly);
            Assert.AreEqual("XORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01", sequenceBIDC.SecDescrptionUnderly);
            //Assert.AreEqual("GB", sequenceBIDC.CountryCode);


            string input3 = "ISIN GB0005405286/RU/B45M5X8/ZORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01";
            var sequenceE1IDCisin = new SubsequenceE1IDC("", "", 0, 0);
            sequenceE1IDCisin.Parse("35B", input3);
            Assert.AreEqual("B45M5X7", sequenceE1IDC.InstrTicker);
            Assert.AreEqual("XORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01", sequenceE1IDC.InstrDescription);
            Assert.AreEqual("GB0005405286", sequenceE1IDCisin.InstrISIN);
            Assert.AreEqual("RU", sequenceE1IDCisin.InstrCntryCode);

             
            string input4 = "ISIN GB1235405286/PP/B45M5X8/ZORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01";
            var sequenceC = new SequenceCIDC();
            sequenceC.Parse("35B", input4);
            Assert.AreEqual("B45M5X8", sequenceC.SecTickerIntrmediate);
            Assert.AreEqual("ZORESIGHT VCT PLC/INFRASTRUCTURE SHS /GBP0.01", sequenceC.SecDescrptionIntrmediate);
            Assert.AreEqual("GB1235405286", sequenceC.SecISINIntrmediate);
            Assert.AreEqual("PP", sequenceC.SecCntryCodeIntrmediate);


            string input5 = "/DR/995M5X8STARTOFDESC VCT PLC/INFRASTRUCTURE SHS /GBP0.01";
            var sequenceEIDC = new SequenceEIDC("", "");
            sequenceEIDC.Parse("35B", input5);
            Assert.AreEqual("995M5X8", sequenceEIDC.InstrTicker);
            Assert.AreEqual("STARTOFDESC VCT PLC/INFRASTRUCTURE SHS /GBP0.01", sequenceEIDC.InstrDescription);
            //Assert.AreEqual("GB1235405286", sequenceC.ISIN);
            Assert.AreEqual("DR", sequenceEIDC.InstrCntryCode);
            
		}
	}
}