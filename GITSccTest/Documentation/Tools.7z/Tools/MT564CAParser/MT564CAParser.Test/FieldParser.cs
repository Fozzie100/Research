﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class FieldParserTests
	{
		[TestMethod]
		[Description("Test :4!c//4!c/[N]15d[/4!c]")]
		public void Can_QualifierRateTypeCodeRateRateStatus()
		{
			const string input = "RDIS//NETT/23343N/ACTU";
			string qualifierType;
			string rateTypeCode;
			decimal amount;
			string rateStatus;

			FieldParser.QualifierRateTypeCodeRateRateStatus(input, out qualifierType, out rateTypeCode, out amount, out rateStatus);

			Assert.AreEqual(Decimal.Parse("-23343"), amount);
			Assert.AreEqual("ACTU", rateStatus);
			Assert.AreEqual("NETT", rateTypeCode);
			Assert.AreEqual("RDIS", qualifierType);
		}

		[TestMethod]
		[Description("Test :4!c//4!c/[N]15d[/4!c]")]
		public void Can_QualifierRateTypeCodeRateRateStatus_NoOptionalPart()
		{
			const string input = "RDIS//NETT/23343N";
			string qualifierType;
			string rateTypeCode;
			decimal amount;
			string rateStatus;

			FieldParser.QualifierRateTypeCodeRateRateStatus(input, out qualifierType, out rateTypeCode, out amount, out rateStatus);

			Assert.AreEqual(Decimal.Parse("-23343"), amount);
			Assert.AreEqual("", rateStatus);
			Assert.AreEqual("NETT", rateTypeCode);
			Assert.AreEqual("RDIS", qualifierType);
		}

	}
}
