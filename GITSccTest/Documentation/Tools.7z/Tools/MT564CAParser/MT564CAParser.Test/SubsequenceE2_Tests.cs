﻿using System;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FTSE.MT564CAParser.FileManager;

namespace capParserTest
{
	[TestClass]
	public class SubsequenceE2_Tests
	{
		[TestMethod]
		public void Can_ParseField22A()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);

			// Option H
			string input = "CRDB//CRED";
			subsequenceE2.ParseField22A("22H", input);
			//Assert.AreEqual("CRDB", subsequenceE2.IndicatorType);
			Assert.AreEqual("CRED", subsequenceE2.IndCreditDebit);

			input = "NELP/ABCD/NELC";
			//subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField22A("22F", input);
            input = "CONT//ACTU";
            subsequenceE2.ParseField22A("22H", input);
            input = "ITYP/ISRX/XYZS";
            subsequenceE2.ParseField22A("22F", input);
            input = "TXAP//TXBL";
            subsequenceE2.ParseField22A("22H", input);

            Assert.AreEqual("CRED", subsequenceE2.IndCreditDebit);
			Assert.AreEqual("NELC", subsequenceE2.IndNonEligibleProceeds);
            Assert.AreEqual("ABCD", subsequenceE2.IndNonEligibleProceedsDtaSrcSchme);
            Assert.AreEqual("ACTU", subsequenceE2.IndContractualPayment);
            Assert.AreEqual("XYZS", subsequenceE2.IndTypeOfIncome);
            Assert.AreEqual("ISRX", subsequenceE2.IndTypeOfIncomeDtaSrcSchme);
            Assert.AreEqual("TXBL", subsequenceE2.IndIssuerOfferorTaxability);
		}

		[TestMethod]
		public void Can_ParseField97A()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			string input = "CASH//123455678901234567890";

			subsequenceE2.ParseField97A("97E", input);

			Assert.AreEqual("123455678901234567890", subsequenceE2.CashAccount);
		}

		[TestMethod]
		public void Can_ParseField19B()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			string input = "GRSS//EUR12,4";
            subsequenceE2.ParseField19B("19B", input);

            input = "ENTL//USD125,46";
            subsequenceE2.ParseField19B("19B", input);

            subsequenceE2.ParseField19B("19B", "RESU//JPY14446,");
            subsequenceE2.ParseField19B("19B", "OCMT//CHF999,45");
            subsequenceE2.ParseField19B("19B", "CAPG//RUB1999,21");
            subsequenceE2.ParseField19B("19B", "INDM//AUD3467,621");
            subsequenceE2.ParseField19B("19B", "CINL//NZD832135,");
            subsequenceE2.ParseField19B("19B", "CHAR//IND2262135,");
            subsequenceE2.ParseField19B("19B", "FLFR//RNG3462,49");
            subsequenceE2.ParseField19B("19B", "UNFR//BHT127344,69");
            subsequenceE2.ParseField19B("19B", "TXFR//BOB6274,69");
            subsequenceE2.ParseField19B("19B", "TXDF//BIB8274,69");
            subsequenceE2.ParseField19B("19B", "SOIC//LIR99274,");
            Assert.AreEqual("USD", subsequenceE2.AmtEntitledCcy);
            Assert.AreEqual(125.46m, subsequenceE2.AmtEntitled);
            Assert.AreEqual("JPY", subsequenceE2.AmtResultingCcy);
            Assert.AreEqual(14446m, subsequenceE2.AmtResulting);
            Assert.AreEqual("CHF", subsequenceE2.AmtOrigCcyandOrderedCcy);
            Assert.AreEqual(999.45m, subsequenceE2.AmtOrigCcyandOrdered);
            Assert.AreEqual("RUB", subsequenceE2.AmtCapitalGainsCcy);
            Assert.AreEqual(1999.21m, subsequenceE2.AmtCapitalGains);
            Assert.AreEqual("AUD", subsequenceE2.AmtImdemnityCcy);
            Assert.AreEqual(3467.621m, subsequenceE2.AmtImdemnity);
            Assert.AreEqual("NZD", subsequenceE2.AmtCashInLieuOfSharesCcy);
            Assert.AreEqual(832135m, subsequenceE2.AmtCashInLieuOfShares);
            Assert.AreEqual("IND", subsequenceE2.AmtChargesFeesCcy);
            Assert.AreEqual(2262135m, subsequenceE2.AmtChargesFees);
            Assert.AreEqual("RNG", subsequenceE2.AmtFullyFrankedCcy);
            Assert.AreEqual(3462.49m, subsequenceE2.AmtFullyFranked);
            Assert.AreEqual("BHT", subsequenceE2.AmtUnFrankedCcy);
            Assert.AreEqual(127344.69m, subsequenceE2.AmtUnFranked);
            Assert.AreEqual("BOB", subsequenceE2.AmtTaxFreeCcy);
            Assert.AreEqual(6274.69m, subsequenceE2.AmtTaxFree);
            Assert.AreEqual("BIB", subsequenceE2.AmtTaxDeferredCcy);
            Assert.AreEqual(8274.69m, subsequenceE2.AmtTaxDeferred);
            Assert.AreEqual("LIR", subsequenceE2.AmtSundryOtherIncomeCcy);
            Assert.AreEqual(99274m, subsequenceE2.AmtSundryOtherIncome);
			
			Assert.AreEqual("EUR", subsequenceE2.AmtGrossCcy);
            Assert.AreEqual(12.4m, subsequenceE2.AmtGross);
		}

		[TestMethod]
		public void Can_ParseField98A()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			// Option A
			string input = "PAYD//20120426";

			subsequenceE2.ParseField98B("98A", input);
			Assert.AreEqual(DateTime.ParseExact("20120426", "yyyyMMdd", CultureInfo.InvariantCulture), subsequenceE2.PayDate);

			// Option C
			input = "PAYD//20120426120101";
			subsequenceE2.ParseField98B("98C", input);
			Assert.AreEqual(DateTime.ParseExact("20120426120101", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), subsequenceE2.PayDate);

            // Option B
            input = "PAYD/CCC/ONGO";
            subsequenceE2.ParseField98B("98B", input);
            Assert.AreEqual(null, subsequenceE2.PayDate);
            Assert.AreEqual("CCC", subsequenceE2.PayDateDtaSrcSchme);


            // Option E  (UTC0 TEst
            input = "EARL//20131221170534,000";
            subsequenceE2.ParseField98B("98E", input);
            Assert.AreEqual(DateTime.ParseExact("20131221170534,000", "yyyyMMddHHmmss,fff", CultureInfo.InvariantCulture), subsequenceE2.EarliestPayDate);
            Assert.AreEqual("", subsequenceE2.EarliestPayDateDtaSrcSchme);
		}
        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void Can_ParseField98E_UTCDate_Throws()
        {
            string input = "EARL//20101221170534,123/N0530";
            var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
            subsequenceE2.ParseField98B("98E", input);
            Assert.AreEqual(DateTime.ParseExact("20101221170534123 -05:30", "yyyyMMddHHmmssfff zzz", CultureInfo.InvariantCulture), subsequenceE2.EarliestPayDate);
            Assert.AreEqual("", subsequenceE2.EarliestPayDateDtaSrcSchme);
        }

		[TestMethod]
		public void Can_ParseField92A()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			
			// Option A
			string input = "ATAX//N12,1";
			subsequenceE2.ParseField92("92A", input);

			//Assert.AreEqual("FDIV", subsequenceE2.RateType);
			Assert.AreEqual(-12.1m, subsequenceE2.AdditionalTaxRate);
			Assert.AreEqual(null, subsequenceE2.RateAdditionalTaxAmt);
            Assert.AreEqual(null, subsequenceE2.RateAdditionalTaxCcy);
            Assert.AreEqual(null, subsequenceE2.RateAdditionalTaxCode);

			// Option B
			input = "EXCH//EUR/GBP/12,2";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField92("92B", input);

			//Assert.AreEqual("EXCH", subsequenceE2.RateType);
			Assert.AreEqual(12.2m, subsequenceE2.ExchangeRate);
			Assert.AreEqual("EUR", subsequenceE2.RateExchangeCcy1);
            Assert.AreEqual("GBP", subsequenceE2.RateExchangeCcy2);

			// Option F
			input = "NRES//EUR12,3";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField92("92F", input);

		    Assert.AreEqual(null, subsequenceE2.NonResidentRate);
			Assert.AreEqual("EUR", subsequenceE2.RateNonResidentCcy);
            Assert.AreEqual(12.3m, subsequenceE2.RateNonResidentAmt);
            Assert.AreEqual(null, subsequenceE2.RateNonResidentCode);

            //Option J
            input = "GRSS/DSRC/TYPE/JPY15679,/STAA";
            subsequenceE2.ParseField92("92J", input);
            Assert.AreEqual(15679m, subsequenceE2.RateGrossAmt);
            Assert.AreEqual("JPY", subsequenceE2.RateGrossCcy);
            Assert.AreEqual("TYPE", subsequenceE2.RateGrossCode);
            Assert.AreEqual("STAA", subsequenceE2.RateGrossStatus);
            Assert.AreEqual("DSRC", subsequenceE2.RateGrossDtaSrcSchme);


			// Option K
			input = "INTP//NILP";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField92("92K", input);
			Assert.AreEqual(null, subsequenceE2.InterestRate);
            Assert.AreEqual(null, subsequenceE2.RateInterestAmt);
            Assert.AreEqual(null, subsequenceE2.RateInterestCcy);
            Assert.AreEqual(null, subsequenceE2.RateInterestDtaSrcSchme);
            Assert.AreEqual("NILP", subsequenceE2.RateInterestCode);
            Assert.AreEqual(null, subsequenceE2.RateInterestStatus);

            // Option M
            input = "SOFE//CHF66489,21/34833,";
            subsequenceE2.ParseField92("92M", input);
            Assert.AreEqual(null, subsequenceE2.SolicitationFeeRate);
            Assert.AreEqual(66489.21m, subsequenceE2.RateSolicitationFeeAmt);
            Assert.AreEqual("CHF", subsequenceE2.RateSolicitationFeeCcy);
            Assert.AreEqual(34833m, subsequenceE2.RateSolicitationFeeQty);
            Assert.IsNull(subsequenceE2.RateSolicitationFeeCode);



		}

		[TestMethod]
		public void Can_ParseField90A()
		{
			// Option A
			string input = "OFFR//PREM/34,5";
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
            subsequenceE2.ParseField90A("90A", input);
            Assert.AreEqual(34.5m, subsequenceE2.GenericCashPriceReceived);
            Assert.AreEqual("PREM", subsequenceE2.GenericCashPriceReceivedPercType);
            input = "PRPP//YIEL/12,34";
            subsequenceE2.ParseField90A("90A", input);
            Assert.AreEqual(12.34m, subsequenceE2.GenericCashPricePaid);
            Assert.AreEqual("YIEL", subsequenceE2.GenericCashPricePaidPercType);

			// Option B
			input = "OFFR//PREM/EUR4,5";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField90A("90B", input);
			Assert.AreEqual(4.5m, subsequenceE2.GenericCashPriceReceived);
			Assert.AreEqual("EUR", subsequenceE2.GenericCashPriceReceivedCcy);
            Assert.AreEqual("PREM", subsequenceE2.GenericCashPriceReceivedAmtType);
            input = "PRPP//PRCT/RUB24,98";
            subsequenceE2.ParseField90A("90B", input);
            Assert.AreEqual(24.98m, subsequenceE2.GenericCashPricePaid);
            Assert.AreEqual("RUB", subsequenceE2.GenericCashPricePaidCcy);
            Assert.AreEqual("PRCT", subsequenceE2.GenericCashPricePaidAmtType);


            //Option F
            input = "OFFR//ACTU/JPY5613,321/AMOR/812456,";
            subsequenceE2 = new SubsequenceE2("", "", 0, 0);
            subsequenceE2.ParseField90A("90F", input);
            Assert.AreEqual(5613.321m, subsequenceE2.GenericCashPriceReceivedAmt);
            Assert.AreEqual("JPY", subsequenceE2.GenericCashPriceReceivedCcy);
            Assert.AreEqual("ACTU", subsequenceE2.GenericCashPriceReceivedAmtType);
            Assert.AreEqual("AMOR", subsequenceE2.GenericCashPriceReceivedQtyType);
            Assert.AreEqual(812456m, subsequenceE2.GenericCashPriceReceivedQty);

            //Opton J
            input = "OFFR//PLOT/CHF578,67";
            subsequenceE2 = new SubsequenceE2("", "", 0, 0);
            subsequenceE2.ParseField90A("90J", input);
            Assert.AreEqual(578.67m, subsequenceE2.GenericCashPriceReceivedAmt);
            Assert.AreEqual("CHF", subsequenceE2.GenericCashPriceReceivedCcy);
            Assert.AreEqual("PLOT", subsequenceE2.GenericCashPriceReceivedAmtType);
   

			// Option E
			input = "PRPP//UKWN";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField90A("90E", input);
			Assert.IsNull(subsequenceE2.GenericCashPricePaid);

            // Option K
            input = "PRPP//6543543,";
            subsequenceE2 = new SubsequenceE2("", "", 0, 0);
            subsequenceE2.ParseField90A("90K", input);
            Assert.IsNull(subsequenceE2.GenericCashPricePaid);
            Assert.AreEqual(6543543m, subsequenceE2.GenericCashPricePaidIdxPoints);
		}
	}
}