﻿namespace FEProcessDisplay
{
	partial class ProcessDefinitionForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProcessDefinitionForm));
			this.uiSqlTextBox = new System.Windows.Forms.TextBox();
			this.uiButtonGroupBox = new System.Windows.Forms.GroupBox();
			this.uiSaveButton = new System.Windows.Forms.Button();
			this.uiSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
			this.uiCopyToClipboardButton = new System.Windows.Forms.Button();
			this.uiButtonGroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiSqlTextBox
			// 
			this.uiSqlTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiSqlTextBox.Location = new System.Drawing.Point(0, 0);
			this.uiSqlTextBox.Multiline = true;
			this.uiSqlTextBox.Name = "uiSqlTextBox";
			this.uiSqlTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.uiSqlTextBox.Size = new System.Drawing.Size(1002, 532);
			this.uiSqlTextBox.TabIndex = 0;
			// 
			// uiButtonGroupBox
			// 
			this.uiButtonGroupBox.Controls.Add(this.uiCopyToClipboardButton);
			this.uiButtonGroupBox.Controls.Add(this.uiSaveButton);
			this.uiButtonGroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.uiButtonGroupBox.Location = new System.Drawing.Point(0, 532);
			this.uiButtonGroupBox.Name = "uiButtonGroupBox";
			this.uiButtonGroupBox.Size = new System.Drawing.Size(1002, 36);
			this.uiButtonGroupBox.TabIndex = 1;
			this.uiButtonGroupBox.TabStop = false;
			// 
			// uiSaveButton
			// 
			this.uiSaveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.uiSaveButton.Location = new System.Drawing.Point(872, 10);
			this.uiSaveButton.Name = "uiSaveButton";
			this.uiSaveButton.Size = new System.Drawing.Size(124, 23);
			this.uiSaveButton.TabIndex = 1;
			this.uiSaveButton.Text = "Save To Local File";
			this.uiSaveButton.UseVisualStyleBackColor = true;
			this.uiSaveButton.Click += new System.EventHandler(this.uiSaveButton_Click);
			// 
			// uiCopyToClipboardButton
			// 
			this.uiCopyToClipboardButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.uiCopyToClipboardButton.Location = new System.Drawing.Point(742, 10);
			this.uiCopyToClipboardButton.Name = "uiCopyToClipboardButton";
			this.uiCopyToClipboardButton.Size = new System.Drawing.Size(124, 23);
			this.uiCopyToClipboardButton.TabIndex = 0;
			this.uiCopyToClipboardButton.Text = "Copy To Clipboard";
			this.uiCopyToClipboardButton.UseVisualStyleBackColor = true;
			this.uiCopyToClipboardButton.Click += new System.EventHandler(this.uiCopyToClipboardButton_Click);
			// 
			// ProcessDefinitionForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1002, 568);
			this.Controls.Add(this.uiSqlTextBox);
			this.Controls.Add(this.uiButtonGroupBox);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "ProcessDefinitionForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Process Definition";
			this.uiButtonGroupBox.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox uiSqlTextBox;
		private System.Windows.Forms.GroupBox uiButtonGroupBox;
		private System.Windows.Forms.Button uiSaveButton;
		private System.Windows.Forms.SaveFileDialog uiSaveFileDialog;
		private System.Windows.Forms.Button uiCopyToClipboardButton;
	}
}