﻿using System;
using System.Linq;
using System.Windows.Forms;
using FEProcessDisplay.Data;
using Ftse.Research.Framework.Windows.ControlHelpers;

namespace FEProcessDisplay
{
	/// <summary>
	/// Form used to display and edit the details of an FE process
	/// </summary>
	public partial class ProcessDetailForm : Form
	{
		#region Private Instance Fields
		private Process _process;
		#endregion

		#region Constructors
		/// <summary>
		/// Private Constructor to prevent incorrect instantiation
		/// </summary>
		private ProcessDetailForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Creates a new instance of ProcessDetailForm
		/// </summary>
		/// <param name="process">Process</param>
		public ProcessDetailForm(Process process) : this()
		{
			_process = process;
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Event raised when the Form Loads
		/// </summary>
		/// <param name="e">EventArgs object</param>
		protected override void  OnLoad(EventArgs e)
		{
 			base.OnLoad(e);
			uiEnabledCheckBox.Checked = _process.Enabled;
			uiWorkDirectoryTextBox.Text = _process.WorkDirectory;
			uiNameTextBox.Text = _process.Name;
			//todo uiStatusStrip.Items["CreatedBy"].Text = string.Format("Created by '{0}' on '{1}'", _process.User, _process.Created.ToString("dd MMM yyyy - hh:mm"));
			uiStatusStrip.Items["CreatedBy"].Text = string.Empty;

			//retrieve the actions for the Process
			using (FEEntities context = new FEEntities())
			{
				var query = from Data.Action action in context.Actions
							where action.ProcessId == _process.ProcessId
							orderby action.ActionOrder
							select action;

				uiActionDataGridView.DataSource = query.ToList();
			}
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the Action DataGridView is bound to a datasource
		/// </summary>
		/// <param name="sender">DataGridView raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiActionDataGridView_DataSourceChanged(object sender, EventArgs e)
		{
			string[] columnNamesToDisplay = new string[] { "ActionOrder", "ActionCommand", "ActionType", "Note", "Enabled" };
			string[] newColumnHeaders = new string[] { "Order", "Command", "Type", "Note", "Enabled" };
			DataGridViewHelper.DisplayColumns(uiActionDataGridView.Columns, columnNamesToDisplay, newColumnHeaders);
		}

		/// <summary>
		/// Event raised the Display Action tool is clicked
		/// </summary>
		/// <param name="sender">ToolStripButton raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiDisplayActionToolStripButton_Click(object sender, EventArgs e)
		{
			DataGridViewRow selectedRow = DataGridViewHelper.GetSelectedRow(uiActionDataGridView);
			Data.Action selectedAction = selectedRow.DataBoundItem as Data.Action;
			using (ActionDetailForm detailForm = new ActionDetailForm(selectedAction))
			{
				detailForm.ShowDialog(this);
			}
		}
		#endregion
	}
}