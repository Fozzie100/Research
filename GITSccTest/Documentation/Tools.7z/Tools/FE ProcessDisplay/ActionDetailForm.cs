﻿using System;
using System.Linq;
using System.Windows.Forms;
using FEProcessDisplay.Data;
using Ftse.Research.Framework.Windows.ControlHelpers;

namespace FEProcessDisplay
{
	/// <summary>
	/// Form used to display FE Actions
	/// </summary>
	public partial class ActionDetailForm : Form
	{
		#region Private Instance Fields
		private Data.Action _action;
		#endregion

		#region Constructors
		/// <summary>
		/// Private Constructor to prevent incorrect instantiation
		/// </summary>
		private ActionDetailForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Creates a new instance of ActionDetailForm
		/// </summary>
		/// <param name="action">Data.Action to display</param>
		public ActionDetailForm(Data.Action action) : this()
		{
			_action = action;
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Event raised when the form loads
		/// </summary>
		/// <param name="e">EventArgs object</param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			using (FEEntities context = new FEEntities())
			{
				var query = from Parameter parameter in context.Parameters
							where parameter.ActionId == _action.ActionId
							orderby Name
							select parameter;
				uiParameterDataGridView.DataSource = query.ToList();

				var actionTypeQuery = from ActionType actionType in context.ActionTypes
									  select actionType;
				uiTypeComboBox.ValueMember = "Code";
				uiTypeComboBox.DisplayMember = "Name";
				uiTypeComboBox.DataSource = actionTypeQuery.ToArray();
			}

			uiNoteTextBox.Text = _action.Note;
			uiTypeComboBox.SelectedValue = _action.ActionType;
			uiConditionTextBox.Text = _action.Condition;
			uiEnabledCheckBox.Checked = _action.Enabled;
			uiCommandTextBox.Text = _action.ActionCommand;
			uiStatusStrip.Items["CreatedBy"].Text = string.Format("Created by '{0}' on '{1}'", _action.User, _action.Created.ToString("dd MMM yyyy - hh:mm"));
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the Parameter DataGridView is bound to a datasource
		/// </summary>
		/// <param name="sender">DataGridView raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiParameterDataGridView_DataSourceChanged(object sender, EventArgs e)
		{
			string[] columnNamesToDisplay = new string[] { "ParameterId", "Name", "Value", "Note"};
			DataGridViewHelper.DisplayColumns(uiParameterDataGridView.Columns, columnNamesToDisplay);
		}

		/// <summary>
		/// Event raised when a type is selected from the ComboBox
		/// </summary>
		/// <param name="sender">ComboBox raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiTypeComboBox_SelectionChangeCommitted(object sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(uiDescriptionTextBox.Text))
			{
				uiDescriptionTextBox.Text = uiTypeComboBox.Text;
			}
		}
		#endregion

		private void uiParameterDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			return;
			/*
			if (e.RowIndex > 0)
			{
				DataGridViewRow viewRow = uiParameterDataGridView.Rows[e.RowIndex];
				Parameter parameter = viewRow.DataBoundItem as Parameter;
				using (ParameterDetailForm detailForm = new ParameterDetailForm(parameter))
				{
					detailForm.ShowDialog(this);
				}
			}
			 */
		}
	}
}
