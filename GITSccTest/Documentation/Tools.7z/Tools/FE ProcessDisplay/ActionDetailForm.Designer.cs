﻿namespace FEProcessDisplay
{
	partial class ActionDetailForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ActionDetailForm));
			this.uiNoteTextBox = new System.Windows.Forms.TextBox();
			this.uiNoteLabel = new System.Windows.Forms.Label();
			this.uiParameterPanel = new System.Windows.Forms.Panel();
			this.uiParameterDataGridView = new System.Windows.Forms.DataGridView();
			this.uiParameterToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiParamtersToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiStatusStrip = new System.Windows.Forms.StatusStrip();
			this.CreatedBy = new System.Windows.Forms.ToolStripStatusLabel();
			this.uiMainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.uiCommandTextBox = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.uiEnabledLabel = new System.Windows.Forms.Label();
			this.uiEnabledCheckBox = new System.Windows.Forms.CheckBox();
			this.uiConditionTextBox = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.uiDescriptionTextBox = new System.Windows.Forms.TextBox();
			this.uiDescriptionLabel = new System.Windows.Forms.Label();
			this.uiNameLabel = new System.Windows.Forms.Label();
			this.uiTypeComboBox = new System.Windows.Forms.ComboBox();
			this.uiParameterPanel.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiParameterDataGridView)).BeginInit();
			this.uiParameterToolStrip.SuspendLayout();
			this.uiStatusStrip.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).BeginInit();
			this.uiMainSplitContainer.Panel1.SuspendLayout();
			this.uiMainSplitContainer.Panel2.SuspendLayout();
			this.uiMainSplitContainer.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiNoteTextBox
			// 
			this.uiNoteTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiNoteTextBox.Location = new System.Drawing.Point(72, 59);
			this.uiNoteTextBox.Name = "uiNoteTextBox";
			this.uiNoteTextBox.Size = new System.Drawing.Size(499, 20);
			this.uiNoteTextBox.TabIndex = 0;
			// 
			// uiNoteLabel
			// 
			this.uiNoteLabel.AutoSize = true;
			this.uiNoteLabel.Location = new System.Drawing.Point(6, 61);
			this.uiNoteLabel.Name = "uiNoteLabel";
			this.uiNoteLabel.Size = new System.Drawing.Size(30, 13);
			this.uiNoteLabel.TabIndex = 1;
			this.uiNoteLabel.Text = "Note";
			// 
			// uiParameterPanel
			// 
			this.uiParameterPanel.Controls.Add(this.uiParameterDataGridView);
			this.uiParameterPanel.Controls.Add(this.uiParameterToolStrip);
			this.uiParameterPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiParameterPanel.Location = new System.Drawing.Point(0, 0);
			this.uiParameterPanel.Name = "uiParameterPanel";
			this.uiParameterPanel.Size = new System.Drawing.Size(579, 286);
			this.uiParameterPanel.TabIndex = 2;
			// 
			// uiParameterDataGridView
			// 
			this.uiParameterDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			this.uiParameterDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.uiParameterDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiParameterDataGridView.Location = new System.Drawing.Point(0, 25);
			this.uiParameterDataGridView.Name = "uiParameterDataGridView";
			this.uiParameterDataGridView.ReadOnly = true;
			this.uiParameterDataGridView.Size = new System.Drawing.Size(579, 261);
			this.uiParameterDataGridView.TabIndex = 0;
			this.uiParameterDataGridView.DataSourceChanged += new System.EventHandler(this.uiParameterDataGridView_DataSourceChanged);
			this.uiParameterDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.uiParameterDataGridView_CellDoubleClick);
			// 
			// uiParameterToolStrip
			// 
			this.uiParameterToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiParamtersToolStripLabel});
			this.uiParameterToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiParameterToolStrip.Name = "uiParameterToolStrip";
			this.uiParameterToolStrip.Size = new System.Drawing.Size(579, 25);
			this.uiParameterToolStrip.TabIndex = 1;
			// 
			// uiParamtersToolStripLabel
			// 
			this.uiParamtersToolStripLabel.Name = "uiParamtersToolStripLabel";
			this.uiParamtersToolStripLabel.Size = new System.Drawing.Size(62, 22);
			this.uiParamtersToolStripLabel.Text = "Parameters";
			// 
			// uiStatusStrip
			// 
			this.uiStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreatedBy});
			this.uiStatusStrip.Location = new System.Drawing.Point(0, 450);
			this.uiStatusStrip.Name = "uiStatusStrip";
			this.uiStatusStrip.Size = new System.Drawing.Size(579, 22);
			this.uiStatusStrip.TabIndex = 12;
			this.uiStatusStrip.Text = "[Created By]";
			// 
			// CreatedBy
			// 
			this.CreatedBy.Name = "CreatedBy";
			this.CreatedBy.Size = new System.Drawing.Size(564, 17);
			this.CreatedBy.Spring = true;
			this.CreatedBy.Text = "[Created By]";
			this.CreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// uiMainSplitContainer
			// 
			this.uiMainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiMainSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.uiMainSplitContainer.Name = "uiMainSplitContainer";
			this.uiMainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiMainSplitContainer.Panel1
			// 
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiCommandTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.label2);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiEnabledLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiEnabledCheckBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiConditionTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.label1);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiDescriptionTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiDescriptionLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiNameLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiTypeComboBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiNoteTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiNoteLabel);
			// 
			// uiMainSplitContainer.Panel2
			// 
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiParameterPanel);
			this.uiMainSplitContainer.Size = new System.Drawing.Size(579, 450);
			this.uiMainSplitContainer.SplitterDistance = 160;
			this.uiMainSplitContainer.TabIndex = 13;
			// 
			// uiCommandTextBox
			// 
			this.uiCommandTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiCommandTextBox.Location = new System.Drawing.Point(72, 134);
			this.uiCommandTextBox.Name = "uiCommandTextBox";
			this.uiCommandTextBox.Size = new System.Drawing.Size(499, 20);
			this.uiCommandTextBox.TabIndex = 19;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 137);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(46, 13);
			this.label2.TabIndex = 18;
			this.label2.Text = "Comand";
			// 
			// uiEnabledLabel
			// 
			this.uiEnabledLabel.AutoSize = true;
			this.uiEnabledLabel.Location = new System.Drawing.Point(6, 115);
			this.uiEnabledLabel.Name = "uiEnabledLabel";
			this.uiEnabledLabel.Size = new System.Drawing.Size(46, 13);
			this.uiEnabledLabel.TabIndex = 16;
			this.uiEnabledLabel.Text = "Enabled";
			// 
			// uiEnabledCheckBox
			// 
			this.uiEnabledCheckBox.AutoSize = true;
			this.uiEnabledCheckBox.Location = new System.Drawing.Point(72, 114);
			this.uiEnabledCheckBox.Name = "uiEnabledCheckBox";
			this.uiEnabledCheckBox.Size = new System.Drawing.Size(15, 14);
			this.uiEnabledCheckBox.TabIndex = 17;
			this.uiEnabledCheckBox.UseVisualStyleBackColor = true;
			// 
			// uiConditionTextBox
			// 
			this.uiConditionTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiConditionTextBox.Location = new System.Drawing.Point(72, 85);
			this.uiConditionTextBox.Name = "uiConditionTextBox";
			this.uiConditionTextBox.Size = new System.Drawing.Size(499, 20);
			this.uiConditionTextBox.TabIndex = 7;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 88);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(51, 13);
			this.label1.TabIndex = 6;
			this.label1.Text = "Condition";
			// 
			// uiDescriptionTextBox
			// 
			this.uiDescriptionTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiDescriptionTextBox.Location = new System.Drawing.Point(72, 6);
			this.uiDescriptionTextBox.Name = "uiDescriptionTextBox";
			this.uiDescriptionTextBox.Size = new System.Drawing.Size(499, 20);
			this.uiDescriptionTextBox.TabIndex = 5;
			// 
			// uiDescriptionLabel
			// 
			this.uiDescriptionLabel.AutoSize = true;
			this.uiDescriptionLabel.Location = new System.Drawing.Point(6, 9);
			this.uiDescriptionLabel.Name = "uiDescriptionLabel";
			this.uiDescriptionLabel.Size = new System.Drawing.Size(60, 13);
			this.uiDescriptionLabel.TabIndex = 4;
			this.uiDescriptionLabel.Text = "Description";
			// 
			// uiNameLabel
			// 
			this.uiNameLabel.AutoSize = true;
			this.uiNameLabel.Location = new System.Drawing.Point(6, 35);
			this.uiNameLabel.Name = "uiNameLabel";
			this.uiNameLabel.Size = new System.Drawing.Size(31, 13);
			this.uiNameLabel.TabIndex = 3;
			this.uiNameLabel.Text = "Type";
			// 
			// uiTypeComboBox
			// 
			this.uiTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.uiTypeComboBox.FormattingEnabled = true;
			this.uiTypeComboBox.Location = new System.Drawing.Point(72, 32);
			this.uiTypeComboBox.Name = "uiTypeComboBox";
			this.uiTypeComboBox.Size = new System.Drawing.Size(465, 21);
			this.uiTypeComboBox.TabIndex = 2;
			this.uiTypeComboBox.SelectionChangeCommitted += new System.EventHandler(this.uiTypeComboBox_SelectionChangeCommitted);
			// 
			// ActionDetailForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(579, 472);
			this.Controls.Add(this.uiMainSplitContainer);
			this.Controls.Add(this.uiStatusStrip);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "ActionDetailForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Action Detail";
			this.uiParameterPanel.ResumeLayout(false);
			this.uiParameterPanel.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiParameterDataGridView)).EndInit();
			this.uiParameterToolStrip.ResumeLayout(false);
			this.uiParameterToolStrip.PerformLayout();
			this.uiStatusStrip.ResumeLayout(false);
			this.uiStatusStrip.PerformLayout();
			this.uiMainSplitContainer.Panel1.ResumeLayout(false);
			this.uiMainSplitContainer.Panel1.PerformLayout();
			this.uiMainSplitContainer.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).EndInit();
			this.uiMainSplitContainer.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox uiNoteTextBox;
		private System.Windows.Forms.Label uiNoteLabel;
		private System.Windows.Forms.Panel uiParameterPanel;
		private System.Windows.Forms.ToolStrip uiParameterToolStrip;
		private System.Windows.Forms.ToolStripLabel uiParamtersToolStripLabel;
		private System.Windows.Forms.DataGridView uiParameterDataGridView;
		private System.Windows.Forms.StatusStrip uiStatusStrip;
		private System.Windows.Forms.ToolStripStatusLabel CreatedBy;
		private System.Windows.Forms.SplitContainer uiMainSplitContainer;
		private System.Windows.Forms.ComboBox uiTypeComboBox;
		private System.Windows.Forms.TextBox uiDescriptionTextBox;
		private System.Windows.Forms.Label uiDescriptionLabel;
		private System.Windows.Forms.Label uiNameLabel;
		private System.Windows.Forms.TextBox uiConditionTextBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label uiEnabledLabel;
		private System.Windows.Forms.CheckBox uiEnabledCheckBox;
		private System.Windows.Forms.TextBox uiCommandTextBox;
		private System.Windows.Forms.Label label2;
	}
}