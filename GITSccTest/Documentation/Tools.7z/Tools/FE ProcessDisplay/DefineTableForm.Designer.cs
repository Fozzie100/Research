﻿namespace FEProcessDisplay
{
	partial class DefineTableForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DefineTableForm));
			this.uiTableNameLabel = new System.Windows.Forms.Label();
			this.uiTableNameTextBox = new System.Windows.Forms.TextBox();
			this.uiGenerateButton = new System.Windows.Forms.Button();
			this.uiResultsTextBox = new System.Windows.Forms.TextBox();
			this.uiResultsLabel = new System.Windows.Forms.Label();
			this.uiSchemaTextBox = new System.Windows.Forms.TextBox();
			this.uiSchemaLabel = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// uiTableNameLabel
			// 
			this.uiTableNameLabel.AutoSize = true;
			this.uiTableNameLabel.Location = new System.Drawing.Point(328, 8);
			this.uiTableNameLabel.Name = "uiTableNameLabel";
			this.uiTableNameLabel.Size = new System.Drawing.Size(34, 13);
			this.uiTableNameLabel.TabIndex = 2;
			this.uiTableNameLabel.Text = "Table";
			// 
			// uiTableNameTextBox
			// 
			this.uiTableNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiTableNameTextBox.Location = new System.Drawing.Point(368, 5);
			this.uiTableNameTextBox.Name = "uiTableNameTextBox";
			this.uiTableNameTextBox.Size = new System.Drawing.Size(323, 20);
			this.uiTableNameTextBox.TabIndex = 3;
			// 
			// uiGenerateButton
			// 
			this.uiGenerateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.uiGenerateButton.Location = new System.Drawing.Point(607, 31);
			this.uiGenerateButton.Name = "uiGenerateButton";
			this.uiGenerateButton.Size = new System.Drawing.Size(84, 23);
			this.uiGenerateButton.TabIndex = 5;
			this.uiGenerateButton.Text = "Generate";
			this.uiGenerateButton.UseVisualStyleBackColor = true;
			this.uiGenerateButton.Click += new System.EventHandler(this.uiGenerateButton_Click);
			// 
			// uiResultsTextBox
			// 
			this.uiResultsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiResultsTextBox.Location = new System.Drawing.Point(5, 60);
			this.uiResultsTextBox.Name = "uiResultsTextBox";
			this.uiResultsTextBox.Size = new System.Drawing.Size(686, 20);
			this.uiResultsTextBox.TabIndex = 6;
			// 
			// uiResultsLabel
			// 
			this.uiResultsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.uiResultsLabel.AutoSize = true;
			this.uiResultsLabel.Location = new System.Drawing.Point(5, 44);
			this.uiResultsLabel.Name = "uiResultsLabel";
			this.uiResultsLabel.Size = new System.Drawing.Size(42, 13);
			this.uiResultsLabel.TabIndex = 4;
			this.uiResultsLabel.Text = "Results";
			// 
			// uiSchemaTextBox
			// 
			this.uiSchemaTextBox.Location = new System.Drawing.Point(57, 5);
			this.uiSchemaTextBox.Name = "uiSchemaTextBox";
			this.uiSchemaTextBox.Size = new System.Drawing.Size(265, 20);
			this.uiSchemaTextBox.TabIndex = 1;
			this.uiSchemaTextBox.Text = "Loader";
			// 
			// uiSchemaLabel
			// 
			this.uiSchemaLabel.AutoSize = true;
			this.uiSchemaLabel.Location = new System.Drawing.Point(5, 8);
			this.uiSchemaLabel.Name = "uiSchemaLabel";
			this.uiSchemaLabel.Size = new System.Drawing.Size(46, 13);
			this.uiSchemaLabel.TabIndex = 0;
			this.uiSchemaLabel.Text = "Schema";
			// 
			// MainForm
			// 
			this.AcceptButton = this.uiGenerateButton;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(694, 84);
			this.Controls.Add(this.uiSchemaTextBox);
			this.Controls.Add(this.uiSchemaLabel);
			this.Controls.Add(this.uiResultsLabel);
			this.Controls.Add(this.uiResultsTextBox);
			this.Controls.Add(this.uiGenerateButton);
			this.Controls.Add(this.uiTableNameTextBox);
			this.Controls.Add(this.uiTableNameLabel);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(1000, 118);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(8, 118);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Table DataFlow Creator";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label uiTableNameLabel;
		private System.Windows.Forms.TextBox uiTableNameTextBox;
		private System.Windows.Forms.Button uiGenerateButton;
		private System.Windows.Forms.TextBox uiResultsTextBox;
		private System.Windows.Forms.Label uiResultsLabel;
		private System.Windows.Forms.TextBox uiSchemaTextBox;
		private System.Windows.Forms.Label uiSchemaLabel;
	}
}

