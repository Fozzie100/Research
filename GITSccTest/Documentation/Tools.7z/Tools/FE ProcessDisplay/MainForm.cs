﻿using System;
using System.Linq;
using System.Windows.Forms;
using FEProcessDisplay.Data;
using Ftse.Research.Framework.Windows.ControlHelpers;

namespace FEProcessDisplay
{
	/// <summary>
	/// Main Application Form
	/// </summary>
	public partial class MainForm : Form
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of MainForm
		/// </summary>
		public MainForm()
		{
			InitializeComponent();
			uiMainSplitContainer.Panel1Collapsed = (!uiSearchToolStripButton.Checked);
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Method called when the form loads
		/// </summary>
		/// <param name="e"></param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			LoadData();
		}
		#endregion

		#region Private Methods
		/// <summary>
		/// Loads the Data for the form
		/// </summary>
		private void LoadData()
		{
			using (FEEntities entities = new FEEntities())
			{
				var query = from Process process in entities.Processes
							orderby process.Name
							select process;

				uiProcessDataGridView.DataSource = query;

				var actionTypeQuery = from ActionType actionType in entities.ActionTypes
									  orderby actionType.Description
									  select actionType;
				uiActionTypeComboBox.ValueMember = "Type";
				uiActionTypeComboBox.DisplayMember = "Description";
				uiActionTypeComboBox.DataSource = actionTypeQuery.ToArray();
			}
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the process DataGridView is bound to a datasouce
		/// </summary>
		/// <param name="sender">DataGridView raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiProcessDataGridView_DataSourceChanged(object sender, EventArgs e)
		{
			string[] columnNamesToDisplay = new string[] { "ProcessId", "Name", "Enabled", "WorkDirectory", "Note" };
			string[] newColumnHeaders = new string[] { "Id", "Name", "Enabled", "Work Directory", "Note" };
			DataGridViewHelper.DisplayColumns(sender, columnNamesToDisplay, newColumnHeaders);
		}

		/// <summary>
		/// Event raised when the Display Process Tool Strip Button is clicked
		/// </summary>
		/// <param name="sender">ToolStripButton raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiDisplayProcessToolStripButton_Click(object sender, EventArgs e)
		{
			DataGridViewRow selectedRow = DataGridViewHelper.GetSelectedRow(uiProcessDataGridView);
			Process selectedProcess = selectedRow.DataBoundItem as Process;
			using (ProcessDetailForm detailForm = new ProcessDetailForm(selectedProcess))
			{
				detailForm.ShowDialog(this);
			}
		}

		/// <summary>
		/// Event raised when the Generate Sql Tool Strip Button is clicked
		/// </summary>
		/// <param name="sender">ToolStripButton raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiGenerateSqlToolStripButton_Click(object sender, EventArgs e)
		{
			DataGridViewRow selectedRow = DataGridViewHelper.GetSelectedRow(uiProcessDataGridView);
			Process selectedProcess = selectedRow.DataBoundItem as Process;
			using (ProcessDefinitionForm definitionForm = new ProcessDefinitionForm(selectedProcess))
			{
				definitionForm.ShowDialog(this);
			}
		}

		/// <summary>
		/// Event raised when the Refresh Tool Strip Button is clicked
		/// </summary>
		/// <param name="sender">ToolStripButton raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiRefreshToolStripButtonItem_Click(object sender, EventArgs e)
		{
			LoadData();
		}

		/// <summary>
		/// Event raised when the Search Tool Strip Button is clicked
		/// </summary>
		/// <param name="sender">ToolStripButton raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiSearchToolStripButton_Click(object sender, EventArgs e)
		{
			uiMainSplitContainer.Panel1Collapsed = (!uiSearchToolStripButton.Checked);
		}

		/// <summary>
		/// Event raised when the Search Button is clicked
		/// </summary>
		/// <param name="sender">button raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiSearchByActionTypeButton_Click(object sender, EventArgs e)
		{
			using (FEEntities entities = new FEEntities())
			{
				var query = from Process process in entities.Processes
							join Data.Action action in entities.Actions
							on process.ProcessId equals action.ProcessId
							where action.ActionType == (string)uiActionTypeComboBox.SelectedValue
							select process;
				uiProcessDataGridView.DataSource = query;
			}
		}
		#endregion

		private void uiDefineTableToolStripButton_Click(object sender, EventArgs e)
		{
			using (DefineTableForm form = new DefineTableForm())
			{
				form.ShowDialog(this);
			}
		}
	}
}