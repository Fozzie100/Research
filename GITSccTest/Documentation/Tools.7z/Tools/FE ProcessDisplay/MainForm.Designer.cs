﻿namespace FEProcessDisplay
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.uiStatusStrip = new System.Windows.Forms.StatusStrip();
			this.uiProcessDataGridView = new System.Windows.Forms.DataGridView();
			this.uiMainToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiRefreshToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiGenerateSqlToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiDisplayProcessToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.uiSearchToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiDefineTableToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiMainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.uiSearchGroupBox = new System.Windows.Forms.GroupBox();
			this.uiSearchByActionTypeButton = new System.Windows.Forms.Button();
			this.uiActionTypeLabel = new System.Windows.Forms.Label();
			this.uiActionTypeComboBox = new System.Windows.Forms.ComboBox();
			((System.ComponentModel.ISupportInitialize)(this.uiProcessDataGridView)).BeginInit();
			this.uiMainToolStrip.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).BeginInit();
			this.uiMainSplitContainer.Panel1.SuspendLayout();
			this.uiMainSplitContainer.Panel2.SuspendLayout();
			this.uiMainSplitContainer.SuspendLayout();
			this.uiSearchGroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiStatusStrip
			// 
			this.uiStatusStrip.Location = new System.Drawing.Point(0, 592);
			this.uiStatusStrip.Name = "uiStatusStrip";
			this.uiStatusStrip.Size = new System.Drawing.Size(708, 22);
			this.uiStatusStrip.TabIndex = 3;
			this.uiStatusStrip.Text = "statusStrip1";
			// 
			// uiProcessDataGridView
			// 
			this.uiProcessDataGridView.AllowUserToAddRows = false;
			this.uiProcessDataGridView.AllowUserToDeleteRows = false;
			this.uiProcessDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.uiProcessDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.uiProcessDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiProcessDataGridView.Location = new System.Drawing.Point(0, 0);
			this.uiProcessDataGridView.Name = "uiProcessDataGridView";
			this.uiProcessDataGridView.ReadOnly = true;
			this.uiProcessDataGridView.Size = new System.Drawing.Size(708, 527);
			this.uiProcessDataGridView.TabIndex = 0;
			this.uiProcessDataGridView.DataSourceChanged += new System.EventHandler(this.uiProcessDataGridView_DataSourceChanged);
			// 
			// uiMainToolStrip
			// 
			this.uiMainToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiRefreshToolStripButton,
            this.uiGenerateSqlToolStripButton,
            this.uiDisplayProcessToolStripButton,
            this.uiToolStripSeparator1,
            this.uiSearchToolStripButton,
            this.uiDefineTableToolStripButton});
			this.uiMainToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiMainToolStrip.Name = "uiMainToolStrip";
			this.uiMainToolStrip.Size = new System.Drawing.Size(708, 25);
			this.uiMainToolStrip.TabIndex = 0;
			this.uiMainToolStrip.Text = "toolStrip1";
			// 
			// uiRefreshToolStripButton
			// 
			this.uiRefreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiRefreshToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiRefreshToolStripButton.Image")));
			this.uiRefreshToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiRefreshToolStripButton.Name = "uiRefreshToolStripButton";
			this.uiRefreshToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiRefreshToolStripButton.Text = "Refresh";
			this.uiRefreshToolStripButton.Click += new System.EventHandler(this.uiRefreshToolStripButtonItem_Click);
			// 
			// uiGenerateSqlToolStripButton
			// 
			this.uiGenerateSqlToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiGenerateSqlToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiGenerateSqlToolStripButton.Image")));
			this.uiGenerateSqlToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiGenerateSqlToolStripButton.Name = "uiGenerateSqlToolStripButton";
			this.uiGenerateSqlToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiGenerateSqlToolStripButton.Text = "Generate SQL for selected Process";
			this.uiGenerateSqlToolStripButton.Click += new System.EventHandler(this.uiGenerateSqlToolStripButton_Click);
			// 
			// uiDisplayProcessToolStripButton
			// 
			this.uiDisplayProcessToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiDisplayProcessToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiDisplayProcessToolStripButton.Image")));
			this.uiDisplayProcessToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiDisplayProcessToolStripButton.Name = "uiDisplayProcessToolStripButton";
			this.uiDisplayProcessToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiDisplayProcessToolStripButton.Text = "Display Selected Process";
			this.uiDisplayProcessToolStripButton.Click += new System.EventHandler(this.uiDisplayProcessToolStripButton_Click);
			// 
			// uiToolStripSeparator1
			// 
			this.uiToolStripSeparator1.Name = "uiToolStripSeparator1";
			this.uiToolStripSeparator1.Size = new System.Drawing.Size(6, 25);
			// 
			// uiSearchToolStripButton
			// 
			this.uiSearchToolStripButton.CheckOnClick = true;
			this.uiSearchToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiSearchToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiSearchToolStripButton.Image")));
			this.uiSearchToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiSearchToolStripButton.Name = "uiSearchToolStripButton";
			this.uiSearchToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiSearchToolStripButton.Text = "Search";
			this.uiSearchToolStripButton.Click += new System.EventHandler(this.uiSearchToolStripButton_Click);
			// 
			// uiDefineTableToolStripButton
			// 
			this.uiDefineTableToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiDefineTableToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiDefineTableToolStripButton.Image")));
			this.uiDefineTableToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiDefineTableToolStripButton.Name = "uiDefineTableToolStripButton";
			this.uiDefineTableToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiDefineTableToolStripButton.Text = "Define Table";
			this.uiDefineTableToolStripButton.Click += new System.EventHandler(this.uiDefineTableToolStripButton_Click);
			// 
			// uiMainSplitContainer
			// 
			this.uiMainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiMainSplitContainer.Location = new System.Drawing.Point(0, 25);
			this.uiMainSplitContainer.Name = "uiMainSplitContainer";
			this.uiMainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiMainSplitContainer.Panel1
			// 
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiSearchGroupBox);
			// 
			// uiMainSplitContainer.Panel2
			// 
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiProcessDataGridView);
			this.uiMainSplitContainer.Size = new System.Drawing.Size(708, 567);
			this.uiMainSplitContainer.SplitterDistance = 36;
			this.uiMainSplitContainer.TabIndex = 0;
			// 
			// uiSearchGroupBox
			// 
			this.uiSearchGroupBox.Controls.Add(this.uiSearchByActionTypeButton);
			this.uiSearchGroupBox.Controls.Add(this.uiActionTypeLabel);
			this.uiSearchGroupBox.Controls.Add(this.uiActionTypeComboBox);
			this.uiSearchGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiSearchGroupBox.Location = new System.Drawing.Point(0, 0);
			this.uiSearchGroupBox.Name = "uiSearchGroupBox";
			this.uiSearchGroupBox.Size = new System.Drawing.Size(708, 36);
			this.uiSearchGroupBox.TabIndex = 0;
			this.uiSearchGroupBox.TabStop = false;
			// 
			// uiSearchByActionTypeButton
			// 
			this.uiSearchByActionTypeButton.Location = new System.Drawing.Point(447, 9);
			this.uiSearchByActionTypeButton.Name = "uiSearchByActionTypeButton";
			this.uiSearchByActionTypeButton.Size = new System.Drawing.Size(75, 23);
			this.uiSearchByActionTypeButton.TabIndex = 2;
			this.uiSearchByActionTypeButton.Text = "Search";
			this.uiSearchByActionTypeButton.UseVisualStyleBackColor = true;
			this.uiSearchByActionTypeButton.Click += new System.EventHandler(this.uiSearchByActionTypeButton_Click);
			// 
			// uiActionTypeLabel
			// 
			this.uiActionTypeLabel.AutoSize = true;
			this.uiActionTypeLabel.Location = new System.Drawing.Point(8, 12);
			this.uiActionTypeLabel.Name = "uiActionTypeLabel";
			this.uiActionTypeLabel.Size = new System.Drawing.Size(194, 13);
			this.uiActionTypeLabel.TabIndex = 0;
			this.uiActionTypeLabel.Text = "Locate Process Containing Action Type";
			// 
			// uiActionTypeComboBox
			// 
			this.uiActionTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.uiActionTypeComboBox.FormattingEnabled = true;
			this.uiActionTypeComboBox.Location = new System.Drawing.Point(208, 9);
			this.uiActionTypeComboBox.Name = "uiActionTypeComboBox";
			this.uiActionTypeComboBox.Size = new System.Drawing.Size(233, 21);
			this.uiActionTypeComboBox.TabIndex = 1;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(708, 614);
			this.Controls.Add(this.uiMainSplitContainer);
			this.Controls.Add(this.uiMainToolStrip);
			this.Controls.Add(this.uiStatusStrip);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FE Process Viewer";
			((System.ComponentModel.ISupportInitialize)(this.uiProcessDataGridView)).EndInit();
			this.uiMainToolStrip.ResumeLayout(false);
			this.uiMainToolStrip.PerformLayout();
			this.uiMainSplitContainer.Panel1.ResumeLayout(false);
			this.uiMainSplitContainer.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).EndInit();
			this.uiMainSplitContainer.ResumeLayout(false);
			this.uiSearchGroupBox.ResumeLayout(false);
			this.uiSearchGroupBox.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.StatusStrip uiStatusStrip;
		private System.Windows.Forms.DataGridView uiProcessDataGridView;
		private System.Windows.Forms.ToolStrip uiMainToolStrip;
		private System.Windows.Forms.ToolStripButton uiRefreshToolStripButton;
		private System.Windows.Forms.ToolStripButton uiGenerateSqlToolStripButton;
		private System.Windows.Forms.ToolStripButton uiDisplayProcessToolStripButton;
		private System.Windows.Forms.SplitContainer uiMainSplitContainer;
		private System.Windows.Forms.ToolStripSeparator uiToolStripSeparator1;
		private System.Windows.Forms.ToolStripButton uiSearchToolStripButton;
		private System.Windows.Forms.GroupBox uiSearchGroupBox;
		private System.Windows.Forms.Button uiSearchByActionTypeButton;
		private System.Windows.Forms.Label uiActionTypeLabel;
		private System.Windows.Forms.ComboBox uiActionTypeComboBox;
		private System.Windows.Forms.ToolStripButton uiDefineTableToolStripButton;
	}
}

