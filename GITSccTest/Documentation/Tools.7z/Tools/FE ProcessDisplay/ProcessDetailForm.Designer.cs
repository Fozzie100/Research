﻿namespace FEProcessDisplay
{
	partial class ProcessDetailForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProcessDetailForm));
			this.uiNameLabel = new System.Windows.Forms.Label();
			this.uiEnabledLabel = new System.Windows.Forms.Label();
			this.uiWorkDirectoryLabel = new System.Windows.Forms.Label();
			this.uiTypeLabel = new System.Windows.Forms.Label();
			this.uiStatusStrip = new System.Windows.Forms.StatusStrip();
			this.CreatedBy = new System.Windows.Forms.ToolStripStatusLabel();
			this.uiCalendarTypeLabel = new System.Windows.Forms.Label();
			this.uiNameTextBox = new System.Windows.Forms.TextBox();
			this.uiEnabledCheckBox = new System.Windows.Forms.CheckBox();
			this.uiWorkDirectoryTextBox = new System.Windows.Forms.TextBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.uiNoteLabel = new System.Windows.Forms.Label();
			this.uiNoteTextBox = new System.Windows.Forms.TextBox();
			this.uiActionsPanel = new System.Windows.Forms.Panel();
			this.uiActionDataGridView = new System.Windows.Forms.DataGridView();
			this.uiActionToolStrip = new System.Windows.Forms.ToolStrip();
			this.uiActionToolStripLabel = new System.Windows.Forms.ToolStripLabel();
			this.uiDisplayActionToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.uiMainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.uiStatusStrip.SuspendLayout();
			this.uiActionsPanel.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiActionDataGridView)).BeginInit();
			this.uiActionToolStrip.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).BeginInit();
			this.uiMainSplitContainer.Panel1.SuspendLayout();
			this.uiMainSplitContainer.Panel2.SuspendLayout();
			this.uiMainSplitContainer.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiNameLabel
			// 
			this.uiNameLabel.AutoSize = true;
			this.uiNameLabel.Location = new System.Drawing.Point(7, 8);
			this.uiNameLabel.Name = "uiNameLabel";
			this.uiNameLabel.Size = new System.Drawing.Size(35, 13);
			this.uiNameLabel.TabIndex = 0;
			this.uiNameLabel.Text = "Name";
			// 
			// uiEnabledLabel
			// 
			this.uiEnabledLabel.AutoSize = true;
			this.uiEnabledLabel.Location = new System.Drawing.Point(7, 36);
			this.uiEnabledLabel.Name = "uiEnabledLabel";
			this.uiEnabledLabel.Size = new System.Drawing.Size(46, 13);
			this.uiEnabledLabel.TabIndex = 1;
			this.uiEnabledLabel.Text = "Enabled";
			// 
			// uiWorkDirectoryLabel
			// 
			this.uiWorkDirectoryLabel.AutoSize = true;
			this.uiWorkDirectoryLabel.Location = new System.Drawing.Point(7, 62);
			this.uiWorkDirectoryLabel.Name = "uiWorkDirectoryLabel";
			this.uiWorkDirectoryLabel.Size = new System.Drawing.Size(78, 13);
			this.uiWorkDirectoryLabel.TabIndex = 2;
			this.uiWorkDirectoryLabel.Text = "Work Directory";
			// 
			// uiTypeLabel
			// 
			this.uiTypeLabel.AutoSize = true;
			this.uiTypeLabel.Location = new System.Drawing.Point(7, 94);
			this.uiTypeLabel.Name = "uiTypeLabel";
			this.uiTypeLabel.Size = new System.Drawing.Size(31, 13);
			this.uiTypeLabel.TabIndex = 3;
			this.uiTypeLabel.Text = "Type";
			// 
			// uiStatusStrip
			// 
			this.uiStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreatedBy});
			this.uiStatusStrip.Location = new System.Drawing.Point(0, 443);
			this.uiStatusStrip.Name = "uiStatusStrip";
			this.uiStatusStrip.Size = new System.Drawing.Size(517, 22);
			this.uiStatusStrip.TabIndex = 12;
			this.uiStatusStrip.Text = "[Created By]";
			// 
			// CreatedBy
			// 
			this.CreatedBy.Name = "CreatedBy";
			this.CreatedBy.Size = new System.Drawing.Size(502, 17);
			this.CreatedBy.Spring = true;
			this.CreatedBy.Text = "[Created By]";
			this.CreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// uiCalendarTypeLabel
			// 
			this.uiCalendarTypeLabel.AutoSize = true;
			this.uiCalendarTypeLabel.Location = new System.Drawing.Point(7, 124);
			this.uiCalendarTypeLabel.Name = "uiCalendarTypeLabel";
			this.uiCalendarTypeLabel.Size = new System.Drawing.Size(76, 13);
			this.uiCalendarTypeLabel.TabIndex = 13;
			this.uiCalendarTypeLabel.Text = "Calendar Type";
			// 
			// uiNameTextBox
			// 
			this.uiNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiNameTextBox.Location = new System.Drawing.Point(94, 5);
			this.uiNameTextBox.Name = "uiNameTextBox";
			this.uiNameTextBox.Size = new System.Drawing.Size(411, 20);
			this.uiNameTextBox.TabIndex = 14;
			// 
			// uiEnabledCheckBox
			// 
			this.uiEnabledCheckBox.AutoSize = true;
			this.uiEnabledCheckBox.Location = new System.Drawing.Point(94, 35);
			this.uiEnabledCheckBox.Name = "uiEnabledCheckBox";
			this.uiEnabledCheckBox.Size = new System.Drawing.Size(15, 14);
			this.uiEnabledCheckBox.TabIndex = 15;
			this.uiEnabledCheckBox.UseVisualStyleBackColor = true;
			// 
			// uiWorkDirectoryTextBox
			// 
			this.uiWorkDirectoryTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiWorkDirectoryTextBox.Location = new System.Drawing.Point(94, 59);
			this.uiWorkDirectoryTextBox.Name = "uiWorkDirectoryTextBox";
			this.uiWorkDirectoryTextBox.Size = new System.Drawing.Size(411, 20);
			this.uiWorkDirectoryTextBox.TabIndex = 16;
			// 
			// comboBox1
			// 
			this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(94, 89);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(411, 21);
			this.comboBox1.TabIndex = 17;
			// 
			// comboBox2
			// 
			this.comboBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Location = new System.Drawing.Point(94, 120);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(411, 21);
			this.comboBox2.TabIndex = 18;
			// 
			// uiNoteLabel
			// 
			this.uiNoteLabel.AutoSize = true;
			this.uiNoteLabel.Location = new System.Drawing.Point(7, 155);
			this.uiNoteLabel.Name = "uiNoteLabel";
			this.uiNoteLabel.Size = new System.Drawing.Size(30, 13);
			this.uiNoteLabel.TabIndex = 19;
			this.uiNoteLabel.Text = "Note";
			// 
			// uiNoteTextBox
			// 
			this.uiNoteTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiNoteTextBox.Location = new System.Drawing.Point(94, 151);
			this.uiNoteTextBox.Multiline = true;
			this.uiNoteTextBox.Name = "uiNoteTextBox";
			this.uiNoteTextBox.Size = new System.Drawing.Size(411, 67);
			this.uiNoteTextBox.TabIndex = 20;
			// 
			// uiActionsPanel
			// 
			this.uiActionsPanel.Controls.Add(this.uiActionDataGridView);
			this.uiActionsPanel.Controls.Add(this.uiActionToolStrip);
			this.uiActionsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiActionsPanel.Location = new System.Drawing.Point(0, 0);
			this.uiActionsPanel.Name = "uiActionsPanel";
			this.uiActionsPanel.Size = new System.Drawing.Size(517, 218);
			this.uiActionsPanel.TabIndex = 21;
			// 
			// uiActionDataGridView
			// 
			this.uiActionDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
			this.uiActionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.uiActionDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiActionDataGridView.Location = new System.Drawing.Point(0, 25);
			this.uiActionDataGridView.Name = "uiActionDataGridView";
			this.uiActionDataGridView.ReadOnly = true;
			this.uiActionDataGridView.Size = new System.Drawing.Size(517, 193);
			this.uiActionDataGridView.TabIndex = 0;
			this.uiActionDataGridView.DataSourceChanged += new System.EventHandler(this.uiActionDataGridView_DataSourceChanged);
			// 
			// uiActionToolStrip
			// 
			this.uiActionToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiActionToolStripLabel,
            this.uiDisplayActionToolStripButton});
			this.uiActionToolStrip.Location = new System.Drawing.Point(0, 0);
			this.uiActionToolStrip.Name = "uiActionToolStrip";
			this.uiActionToolStrip.Size = new System.Drawing.Size(517, 25);
			this.uiActionToolStrip.TabIndex = 1;
			// 
			// uiActionToolStripLabel
			// 
			this.uiActionToolStripLabel.Name = "uiActionToolStripLabel";
			this.uiActionToolStripLabel.Size = new System.Drawing.Size(42, 22);
			this.uiActionToolStripLabel.Text = "Actions";
			// 
			// uiDisplayActionToolStripButton
			// 
			this.uiDisplayActionToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.uiDisplayActionToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("uiDisplayActionToolStripButton.Image")));
			this.uiDisplayActionToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.uiDisplayActionToolStripButton.Name = "uiDisplayActionToolStripButton";
			this.uiDisplayActionToolStripButton.Size = new System.Drawing.Size(23, 22);
			this.uiDisplayActionToolStripButton.Text = "Display Action";
			this.uiDisplayActionToolStripButton.Click += new System.EventHandler(this.uiDisplayActionToolStripButton_Click);
			// 
			// uiMainSplitContainer
			// 
			this.uiMainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiMainSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.uiMainSplitContainer.Name = "uiMainSplitContainer";
			this.uiMainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// uiMainSplitContainer.Panel1
			// 
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiNameTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiNoteTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiNameLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiNoteLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiEnabledLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.comboBox2);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiWorkDirectoryLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.comboBox1);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiTypeLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiWorkDirectoryTextBox);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiCalendarTypeLabel);
			this.uiMainSplitContainer.Panel1.Controls.Add(this.uiEnabledCheckBox);
			// 
			// uiMainSplitContainer.Panel2
			// 
			this.uiMainSplitContainer.Panel2.Controls.Add(this.uiActionsPanel);
			this.uiMainSplitContainer.Size = new System.Drawing.Size(517, 443);
			this.uiMainSplitContainer.SplitterDistance = 221;
			this.uiMainSplitContainer.TabIndex = 22;
			// 
			// ProcessDetailForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(517, 465);
			this.Controls.Add(this.uiMainSplitContainer);
			this.Controls.Add(this.uiStatusStrip);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "ProcessDetailForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Process Detail";
			this.uiStatusStrip.ResumeLayout(false);
			this.uiStatusStrip.PerformLayout();
			this.uiActionsPanel.ResumeLayout(false);
			this.uiActionsPanel.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.uiActionDataGridView)).EndInit();
			this.uiActionToolStrip.ResumeLayout(false);
			this.uiActionToolStrip.PerformLayout();
			this.uiMainSplitContainer.Panel1.ResumeLayout(false);
			this.uiMainSplitContainer.Panel1.PerformLayout();
			this.uiMainSplitContainer.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.uiMainSplitContainer)).EndInit();
			this.uiMainSplitContainer.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label uiNameLabel;
		private System.Windows.Forms.Label uiEnabledLabel;
		private System.Windows.Forms.Label uiWorkDirectoryLabel;
		private System.Windows.Forms.Label uiTypeLabel;
		private System.Windows.Forms.StatusStrip uiStatusStrip;
		private System.Windows.Forms.ToolStripStatusLabel CreatedBy;
		private System.Windows.Forms.Label uiCalendarTypeLabel;
		private System.Windows.Forms.TextBox uiNameTextBox;
		private System.Windows.Forms.CheckBox uiEnabledCheckBox;
		private System.Windows.Forms.TextBox uiWorkDirectoryTextBox;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.Label uiNoteLabel;
		private System.Windows.Forms.TextBox uiNoteTextBox;
		private System.Windows.Forms.Panel uiActionsPanel;
		private System.Windows.Forms.DataGridView uiActionDataGridView;
		private System.Windows.Forms.ToolStrip uiActionToolStrip;
		private System.Windows.Forms.ToolStripLabel uiActionToolStripLabel;
		private System.Windows.Forms.SplitContainer uiMainSplitContainer;
		private System.Windows.Forms.ToolStripButton uiDisplayActionToolStripButton;
	}
}