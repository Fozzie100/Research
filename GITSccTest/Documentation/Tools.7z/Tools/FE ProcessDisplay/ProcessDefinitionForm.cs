﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using FEProcessDisplay.Data;

namespace FEProcessDisplay
{
	/// <summary>
	/// Form used to generate the Sql definition of a process
	/// </summary>
	public partial class ProcessDefinitionForm : Form
	{
		const string Tab = "\t";

		private Process _process;

		#region Constructors
		/// <summary>
		/// Private Constructor to prevent incorrect instantiation
		/// </summary>
		private ProcessDefinitionForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Creates a new instance of ProcessDefinitionForm
		/// </summary>
		/// <param name="process">Process to Create script for</param>
		public ProcessDefinitionForm(Process process) : this()
		{
			_process = process;
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Event raised when the Form Loads
		/// </summary>
		/// <param name="e">EventArgs object</param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			using (FEEntities entities = new FEEntities())
			{

				List<Data.Action> actions = (from Data.Action action in entities.Actions
											where action.ProcessId == _process.ProcessId
											orderby action.ActionOrder
											select action).ToList();

				List<Data.Parameter> parameters = (from Data.Parameter parameter in entities.Parameters
												   where parameter.Action.ProcessId == _process.ProcessId
												   select parameter).ToList();

				List<string> sqlLines = new List<string>();
				sqlLines.Add("USE FE");
				sqlLines.Add("GO");
				sqlLines.Add(string.Empty);
				sqlLines.Add("DECLARE @ProcessName VARCHAR(55)");
				sqlLines.Add("DECLARE @ProcessId INT");
				sqlLines.Add("DECLARE @ActionId INT");
				sqlLines.Add("BEGIN TRY");
				sqlLines.Add(string.Empty);
				sqlLines.Add(Tab + "BEGIN TRANSACTION");
				sqlLines.Add(string.Empty);
				sqlLines.Add(Tab + "--DELETE EXISTING PROCESS IF IT EXISTS");
				sqlLines.Add(Tab + "SET @ProcessName = '" + _process.Name + "'");
				sqlLines.Add(Tab + "SET @ProcessId = (SELECT ProcessId FROM FE.Process WHERE Name = @ProcessName)");
				sqlLines.Add(Tab + "DELETE FROM [FE].[Parameter] FROM [FE].[Parameter] INNER JOIN [FE].[Action] ON [FE].[Parameter].ActionId = [FE].Action.ActionId WHERE ProcessId = @ProcessId");
				sqlLines.Add(Tab + "DELETE FROM [FE].[Action] WHERE  ProcessId = @ProcessId");
				sqlLines.Add(Tab + "DELETE FROM [FE].[Process] where ProcessId = @ProcessId");

				sqlLines.Add(string.Empty);
				sqlLines.Add(Tab + "--CREATE THE PROCESS");
				OutputProcess(sqlLines);
				sqlLines.Add(Tab + "--CREATE ACTIONS AND RELATED PARAMETERS");

				foreach (Data.Action action in actions)
				{
					OutputAction(sqlLines, action);

					List<Data.Parameter> actionParameters = (from Data.Parameter parameter in parameters
															 where parameter.ActionId == action.ActionId
															 select parameter).ToList();

					foreach (Data.Parameter parameter in actionParameters)
					{
						OutputParameter(sqlLines, parameter);
					}
				}

				sqlLines.Add(Tab + "COMMIT TRANSACTION");
				sqlLines.Add(string.Empty);
				sqlLines.Add("END TRY");
				sqlLines.Add(string.Empty);
				sqlLines.Add("BEGIN CATCH");
				sqlLines.Add(Tab + "SELECT ERROR_NUMBER() AS ErrorNumber ,ERROR_SEVERITY() AS ErrorSeverity ,ERROR_STATE() AS ErrorState ,ERROR_PROCEDURE() AS ErrorProcedure ,ERROR_LINE() AS ErrorLine ,ERROR_MESSAGE() AS ErrorMessage;");
				sqlLines.Add(Tab + "ROLLBACK TRANSACTION");
				sqlLines.Add("END CATCH");

				uiSqlTextBox.Lines = sqlLines.ToArray();
			}
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the Save button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiSaveButton_Click(object sender, EventArgs e)
		{
			uiSaveFileDialog.Filter = "SQL Script|*.sql";
			if (uiSaveFileDialog.ShowDialog(this) == DialogResult.OK)
			{
				string filePath = uiSaveFileDialog.FileName;
				WriteLines(filePath, uiSqlTextBox.Lines);
			}
		}

		/// <summary>
		/// Event raised when the Copy to clipboard button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiCopyToClipboardButton_Click(object sender, EventArgs e)
		{
			Clipboard.SetText(uiSqlTextBox.Text);
		}	
		#endregion

		#region Private Methods
		/// <summary>
		/// Generates the Sql for a Process
		/// </summary>
		/// <param name="sqlLines">List string to append to</param>
		private void OutputProcess(List<string> sqlLines)
		{
			string valueFormat = GenerateSqlValuesFormat(9);
			sqlLines.Add(Tab + "INSERT INTO FE.Process (Name, Enabled, WorkDirectory, Type, DeliveryTimeApprox, CalendarType, CalendarDays, Note, TemplateId)");
			sqlLines.Add(Tab + string.Format(valueFormat, "@ProcessName", ToSqlString(_process.Enabled), ToSqlString(_process.WorkDirectory), ToSqlString(_process.Type), ToSqlString(_process.DeliveryTimeApprox), ToSqlString(_process.CalendarType), ToSqlString(_process.CalendarDays), ToSqlString(_process.Note), ToSqlString(_process.TemplateId)));
			sqlLines.Add(Tab + "SET @ProcessId = (SELECT ProcessId FROM FE.Process WHERE Name = @ProcessName)");
			sqlLines.Add(string.Empty);
		}

		/// <summary>
		/// Generates the Sql for an Action
		/// </summary>
		/// <param name="sqlLines">List string to append to</param>
		/// <param name="action">Action to output</param>
		private void OutputAction(List<string> sqlLines, Data.Action action)
		{
			string valueFormat = GenerateSqlValuesFormat(9);
			sqlLines.Add(Tab + "--CREATE ACTION " + action.ActionOrder);
			sqlLines.Add(Tab + "INSERT INTO FE.[Action] (ProcessId, ActionOrder, Condition, ActionType, ActionCommand, OnError, Note, Enabled, [User])");
			sqlLines.Add(Tab + string.Format(valueFormat, "@ProcessId", action.ActionOrder, ToSqlString(action.Condition), ToSqlString(action.ActionType), ToSqlString(action.ActionCommand), ToSqlString(action.OnError), ToSqlString(action.Note), ToSqlString(action.Enabled), ToSqlString(action.User)));
			sqlLines.Add(Tab + "SET @ActionId = (SELECT ActionId FROM FE.Action WHERE ProcessId = @ProcessId AND ActionOrder = " + action.ActionOrder + ")");
			sqlLines.Add(string.Empty);
		}

		/// <summary>
		/// Generates the Sql for a Parameter
		/// </summary>
		/// <param name="sqlLines">List string to append to</param>
		/// <param name="parameter">Parameter to output</param>
		private void OutputParameter(List<string> sqlLines, Data.Parameter parameter)
		{
			string valueFormat = GenerateSqlValuesFormat(6);
			sqlLines.Add(Tab + "INSERT INTO FE.Parameter (ActionId, Name, Value, DbType, Note, [User])");
			sqlLines.Add(Tab + string.Format(valueFormat, "@ActionId", ToSqlString(parameter.Name), ToSqlString(parameter.Value), ToSqlString(parameter.DbType), ToSqlString(parameter.Note), ToSqlString(parameter.User)));
			sqlLines.Add(string.Empty);
		}

		/// <summary>
		/// Generates the Format for a Sql Values Statement with the appropriate number of fields
		/// </summary>
		/// <param name="numberOfColumns">Number of columns required</param>
		/// <returns>string</returns>
		private string GenerateSqlValuesFormat(int numberOfColumns)
		{
			List<string> fields = new List<string>();
			for (int i = 0; i < numberOfColumns; i++)
			{
				fields.Add(string.Concat("{", i, "}"));
			}
			return string.Format("VALUES ({0})", string.Join(", ", fields));
		}

		/// <summary>
		/// Writes strings to a file
		/// </summary>
		/// <param name="filePath">Path to the file</param>
		/// <param name="lines">string array to write</param>
		public static void WriteLines(string filePath, string[] lines)
		{
			if (lines != null)
			{
				using (TextWriter writer = new StreamWriter(filePath))
				{
					foreach (string line in lines)
					{
						writer.WriteLine(line);
					}
				}
			}
		}

		/// <summary>
		/// Creates a nullable string for a string
		/// </summary>
		/// <param name="value">string value</param>
		/// <returns>string</returns>
		private string ToSqlString(string value)
		{
			return value == null ? "NULL" : "'" + value.Replace("'", "''") + "'";
		}

		/// <summary>
		/// Creates a nullable string for a short
		/// </summary>
		/// <param name="value">short value</param>
		/// <returns>string</returns>
		private string ToSqlString(short? value)
		{
			return value == null ? "NULL" : value.ToString();
		}

		/// <summary>
		/// Creates a nullable string for an int
		/// </summary>
		/// <param name="value">int value</param>
		/// <returns>string</returns>
		private string ToSqlString(int? value)
		{
			return value == null ? "NULL" : value.ToString();
		}

		/// <summary>
		/// Creates a nullable string for a DateTime
		/// </summary>
		/// <param name="value">string value</param>
		/// <returns>string</returns>
		private string ToSqlString(DateTime? value)
		{
			//todo check format, may need changing
			return value == null ? "NULL" : "'" + value.Value.ToString("yyyy MMM dd hh:mm:ss") + "'";
		}

		/// <summary>
		/// Creates a string for a bool
		/// </summary>
		/// <param name="value">bool value</param>
		/// <returns>string</returns>
		private string ToSqlString(bool value)
		{
			return value ? "1" : "0";
		}
		#endregion
	}
}
