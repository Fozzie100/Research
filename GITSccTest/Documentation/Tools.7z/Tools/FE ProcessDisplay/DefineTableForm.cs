﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using FEProcessDisplay.Properties;
using FEProcessDisplay.Data;
using System.Configuration;

namespace FEProcessDisplay
{
	/// <summary>
	/// Form used to define a table
	/// </summary>
	public partial class DefineTableForm : Form
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of DefineTableForm
		/// </summary>
		public DefineTableForm()
		{
			InitializeComponent();
		}	
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raused when the generate button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs</param>
		private void uiGenerateButton_Click(object sender, EventArgs e)
		{
			uiResultsTextBox.Text = string.Empty;
			string tableDefinition = string.Empty;
			string sqlStatement = "SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName ORDER BY ORDINAL_POSITION";
			List<string> columnDefinitions = new List<string>();

			try
			{
				string connectionString = string.Empty;
				using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["FEProcessDisplay.Properties.Settings.PrimeConnectionString"].ConnectionString))
				{
					connection.Open();
					using (SqlCommand command = connection.CreateCommand())
					{
						command.CommandText = sqlStatement;
						command.CommandType = CommandType.Text;
						command.Parameters.AddWithValue("@TableName", uiTableNameTextBox.Text);
						command.Parameters.AddWithValue("@SchemaName", uiSchemaTextBox.Text);
						using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
						{
							while (reader.Read())
							{
								string dataType = reader["DATA_TYPE"].ToString();
								string columnSize = reader["CHARACTER_MAXIMUM_LENGTH"].ToString();
								string numericPrecision = reader["NUMERIC_PRECISION"].ToString();
								string numericScale = reader["NUMERIC_SCALE"].ToString();
								string columnDefinition = ConstructColumnDefinition(reader["COLUMN_NAME"].ToString(), dataType, columnSize, numericPrecision, numericScale);
								columnDefinitions.Add(columnDefinition);
							}
							tableDefinition = string.Join("; ", columnDefinitions.ToArray());
							reader.Close();
						}
					}
				}
				uiResultsTextBox.Text = string.Concat("{", tableDefinition, ";}");
				uiResultsTextBox.Focus();
				uiResultsTextBox.SelectAll();
			}
			catch (Exception ex)
			{
				MessageBox.Show(this, ex.Message, "Unable to define table", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		#endregion

		#region Private Methods
		/// <summary>
		/// Constructs the definition for a database column  as expected by a dataflow task
		/// </summary>
		/// <param name="columnName">Name of the database column</param>
		/// <param name="dataType">Name of the datatype</param>
		/// <param name="columnSize">Column Size</param>
		/// <param name="precision">Precision</param>
		/// <param name="scale">Scale</param>
		/// <returns>string</returns>
		private string ConstructColumnDefinition(string columnName, string dataType, string columnSize, string precision, string scale)
		{
			switch (dataType.ToLower())
			{
				case "char":
				case "varchar":
					return string.Concat(columnName, ", ", dataType, "(", columnSize, ")");
				case "decimal":
					return string.Concat(columnName, ", ", dataType, "(", precision, ",", scale, ")");
				case "date":
				case "datetime":
				case "float":
				case "int":
				case "bigint":
					return string.Concat(columnName, ", ", dataType);
				default:
					throw new ArgumentOutOfRangeException(string.Concat("Unknown datatype: ", dataType));
			}
		}		
		#endregion
	}
}