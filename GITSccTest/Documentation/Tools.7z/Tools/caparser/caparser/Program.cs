﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Ftse.Research.Framework.IO;
using SWIFTUtils;

namespace caparser
{
	class Program
	{
		private static string _fileName;
		private static string _sourcedirectoryName;
		private static string _outputDirectoryName;
		private static bool _isVerboseOutput;
		private static bool _isIgnoreFailure;

		static void Main(string[] args)
		{
			if (!Initialize(args))
			{
				UsageInfo();
				return;
			}

			string sourcePath;
			List<FileInfo> filesCollection;
			if (!String.IsNullOrEmpty(_fileName))
			{
				var file = new FileInfo(_fileName);
				filesCollection = new List<FileInfo> {file};
				sourcePath = file.DirectoryName;
			}
			else
			{
				var directoryInfo = new DirectoryInfo(_sourcedirectoryName);
				filesCollection = directoryInfo.EnumerateFiles("*.txt", SearchOption.TopDirectoryOnly).ToList();
				sourcePath = directoryInfo.FullName;
			}
			DirectoryInfo targetDirectory = !String.IsNullOrEmpty(_outputDirectoryName) ? new DirectoryInfo(_outputDirectoryName) : new DirectoryInfo(sourcePath);

			foreach (var file in filesCollection) 
			{
				Console.Write("Parsing file {0}  ...", file.FullName);

				var swiftMessageFile = new SwiftMessage564File {IsIgnoreFailure = _isIgnoreFailure};
				swiftMessageFile.ParseFile(file.FullName, _isVerboseOutput);

				Console.WriteLine("Parsing COMPLETED: valid messages: {0}, invalid: {1}, messages with warnings: {2}", swiftMessageFile.MessagesCount, swiftMessageFile.MessagesBadCount, swiftMessageFile.MessagesWithWarningsCount);

				
				Console.Write("Writing output files to {0}...", targetDirectory);
				swiftMessageFile.WriteFiles(targetDirectory.FullName, file.FullName);
				Console.WriteLine("done.");
			}
		}

		/// <summary>
		/// Reads command line arguments
		/// </summary>
		/// <param name="args"></param>
		/// <returns></returns>
		private static bool Initialize(string[] args)
		{
			// Return false if -? help requested
			if (args.Length > 0 && (args[0] == "-?" || args[0] == "/?"))
				return false;

			var argumentsParser = new ArgumentParser(args);
			foreach (var entry in argumentsParser.Parameters)
				switch (entry.Key)
				{
					case "file": _fileName = entry.Value;
						break;
					case "dir":
					case "directory": _sourcedirectoryName = entry.Value;
						break;
					case "output": _outputDirectoryName = entry.Value;
						break;
					case "v": _isVerboseOutput = true;
						break;
					case "ignorefailure": _isIgnoreFailure = true;
						break;
				}

			return !String.IsNullOrWhiteSpace(_fileName) || !String.IsNullOrWhiteSpace(_sourcedirectoryName);
		}

		/// <summary>
		/// Write usage info to the console
		/// </summary>
		private static void UsageInfo()
		{
			Console.WriteLine();
			Console.WriteLine("FTSE SWIFT MT564 Messages (Corporate Actions) Parser. 2012 - {0:yyyy}", DateTime.Now);
			Console.WriteLine("Parses files with messages adhering to the SWIFT ISO 15022 MT564 and outputs delimited files.");
			Console.WriteLine("Usage: caparser.exe (-file ShortFileName | -directory path) [-output path]");

			Console.WriteLine("-file fullfilename\n\t\tparses and converts a single file");
			Console.WriteLine("-dir path\n\t\tparses all text files in directory");
			Console.WriteLine("-output path\n\t\tOptional parameter specifying output directory.");
			Console.WriteLine("-v\n\t\tSpecifies that full message information is output while parsing.");
			Console.WriteLine("-ignorefailure\n\t\tAllows to ignore some expections in messages and parse the rest successfully. Any unrecognized messages will be placed in .bad file(s).");
			Console.WriteLine("If -output is not specified the output files go to the source directory.");
		}
	}
}