﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	public class SubsequenceE2 : SequenceE
	{
		#region Fields
		private bool _hasParsedField19B;
		private readonly int _subsequenceNumber;
		#endregion

		#region SWIFT Message attributes
		/// <summary>
		/// 22A
		/// </summary>
		public string IndicatorType { get; set; }

		/// <summary>
		/// 22A
		/// </summary>
		public new string Indicator { get; set; }

		/// <summary>
		/// 97A
		/// </summary>
		public string CashAccount { get; set; }

		/// <summary>
		/// 19B
		/// </summary>
		public string AmountType { get; private set; }
		/// <summary>
		/// 19B
		/// </summary>
		public string AmountCurrency { get; private set; }
		/// <summary>
		/// 19B
		/// </summary>
		public decimal? Amount { get; private set; }

		/// <summary>
		/// 98A - PayDate
		/// </summary>
		public DateTime? PayDate { get; private set; }
		/// <summary>
		/// 98A - ValueDate
		/// </summary>
		public DateTime? ValueDate { get; private set; }
		/// <summary>
		/// 98A - Earliest Payment Date
		/// </summary>
		public DateTime? EarliestPayDate { get; private set; }
		/// <summary>
		/// 98A - FX Rate Fixing Date
		/// </summary>
		public DateTime? FxRateFixingDate { get; set; }
		
		/// <summary>
		/// 92A - Rate
		/// </summary>
		public decimal? AdditionalTaxRate { get; private set; }
		public decimal? ChangesFeesRate { get; private set; }
		public decimal? EarlySolicitationRate { get; private set; }
		public decimal? FinalDividendRate { get; private set; }
		public new decimal? FullyFrankedRate { get; private set; }
		public decimal? FiscalStampRate { get; private set; }
		public new decimal? DividendGrossRate { get; private set; }
		public decimal? ExchangeRate { get; set; }
		public decimal? CashIncentiveRate { get; private set; }
		public decimal? InterestRate { get; private set; }
		public decimal? DividendNetRate { get; private set; }
		public decimal? NonResidentRate { get; private set; }
		public new decimal? ProvDividendRate { get; private set; }
		public decimal? ApplicableRate { get; private set; }
		public decimal? SolicitationFeeRate { get; private set; }
		public new decimal? TaxCreditRate { get; private set; }
		public new decimal? TaxRelatedRate{ get; private set; }
		public decimal? TaxWithholdingRate { get; private set; }
		public decimal? TaxOnIncomeRate { get; private set; }
		public decimal? TaxOnProfitsRate { get; private set; }
		public decimal? ReclaimTaxRate { get; private set; }
		public decimal? WithholdingForeignTax { get; private set; }
		public decimal? WithholdingLocalTax { get; private set; }
		
		/// <summary>
		/// 92
		/// </summary>
		public decimal? RateQuantity { get; private set; }

		/// <summary>
		/// 92A - Rate Note
		/// </summary>
		public new string RateCurrency { get; private set; }

		/// <summary>
		/// 90A
		/// </summary>
		public new string PriceCurrency { get; private set; }

		/// <summary>
		/// 90A
		/// </summary>
		public decimal? Price { get; private set; }
		#endregion

		public SubsequenceE2(string caRef, string senderRef, int caOptionNumber, int number) : base(caRef, senderRef)
		{
			CAOptionNumber = caOptionNumber;
			_subsequenceNumber = number;
		}

		/// <summary>
		/// Main method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public override void Parse(string code, string text)
		{
			switch (code)
			{
				case "22H": 
				case "22F":
							ParseField22A(text); // Files contain 22H not 22A 
					break;
				case "97A" : 
				case "97E":
							ParseField97A(text);
					break;

				case "92J":
				case "92K": ParseField92(code, text);// Our files contain 92K (not in standard)- NO, not true
					break;
				case "19B": ParseField19B(text);
					break;
				case "98A":
				case "98B": 
				case "98C":
				case "98E":
							ParseField98B(text);
					break;
				case "92A":
				case "92F": // In our files we get 92F instead of 92A!
				case "92B": ParseField92(code, text);
					break;
				case "90A": 
				case "90B":
				case "90E":
				case "90F":
				case "90J": ParseField90A(text); break;
				case "16S": // Nop
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}

		public void ParseField22A(string input)
		{
			// Option H
			if (Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))
			{
				var s = input.Split(new[] { "//" }, StringSplitOptions.None);
				IndicatorType = s[0];
				Indicator = s[1];
				return;
			}

			// Option F
			if (Regex.IsMatch(input, @"^[A-Z]{4}/{0,2}[A-Z]*/[A-Z]{4}$"))
			{
				IndicatorType = input.Substring(0, input.IndexOf("/", StringComparison.Ordinal));
				Indicator = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
				return;
			}

			throw new UnexpectedCodeException(String.Format("{0}: The input {1} for 22A does not match any of the options.", GetType().Name, input));
		}

		/// <summary>
		/// Account: Cash Account
		/// </summary>
		/// <example>	Option A	:4!c//35x	(Qualifier)(Account Number)
		///				Option E	:4!c//34x	(Qualifier)(International Bank Account Number)</example>
		public void ParseField97A(string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			switch (s[0])
			{
				case "CASH": CashAccount = s[1]; break;
				default:
					throw new UnexpectedCodeException(String.Format("{0}: Unexpected code in field 97A.", GetType().Name));
			}
		}

		/// <summary>
		/// Amount
		/// </summary>
		public void ParseField19B(string input)
		{
			if (_hasParsedField19B)
				throw new MoreThanOneParseAttemptException(String.Format("{0}: Field 19B has already been parsed.", GetType().Name));

			_hasParsedField19B = true;
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			if (s[1] == "UKWN")
				return;

			AmountType = s[0];
			AmountCurrency = s[1].Substring(0, 3);
			Amount = ParseDecimalFr(s[1].Substring(3));
		}


		public void ParseField98B(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			
			switch (s[0])
			{
				case "PAYD": PayDate = ParseDateOptionalTime(s[1]); break;
				case "VALU": ValueDate = ParseDateOptionalTime(s[1]); break;
				case "EARL": EarliestPayDate = ParseDateOptionalTime(s[1]); break;
				case "FXDT": FxRateFixingDate = ParseDateOptionalTime(s[1]); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered in field 98A.", GetType().Name, s[1]));
			}
		}

		/// <summary>
		/// Parse field 92 (http://www.iso15022.org/uhb/uhb/mt564-92-field-92a.htm)
		/// </summary>
		/// <param name="code"></param>
		/// <param name="input"></param>
		public void ParseField92(string code, string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			decimal? rate = null;

			switch (code.Substring(2, 1))
			{
				case "A": rate = ParseDecimalFr(s[1]);
					break;

				case "B":
					RateCurrency = s[1].Substring(0, s[1].LastIndexOf("/", StringComparison.Ordinal));
					rate = decimal.Parse(s[1].Substring(s[1].LastIndexOf("/", StringComparison.Ordinal)+1), CultureInfo.CreateSpecificCulture("fr-FR"));
					break;

				case "F":
					RateCurrency = s[1].Substring(0, 3);
					rate = ParseDecimalFr(s[1].Substring(3));
					break;

				case "J":
					var splitJ = s[1].Split(new[] { "/" }, StringSplitOptions.None);
					RateCurrency = splitJ[1].Substring(0, 3);
					RateQuantity = ParseDecimalFr(splitJ[1].Substring(3));
					break;

				case "K":
					//RateType = s[1];
					break;

				case "M":
					var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					RateQuantity = ParseDecimalFr(splitB[1]);
					RateCurrency = splitB[0].Substring(0, 3);
					rate = ParseDecimalFr(splitB[0].Substring(3));
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unrecognized code option {1} in field 92.", GetType().Name, input.Substring(2, 1)));
			}

			switch(s[0])
			{
				case "ATAX": AdditionalTaxRate = rate; break;
				case "CHAR": ChangesFeesRate = rate;break; 
				case "ESOF": EarlySolicitationRate = rate; break;
				case "FDIV": FinalDividendRate = rate; break;
				case "FLFR": FullyFrankedRate = rate; break;
				case "FISC": FiscalStampRate = rate; break;
				case "GRSS": DividendGrossRate = rate; break;
				case "EXCH": ExchangeRate = rate; break;
				case "INCE": CashIncentiveRate = rate; break;
				case "INTP": InterestRate = rate; break;
				case "NETT": DividendNetRate = rate; break;
				case "NRES": NonResidentRate = rate; break;
				case "PDIV": ProvDividendRate = rate; break;
				case "RATE": ApplicableRate = rate; break;
				case "SOFE": SolicitationFeeRate = rate; break;
				case "TAXC": TaxCreditRate = rate; break;
				case "TAXE": TaxRelatedRate = rate; break;
				case "TAXR": TaxWithholdingRate = rate; break;
				case "TXIN": TaxOnIncomeRate = rate; break;
				case "TXPR": TaxOnProfitsRate = rate; break;
				case "TXRC": ReclaimTaxRate = rate; break;
				case "WITF": WithholdingForeignTax = rate; break;
				case "WITL": WithholdingLocalTax = rate; break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code in Field 92.", GetType().Name));
			}
		}

		/// <summary>
		/// Price
		/// </summary>
		/// <example>	Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///				Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///				Option E	:4!c//4!c	(Qualifier)(Price Code)
		///				Option F	:4!c//4!c/3!a15d/4!c/15d	(Qualifier)(Amount Type Code)(Currency Code)(Amount)(Quantity Type Code)(Quantity)
		///				Option J	:4!c//4!c/3!a15d/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Amount)(Currency Code)(Amount)
		///				Option K	:4!c//15d	(Qualifier)(Index Points)</example>
		/// <param name="input"></param>
		public new void ParseField90A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			var split2 = s[1].Split(new[] { "/" }, 2, StringSplitOptions.None);

			switch (s[0])
			{
				case "EXER":
				case "OFFR":
				case "PRPP":

					// E
					if (split2[0] == "UKWN" || split2[0] == "NILP" || split2[0] == "TBSP" || split2[0] == "UNSP")
					{
						Price = null;
						break;
					}

					// B, A
					try
					{
						Price = ParseDecimalFr(split2[1]);
					}
					catch (FormatException)
					{   // B
						PriceCurrency = split2[1].Substring(0, 3);
						Price = ParseDecimalFr(split2[1].Substring(3));
					}

					break;

				default:
					throw new UnexpectedCodeException(String.Format("{0}: Unexpected qualifier {1} encountered in field 90A.", GetType().Name, s[1]));
			}
		}

		public new static string GetHeaders()
		{
			return "CARef|SenderRef|CAOptionNumber|SeqNum|IndicatorType|Indicator|CashAccount|AmountType|AmountCurrency|Amount|PayDate|ValueDate|EarliestPayDate|FXRateFixingDate|AdditionalTaxRate|ChangesFeesRate|EarlySolicitationRate" +
			       "|FinalDividendRate|FullyFrankedRate|FiscalStampRate|DividendGrossRate|ExchangeRate|CashIncentiveRate|InterestRate|DividendNetRate|NonResidentRate|ProvDividendRate" +
			       "|ApplicableRate|SolicitationFeeRate|TaxCreditRate|TaxRelatedRate|TaxWithholdingRate|TaxOnIncomeRate|TaxOnProfitsRate|ReclaimTaxRate|WithholdingForeignTax|WithholdingLocalTax" +
			       "|RateQuantity|RateCurrency|PriceCurrency|Price";
		}

		public override string ToString()
		{
			return CARef + "|" + SenderRef + "|" + CAOptionNumber + "|" + _subsequenceNumber + "|" + IndicatorType + "|" + Indicator + "|" + CashAccount + "|" + AmountType + "|" + AmountCurrency + "|" + Amount + "|" + PayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ValueDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EarliestPayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + FxRateFixingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + AdditionalTaxRate + "|" + ChangesFeesRate + "|" + EarlySolicitationRate +
			       "|" + FinalDividendRate + "|" + FullyFrankedRate + "|" + FiscalStampRate + "|" + DividendGrossRate + "|" + ExchangeRate + "|" + CashIncentiveRate + "|" + InterestRate + "|" + DividendNetRate + "|" + NonResidentRate + "|" + ProvDividendRate +
			       "|" + ApplicableRate + "|" + SolicitationFeeRate + "|" + TaxCreditRate + "|" + TaxRelatedRate + "|" + TaxWithholdingRate + "|" + TaxOnIncomeRate + "|" + TaxOnProfitsRate + "|" + ReclaimTaxRate + "|" + WithholdingForeignTax + "|" + WithholdingLocalTax +
			       "|" + RateQuantity + "|" + RateCurrency + "|" + PriceCurrency + "|" + Price;
		}
	}
}