﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	public class SwiftMessage564File
	{
		private List<SwiftMessage564> _swiftMessage564S = new List<SwiftMessage564>();
		private List<SwiftMessage564> _swiftMessage564SWithErrors = new List<SwiftMessage564>();
		private readonly List<SwiftMessage564> _swiftMessage564SWarnings = new List<SwiftMessage564>(); 
		
		public int MessagesCount
		{
			get { return _swiftMessage564S.Count; }
		}
		public int MessagesBadCount
		{
			get { return _swiftMessage564SWithErrors.Count; }
		}
		public int MessagesWithWarningsCount
		{
			get { return _swiftMessage564SWarnings.Count; }
		}

		/// <summary>
		/// Indicates if certain exceptions are to be raised
		/// </summary>
		public bool IsIgnoreFailure { get; set; }

		public void ParseFile(string fileName, bool isVerboseOutput)
		{
			_swiftMessage564S = new List<SwiftMessage564>();
			_swiftMessage564SWithErrors = new List<SwiftMessage564>();

			Console.WriteLine("Parsing messages from file {0} ...", fileName);
			using (var sr = new StreamReader(fileName))
			{
				String line;
				var messageLines = new List<string>(100);

				// Read and display lines from the file until the end of the file is reached
				while ((line = sr.ReadLine()) != null)
				{
					if (String.IsNullOrEmpty(line))
						continue;

					messageLines.Add(line);
					// End of message
					if (line != "-}$")
						continue;

					// End of message -> Parse
					var swiftMessage564 = new SwiftMessage564(messageLines);
					Console.Write("Parsing message...");
					
					try
					{
						swiftMessage564.Parse(isVerboseOutput);
						swiftMessage564.IsValid = true;

						// If such message (CARef,SenderRef) already exists -> Update
						SwiftMessage564 messageFound = _swiftMessage564S.FirstOrDefault(m => m.SequenceA.CARef == swiftMessage564.SequenceA.CARef && m.SequenceA.SenderRef == swiftMessage564.SequenceA.SenderRef);
						if (messageFound != null)
							_swiftMessage564S.Remove(messageFound);

						_swiftMessage564S.Add(swiftMessage564);

						if (swiftMessage564.UnexpectedCodeExceptions.Count > 0)
						{
							_swiftMessage564SWarnings.Add(swiftMessage564);
							Console.WriteLine("Message [CORP: {0} SEME:{1}] parsed ok, however the following issues were encountered:", swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef);
							foreach (var exception in swiftMessage564.UnexpectedCodeExceptions)
							{
								Exception codeEx = exception;
								while (codeEx != null)
								{
									Console.WriteLine(codeEx.Message);
									codeEx = codeEx.InnerException;
								}
							}
						}
						else
						{
							Console.WriteLine("Message [CORP:{0} SEME:{1}] parsed ok.", swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef);	
						}
						
						messageLines.Clear();
					}
					catch (NotRequiredMessageException)
					{
						Console.WriteLine("Message [CORP:{0} SEME:{1}] is of type {2} and it is NOT required. Skipping.", swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef, swiftMessage564.SequenceA.CAType);
						messageLines.Clear();
					}
					catch (Exception ex)
					{
						// Rethrow exception if message is in set of required types and we haven't put a parameter to ignore
						if (swiftMessage564.IsRequiredType)
						{
							Console.WriteLine("One or more errors rendered message [CORP:{0} SEME:{1}] invalid. Invalid messages are not output in the output files but placed in .bad files. More Info: {2}",
							                  swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef, ex.Message);
							swiftMessage564.IsValid = false;

							swiftMessage564.ProcessingException = ex; // ?
							_swiftMessage564SWithErrors.Add(swiftMessage564);

							if (!IsIgnoreFailure)
								throw;
						}
						else
							Console.WriteLine("One or more errors rendered message [CORP:{0} SEME:{1}] invalid but it is not required and will be ignored. More Info: {2} ",
							                  swiftMessage564.SequenceA.CARef, swiftMessage564.SequenceA.SenderRef, ex.Message);
					}
				}
			}
			Console.WriteLine("Finished parsing messages in file {0}", fileName);

			if (_swiftMessage564SWithErrors.Count <= 0)
				return;

			string destFileName = fileName + ".bad";
			Console.WriteLine("There are {0} messages with errors. Writing them in file {1}", _swiftMessage564SWithErrors, destFileName);

			using (var writer = new StreamWriter(destFileName))
				foreach (var swiftMessage564SWithError in _swiftMessage564SWithErrors)
				{
					writer.WriteLine("The following exception was encountered while parsing this message: {0}", swiftMessage564SWithError.ProcessingException.Message);
					writer.WriteLine(swiftMessage564SWithError.OriginalMessage);
					writer.WriteLine();
				}
		}

		/// <summary>
		/// Write out files - flat delimited files. In case of no valid messages files contain headers only
		/// </summary>
		/// <param name="targetDirectoryName"></param>
		/// <param name="sourceFileName"></param>
		public void WriteFiles(string targetDirectoryName, string sourceFileName)
		{
			var validMessages = _swiftMessage564S.Where(swiftMessage564 => swiftMessage564.IsValid).ToList();

			// F1
			var targetF1 = GetTargetFileName(targetDirectoryName, sourceFileName, "F1");
			using (var writer = new StreamWriter(targetF1))
			{
				// Headers
				writer.WriteLine(SequenceA.GetHeaders() + "|" + SequenceB.GetHeaders() + "|" + SequenceC.GetHeaders() + "|" + SequenceD.GetHeaders() + "|" + SequenceF.GetHeaders());

				foreach (var swiftMessage564 in validMessages)
					writer.WriteLine(swiftMessage564.SequenceA + "|" + swiftMessage564.SequenceB + "|" + swiftMessage564.SequenceC + "|" + swiftMessage564.SequenceD + "|" + swiftMessage564.SequenceF);
			}

			// F2
			var targetF2 = GetTargetFileName(targetDirectoryName, sourceFileName, "F2");
			using (var writer = new StreamWriter(targetF2))
			{
				// Headers
				writer.WriteLine(SequenceE.GetHeaders());
				// Lines
				foreach (var seqE in from message in validMessages where message.SequencesE != null 
									 from seqE in message.SequencesE where seqE != null 
									 select seqE)
					writer.WriteLine(seqE);
			}

			// F3
			var targetF3 = GetTargetFileName(targetDirectoryName, sourceFileName, "F3");
			using (var writer = new StreamWriter(targetF3))
			{
				// Headers
				writer.WriteLine(SubsequenceE1.GetHeaders());

				// Lines
				foreach (var subE1 in from message in validMessages where message.SequencesE != null 
									  from seqE in message.SequencesE where seqE != null 
									  from subE1 in seqE.SubsequenceE1S select subE1)
					writer.WriteLine(subE1);
			}

			// F4
			var targetF4 = GetTargetFileName(targetDirectoryName, sourceFileName, "F4");
			using (var writer = new StreamWriter(targetF4))
			{
				// Headers
				writer.WriteLine(SubsequenceE2.GetHeaders());
				
				// Lines
				foreach (var subE2 in from message in validMessages 
									  from seqE in message.SequencesE where seqE != null 
									  from subE2 in seqE.SubsequenceE2S select subE2)
					writer.WriteLine(subE2);
			}

			// F5
			var targetF5 = GetTargetFileName(targetDirectoryName, sourceFileName, "F5");
			using (var writer = new StreamWriter(targetF5))
			{
				// Headers
				writer.WriteLine(SubsequenceA1.GetHeaders());
	
				// Lines
				foreach (var subsA in from message in validMessages where message.SequenceA != null 
									  from subsA in message.SequenceA.SubsequenceA1S where subsA != null 
									  select subsA)
					writer.WriteLine(subsA);
			}
		}

		private static string GetTargetFileName(string targetdirectoryName, string sourcefileName, string fileType)
		{
			var i = sourcefileName.LastIndexOf(".", StringComparison.Ordinal);
			var newFileName = sourcefileName.Substring(0, i) + fileType + sourcefileName.Substring(i);
			var target = Path.Combine(targetdirectoryName, new FileInfo(newFileName).Name);
			return target;
		}
	}
}