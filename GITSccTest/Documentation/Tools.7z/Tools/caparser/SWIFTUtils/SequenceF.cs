﻿using System;
using System.Text;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	/// <summary>
	/// Sequence F of MT564 - Additional Information
	/// </summary>
	public class SequenceF: Sequence
	{
		private readonly StringBuilder _sbDetails = new StringBuilder();
		private readonly StringBuilder _sbParty = new StringBuilder();

		#region SWIFT Message attributes
		// 70E - Narrative
		public string AdditionalText { get; private set; }
		public string Narrative { get; private set; }
		public string InformationConditions { get; private set; }
		public string InformationComplied { get; private set; }
		public string OtherDetails2 { get { return _sbDetails.ToString(); } }
		
		// 95A - Party
		public string Registrar { get; private set; }
		public string Party { get { return _sbParty.ToString(); } }
		#endregion

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public override void Parse(string code, string text)
		{
			switch (code)
			{
				case "70E": ParseField70E(text); break;
				case "95A": 
				case "95Q":	ParseField95A(text); break;
				case "16R": // Nop
					break;
				case "16S": // Nop
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}

		/// <summary>
		/// Narrative
		/// </summary>
		/// <example>Option E	:4!c//10*35x	(Qualifier)(Narrative)</example>
		public void ParseField70E(string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			switch (s[0])
			{
				case "ADTX": AdditionalText = s[1]; break;
				case "TXNR": Narrative = s[1]; break;
				case "INCO": InformationConditions = s[1]; break;
				case "COMP": InformationComplied = s[1]; break;

				default: _sbDetails.Append(input + ";");
					break;
			}
		}

		/// <summary>
		/// Party
		/// </summary>
		/// <example>Option P	:4!c//4!a2!a2!c[3!c]	(Qualifier)(Identifier Code)
		///			 Option Q	:4!c//4*35x	(Qualifier)(Name and Address)
		///			 Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)
		/// </example>
		public void ParseField95A(string input)
		{
			// Option P, Q or R?
			var qualifier = input.Substring(0, 4);
            var value = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);

			switch (qualifier)
			{
				case "REGR": Registrar = value; break;

				default:
					_sbParty.Append(value + "//");
					break;
			}
		}

		public static string GetHeaders()
		{
			return "AdditionalText|Narrative|InformationConditions|InformationComplied|OtherDetails2|Registrar|Party";
		}

		public override string ToString()
		{
			return AdditionalText + "|" + Narrative + "|" + InformationConditions + "|" + InformationComplied + "|" + OtherDetails2 + "|" + Registrar + "|" + Party;
		}
	}
}