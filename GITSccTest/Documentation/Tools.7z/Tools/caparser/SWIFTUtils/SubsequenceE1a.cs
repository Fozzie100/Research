﻿using System;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	/// <summary>
	/// Optional Subsequence E1a Financial Instrument Attributes
	/// </summary>
	public class SubsequenceE1A : SubsequenceE1
	{
		private bool _hasParsed92A;

		public SubsequenceE1A(string caRef, string senderRef, int caOptionNumber, int number) : base(caRef, senderRef, caOptionNumber, number)
		{
		}

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public new void Parse(string code, string text)
		{
			switch (code)
			{
				// case "16R": ParseField16R(text); break;

				case "16S": // Nop
					break;
				case "94B": FIParseField94B(text); break;
				case "22F": FIParseField22F(text); break;
				case "12A": FIParseField12A(text); break;
				case "11A": FIParseField11A(text); break;
				case "98A": FIParseField98A(text); break;

				case "90B":
				case "90A": FIParseField90A(text); break;

				case "92A": 
				case "92D":
				case "92K":
				case "92L":
				case "92M":
				case "92N":
							FIParseField92A(text); break;
				case "36B": FIParseField36B(text); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}

		/// <summary>
		/// Place of listing (not as standard)
		/// </summary>
		/// <example>Option B	:4!c/[8c]/4!c[/30x]	(Qualifier)(Data Source Scheme)(Place Code)(Narrative)</example>
		/// <param name="input"></param>
		public void FIParseField94B(string input)
		{
			// 4!c//4!c[/30x]
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			if (s.Length == 1)
				throw new NotImplementedException(String.Format("{0}: Option B with Data Source Scheme is not supported.", GetType().Name));

			string[] splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
			PlaceListingType = splitB[0];
			
			if (splitB.Length == 2)
			PlaceListing = splitB[1];
		}

		/// <summary>
		/// Method of interest computation indicator
		/// </summary>
		/// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
		/// <param name="input"></param>
		public void FIParseField22F(string input)
		{
			var qualifier = input.Substring(0, input.IndexOf("/", StringComparison.Ordinal));
			if (!qualifier.Equals("MICO"))
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected code in field 22F.", GetType().Name));

			MICO = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
		}

		/// <summary>
		/// CFI Code; Option C is impl. only
		/// </summary>
		/// <example>Option A	:4!c/[8c]/30x	(Qualifier)(Data Source Scheme)(Instrument Code or Description)
		///			 Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Instrument Type Code)
		///			 Option C	:4!c//6!c		(Qualifier)(CFI Code)</example>
		/// <param name="input"></param>
		public void FIParseField12A(string input)
		{
			if (!Regex.IsMatch(input, "CLAS|OPST"))
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected qualifier {1} in Field 12A.", GetType().Name, input.Substring(0, 4)));

			InstrTypeCode = input.Substring(0, 4);
			InstrType = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
		}

		/// <summary>
		/// Currency of denomination
		/// </summary>
		/// <param name="input"></param>
		public void FIParseField11A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			if (s[0] != "DENO")
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected qualifier in field 11A.", GetType().Name));
			InstrCurrency = s[1];
		}

		/// <summary>
		/// DateTime (various)
		/// </summary>
		/// <example>Option A	:4!c//8!n	(Qualifier)(Date)</example>
		/// <param name="input"></param>
		public void FIParseField98A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "COUP": InstrCouponDate = ParseDateOptionalTime(s[1]); break;
				case "FRNR": InstrFloatingRateDate = ParseDateOptionalTime(s[1]); break;
				case "MATU": InstrMaturityDate = ParseDateOptionalTime(s[1]); break;
				case "ISSU": InstrIssueDate = ParseDateOptionalTime(s[1]); break;
				case "CALD": InstrCallDate = ParseDateOptionalTime(s[1]); break;
				case "PUTT": InstrPutDate = ParseDateOptionalTime(s[1]); break;
				case "DDTE": InstrDatedDate = ParseDateOptionalTime(s[1]); break;
				case "CONV": InstrConvDate = ParseDateOptionalTime(s[1]); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 98A.", GetType().Name, s[0]));
			}
		}

		public void FIParseField90A(string input)
		{
			if (!Regex.IsMatch(input, @"ISSU"))
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 98A.", GetType().Name, input));

			if (input.Substring(input.LastIndexOf("/", StringComparison.Ordinal)+1) == "UKWN")
			{
				InstrPrice = null;
				InstrPriceCurrency = null;
				InstrPriceType = null;
				return;
			}

			var price = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
			try
			{
				InstrPrice = ParseDecimalFr(price);
			}
			catch (FormatException)
			{
				InstrPriceCurrency = price.Substring(0, 3);
				InstrPrice = ParseDecimalFr(price.Substring(3));
			}
			InstrPriceType = ParseAmountTypeCode(input);
		}

		public void FIParseField92A(string input)
		{
			if (_hasParsed92A)
				throw new Exception(String.Format("{0}: 92A has already been parsed in E1a. Second attempt!", GetType().Name));

			_hasParsed92A = true;
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "PRFC":
				case "NWFC":
				case "INTR":
				case "NXRT":

					InstrRateType = s[0];
					try
					{
						InstrRate = ParseDecimalFr(s[1].Replace("N", "-"));
					}
					catch (FormatException)
					{
						InstrRate = null;
					}

					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 92A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Quantity of Financial Instrument
		/// </summary>
		/// <example>Option B	:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)</example>
		/// <param name="input"></param>
		public void FIParseField36B(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			var splitB = s[1].Split(new[] { "/" }, StringSplitOptions.None);
			InstrQuantityType = splitB[0];

			switch (s[0])
			{
				case "MINO": InstrMinNomQuantity = ParseDecimalFr(splitB[1]); break;
				case "MIEX": InstrMinExQuantity = ParseDecimalFr(splitB[1]); break;
				case "MILT": InstrMinExMQuantity = ParseDecimalFr(splitB[1]); break;
				case "SIZE": InstrContractSize = ParseDecimalFr(splitB[1]); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in Field 36B.", GetType().Name, s[0]));
			}
		}
	}
}