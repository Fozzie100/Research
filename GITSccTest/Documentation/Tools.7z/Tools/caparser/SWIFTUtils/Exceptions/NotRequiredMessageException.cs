﻿using System;

namespace SWIFTUtils.Exceptions
{
	public class NotRequiredMessageException : Exception
	{
		public NotRequiredMessageException() { }
		public NotRequiredMessageException(string message) : base(message) { }
		public NotRequiredMessageException(string message, Exception cause) : base(message, cause) { }
		public NotRequiredMessageException(Exception ex) : base("Message does not belong to the set of required types to be processed.", ex) { }
	}
}