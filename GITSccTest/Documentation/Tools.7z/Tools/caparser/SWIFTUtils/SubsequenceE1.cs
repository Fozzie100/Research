﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	public class SubsequenceE1: SequenceE
	{
		private SubsequenceE1A _subsequenceE1A;
		private bool _isInE1A;
		private readonly int _subsequenceNumber;

		public SubsequenceE1(string caRef, string senderRef, int caOptionNumber, int number) : base(caRef, senderRef)
		{
			CAOptionNumber = caOptionNumber;
			_subsequenceNumber = number;
		}

		#region SWIFT Message attributes
		/// <summary>
		/// 22 - E1
		/// </summary>
		public string IndicatorType { get; set; }
		/// <summary>
		/// 22 - E1
		/// </summary>
		public new string Indicator { get; set; }
		/// <summary>
		/// 35B - E1
		/// </summary>
		public new string SEDOL { get; set; }
		/// <summary>
		/// 35B - E1
		/// </summary>
		public new string Entity { get; private set; }

		#region SWIFT Message attributes-E1a
		/// <summary>
		/// 94B - E1a
		/// </summary>
		public string PlaceListingType { get; set; }
		/// <summary>
		/// 94B - E1a
		/// </summary>
		public string PlaceListing { get; set; }
		/// <summary>
		/// 22F - E1a
		/// </summary>
		public string MICO { get; set; }
		/// <summary>
		/// 12a - E1
		/// </summary>
		public string InstrTypeCode { get; set; }
		/// <summary>
		/// 12a - E1
		/// </summary>
		public string InstrType { get; set; }
		/// <summary>
		/// 11a - E1
		/// </summary>
		public string InstrCurrency { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrCouponDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrFloatingRateDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrMaturityDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrIssueDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrCallDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrPutDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrDatedDate { get; set; }
		/// <summary>
		/// 98 A - E1a
		/// </summary>
		public DateTime? InstrConvDate { get; set; }
		/// <summary>
		/// 90A - E1a
		/// </summary>
		public decimal? InstrPrice { get; set; }
		/// <summary>
		/// 90A - E1a
		/// </summary>
		public string InstrPriceType { get; set; }
		/// <summary>
		/// 90A - E1a
		/// </summary>
		public string InstrPriceCurrency { get; set; }
		/// <summary>
		/// 92A - E1a
		/// </summary>
		public string InstrRateType { get; set; }
		/// <summary>
		/// 92A - E1a
		/// </summary>
		public decimal? InstrRate { get;  set; }
		/// <summary>
		/// 36B - E1a -  Quantity of Financial Instrument
		/// </summary>
		public string InstrQuantityType { get;  set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
		public decimal? InstrMinNomQuantity { get;  set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
		public decimal? InstrMinExQuantity { get;  set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
		public decimal? InstrMinExMQuantity { get;  set; }
		/// <summary>
		/// 36B - E1a - Quantity of Financial Instrument
		/// </summary>
		public decimal? InstrContractSize { get; set; }
		#endregion
		// *************************************************End of E1a *****************************************************

		/// <summary>
		/// 36B - E1
		/// </summary>
		public string EntitledQuantityType { get; private set; }

		/// <summary>
		/// 36B - E1
		/// </summary>
		public decimal? EntitledQuantity { get; private set; }

		/// <summary>
		/// 22F
		/// </summary>
		public string DispositionFractions { get; private set; }

		/// <summary>
		/// 11A
		/// </summary>
		public string CurrencyOption { get; private set; }

		/// <summary>
		/// 69A - Period
		/// </summary>
		public DateTime? TradingPeriodStart { get; set; }

		/// <summary>
		/// 69A - Period
		/// </summary>
		public DateTime? TradingPeriodEnd { get; set; }

		/// <summary>
		/// 90A - E1
		/// </summary>
		public decimal? IndicativePrice { get; private set; }
		/// <summary>
		/// 90A - E1
		/// </summary>
		public decimal? MarketPrice { get; private set; }
		/// <summary>
		/// 90A - E1
		/// </summary>
		public decimal? CashInLieuSharesPrice { get; private set; }

		/// <summary>
		/// 90A
		/// </summary>
		public new string PriceCurrency { get; private set; }
		/// <summary>
		/// 92 in E1 - Securities Movements
		/// </summary>
		public string RateType { get; private set; }
		/// <summary>
		/// 92 in E1 - Securities Movements
		/// </summary>
		public decimal? Rate1 { get; private set; }
		/// <summary>
		/// 92 in E1 - Securities Movements
		/// </summary>
		public string Rate1Currency { get; private set; }
		/// <summary>
		/// 92 in E1 - Securities Movements
		/// </summary>
		public decimal? Rate2 { get; private set; }
		/// <summary>
		/// 92 in E1 - Securities Movements
		/// </summary>
		public string Rate2Currency { get; private set; }
		/// <summary>
		/// 92 in E1 - Securities Movements
		/// </summary>
		public decimal? RateQuantity { get; private set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
		public DateTime? PayDate { get; set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
		public DateTime? AvailableDate { get; private set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
		public DateTime? DividendRankDate { get; private set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
		public DateTime? EarliestPayDate { get; private set; }
		/// <summary>
		/// 98A - E1
		/// </summary>
		public DateTime? PariPassuDate { get; private set; }
		#endregion

		/// <summary>
		/// Main Parse method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public new void Parse(string code, string text)
		{
			if (_isInE1A)
			{
				_subsequenceE1A.Parse(code, text);
				switch (code)
				{
					case "16R": ParseField16R(text); return;
					case "16S": ParseField16S(text); return;
				}
				return;
			}

			switch(code)
			{
				case "16R": ParseField16R(text); return;
				case "16S": ParseField16S(text); return;
			}

			switch (code.Substring(0,2))
			{
				case "35": ParseField35B(text); break;
				case "36": ParseField36B(text); break;
				case "22": ParseField22(text); break;
				case "11": ParseField11A(text); break;
				case "69": ParseField69A(text); break;
				case "90": ParseField90A(text); break;
				case "92": ParseField92(code, text); break;
				case "98": ParseField98A(text); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}

		public new void ParseField16R(string input)
		{
			switch (input)
			{
				case "FIA": _subsequenceE1A = new SubsequenceE1A(CARef, SenderRef, CAOptionNumber, _subsequenceNumber);
							_isInE1A = true;
							break;
			}
		}

		public new void ParseField16S(string input)
		{
			switch(input)
			{
				case "FIA": _isInE1A = false; 
					break;
				case "SECMOVE": // Nop
					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unrecognized code in 16S.", GetType().Name));
			}
		}

		/// <summary>
		/// Disposition of Fractions
		/// </summary>
		/// <example></example>
		/// <param name="input"></param>
		public void ParseField22F(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			if (s[0] != "DISF")
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in Field 22F.", GetType().Name, s[0]));

			DispositionFractions = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
		}

		/// <summary>
		/// Indicator: for fields 67 and 80
		/// </summary>
		/// <example>
		/// Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)
		/// Option H	:4!c//4!c	(Qualifier)(Indicator)
		/// </example>
		public new void ParseField22(string input)
		{
			// Option H
			if (Regex.IsMatch(input, @"^[A-Z]{4}//[A-Z]{4}$"))
			{
				var s = input.Split(new[] {"//"}, StringSplitOptions.None);
				switch (s[0])
				{
					case "DISF": DispositionFractions = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1); break;

					case "CRDB":
					case "TEMP":
					case "NELP": IndicatorType = s[0];
								 Indicator = s[1];
								 break;

					default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected indicator type in field 22.", GetType().Name));
				}
				return;
			}

			// Option F
			if (Regex.IsMatch(input, @"^[A-Z]{4}/[A-Z]*/[A-Z]{4}$"))
			{
				IndicatorType = input.Substring(0, input.IndexOf("/", StringComparison.Ordinal));
				Indicator = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);
				return;
			}

			throw new UnexpectedCodeException(String.Format("{0}: The input for 22 does not match any of the options. Either the SWIFT standard has changed or the message is malformed.", GetType().Name));
		}
		
		/// <summary>
		/// 
		/// </summary>
		/// <example>/GB/B43GVJ8
		/// /HAZEL RENEWABLE ENERGY 
		/// VCT 2 PLC/ORD GBP0.001</example>
		/// <param name="input"></param>
		public void ParseField35B(string input)
		{
			var regexDash = new Regex(@"^\s*/");
			input = regexDash.Replace(input, string.Empty);

			var splitResult = input.Split(new[] { "/" }, 3, StringSplitOptions.None);

			for (int i = 0; i < splitResult.Length; i++)
				if (splitResult[i].Length == 6 || splitResult[i].Length == 7)
				{
					SEDOL = splitResult[i];
					if (i + 1 < splitResult.Length)
					{
						Entity = splitResult[i + 1];
						break;
					}
				}
		}

		/// <summary>
		/// Entitled Quantity
		/// </summary>
		/// <example>:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)</example>
		/// <param name="input"></param>
		public void ParseField36B(string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			switch (s[0])
			{
				case "ENTL":
					var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					EntitledQuantityType = splitB[0];
					EntitledQuantity = ParseDecimalFr(splitB[1]);
					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in Field 36B.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Currency (option)
		/// </summary>
		/// <example>Option A	:4!c//3!a	(Qualifier)(Currency Code)</example>
		/// <param name="input"></param>
		public new void ParseField11A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "OPTN": CurrencyOption = s[1]; break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in Field 11A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Trading Period
		/// </summary>
		/// <param name="input"></param>
		public new void ParseField69A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "TRDP": // Nop
					break;
					// PRIC ??
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 69A.", GetType().Name, s[0]));
			}

			var splitResultB = s[1].Split(new[] { "/" }, StringSplitOptions.None);

			// Option J
			if (splitResultB.Length == 1)
			{
				TradingPeriodStart = null;
				TradingPeriodEnd = null;

				return;
			}

			// Option A
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
			{
				TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				return;
			}

			// Option B
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
			{
				TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				return;
			}

			// Option C, D
			if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN")
			{
				TradingPeriodEnd = null;
				try
				{
					TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
				return;
			}

			// Option E, F
			if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN")
			{
				TradingPeriodStart = null;

				try
				{
					TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}	
		}

		/// <summary>
		/// Price
		/// </summary>
		/// <example></example>
		/// <param name="input"></param>
		public new void ParseField90A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			var split2 = s[1].Split(new[] { "/" }, 2, StringSplitOptions.None);

			decimal? price = null;
			// E
			if (split2[0] == "UKWN")
				return;

			// B, A
			try
			{
				price = ParseDecimalFr(split2[1]);
			}
			catch (FormatException)
			{   // A
				PriceCurrency = split2[1].Substring(0, 3);
				price = ParseDecimalFr(split2[1].Substring(3));
			}

			switch (s[0])
			{
				case "INDC": IndicativePrice = price; break;
				case "MRKT": MarketPrice = price; break;
				case "CINL": CashInLieuSharesPrice = price; break;

				case "PRPP": // Not implemented
				case "REIN":
				case "REDM":
				case "SUPR":
				case "ISSU":
					break;

				default:
					throw new UnexpectedCodeException(String.Format("{0}: Unexpected qualifier {1} encountered in field 90A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Parses Rate: There can be various types of rates: NB: This field is partially implemented
		/// </summary>
		/// <param name="code"></param>
		/// <param name="input"></param>
		public void ParseField92(string code, string input)
		{
			// This field has been partially implemented
			// Per Darren the securities movement section is something we are not concerned about
			// Can comment the below If
			/*
			if (_hasParsedRate)
				throw new UnexpectedCodeException("92 has already been parsed in Subsequence E1. Second attempt!");
			*/

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			decimal? rate1 = null;
			decimal? rate2 = null;

			RateType = s[0];
			switch (code.Substring(2,1))
			{
				case "A": rate1 = ParseDecimalFr(s[1].Replace("N", "-"));
					Rate1Currency = null;
					Rate2Currency = null;
					break;

				case "D":
					var splitRates = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					rate1 = ParseDecimalFr(splitRates[0]);
					rate2 = ParseDecimalFr(splitRates[1]);
					Rate1Currency = null;
					Rate2Currency = null;
					break;

				case "F":
					Rate1Currency = s[1].Substring(0, 3);
					RateQuantity = ParseDecimalFr(s[1].Substring(3));

					Rate2Currency = null;
					break;

				case "K": // Nop - UKWN
					break;

				case "L": var splitCurrencies = s[1].Split(new[] { "/" }, StringSplitOptions.None);
					Rate1Currency = splitCurrencies[0].Substring(0, 3);
					Rate2Currency = splitCurrencies[1].Substring(0, 3);

					rate1 = ParseDecimalFr(splitCurrencies[0].Substring(3));
					rate2 = ParseDecimalFr(splitCurrencies[1].Substring(3));

					break;

				case "M":
					var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					RateQuantity = ParseDecimalFr(splitB[1]);
					Rate1Currency = splitB[0].Substring(0, 3);

					rate1 = ParseDecimalFr(splitB[0].Substring(3));

					Rate2Currency = null;
					break;
				case "N":
					var splitN = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					RateQuantity = ParseDecimalFr(splitN[0]);
					Rate1Currency = splitN[1].Substring(0, 3);
					rate1 = ParseDecimalFr(splitN[1].Substring(3));

					Rate2Currency = null;
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected Option {1} in field 92.", GetType().Name, code));
			}
			Rate1 = rate1;
			Rate2 = rate2;

			//_hasParsedRate = true;
		}

		/// <summary>
		/// DateTime
		/// </summary>
		/// <example>Option A	:4!c//8!n	(Qualifier)(Date)
		///			 Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		///			 Option C	:4!c//8!n6!n	(Qualifier)(Date)(Time)
		///			 Option E	:4!c//8!n6!n[,3n][/[N]2!n[2!n]]	(Qualifier)(Date)(Time)(Decimals)(UTC Indicator)</example>
		/// <param name="input"></param>
		public new void ParseField98A(string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			if (s[1].Length == 4)
				return;

			switch (s[0])
			{
				case "PAYD":
					PayDate = ParseDateOptionalTime(s[1]);
					break;

				case "AVAL":
					AvailableDate = ParseDateOptionalTime(s[1]);
					break;

				case "DIVR":
					DividendRankDate = ParseDateOptionalTime(s[1]);
					break;

				case "EARL":
					EarliestPayDate = ParseDateOptionalTime(s[1]);
					break;

				case "PPDT":
					PariPassuDate = ParseDateOptionalTime(s[1]);
					break;

				// Nope - bad files
				// case "FDDT": //TODO
				// break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered in field 98A.", GetType().Name, s[0]));
			}
		}

		public new static string GetHeaders()
		{
			return "CARef|SenderRef|CAOptionNumber|SeqNum|IndicatorType|Indicator|SEDOL|Entity|PlaceListingType|PlaceListing|MICO|InstrTypeCode|InstrType|InstrCurrency|InstrCouponDate|InstrFloatingRateDate" +
			       "|InstrMaturityDate|InstrIssueDate|InstrCallDate|InstrPutDate|InstrDatedDate|InstrConvDate|InstrPrice|InstrPriceType|InstrPriceCurrency|InstrRateType|InstrRate" +
			       "|InstrQuantityType|InstrMinNomQuantity|InstrMinExQuantity|InstrMinExMQuantity|InstrContractSize|EntitledQuantityType|EntitledQuantity|DispositionFractions" +
			       "|CurrencyOption|TradingPeriodStart|TradingPeriodEnd|IndicativePrice|MarketPrice|CashInLieuSharesPrice|PriceCurrency|RateType|Rate1|Rate1Currency|Rate2|Rate2Currency" +
			       "|RateQuantity|PayDate|AvailableDate|DividendRankDate|EarliestPayDate|PariPassuDate";
		}

		public override string ToString()
		{
			return CARef + "|" + SenderRef + "|" + CAOptionNumber + "|" + _subsequenceNumber + "|" + IndicatorType + "|" + Indicator + "|" + SEDOL + "|" + Entity + "|" + PlaceListingType + "|" + PlaceListing + "|" + MICO + "|" + InstrTypeCode + "|" + InstrType + "|" + InstrCurrency + "|" + InstrCouponDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrFloatingRateDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
				   "|" + InstrMaturityDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrIssueDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrCallDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrPutDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrDatedDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrConvDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + InstrPrice + "|" + InstrPriceType + "|" + InstrPriceCurrency + "|" + InstrRateType + "|" + InstrRate +
			       "|" + InstrQuantityType + "|" + InstrMinNomQuantity + "|" + InstrMinExQuantity + "|" + InstrMinExMQuantity + "|" + InstrContractSize + "|" + EntitledQuantityType + "|" + EntitledQuantity + "|" + DispositionFractions +
				   "|" + CurrencyOption + "|" + TradingPeriodStart.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + TradingPeriodEnd.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + IndicativePrice + "|" + MarketPrice + "|" + CashInLieuSharesPrice + "|" + PriceCurrency + "|" + RateType + "|" + Rate1 + "|" + Rate1Currency + "|" + Rate2 + "|" + Rate2Currency +
				   "|" + RateQuantity + "|" + PayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + AvailableDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DividendRankDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EarliestPayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PariPassuDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss");
		}
	}
}