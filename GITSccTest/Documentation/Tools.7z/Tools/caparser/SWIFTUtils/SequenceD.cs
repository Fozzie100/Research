﻿using System;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	/// <summary>
	/// Sequence D of MT564 - Corporate Action Details
	/// </summary>
	public class SequenceD : Sequence
	{
		private readonly StringBuilder _sbDetails = new StringBuilder();
		
		private bool _hasParsed69A;
		private bool _hasParsed92A;
		private bool _hasParsed22F;

		#region SWIFT Message attributes
		// Interest Payment
		//public DateTime? CouponDate { get; set; }
		//public DateTime? MaturityDate { get; set; }
		//public decimal Interest { get; set; }

		// Bond Redemption
		//public DateTime? ValueDate { get; set; }
		
		/// <summary>
		/// 98A
		/// </summary>
		public DateTime? AnnouncementDate { get; private set; }
		public DateTime? ExDate { get; private set; }
		public DateTime? EffectiveDate { get; private set; }
		public DateTime? DeadlineSplitDate { get; private set; }
		public DateTime? MeetingDate { get; private set; }
		public DateTime? MeetingDate2 { get; private set; }
		public DateTime? MeetingDate3 { get; private set; }
		public DateTime? RecordDate { get; private set; }
		public DateTime? ExDateSpecial { get; private set; }
		public DateTime? PayDate { get; private set; }
		public DateTime? FurtherDetailedAnnouncementDate { get; private set; }
		public DateTime? CourtApprovalDate { get; private set; }
		public DateTime? TradingSuspendedDate { get; private set; }
		public DateTime? ProrationDate { get; private set; }
		public DateTime? DeadlineToRegister { get; private set; }
		public DateTime? WhollyUnconditionalDate { get; private set; }
		public DateTime? ResultsPublicationDate { get; private set; }
		public DateTime? NewMaturityDate { get; private set; }
		public DateTime? UnconditionalDate { get; private set; }

		/// <summary>
		/// 69A - Period Type
		/// </summary>
		public string PeriodType { get; set; }
		/// <summary>
		/// 69A - Period Start
		/// </summary>
		public DateTime? PeriodStart { get; private set; }
		/// <summary>
		/// 69A - Period End
		/// </summary>
		public DateTime? PeriodEnd { get; private set; }

		/// <summary>
		/// 99A - Days accrued
		/// </summary>
		public int? DaysAccrued { get; set; }

		/// <summary>
		/// 92A - Interest Rate
		/// </summary>
		public decimal? InterestRate { get; private set; }
		public decimal? BidIntervalRate { get; private set; }
		public decimal? PercentageSought { get; private set; }
		public string RateCurrency { get; private set; }

		/// <summary>
		/// 92A - Rate Types
		/// </summary>
		public string RateType { get; private set; }
		/// <summary>
		/// 92A - Rate
		/// </summary>
		public decimal? Rate { get; private set; }

		/// <summary>
		/// 90A - Maximum Price
		/// </summary>
		public decimal? PriceMax { get; set; }
		/// <summary>
		/// 90A - Minimum Price
		/// </summary>
		public decimal? PriceMin { get; set; }
		/// <summary>
		/// 90A - Price Currency
		/// </summary>
		public string PriceCurrency { get; set; }

		public string PricePercentType { get; private set; }

		public string PriceAmountType { get; private set; }
		
		/// <summary>
		/// 36A - Fin Instr Quantity Type
		/// </summary>
		public string FIQuantityType { get; set; }

		/// <summary>
		/// 36A - Fin Instr Quantity
		/// </summary>
		public decimal? FIQuantity { get; set; }

		/// <summary>
		/// 13A - Coupon Number
		/// </summary>
		public string CouponNumber { get; set; }

		/// <summary>
		/// 17B - Certification Flag
		/// </summary>
		public bool IsCertification { get; private set; }
		/// <summary>
		/// 17 B - Charges Flag
		/// </summary>
		public bool IsChargesApply { get; private set; }
		/// <summary>
		/// 17B - Certification Flag
		/// </summary>
		public bool IsComplianceInfo { get; private set; }
		/// <summary>
		/// 17B - Accrued Interest Indicator
		/// </summary>
		public bool IsEntitledAccruedInterest { get; private set; }
		
		/// <summary>
		/// 22F - Dividend Type
		/// </summary>
		public string DividendType { get; private set; }

		public string DistributionType { get; private set; }
		public string OfferType { get; private set; }

		public string CorpActionEventStage { get; private set; }
		public string AdditionalBusinessProcess { get; private set; }

		public string RSEI { get; private set; }
		public string IntermSecDistrib { get; private set; }

		/// <summary>
		/// 22F - Indicator Type
		/// </summary>
		public string IndicatorType { get; set; }
		/// <summary>
		/// 22F - IndicatorValue
		/// </summary>
		public string IndicatorValue { get; set; }

		/// <summary>
		/// 94G - Place (of meeting / New Place of Incorp.)
		/// </summary>
		public string Place { get; set; }

		/// <summary>
		/// 70 - Other Details
		/// </summary>
		public string OtherDetails { get { return _sbDetails.ToString(); } }

		/// <summary>
		/// 70A - Website
		/// </summary>
		public string Website { get; private set; }
		#endregion

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public override void Parse(string code, string text)
		{
			switch (code)
			{
				case "16R": // NOP
					break;
				case "16S":
					break;

				case "98A": 
				case "98B":
				case "98C":	
				case "98E": ParseField98A(text); break;

				case "69A":
				case "69B":
				case "69C":
				case "69D":
				case "69E":
				case "69F":
				case "69J": ParseField69A(text); break;

				case "99A": ParseField99A(text); break;

				case "92A": 
				case "92F":
				case "92K": ParseField92(code, text); break;
				case "90A": 
				case "90B":
				case "90E": ParseField90(code, text); break;

				case "36A": 
				case "36B":
				case "36C": ParseField36A(text); break;

				case "13A": 
				case "13B": ParseField13A(text); break;

				case "17B": ParseField17B(text); break;
				case "22F": ParseField22F(text); break;
				case "94G": ParseField94G(text); break;
				case "70A": 
				case "70E": 
				case "70G": ParseField70A(text); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected field {1} encountered in this sequence.", GetType().Name, code));
			}
		}

		/// <summary>
		/// DateTime. Option A supported only
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n	(Qualifier)(Date)
		/// Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		/// Option C	:4!c//8!n6!n	(Qualifier)(Date)(Time)
		/// Option E	:4!c//8!n6!n[,3n][/[N]2!n[2!n]]	(Qualifier)(Date)(Time)(Decimals)(UTC Indicator)
		/// </example>
		/// <param name="input"></param>
		public void ParseField98A(string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			try
			{
				// Note: There are many types of dates. Not all of them are implemented.
				switch (s[0])
				{
					case "ANOU": AnnouncementDate = ParseDateOptionalTime(s[1], true); break;
					case "XDTE": ExDate = ParseDateOptionalTime(s[1], true); break;
					case "EFFD": EffectiveDate = ParseDateOptionalTime(s[1], true); break;
					case "SPLT": DeadlineSplitDate = ParseDateOptionalTime(s[1], true); break;
					case "MEET": MeetingDate = ParseDateOptionalTime(s[1], true); break;
					case "MET2": MeetingDate2 = ParseDateOptionalTime(s[1], true); break;
					case "MET3": MeetingDate3 = ParseDateOptionalTime(s[1], true); break;
					case "RDTE": RecordDate = ParseDateOptionalTime(s[1], true); break;
					case "SXDT": ExDateSpecial = ParseDateOptionalTime(s[1], true); break;
					case "PAYD": PayDate = ParseDateOptionalTime(s[1], true); break;
					case "PROD": ProrationDate = ParseDateOptionalTime(s[1], true); break;
					case "FDAT": FurtherDetailedAnnouncementDate = ParseDateOptionalTime(s[1], true); break;
					case "COAP": CourtApprovalDate = ParseDateOptionalTime(s[1], true); break;
					case "TSDT": TradingSuspendedDate = ParseDateOptionalTime(s[1], true); break;
					case "REGI": DeadlineToRegister = ParseDateOptionalTime(s[1], true);  break;
					case "WUCO": WhollyUnconditionalDate = ParseDateOptionalTime(s[1], true); break;
					case "RESU": ResultsPublicationDate = ParseDateOptionalTime(s[1], true); break;
					case "MATU": NewMaturityDate = ParseDateOptionalTime(s[1], true); break;
					case "UNCO": UnconditionalDate = ParseDateOptionalTime(s[1], true); break;

			//		case "HEAR" : // NOP
			//			break;

					// case "QUOT": break;
					case "IFIX": // FixingDate: Not implemented; met sometimes but I don't see it in the standard - http://www.iso15022.org/uhb/uhb2005/mt564-41-field-98a.htm
						break;

					default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 98A. Note: Not all type of codes/dates are implemented.", GetType().Name, s[0]));
				}
			}
			catch (FormatException)
			{
				throw new UnexpectedFormatException(String.Format("{0}: The date value in field 98A is not a valid Date. Note that only Option A, B, C is supported. The encountered value may be formated as Option B,C,E.", GetType().Name));
			}
		}

		/// <summary>
		/// Period
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n/8!n	(Qualifier)(Date)(Date)
		/// Option B	:4!c//8!n6!n/8!n6!n	(Qualifier)(Date)(Time)(Date)(Time)
		/// Option C	:4!c//8!n/4!c	(Qualifier)(Date)(Date Code)
		/// Option D	:4!c//8!n6!n/4!c	(Qualifier)(Date)(Time)(Date Code)
		/// Option E	:4!c//4!c/8!n	(Qualifier)(Date Code)(Date)
		/// Option F	:4!c//4!c/8!n6!n	(Qualifier)(Date Code)(Date)(Time)
		/// Option J	:4!c//4!c	(Qualifier)(Date Code)
		/// </example>
		/// <param name="input"></param>
		public void ParseField69A(string input)
		{
			if (_hasParsed69A)
				throw new Exception(String.Format("{0}: Field 69 has already been parsed.", GetType().Name));

			_hasParsed69A = true;
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			PeriodType = s[0];

			var splitResultB = s[1].Split(new[] { "/" }, StringSplitOptions.None);

			// Option J
			if (splitResultB.Length == 1)
			{
				PeriodStart = null;
				PeriodEnd = null;

				return;
			}

			// Option A
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
			{
				PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				return;
			}

			// Option B
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
			{
				PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				return;
			}

			// Option C, D
			if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN")
			{
				PeriodEnd = null;
				try
				{
					PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
				return;
			}

			// Option E, F
			if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN")
			{
				PeriodStart = null;

				try
				{
					PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}
		}

		/// <summary>
		/// Days Accrued
		/// </summary>
		/// <example>
		/// Option A	:4!c//[N]3!n	(Qualifier)(Sign)(Number)
		/// </example>
		/// <param name="input"></param>
		public void ParseField99A(string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			switch (s[0])
			{
				case "DAAC": DaysAccrued = int.Parse(s[1]); break;
				default:
					throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 99A.", GetType().Name, s[1]));
			}
		}

		/// <summary>
		/// Rate - note (most of the rates are given in Option E; hence the lean implementation of rates here)
		/// </summary>
		/// <example>
		/// Option A	:4!c//[N]15d	(Qualifier)(Sign)(Rate)
		/// Option F	:4!c//3!a15d	(Qualifier)(Currency Code)(Amount) (Not supported)
		/// Option K	:4!c//4!c	(Qualifier)(Rate Type Code)
		/// </example>
		/// <param name="code"> </param>
		/// <param name="input"></param>
		public void ParseField92(string code, string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			switch(code.Substring(2,1))
			{
				case "A": Set92Value(s[0], s[1]);
					break;

				case "F":
					RateCurrency = s[1].Substring(0, 3);
					Set92Value(s[0], s[1].Substring(3));
					break;

				case "K":
					// Nop
					Rate = null;
					RateType = s[1];
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected option in field 92. Only A,F,K are expected.", GetType().Name));
			}
		}

		private void Set92Value(string qualifier, string input)
		{
			switch (qualifier)
			{
				case "INTR": InterestRate = ParseDecimalFr(input); break;
				case "BIDI": BidIntervalRate = ParseDecimalFr(input); break;
				case "PTSC": PercentageSought = ParseDecimalFr(input); break;

				default:
					try
					{
						if (_hasParsed92A)
							throw new Exception(String.Format("{0}: Field 92A has been parsed already. If more than 1 value is met the implementation of this field may need to be expanded.", GetType().Name));

						Rate = ParseDecimalFr(input);
						_hasParsed92A = true;
					}
					catch (FormatException)
					{
						RateType = qualifier;
					}
					RateType = qualifier;

					break;
			}
		}

		/// <summary>
		/// Price. Most of the prices will be in Sequence E
		/// </summary>
		/// <example>Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///			 Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///			 Option E	:4!c//4!c	(Qualifier)(Price Code)</example>
		///<param name="code"> </param>
		///<param name="input"></param>
		public void ParseField90(string code, string input)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			var split2 = s[1].Split(new[] { "/" }, StringSplitOptions.None);
			decimal? price = null;

			switch (code.Substring(2, 1))
			{
				case "A":
					PricePercentType = split2[0];
					price = ParseDecimalFr(split2[1]);
					break;

				case "B":
					PriceAmountType = split2[0];
					PriceCurrency = split2[1].Substring(0, 3);
					price = ParseDecimalFr(split2[1].Substring(3));
					break;

				case "E": // UKWN
					price = ParseDecimalFr(split2[0]);
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unrecognized code {1} in field 90.", GetType().Name, input.Substring(2, 1)));
			}

			switch (s[0])
			{
				case "MAXP":
					PriceMax = price;
					break;

				case "MINP":
					PriceMin = price;
					break;

				default:
					throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered in field 90A.", GetType().Name, s[1]));
			}
		}

		/// <summary>
		/// Quantity of Financial Instrument
		/// </summary>
		/// <param name="input"></param>
		public void ParseField36A(string input)
		{
			if (!Regex.IsMatch(input, "MIEX|MILT|MQSO|QTSO|NBLT|NEWD|BASE|INCR"))
				throw new UnexpectedCodeException(String.Format("{0}: The qualifier encountered in 36A is not part of the expected set.", GetType().Name));

			var s = input.Split(new[] {"//"}, StringSplitOptions.None);

			FIQuantityType = s[0];
			FIQuantity = ParseDecimalFr(input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1));
		}

		/// <summary>
		/// Coupon
		/// </summary>
		/// <example>
		/// Option A	:4!c//3!c		(Qualifier)(Number Id)
		/// Option B	:4!c/[8c]/30x	(Qualifier)(Data Source Scheme)(Number)
		/// </example>
		/// <param name="input"></param>
		public void ParseField13A(string input)
		{
			if (Regex.IsMatch(input, @"//"))
			{
				// Option A
				var s = input.Split(new[] { "//" }, StringSplitOptions.None);
				switch (s[0])
				{
					case "COUP":
						CouponNumber = s[1];
						break;
					default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code at field 13A. Only COUP is expected.", GetType().Name));
				}
				return;
			}

			// Option B
			var s2 = input.Split(new[] {"/"}, StringSplitOptions.None);
			if (s2[0] != "COUP")
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected code at field 13A.", GetType().Name));
			CouponNumber = s2[2];
		}

		/// <summary>
		/// Flag
		/// </summary>
		/// <example>
		/// Option B	:4!c//1!a	(Qualifier)(Flag)
		/// </example>
		/// <param name="input"></param>
		public void ParseField17B(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			
			switch(s[0])
			{
				case "CERT":
					IsCertification = (s[1] == "Y");
					break;
				case "RCHG": 
					IsChargesApply = (s[1] == "Y");
					break;
				case "COMP":
					IsComplianceInfo = (s[1] == "Y");
					break;
				case "ACIN":
					IsEntitledAccruedInterest = (s[1] == "Y");
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} at field 17B.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Indicator
		/// </summary>
		/// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
		/// <param name="input"></param>
		public void ParseField22F(string input)
		{
			// Here what we get in file does not match the standard - "//" instead of "/"
			var qualifier = input.Substring(0, input.IndexOf("/", StringComparison.Ordinal));
			var value = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1);

			switch (qualifier)
			{
				case "DIVI": DividendType = value; break;
				case "DITY": DistributionType = value; break;
				case "OFFE": OfferType = value; break;

				case "ESTA": CorpActionEventStage = value; break;
				case "ADDB": AdditionalBusinessProcess = value; break;

				case "SELL": RSEI = value;
					break;
				case "RHDI":
					IntermSecDistrib = value;
					break; 

				default: 
					if (_hasParsed22F)
						throw new MoreThanOneParseAttemptException(String.Format("{0}: Field 22F has been encountered more than once in Sequence D.", GetType().Name));

						IndicatorType = qualifier;
						IndicatorValue = value;
						_hasParsed22F = true;
					break;
			}
		}

		/// <summary>
		/// Place
		/// </summary>
		/// <example>Option G	:4!c//2*35x	(Qualifier)(Address)</example>
		/// <param name="input"></param>
		public void ParseField94G(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "MEET": 
				case "MET2":
				case "MET3":
				case "NPLI": Place = s[1];
							break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 94G.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Narrative
		/// </summary>
		/// <example>	Option E	:4!c//10*35x	(Qualifier)(Narrative)
		///				Option G	:4!c//10*35z	(Qualifier)(Narrative)</example>
		/// <param name="input"></param>
		public void ParseField70A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				//case "OFFO": Offeror = s[1];break;
				//case "NAME": NewName = s[1]; break;
				case "WEBB": Website = s[1]; break;

				default: _sbDetails.Append(input + ";");
					break;
			}
		}

		public static string GetHeaders()
		{
			return "AnnouncementDate|ExDate|EffectiveDate|DeadlineSplitDate|MeetingDate|MeetingDate2|MeetingDate3|RecordDate|ExDateSpecial" +
			       "|PayDate|FurtherDetailedAnnouncementDate|CourtApprovalDate|TradingSuspendedDate|ProrationDate|DeadlineToRegister" +
			       "|WhollyUnconditionalDate|ResultsPublicationDate|NewMaturityDate|UnconditionalDate|PeriodType|PeriodStart|PeriodEnd|DaysAccrued" +
			       "|InterestRate|BidIntervalRate|PercentageSought|RateCurrency|RateType|Rate|PriceMax|PriceMin|PriceCurrency|PricePercentType|PriceAmountType" +
			       "|FIQuantityType|FIQuantity|CouponNumber|IsCertification|IsChargesApply|IsComplianceInfo|IsEntitledAccruedInterest|DividendType|DistributionType" +
			       "|OfferType|CorpActionEventStage|AdditionalBusinessProcess|RSEI|IntermSecDistrib|IndicatorType|IndicatorValue|Place|Website|OtherDetails";
		}

		public override string ToString()
		{
			return AnnouncementDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ExDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EffectiveDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DeadlineSplitDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MeetingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MeetingDate2.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MeetingDate3.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + RecordDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ExDateSpecial.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" +
				   PayDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + FurtherDetailedAnnouncementDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + CourtApprovalDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + TradingSuspendedDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ProrationDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DeadlineToRegister.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" +
				   WhollyUnconditionalDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ResultsPublicationDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + NewMaturityDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + UnconditionalDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodType + "|" + PeriodStart.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodEnd.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DaysAccrued + "|" +
			       InterestRate + "|" + BidIntervalRate + "|"  + PercentageSought + "|"+ RateCurrency + "|" + RateType + "|" + Rate + "|" + PriceMax + "|" + PriceMin + "|" + PriceCurrency + "|" + PricePercentType + "|" + PriceAmountType + "|" +
			       FIQuantityType + "|" + FIQuantity + "|" + CouponNumber + "|" + IsCertification + "|" + IsChargesApply + "|" + IsComplianceInfo + "|" + IsEntitledAccruedInterest + "|" + DividendType + "|" + DistributionType + "|" +
			       OfferType + "|" + CorpActionEventStage + "|" + AdditionalBusinessProcess + "|" + RSEI + "|" + IntermSecDistrib + "|" + IndicatorType + "|" + IndicatorValue + "|" + Place + "|" + Website + "|" + OtherDetails;
		}
	}
}