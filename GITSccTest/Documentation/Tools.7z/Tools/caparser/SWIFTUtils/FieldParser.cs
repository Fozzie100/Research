﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SWIFTUtils
{
	public static class FieldParser
	{
		/// <summary>
		/// 4!c//3!a15d - (Qualifier) (Currency Code) (Amount)
		/// </summary>
		public static void QualifierCurrencyAmountParse(string input, out string qualifierType, out string currencyCode, out decimal amount)
		{
			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			qualifierType = s[0];
			currencyCode = s[1].Substring(0, 3);
			amount = Decimal.Parse(s[1].Substring(3), CultureInfo.CreateSpecificCulture("fr-FR"));
		}

		// :4!c//4!c/[N]15d[/4!c]
		public static void QualifierRateTypeCodeRateRateStatus(string input, out string qualifierType, out string rateTypeCode, out decimal amount, out string rateStatus)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			qualifierType = s[0];

			var s1 = s[1].Split(new[] {"/"}, StringSplitOptions.None);
			rateTypeCode = s1[0];
			
			amount = Decimal.Parse(s1[1].Replace("N", "-"));
			rateStatus = s1.Length >= 3 ? s1[2] : string.Empty;
		}
	}
}