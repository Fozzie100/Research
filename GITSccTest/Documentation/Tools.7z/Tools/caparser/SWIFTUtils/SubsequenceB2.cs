﻿using System;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	/// <summary>
	/// Repetitive Mandatory Subsequence B2 Account Information
	/// </summary>
	public class SubsequenceB2: SequenceB
	{
		/// <summary>
		/// 95A
		/// </summary>
		public string AccountOwner { get; set; }
		/// <summary>
		/// 97A
		/// </summary>
		public string SafeKeepingAccount { get; set; }
		/// <summary>
		/// 94A
		/// </summary>
		public string SafeKeepingPlace { get; set; }
		/// <summary>
		/// 93A
		/// </summary>
		public string BalanceType { get; set; }
		/// <summary>
		/// 93A
		/// </summary>
		public string BalanceQuantityType { get; set; }
		/// <summary>
		/// 93A
		/// </summary>
		public decimal? Balance { get; set; }

		/// <summary>
		/// 95A: Account Owner
		/// </summary>
		/// <example>:4!c//4!a2!a2!c[3!c]
		/// :4!c/8c/34x
		/// </example>
		/// <param name="input"></param>
		public void ParseField95A(string input)
		{
			if (!Regex.IsMatch(input, @"//"))
				throw new NotImplementedException(String.Format("{0}: Option R is not supported for field 95A.", GetType().Name));

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			switch(s[0])
			{
				case "ACOW": AccountOwner = s[1]; 
					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 95A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// SafeKeeping Account
		/// </summary>
		/// <example>Option A	:4!c//35x	(Qualifier)(Account Number)
		///			 Option C	:4!c//4!c	(Qualifier)(Account Code)</example>
		/// <param name="input"></param>
		public void ParseField97A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "SAFE": SafeKeepingAccount = s[1];
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected qualifier {1} in field 97A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Place of safekeeping (Options C,F supported only)
		/// </summary>
		/// <example>	Option B	:4!c/[8c]/4!c[/30x]	(Qualifier)(Data Source Scheme)(Place Code)(Narrative)
		///				Option C	:4!c//2!a	(Qualifier)(Country Code)
		///				Option F	:4!c//4!c/4!a2!a2!c[3!c]	(Qualifier)(Place Code)(Identifier Code)</example>
		/// <param name="input"></param>
		public void ParseField94A(string input)
		{
			if (!Regex.IsMatch(input, @"//"))
				throw new NotImplementedException(String.Format("{0}: Option B is not supported for field 94A.", GetType().Name));

			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			switch (s[0])
			{
				case "SAFE": SafeKeepingPlace = s[1]; break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected qualifier {1} in field 94A", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Balance
		/// </summary>
		/// <example>
		/// Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
		/// Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)
		/// </example>
		/// <param name="input"></param>
		public void ParseField93A(string input)
		{
			var s = input.Contains("//") ? input.Split(new[] {"//"}, StringSplitOptions.None) : input.Split(new[] {"/"}, 2, StringSplitOptions.None);

			switch (s[0])
			{
				case "ELIG":
				case "BLOK":
				case "BORR":
				case "COLI":
				case "COLO":
				case "LOAN":
				case "PEND":
				case "PENR":
				case "REGO":
				case "SETT":
				case "SPOS":
				case "TRAD":
				case "TRAN":
				case "NOMI":
				case "UNBA":
				case "INBA":
 
				case "OBAL":
				case "AFFB":
				case "UNAF":

					BalanceType = s[0];
					var regexQuantityType = new Regex(@"AMOR|FAMT|UNIT");
					if (regexQuantityType.IsMatch(s[1]))
					{
						var match = regexQuantityType.Match(s[1]);
						BalanceQuantityType = match.Value;
					}

					var numericValue = s[1].Substring(s[1].LastIndexOf("/", StringComparison.Ordinal) + 1);
					Balance = ParseDecimalFr(numericValue.Replace("N", "-"));

					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 93A.", GetType().Name, s[0]));
			}
		}
	}
}