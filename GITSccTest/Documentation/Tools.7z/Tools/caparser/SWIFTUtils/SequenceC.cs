﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	/// <summary>
	/// Sequence C of MT564 represents Intermediate Securities
	/// </summary>
	public class SequenceC : Sequence
	{
		private bool _hasParsed22;
		private string _sedol;
		private string _entity;

		#region SWIFT Message attributes
		/// <summary>
		/// 35B - Security SEDOL
		/// </summary>
		public string SecuritySEDOL
		{
			get { return _sedol; }
		}

		/// <summary>
		/// 35B - Security Description
		/// </summary>
		public string SecurityName
		{
			get { return _entity; }
		}

		/// <summary>
		/// 36A - Security Quantity
		/// </summary>
		public decimal? SecurityQuantity { get; set; }

		/// <summary>
		/// 93A - Balance
		/// </summary>
		public decimal? Balance { get; set; }

		/// <summary>
		/// 22F - Indicator Type
		/// </summary>
		public string SecIndicatorType { get; set; }
		/// <summary>
		/// 22F - Indicator
		/// </summary>
		public string SecIndicator { get; set; }

		/// <summary>
		/// 92D - Intermediate Securities to Underlying
		/// </summary>
		public decimal? QuantitySecurityUnderlying { get; set; }
		/// <summary>
		/// 90B - Market Price
		/// </summary>
		public decimal? MarketPrice { get; set; }
		/// <summary>
		/// 90B - Market Price Currency
		/// </summary>
		public string MarketPriceCurrency { get; set; }

		/// <summary>
		/// 98A - Expiry Date
		/// </summary>
		public DateTime? ExpiryDate { get; set; }
		/// <summary>
		/// 98A - Posting Date 
		/// </summary>
		public DateTime? PostingDate { get; set; }

		/// <summary>
		/// 69A - Trading Period
		/// </summary>
		public DateTime? TradingPeriodStart { get; set; }

		/// <summary>
		/// 69A - Trading Period
		/// </summary>
		public DateTime? TradingPeriodEnd { get; set; }
		#endregion

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public override void Parse(string code, string text)
		{
			switch (code)
			{
				case "16R": ParseField16R(text); break;

				case "35B": ParseField35B(text, out _sedol, out _entity); break;

				case "36A": 
				case "36B":
				case "36E": ParseField36A(text); break;

				case "93A": 
				case "93B":
				case "93C": ParseField93A(text); break;

				case "22F": ParseField22F(text); break;
				case "92D": ParseField92D(text); break;
				case "90B": ParseField90B(text); break;

				case "98A": 
				case "98B": ParseField98A(text); break;

				case "69A":
				case "69B":
				case "69C":
				case "69D":
				case "69E":
				case "69F": ParseField69A(text); break;

				case "16S": // NOP
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered in this sequence.", GetType().Name, code));
			}
		}


		public void ParseField16R(string input)
		{
			if (!Regex.IsMatch(input, "INTSEC"))
				throw new UnexpectedCodeException(String.Format("{0}: Code 16R is not properly formed. Expected value INTSEC.", GetType().Name));
		}

		/// <summary>
		/// Quantity of Financial Intrument
		/// </summary>
		/// <example>Option B	:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)
		///			 Option E	:4!c//4!c/[N]15d	(Qualifier)(Quantity Type Code)(Sign)(Quantity)
		///</example>
		/// <param name="input"></param>
		public void ParseField36A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "QINT":
					var spRes = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					SecurityQuantity = ParseDecimalFr(spRes[1].Replace("N", "-"));
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 36A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Balance
		/// </summary>
		/// <example>Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
		///			 Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)</example>
		/// <param name="input"></param>
		/// NOTE: This is partially implemented
		public void ParseField93A(string input)
		{
			var s = input.Substring(0, 4);

			switch (s)
			{
				case "UNBA":
				case "INBA":
					Balance = ParseDecimalFr(input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1));
					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 93A.", GetType().Name, s));
			}
		}

		/// <summary>
		/// Indicator
		/// </summary>
		/// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
		/// <param name="input"></param>
		public void ParseField22F(string input)
		{
			if(_hasParsed22)
				throw new ApplicationException(String.Format("{0}: Field 22 has already been parsed. This is a second attempt.", GetType().Name));

			var s = input.Split(new[] {"/"}, 2, StringSplitOptions.None);

			switch (s[0])
			{
				case "DISF":
				case "SELL":	SecIndicatorType = s[0];
								var splitResult2 = s[1].Split(new[] {"/"}, StringSplitOptions.None);
								SecIndicator = splitResult2[splitResult2.Length - 1];
							break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 22F.", GetType().Name, s[0]));
			}
			_hasParsed22 = true;
		}

		/// <summary>
		/// Rate
		/// </summary>
		/// <example>:4!c//15d/15d	(Qualifier)(Quantity)(Quantity)</example>
		/// <param name="input"></param>
		public void ParseField92D(string input)
		{
			// Not sure why 15d/15d ??		// There is also ADSR ? (http://www.10588.com/pub_web/swift/books/us5mc/)
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "RTUN": QuantitySecurityUnderlying = ParseDecimalFr(s[s.Length - 1]);
					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 92.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Market Price
		/// </summary>
		/// <example>Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)</example>
		/// <param name="input"></param>
		public void ParseField90B(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "MRKT":
					var splitResult2 = s[1].Split(new[] {"/"}, StringSplitOptions.None);
					var regexCurrency = new Regex("[A-Z]{3}");
					Match match = regexCurrency.Match(splitResult2[splitResult2.Length - 1]);
					MarketPriceCurrency = match.Value;

					MarketPrice = ParseDecimalFr(regexCurrency.Replace(splitResult2[splitResult2.Length - 1], string.Empty));
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 90B.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// DateTime
		/// </summary>
		/// <example>Option A	:4!c//8!n	(Qualifier)(Date)
		///			 Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		/// </example>
		/// <param name="input"></param>
		public void ParseField98A(string input)
		{
			var s = input.Split(new[] {"//", "/"}, StringSplitOptions.None);
			switch (s[0])
			{
				case "EXPI": ExpiryDate = ParseDateOptionalTime(input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1)); break;
				case "POST": PostingDate = ParseDateOptionalTime(input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1)); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 98A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Trading Period (Start, End)
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n/8!n	(Qualifier)(Date)(Date)
		/// Option B	:4!c//8!n6!n/8!n6!n	(Qualifier)(Date)(Time)(Date)(Time)
		/// Option C	:4!c//8!n/4!c	(Qualifier)(Date)(Date Code)
		/// Option D	:4!c//8!n6!n/4!c	(Qualifier)(Date)(Time)(Date Code)
		/// Option E	:4!c//4!c/8!n	(Qualifier)(Date Code)(Date)
		/// Option F	:4!c//4!c/8!n6!n	(Qualifier)(Date Code)(Date)(Time)
		/// </example>
		/// <param name="input"></param>
		public void ParseField69A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "TRDP":
					var splitResultB = s[1].Split(new[] {"/"}, StringSplitOptions.None);

					// Option A
					if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
					{
						TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
						TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
						break;
					}

					// Option B
					if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
					{
						TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						break;
					}

					// Option C, D
					if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN" || splitResultB[1] == "OPEN")
					{
						TradingPeriodEnd = null;
						try
						{
							TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						}
						catch (FormatException)
						{
							TradingPeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);							
						}
						break;
					}

					// Option E, F
					if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN" || splitResultB[1] == "OPEN")
					{
						TradingPeriodStart = null;
						try
						{
							TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						}
						catch (FormatException)
						{
							TradingPeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
						}
						break;
					}
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 69A.", GetType().Name, s[0]));
			}
		}

		public static string GetHeaders()
		{
			return "SecuritySEDOL|SecurityName|SecurityQuantity|Balance|SecIndicatorType|SecIndicator|QuantitySecurityUnderlying" +
			       "|MarketPrice|MarketPriceCurrency|ExpiryDate|PostingDate|TradingPeriodStart|TradingPeriodEnd";
		}

		public override string ToString()
		{
			return SecuritySEDOL + "|" + SecurityName + "|" + SecurityQuantity + "|" + Balance + "|" + SecIndicatorType + "|" + SecIndicator + "|" + QuantitySecurityUnderlying + "|" +
				   MarketPrice + "|" + MarketPriceCurrency + "|" + ExpiryDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PostingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + TradingPeriodStart.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + TradingPeriodEnd.ToStringOrDefault("yyyy-MM-dd HH:mm:ss");
		}
	}
}