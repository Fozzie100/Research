﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	/// <summary>
	/// Repetitive Optional Sequence E - Corporate Actions Options
	/// </summary>
	public class SequenceE: Sequence
	{
		private bool _hasParsed17B;
		private bool _hasParsed36A;
		private readonly StringBuilder _sbField22 = new StringBuilder();
		private readonly StringBuilder _sbDetails = new StringBuilder();
		private string _sedol;
		private string _entity;
		private readonly string _caRef;
		private readonly string _senderRef;
		private SubsequenceE1 _subsequenceE1;
		private SubsequenceE2 _subsequenceE2;
		private CurrentSubsequence _currentSubsequence;

		private int _e1Counter;
		private int _e2Counter;

		public List<SubsequenceE1> SubsequenceE1S  = new List<SubsequenceE1>();
		public List<SubsequenceE2> SubsequenceE2S = new List<SubsequenceE2>(); 
		
		#region SWIFT Message attributes
		public string CARef { get { return _caRef; } }
		public string SenderRef { get { return _senderRef; } }

		/// <summary>
		/// 13A
		/// </summary>
		public int CAOptionNumber { get; set; }

		/// <summary>
		/// 22F
		/// </summary>
		public string Indicator
		{
			get { return _sbField22.ToString(); }
		}

		public string CorpActionOptionCode { get; set; }
		public string DispFractionsInd  { get; set; }
		public string OfferType  { get; set; }

		/// <summary>
		/// 94C
		/// </summary>
		public string CountryDomicile { get; private set; }

		/// <summary>
		/// 94C
		/// </summary>
		public string CountryNonDomicile { get; private set; }

		/// <summary>
		/// 11A
		/// </summary>
		public string Currency { get; set; }

		/// <summary>
		/// 17B
		/// </summary>
		public string Flag { get; private set; }

		public string FlagType { get; private set; }

		public bool IsDefault { get; private set; }

		/// <summary>
		/// 35B
		/// </summary>
		public string SEDOL { get { return _sedol; } }

		/// <summary>
		/// 35B
		/// </summary>
		public string Entity { get { return _entity; } }

		/// <summary>
		/// 98A
		/// </summary>
		public DateTime? DepositoryCoverExpiration { get; private set; }
		public DateTime? EarlyResponseDeadline { get; private set; }
		public DateTime? ExpiryDate { get; private set; }
		public DateTime? MarketDeadline  { get; private set; }
		public DateTime? ProtectDate  { get; private set; }
		public DateTime? SubscriptionCostDebit   { get; private set; }
		public DateTime? ResponseDeadline  { get; private set; }
		public DateTime? CoverExpiration { get; private set; }

		/// <summary>
		/// 69A - Period
		/// </summary>
		public DateTime? PeriodStart { get; set; }

		/// <summary>
		/// 69A - Period
		/// </summary>
		public DateTime? PeriodEnd { get; set; }

		/// <summary>
		/// 69A - PeriodType
		/// </summary>
		public string PeriodType { get; set; }

		/// <summary>
		/// 92A - Rate
		/// </summary>
		public decimal? DividendGrossRate { get; private set; }
		public decimal? TaxRelatedRate { get; private set; }
		public decimal? WithholdingTaxRate  { get; private set; }
		public decimal? AdditionalTax { get; private set; }
		public decimal? IndexFactor { get; private set; }
		public decimal? MaximumAllowedOversubRate { get; private set; }
		public decimal? ProRationRate { get; private set; }
		public decimal? InterestPaymentRate { get; private set; }
		public decimal? TaxableIncomePerDS { get; private set; }
		public decimal? ForeignTaxWithholding { get; private set; }
		public decimal? LocalTaxWithholding { get; private set; }

		public decimal? ChargesRate { get; private set; }
		public decimal? NetRateShare { get; private set; }
		public decimal? TaxCreditRate { get; private set; }
		public decimal? FullyFrankedRate { get; private set; }
		public decimal? ProvDividendRate { get; private set; }

		/// <summary>
		/// 92A - Rate Currency
		/// </summary>
		public string RateCurrency { get; set; }
		
		/// <summary>
		/// 90 A - Price amount Type
		/// </summary>
		public string PriceAmountType { get; set; }

		/// <summary>
		/// 90A
		/// </summary>
		public string PriceCurrency { get; set; }

		/// <summary>
		/// 90A
		/// </summary>
		public decimal? GenericCashPriceReceived { get; private set; }
		public decimal? CashinLieuSharesPrice { get; private set; }
		public decimal? OverSubDepositPrice { get; private set; }
		public decimal? GenericCashPricePaid { get; private set; }

		/// <summary>
		/// 36A
		/// </summary>
		public string InstrumentQuantityType { get; set; }

		/// <summary>
		/// 36A
		/// </summary>
		public string InstrumentQuantityTypeCode { get; set; }

		/// <summary>
		/// 36A
		/// </summary>
		public decimal? InstrumentQuantity { get; set; }

		/// <summary>
		/// 70E - Narrative
		/// </summary>
		public string AdditionalDetails { get { return _sbDetails.ToString(); } }
		#endregion

		/// <summary>
		/// Instantiates Sequence E
		/// </summary>
		public SequenceE(string caRef, string senderRef)
		{
			_caRef = caRef;
			_senderRef = senderRef;
			_currentSubsequence = CurrentSubsequence.None;
		}

		private bool SubsequenceExistsInList(SequenceE subsequenceE1)
		{
			return SubsequenceE1S.Any(seqE1 => seqE1.CARef == subsequenceE1.CARef && seqE1.SenderRef == subsequenceE1.SenderRef && seqE1.CAOptionNumber == subsequenceE1.CAOptionNumber);
		}

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public override void Parse(string code, string text)
		{
			switch (_currentSubsequence)
			{
				case CurrentSubsequence.E1: _subsequenceE1.Parse(code, text);
					if (code == "16S" && text == "SECMOVE")
					{
						// Before adding it - check if such a sequence exists (to avoid PK violations)
						if (!SubsequenceExistsInList(_subsequenceE1))
							SubsequenceE1S.Add(_subsequenceE1);

						_currentSubsequence = CurrentSubsequence.None;
					}
					break;
				case CurrentSubsequence.E2: _subsequenceE2.Parse(code, text);
					if (code == "16S" && text == "CASHMOVE")
					{
						// Before adding it - check if such a sequence exists (to avoid PK violations)
						if (!SubsequenceExistsInList(_subsequenceE2))
							SubsequenceE2S.Add(_subsequenceE2);

						_currentSubsequence = CurrentSubsequence.None;
					}
					break;
				
				case CurrentSubsequence.None:
					switch (code)
					{
						case "16R": ParseField16R(text); return;
						case "16S": ParseField16S(text); return;
					}

					switch (code.Substring(0,2))
					{
						case "13": ParseField13A(text); break;
						case "22": ParseField22(text); break;
						case "94": ParseField94C(text); break;
						case "11": ParseField11A(text); break;
						case "17": ParseField17B(text); break;
						case "35": ParseField35B(text, out _sedol, out _entity); break;
						case "98": ParseField98A(text); break;
						case "69": ParseField69A(text); break;
						case "92": ParseField92A(text); break;
						case "90": ParseField90A(text); break;
						case "36": ParseField36A(text); break;
						case "70": ParseField70E(text); break;
						
						default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected field type {1} encountered.", GetType().Name, code));
					}
					break;
				default: throw new Exception(String.Format("{0}: Wrong control flow. This is most likely means that the message is malformed and the parser could not parse it. You may rerun with -ignorefailure as an alternative.", GetType().Name));
			}
		}

		public void ParseField16R(string input)
		{
			switch (input)
			{
				case "SECMOVE":
					_e1Counter++;
					_subsequenceE1 = new SubsequenceE1(CARef, SenderRef, CAOptionNumber, _e1Counter);
					_currentSubsequence = CurrentSubsequence.E1;
					break;
				case "CASHMOVE":
					_e2Counter++;
					_subsequenceE2 = new SubsequenceE2(CARef, SenderRef, CAOptionNumber, _e2Counter);
					_currentSubsequence = CurrentSubsequence.E2;
					break;
				case "CAOPTN":
					_currentSubsequence = CurrentSubsequence.None;
					break;
			}
		}

		public void ParseField16S(string input)
		{
			switch (input)
			{
				//case "SECMOVE":	// Add the just parsed subsequence E1 to list
				         //   SubsequenceE1S.Add(_subsequenceE1);
				         //   _currentSubsequence = CurrentSubsequence.None;
				         //   break;
				//case "CASHMOVE":
				        //    SubsequenceE2S.Add(_subsequenceE2);
				        //    _currentSubsequence = CurrentSubsequence.None;
				         //   break;
				case "CAOPTN": // Nop
					// was for when no 16S is encountered; ok, add but only if the same object is not already in the list
					/*
							if (_subsequenceE1 != null)
								SubsequenceE1S.Add(_subsequenceE1);
							if (_subsequenceE2 != null)
								SubsequenceE2S.Add(_subsequenceE2);
					 */ 
					break;
			}
		}

		/// <summary>
		/// 13A
		/// </summary>
		/// <example></example>
		/// <param name="input"></param>
		public void ParseField13A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "CAON": CAOptionNumber = int.Parse(s[1]); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered in field 13A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <example>Option F	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)</example>
		/// <param name="input"></param>
		public void ParseField22(string input)
		{
			var s = input.Split(new[] { "/" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "CAOP": CorpActionOptionCode = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1); break;
				case "DISF": DispFractionsInd = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1); break;
				case "OFFE": OfferType = input.Substring(input.LastIndexOf("/", StringComparison.Ordinal) + 1); break;

				case "OPTF": 
				case "OSTA":
				case "CETI":
							_sbField22.Append(input + ";");
					break;

				case "CRDB": // NOP: This is not part of the standard but sometimes 22H:CRDB//CRED does appear in Sequence E
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 22F.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Place
		/// </summary>
		/// <example>Option C	:4!c//2!a	(Qualifier)(Country Code)</example>
		/// <param name="input"></param>
		public void ParseField94C(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "DOMI": CountryDomicile = s[1];  break;
				case "NDOM": CountryNonDomicile = s[1]; break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 94C.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Currency
		/// </summary>
		/// <example>Option A	:4!c//3!a	(Qualifier)(Currency Code)</example>
		/// <param name="input"></param>
		public void ParseField11A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "OPTN": Currency = s[1]; break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 11A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Flag
		/// </summary>
		/// <example>Option B	:4!c//1!a	(Qualifier)(Flag)</example>
		/// <param name="input"></param>
		public void ParseField17B(string input)
		{
			Flag = input.Replace("//", ":");

			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			switch (s[0])
			{
				case "DFLT": IsDefault = s[1] == "Y";
					break;

				default:
					if (_hasParsed17B)
						throw new MoreThanOneParseAttemptException(String.Format("{0}: Field 17B has been encountered more than once in Sequence E.", GetType().Name));

					_hasParsed17B = true;
					Flag = s[1];
					FlagType = s[0];
					break;
			}
		}

		/// <summary>
		/// DateTime. Option A supported only
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n	(Qualifier)(Date)
		/// Option B	:4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Date Code)
		/// Option C	:4!c//8!n6!n	(Qualifier)(Date)(Time)
		/// Option E	:4!c//8!n6!n[,3n][/[N]2!n[2!n]]	(Qualifier)(Date)(Time)(Decimals)(UTC Indicator)
		/// </example>
		/// <param name="input"></param>
		public void ParseField98A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			if (s[1].Length == 4)
				return;

			switch (s[0])
			{
				case "DVCP": DepositoryCoverExpiration = ParseDateOptionalTime(s[1]); break;
				case "EARL": // This isn't in the standard but LSE send EARLs...
				case "EARD": EarlyResponseDeadline = ParseDateOptionalTime(s[1]); break;
				case "EXPI": ExpiryDate = ParseDateOptionalTime(s[1]); break;
				case "MKDT": MarketDeadline = ParseDateOptionalTime(s[1]); break;
				case "PODT": ProtectDate = ParseDateOptionalTime(s[1]); break;
				case "SUBS": SubscriptionCostDebit = ParseDateOptionalTime(s[1]); break;
				case "RDDT": ResponseDeadline = ParseDateOptionalTime(s[1]); break;
				case "CVPR": CoverExpiration = ParseDateOptionalTime(s[1]); break;

				/*
				// From the Chinese Site: older version of the standard - this is now in SECMOVE / CASHMOVE
				case "PAYD":
					if (_subsequenceE1 == null)
						_subsequenceE1 = new SubsequenceE1();
						_subsequenceE1.PayDate = ParseDateOptionalTime(s[1]);
					break;
				case "FXDT":
					if (_subsequenceE2 == null)
						_subsequenceE2 = new SubsequenceE2();
					_subsequenceE2.FXRateFixingDate = ParseDateOptionalTime(s[1]);
					break;
				case "SPLT": // TODO
					break;
					*/

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} for field 98.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Period
		/// </summary>
		/// <example>
		/// Option A	:4!c//8!n/8!n	(Qualifier)(Date)(Date)
		/// Option B	:4!c//8!n6!n/8!n6!n	(Qualifier)(Date)(Time)(Date)(Time)
		/// Option C	:4!c//8!n/4!c	(Qualifier)(Date)(Date Code)
		/// Option D	:4!c//8!n6!n/4!c	(Qualifier)(Date)(Time)(Date Code)
		/// Option E	:4!c//4!c/8!n	(Qualifier)(Date Code)(Date)
		/// Option F	:4!c//4!c/8!n6!n	(Qualifier)(Date Code)(Date)(Time)
		/// Option J	:4!c//4!c	(Qualifier)(Date Code)
		/// </example>
		/// <param name="input"></param>
		public void ParseField69A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			if (!Regex.IsMatch(s[0], "PRIC|REVO|PWAL|PARL|SUSP|AREV|DSWO"))
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 69A.", GetType().Name, s[0]));
			PeriodType = s[0];

			var splitResultB = s[1].Split(new[] {"/"}, StringSplitOptions.None);

			// Option J
			if (splitResultB.Length == 1)
			{
				PeriodStart = null;
				PeriodEnd = null;

				return;
			}

			// Option A
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{8}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{8}$"))
			{
				PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				return;
			}

			// Option B
			if (Regex.IsMatch(splitResultB[0], "^[0-9]{14}$") && Regex.IsMatch(splitResultB[1], "^[0-9]{14}$"))
			{
				PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				return;
			}

			// Option C, D
			if (splitResultB[1] == "ONGO" || splitResultB[1] == "UKWN")
			{
				PeriodEnd = null;
				try
				{
					PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					PeriodStart = DateTime.ParseExact(splitResultB[0], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
				return;
			}

			// Option E, F
			if (splitResultB[0] == "ONGO" || splitResultB[0] == "UKWN")
			{
				PeriodStart = null;

				try
				{
					PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					PeriodEnd = DateTime.ParseExact(splitResultB[1], "yyyyMMdd", CultureInfo.InvariantCulture);
				}
			}
		}

		/// <summary>
		/// Rate
		/// </summary>
		/// <example>Option A	:4!c//[N]15d				(Qualifier)(Sign)(Rate)
		///			 Option F	:4!c//3!a15d				(Qualifier)(Currency Code)(Amount)
		///			 Option J	:4!c/[8c]/4!c/3!a15d[/4!c]	(Qualifier)(Data Source Scheme)(Rate Type Code)(Currency Code)(Amount)(Rate Status)
		///			 Option K	:4!c//4!c					(Qualifier)(Rate Type Code)
		/// </example>
		/// <param name="input"></param>
		public void ParseField92A(string input)
		{
			var s = input.Contains("//") ? input.Split(new[] {"//"}, StringSplitOptions.None) : input.Split(new[] {"/"}, 2, StringSplitOptions.None);
			string currency = null;

			switch (s[0])
			{
				case "GRSS": DividendGrossRate = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "TAXE": TaxRelatedRate = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "TAXR": WithholdingTaxRate = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "ATAX": AdditionalTax = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "INDX": IndexFactor = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "OVEP": MaximumAllowedOversubRate = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "PROR": ProRationRate = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "INTP": InterestPaymentRate = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "TDMT": TaxableIncomePerDS = ParseNumberOptionalCurrency(s[1], out currency); break;
				
				case "WITF": ForeignTaxWithholding = ParseNumberOptionalCurrency(s[1], out currency); break;
				case "WITL": LocalTaxWithholding = ParseNumberOptionalCurrency(s[1], out currency); break;

				case "CHAR": ChargesRate = ParseNumberOptionalCurrency(s[1], out currency); break;	// Charges/Fees
				case "NETT": NetRateShare = ParseNumberOptionalCurrency(s[1], out currency); break;	// Net Dividend Rate
				case "TAXC": TaxCreditRate = ParseNumberOptionalCurrency(s[1], out currency); break;	// Tax Credit Rate
				case "FLFR": FullyFrankedRate = ParseNumberOptionalCurrency(s[1], out currency); break;	// Fully Franked Rate
				case "PDIV": ProvDividendRate = ParseNumberOptionalCurrency(s[1], out currency); break;	// Provisional Dividend Rate
				
				case "ADEX": // No; this data is not collected; not implemented;
					break;

				// Older files, older version of standard
				case "EXCH": 
					if (_subsequenceE2 == null)
						_subsequenceE2 = new SubsequenceE2(CARef, SenderRef, CAOptionNumber, _e2Counter);
					_subsequenceE2.ExchangeRate = ParseNumberOptionalCurrency(s[1], out currency); 
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} for field 92A. Note: Option J is not implemented.", GetType().Name, s[0]));
			}
			RateCurrency = currency;
		}


		/// <summary>
		/// Price
		/// </summary>
		/// <example>
		///		Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///		Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///		Option E	:4!c//4!c	(Qualifier)(Price Code)
		///		Option F	:4!c//4!c/3!a15d/4!c/15d	(Qualifier)(Amount Type Code)(Currency Code)(Amount)(Quantity Type Code)(Quantity)
		///		Option J	:4!c//4!c/3!a15d/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Amount)(Currency Code)(Amount)
		/// </example>
		/// <param name="input"></param>
		public void ParseField90A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			if (!Regex.IsMatch(input, "OFFR|CINL|OSUB|PRPP|MRKT")) //MRKT
				throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 90A.", GetType().Name, s[0]));

			// Option A: 4!c/15d
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}/\d+,\d*$"))
			{
				var splitA = s[1].Split(new[] { "/" }, StringSplitOptions.None);
				PriceAmountType = splitA[0];
				SetPrice90A(splitA[1], s[0]);
				return;
			}

			// Option B: 4!c/3!a15d
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}/[A-Z]{3}\d+,\d*$"))
			{
				var splitA = s[1].Split(new[] { "/" }, StringSplitOptions.None);

				PriceAmountType = splitA[0];
				PriceCurrency = splitA[1].Substring(0, 3);
				SetPrice90A(splitA[1].Substring(3), s[0]);
				return;
			}

			// Option E
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}$"))
			{
				GenericCashPriceReceived = GenericCashPricePaid = CashinLieuSharesPrice = OverSubDepositPrice = null;
				return;
			}

			// Option F
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}/[A-Z]{3}\d+,\d*/[A-Z]{4}/\d+,\d*$"))
			{
				var splitF = s[1].Split(new[] {"/"}, StringSplitOptions.None);
				
				// (Amount Type Code)/(Currency Code)(Amount)/(Quantity Type Code)(Quantity)
				PriceCurrency = splitF[1].Substring(0,3);
				PriceAmountType = s[1].Substring(0, s[1].IndexOf("/", StringComparison.Ordinal));
				SetPrice90A(splitF[1].Substring(3), s[0]);
				return;
			}

			// Option J
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}/[A-Z]{3}\d+,\d*/[A-Z]{3}\d+,\d*$"))
			{
				var splitJ = s[1].Split(new[] {"/"}, StringSplitOptions.None);
				// (Amount Type Code)(Currency Code)(Amount)(Currency Code)(Amount)
				PriceCurrency = splitJ[1].Substring(0,3);
				SetPrice90A(splitJ[1].Substring(3), s[0]);

				// Why twice : (Amount Type Code)(Currency Code)
				return;
			}

			throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in 90A.", GetType().Name));
		}

		private void SetPrice90A(string priceInput, string qualifier)
		{
			switch (qualifier)
			{
				case "OFFR": GenericCashPriceReceived = ParseDecimalFr(priceInput);
					break;
				case "CINL": CashinLieuSharesPrice = ParseDecimalFr(priceInput);
					break;
				case "OSUB": OverSubDepositPrice = ParseDecimalFr(priceInput);
					break;
				case "PRPP": GenericCashPricePaid = ParseDecimalFr(priceInput);
					break;
					
				//case "MRKT": // TODO
					//break;

				default:
					throw new UnexpectedCodeException(String.Format("{0}: Unexpected Price Type ({1}) in field 90A.", GetType().Name, qualifier));
			}
		}

		/// <summary>
		/// Quantity of Financial Instrument
		/// </summary>
		/// <example>Option B	:4!c//4!c/15d	(Qualifier)(Quantity Type Code)(Quantity)
		///			 Option C	:4!c//4!c		(Qualifier)(Quantity Code)</example>
		/// <param name="input"></param>
		public void ParseField36A(string input)
		{
			if (_hasParsed36A)
				throw new MoreThanOneParseAttemptException(String.Format("{0}: Field 36A has been encountered already.", GetType().Name));

			_hasParsed36A = true;
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			InstrumentQuantityType = s[0];

			// Option B
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}/\d+,\d*$"))
			{
				var splitB = s[1].Split(new[] { "/" }, StringSplitOptions.None);
				InstrumentQuantityTypeCode = splitB[0];
				InstrumentQuantity = ParseDecimalFr(splitB[1]);

				return;
			}

			// Option C
			if (Regex.IsMatch(s[1], @"^[A-Z]{4}$"))
			{
				InstrumentQuantityTypeCode = s[1];
				return;
			}

			throw new UnexpectedCodeException(String.Format("{0}: Unrecognized option in field 36A.", GetType().Name));
		}

		/// <summary>
		/// Narrative
		/// </summary>
		/// <example>Option E	:4!c//10*35x	(Qualifier)(Narrative)</example>
		public void ParseField70E(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			_sbDetails.Append(s[1] + ";");
		}

		public static string GetHeaders()
		{
			return "CARef|SenderRef|CAOptionNumber|Indicator|CorpActionOptionCode|DispFractionsInd|OfferType|CountryDomicile|CountryNonDomicile|Currency|Flag|FlagType|IsDefault|SEDOL|Entity" +
			       "|DepositoryCoverExpiration|EarlyResponseDeadline|ExpiryDate|MarketDeadline|ProtectDate|SubscriptionCostDebit|ResponseDeadline|CoverExpiration" +
			       "|PeriodStart|PeriodEnd|PeriodType|DividendGrossRate|TaxRelatedRate|WithholdingTaxRate|AdditionalTax|IndexFactor|MaximumAllowedOversubRate|ProRationRate" +
			       "|InterestPaymentRate|TaxableIncomePerDS|ForeignTaxWithholding|LocalTaxWithholding|ChargesRate|NetRateShare|TaxCreditRate|FullyFrankedRate|ProvDividendRate" +
			       "|RateCurrency|PriceAmountType|PriceCurrency|GenericCashPriceReceived|CashinLieuSharesPrice|OverSubDepositPrice|GenericCashPricePaid|InstrumentQuantityType" +
			       "|InstrumentQuantityTypeCode|InstrumentQuantity|AdditionalDetails";
		}

		public override string ToString()
		{
			return CARef + "|" + SenderRef + "|" + CAOptionNumber + "|" + Indicator + "|" + CorpActionOptionCode + "|" + DispFractionsInd + "|" + OfferType + "|" + CountryDomicile + "|" + CountryNonDomicile + "|" + Currency + "|" + Flag + "|" + FlagType + "|" + IsDefault + "|" + SEDOL + "|" + Entity +
					"|" + DepositoryCoverExpiration.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + EarlyResponseDeadline.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ExpiryDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MarketDeadline.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ProtectDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + SubscriptionCostDebit.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ResponseDeadline.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + CoverExpiration.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") +
					"|" + PeriodStart.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodEnd.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PeriodType + "|" + DividendGrossRate + "|" + TaxRelatedRate + "|" + WithholdingTaxRate + "|" + AdditionalTax + "|" + IndexFactor + "|" + MaximumAllowedOversubRate + "|" + ProRationRate +
					"|" + InterestPaymentRate + "|" + TaxableIncomePerDS + "|" + ForeignTaxWithholding + "|" + LocalTaxWithholding + "|" + ChargesRate + "|" + NetRateShare + "|" + TaxCreditRate + "|" + FullyFrankedRate + "|" + ProvDividendRate +
				   "|" + RateCurrency + "|" + PriceAmountType + "|" + PriceCurrency + "|" + GenericCashPriceReceived + "|" + CashinLieuSharesPrice + "|" + OverSubDepositPrice + "|" + GenericCashPricePaid + "|" + InstrumentQuantityType +
				   "|" + InstrumentQuantityTypeCode + "|" + InstrumentQuantity + "|" + AdditionalDetails;
		}
	}
}