﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	/// <summary>
	/// Sequence B - Underlying Securities. The Optional Subsequence B1 (Financial Instrument Attributes) has been incorporated into sequence B.
	/// </summary>
	public class SequenceB : Sequence
	{
		#region Fields
		private SubsequenceB2 _subSequenceB2;
		private readonly List<SubsequenceB2> _subsequenceB2S = new List<SubsequenceB2>();

		private string _sedol;
		private string _entity;
		#endregion

		#region SWIFT Message attributes
		/// <summary>
		/// Repetitive Mandatory Subsequence B2 Account Information
		/// </summary>
		public List<SubsequenceB2> SubsequenceB2S { get { return _subsequenceB2S; } }

		/// <summary>
		/// 35B
		/// </summary>
		public string SEDOL { get { return _sedol; } }

		/// <summary>
		/// 35B
		/// </summary>
		public string Entity { get { return _entity; } }

		// Optional subsequence  B1 - Financial Instrument Attributes
		#region Financial Instruments Attributes

		/// <summary>
		/// 94B
		/// </summary>
		public string PlaceListing { get; set; }

		/// <summary>
		/// 22F
		/// </summary>
		public string MICO { get; set; }
		
		/// <summary>
		/// 12A
		/// </summary>
		public string FIClassification { get; set; }
		/// <summary>
		/// 12A
		/// </summary>
		public string OptionStyle { get; set; }

		/// <summary>
		/// 11A
		/// </summary>
		public string Currency { get; set; }
		
		public DateTime? CallDate { get; set; }
		public DateTime? ConversionDate { get; set; }
		public DateTime? CouponDate { get; set; }
		public DateTime? DatedDate { get; set; }
		public DateTime? SecExpiryDate { get; set; }
		public DateTime? FloatingRateFixingDate { get; set; }
		public DateTime? IssueDate { get; set; }
		public DateTime? MaturityDate { get; set; }
		public DateTime? PutDate { get; set; }

		/// <summary>
		/// 92A - Percentage of Debt Claims
		/// </summary>
		public decimal? InstrPercentageDebtClaims { get; set; }
		/// <summary>
		/// 92A - Interest Rate
		/// </summary>
		public decimal? InstrInterestRate { get; set; }
		public decimal? InstrNextFactor { get; set; }
		public decimal? InstrNextInterestRate { get; set; }
		public decimal? InstrPrevFactor { get; set; }

		/// <summary>
		/// 36B - Quantity of Financial Instrument - type
		/// </summary>
		public string InstrQuantityType { get; set; }

		/// <summary>
		/// 36B: Minimum quantity of financial instrument or lot of rights/warrants that must be exercised
		/// </summary>
		public decimal? InstrMinimumExercisableQuantity { get; set; }
		/// <summary>
		/// 36B: Minimum multiple quantity of financial instrument or lot of rights/warrants that must be exercised.
		/// </summary>
		public decimal? InstrMinimumExercisableMultipleQuantity { get; set; }
		/// <summary>
		/// 36B: Minimum nominal quantity of financial instrument that must be purchased/sold.
		/// </summary>
		public decimal? InstrMinimumNominalQuantity { get; set; }

		/// <summary>
		/// 36B: Ratio or multiplying factor used to convert one contract into a financial instrument quantity.
		/// </summary>
		public decimal? InstrContractSize { get; set; }
		#endregion
		#endregion

		/// <summary>
		/// Main Parse entry method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public override void Parse(string code, string text)
		{
			switch (code)
			{
				case "16R": ParseField16R(text); break;
				case "35B": ParseField35B(text, out _sedol, out _entity); break;
				case "94B": ParseField94B(text); break;
				case "22F": ParseField22F(text); break;
			
				case "12A": 
				case "12B":
				case "12C": ParseField12A(text); break;
				case "11A": ParseField11A(text); break;
				case "98A": ParseField98A(text); break;
				case "92A": 
				case "92K":
							ParseField92A(text); break;
				case "36B": ParseField36B(text); break;
				case "16S": ParseField16S(text); break;
				
				// 95P  95R 
				case "95A": _subSequenceB2.ParseField95A(text); break;
				
				case "97A":
				case "97C":
							_subSequenceB2.ParseField97A(text); break;

				case "94A": 
				//case "94B":
				case "94C":
				case "94F":
							_subSequenceB2.ParseField94A(text); break;
				case "93A": _subSequenceB2.ParseField93A(text); break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} for this sequence.", GetType().Name, code));
			}
		}

		/// <summary>
		/// Currency of denomination
		/// </summary>
		/// <param name="input"></param>
		public void ParseField11A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch(s[0])
			{
				case "DENO": Currency = s[1];
					break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 11A.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Types of Financial Instrument
		/// </summary>
		/// <example>:4!c/[8c]/30x
		/// :4!c/[8c]/4!c
		/// :4!c//6!c
		/// </example>
		/// <param name="input"></param>
		public void ParseField12A(string input)
		{
			var regexClas = new Regex("^CLAS");
			var regexOPST = new Regex("^OPST");

			if (regexClas.IsMatch(input))
			{
				input = regexClas.Replace(input, string.Empty, 1);
				var regexDash = new Regex("^/{1,2}");
				input = regexDash.Replace(input, string.Empty);
				FIClassification = input;
				return;
			}
			if (regexOPST.IsMatch(input))
			{
				input = regexClas.Replace(input, string.Empty, 1);
				var regexDash = new Regex("^/{1,2}");
				input = regexDash.Replace(input, string.Empty);
				OptionStyle = input;
				return;
			}

			throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 12A.", GetType().Name, input));
		}

		public void ParseField16R(string input)
		{
			// USECU
			// ACCTINFO
			// FIA
			switch (input)
			{
				case "FIA": // NOP 
							// SubsequenceB1 = new SubsequenceB1(); 
							break;
				case "ACCTINFO": _subSequenceB2 = new SubsequenceB2();
							break;
			}
		}

		public void ParseField16S(string input)
		{
			//	ACCTINFO
			//	USECU
			switch (input)
			{
				case "FIA": // Nop
					break;
				case "ACCTINFO":	// Add Account Information only if the Account value is not "NONREF" as Market Data Providers do not act in the capacity of Securities Account Servicers
					// therefor SafeKeeping account is not needed (The field is mandatory though, according to ISO)
					/*
					if (_subSequenceB2.SafeKeepingAccount != "NONREF")
					{
						// TEMP
						throw new ApplicationException("Thrown because a subsequence B2 contains safekeepingaccount different that NONREF.");
						_subsequenceB2S.Add(_subSequenceB2);
					}
					 */ 
					break;
				case "USECU": // Nop ; Validate?
					break;
			}
		}

		public void ParseField22F(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch(s[0])
			{
				case "MICO":
					string res = string.Empty;
					for (int i = 1; i < s.Length; i++)
						res += s[i];

					MICO = res;
					break;

				//case "DIVI": // TODO
					//break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 22F.", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Quantity of Financial Instrument
		/// </summary>
		/// <example>:4!c//4!c/15d</example>
		/// <param name="input"></param>
		public void ParseField36B(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			var splitB = s[1].Split(new[] {"/"}, StringSplitOptions.None);
			var value = ParseDecimalFr(splitB[1]);

			switch(s[0])
			{
				case "MIEX": // Minimum Exercisable Quantity
					InstrMinimumExercisableQuantity = value;
					InstrQuantityType = splitB[0];
					break;

				case "MILT": // Minimum Exercisable Multiple Quantity
					InstrMinimumExercisableMultipleQuantity = value;
					InstrQuantityType = splitB[0];
					break;

				case "MINO": // Minimum Nominal Quantity
					InstrMinimumNominalQuantity = value;
					InstrQuantityType = splitB[0];
					break;

				case "SIZE": // Contract Size
					InstrContractSize = value;
					InstrQuantityType = splitB[0];
					break;
			}
		}


		/// <summary>
		/// Rate (Subsequence B1)
		/// </summary>
		/// <param name="input"></param>
		public void ParseField92A(string input)
		{
			if (Regex.IsMatch(input, "UKWN"))
				return;

			var s = input.Split(new[] {"//"}, StringSplitOptions.None);
			var rate = ParseDecimalFr(s[1].Replace("N", "-"));

			switch (s[0])
			{
				case "PRFC": InstrPrevFactor = rate; break;
				case "DECL": InstrPercentageDebtClaims = rate; break;
				case "INTR": InstrInterestRate = rate; break;
				case "NWFC": InstrNextFactor = rate; break;
				case "NXRT": InstrNextInterestRate = rate ; break;
				
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in 92A (Subsequence B1).", GetType().Name, s[0]));
			}
		}

		/// <summary>
		/// Place of listing
		/// </summary>
		/// <example>PLIS//EXCH/XLON</example>
		/// <param name="input"></param>
		public void ParseField94B(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch(s[0])
			{
				case "PLIS": PlaceListing = s[1]; break;
				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code in field 94B.", GetType().Name));
			}
		}

		/// <summary>
		/// Optional Subsequence B1 - Underlying securities
		/// </summary>
		/// <param name="input"></param>
		public void ParseField98A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch(s[0])
			{
				case "CALD": CallDate = ParseDateOptionalTime(s[1]);
					break;

				case "CONV": ConversionDate = ParseDateOptionalTime(s[1]);
					break;

				case "COUP": CouponDate = ParseDateOptionalTime(s[1]);
					break;

				case "DDTE": DatedDate = ParseDateOptionalTime(s[1]);
					break;

				case "EXPI": SecExpiryDate = ParseDateOptionalTime(s[1]);
					break;

				case "FRNR": FloatingRateFixingDate = ParseDateOptionalTime(s[1]);
					break;

				case "ISSU": IssueDate = ParseDateOptionalTime(s[1]);
					break;

				case "MATU": MaturityDate = ParseDateOptionalTime(s[1]);
					break;

				case "PUTT": PutDate = ParseDateOptionalTime(s[1]);
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected (all implemented) code in field 98A (Optional Subsequence B1)", GetType().Name));
			}
		}

		public static string GetHeaders()
		{
			return "SEDOL|Entity|PlaceListing|MICO|FIClassification|OptionStyle|Currency|CallDate|ConversionDate" +
			       "|CouponDate|DatedDate|SecExpiryDate|FloatingRateFixingDate|IssueDate|MaturityDate|PutDate" +
			       "|InstrPercentageDebtClaims|InstrInterestRate|InstrNextFactor|InstrNextInterestRate|InstrPrevFactor|InstrQuantityType" +
			       "|InstrMinimumExercisableQuantity|InstrMinimumExercisableMultipleQuantity|InstrMinimumNominalQuantity|InstrContractSize";
		}

		public override string ToString()
		{
			return SEDOL + "|" + Entity + "|" + PlaceListing + "|" + MICO + "|" + FIClassification + "|" + OptionStyle + "|" + Currency + "|" + CallDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + ConversionDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" +
				   CouponDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + DatedDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + SecExpiryDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + FloatingRateFixingDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + IssueDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + MaturityDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + PutDate.ToStringOrDefault("yyyy-MM-dd HH:mm:ss") + "|" + 
				   InstrPercentageDebtClaims + "|" + InstrInterestRate + "|" +  InstrNextFactor + "|" + InstrNextInterestRate + "|" + InstrPrevFactor + "|" + InstrQuantityType + "|" + 
				   InstrMinimumExercisableQuantity + "|"+ InstrMinimumExercisableMultipleQuantity + "|" + InstrMinimumNominalQuantity + "|" + InstrContractSize;
			
			// SubsequenceB2S is not exported as it contains safekeeping account information
		}
	}
}