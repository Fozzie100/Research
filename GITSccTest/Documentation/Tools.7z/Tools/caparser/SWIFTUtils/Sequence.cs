﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace SWIFTUtils
{
	public abstract class Sequence
	{
		public abstract void Parse(string code, string text);

		private static CultureInfo CultureFr
		{
			get { return CultureInfo.CreateSpecificCulture("fr-FR"); }
		}

		public static decimal? ParseDecimalFr(string input)
		{
			if (string.IsNullOrWhiteSpace(input))
				return null;

			if (input == "UKWN" || input == "OPEN" || input == "ANYA")
				return null;

			return Decimal.Parse(input.Replace("N", "-"), CultureFr);
		}

		public static decimal? ParseNumberOptionalCurrency(string input, out string currency)
		{
			currency = null;
			if (string.IsNullOrWhiteSpace(input))
				return null;

			// Option A
			if (Regex.IsMatch(input, @"^N*\d+,\d*$"))
				return Decimal.Parse(input.Replace("N", "-"), CultureFr);

			// Option F
			if (Regex.IsMatch(input, @"^[A-Z]{3}\d+,\d*$"))
			{
				currency = input.Substring(0, 3);
				return Decimal.Parse(input.Substring(3), CultureFr);
			}

			// Option K
			if (Regex.IsMatch(input, @"^[A-Z]{4}$"))
			{
				// In this case the rate is either NILP (nil) or UKWN - unknown
				return null;
			}
			throw new ArgumentOutOfRangeException(String.Format("Could not parse the input {0} as a date /with or without hh:mm:ss/.", input));
		}

		public static DateTime? ParseDateOptionalTime(string input, bool throwExceptionBadInput = false)
		{
			if (String.IsNullOrWhiteSpace(input))
				return null;

			if (input == "ONGO" || input == "UKWN" || input == "OPEN")
				return null;

			try
			{
				return DateTime.ParseExact(input, "yyyyMMdd", CultureInfo.InvariantCulture);
			}
			catch (FormatException)
			{
				try
				{
					return DateTime.ParseExact(input, "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
				}
				catch (FormatException)
				{
					if (throwExceptionBadInput)
						throw;

					return null;
				}
			}
		}

		public static string ParseAmountTypeCode(string input)
		{
			if (input.Contains("/ACTU/"))
				return "ACTU";
			if (input.Contains("/DISC/"))
				return "DISC";
			if (input.Contains("/PLOT/"))
				return "PLOT";
			if (input.Contains("/PREM/"))
				return "PREM";

			return null;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <example>/GB/B43GVJ8
		/// /HAZEL RENEWABLE ENERGY 
		/// VCT 2 PLC/ORD GBP0.001</example>
		/// <param name="input"></param>
		/// <param name="sedol"> </param>
		/// <param name="entity"> </param>
		public void ParseField35B(string input, out string sedol, out string entity)
		{
			var regexDash = new Regex(@"^\s*/");
			input = regexDash.Replace(input, string.Empty);
			var s = input.Split(new[] {"/"}, 3, StringSplitOptions.None);
			sedol = entity = null;

			for (int i = 0; i < s.Length; i++)
				if (s[i].Length == 6 || s[i].Length == 7)
				{
					sedol = s[i];
					if (i + 1 < s.Length)
					{
						entity = s[i + 1];
						break;
					}
				}
		}
	}
}