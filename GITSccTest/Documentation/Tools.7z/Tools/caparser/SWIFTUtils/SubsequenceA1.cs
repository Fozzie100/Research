﻿using System;
using SWIFTUtils.Exceptions;

namespace SWIFTUtils
{
	public class SubsequenceA1: SequenceA
	{
		private readonly int _a1No;

		#region SWIFT Message attributes
		public string LinkType { get; set; }
		public string LinkedMessage { get; set; }
		//public string Reference { get; set; }

		public string LinkCARef { get; private set; }
		public string PrevMessageRef { get; private set; }
		public string CaseNo { get; private set; }
		#endregion

		public SubsequenceA1(string caRef, string senderRef, int a1No)
		{
			CARef = caRef;
			SenderRef = senderRef;
			_a1No = a1No;
		}

		/// <summary>
		/// Main method
		/// </summary>
		/// <param name="code"></param>
		/// <param name="text"></param>
		public override void Parse(string code, string text)
		{
			switch (code)
			{
				case "22F": ParseField22F(text);
					break;
				case "13A": ParseField13A(text);
					break;
				case "20C": ParseField20C(text);
					break;
					
				case "16S": // Nop
					//base.Parse(code, text);
					break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} encountered.", GetType().Name, code));
			}
		}

		public void ParseField13A(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			switch (s[0])
			{
				case "LINK": LinkedMessage = s[1]; break;
			}
		}

		/// <summary>
		/// Indicator: Corporate Action Type
		/// </summary>
		/// <param name="input"></param>
		public new void ParseField22F(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);

			switch (s[0])
			{
				case "LINK": 
					LinkType = s[1];
					break;

					/*
					if (_subsequenceA1 == null)
						throw new ApplicationException("Unexpected LINK code without 16R:LINK start of link section code.");

					_subsequenceA1.LinkType = s[1];
					break;
					*/

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 22F.", GetType().Name, s[0]));
			}
		}

		public void ParseField20C(string input)
		{
			var s = input.Split(new[] { "//" }, StringSplitOptions.None);
			switch (s[0])
			{
				case "COAF":
				case "CORP": LinkCARef = s[1]; break;
				case "PREV":
				case "RELA": PrevMessageRef = s[1]; break;
				case "CACN": CaseNo = s[1]; break;

				default: throw new UnexpectedCodeException(String.Format("{0}: Unexpected code {1} in field 20C.", GetType().Name, s[0]));
			}
		}

		public new static string GetHeaders()
		{
			return "CARef|SenderRef|No|LinkType|LinkedMessage|LinkCARef|PrevMessageRef|CaseNo";
		}

		public override string ToString()
		{
			return CARef + "|" + SenderRef + "|" + _a1No + "|" + LinkType + "|" + LinkedMessage + "|" + LinkCARef + "|" + PrevMessageRef + "|" + CaseNo;
		}
	}
}