﻿using System;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SequenceC_Tests
	{
		[TestMethod]
		public void Can_ParseField36A_Negative()
		{
			const string input = "QINT//UNIT/N1234546543,"; // 4!c//4!c/[N]15d

			var sequenceC = new SequenceC();
			sequenceC.ParseField36A(input);

			Assert.AreEqual(-1234546543.0M, sequenceC.SecurityQuantity);
		}

		[TestMethod]
		public void Can_ParseField36A_Positive()
		{
			const string input = "QINT//UNIT/1234546543,"; // 4!c//4!c/15d

			var sequenceC = new SequenceC();
			sequenceC.ParseField36A(input);

			Assert.AreEqual(1234546543.0M, sequenceC.SecurityQuantity);
		}

		[TestMethod]
		public void Can_ParseField22F_NoDataSourceScheme()
		{
			const string input = "DISF//RDDN"; // 4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)

			var sequenceC = new SequenceC();
			sequenceC.ParseField22F(input);

			Assert.AreEqual("DISF", sequenceC.SecIndicatorType);
			Assert.AreEqual("RDDN", sequenceC.SecIndicator);
		}

		[TestMethod]
		public void Can_ParseField22F_WithDataSourceScheme()
		{
			const string input = "DISF/abcdefgh/RDDN"; // 4!c/[8c]/4!c	(Qualifier)(Data Source Scheme)(Indicator)

			var sequenceC = new SequenceC();
			sequenceC.ParseField22F(input);

			Assert.AreEqual("DISF", sequenceC.SecIndicatorType);
			Assert.AreEqual("RDDN", sequenceC.SecIndicator);
		}

		[TestMethod]
		public void Can_ParseField90B()
		{
			const string input = "MRKT//ACTU/USD3,";
			
			var sequenceC = new SequenceC();
			sequenceC.ParseField90B(input);

			Assert.AreEqual(3M, sequenceC.MarketPrice);
			Assert.AreEqual("USD", sequenceC.MarketPriceCurrency);
		}

		[TestMethod]
		public void Can_ParseField98A()
		{
			var sequenceC = new SequenceC();
			string input = "EXPI//20120302";
			sequenceC.ParseField98A(input);

			Assert.AreEqual(DateTime.ParseExact("20120302", "yyyyMMdd", CultureInfo.InvariantCulture), sequenceC.ExpiryDate);

			input = "POST/SMTH/20120301";
			sequenceC.ParseField98A(input);

			Assert.AreEqual(DateTime.ParseExact("20120301", "yyyyMMdd", CultureInfo.InvariantCulture), sequenceC.PostingDate);
		}

		[TestMethod]
		public void Can_ParseField93A()
		{
			var sequenceC = new SequenceC();
			//Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
			string input = "UNBA/abcedfgh/AMOR/N12,3";
			sequenceC.ParseField93A(input);

			Assert.AreEqual(-12.3m, sequenceC.Balance);

			// Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)
			input = "INBA/FAMT/ELIG/N4,5";
			sequenceC.ParseField93A(input);

			Assert.AreEqual(-4.5m, sequenceC.Balance);
		}

		[TestMethod]
		public void Can_ParseField69A()
		{
			var sequenceC = new SequenceC();

			// Option A
			string input = "TRDP//20120419/20120420";
			sequenceC.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120419", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120420", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);

			// Option B
			input = "TRDP//20120419120000/20120420120000";
			sequenceC.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120419120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120420120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);

			// Option C
			input = "TRDP//20120419/ONGO";
			sequenceC.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120419", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(null, sequenceC.TradingPeriodEnd);

			// Option D
			input = "TRDP//20120419120000/ONGO";
			sequenceC.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120419120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodStart);
			Assert.AreEqual(null, sequenceC.TradingPeriodEnd);

			// Option E
			input = "TRDP//ONGO/20120419";
			sequenceC.ParseField69A(input);
			Assert.AreEqual(null, sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120419", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);

			// Option F
			input = "TRDP//ONGO/20120419120000";
			sequenceC.ParseField69A(input);
			Assert.AreEqual(null, sequenceC.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120419120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), sequenceC.TradingPeriodEnd);
		}
	}
}