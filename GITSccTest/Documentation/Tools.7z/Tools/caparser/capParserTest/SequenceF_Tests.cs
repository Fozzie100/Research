﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SequenceF_Tests
	{
		[TestMethod]
		public void Can_ParseField95A_OptionPQ()
		{
			// Option P	:4!c//4!a2!a2!c[3!c]	(Qualifier)(Identifier Code)
			// Option Q	:4!c//4*35x	(Qualifier)(Name and Address)
			// Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)
			const string input = "REGR//FGTRTYGHERTRGH";
			var sequenceF = new SequenceF();
			sequenceF.ParseField95A(input);

			Assert.AreEqual("FGTRTYGHERTRGH", sequenceF.Registrar);
			Assert.AreEqual(string.Empty, sequenceF.Party);
		}

		[TestMethod]
		public void Can_ParseField95A_OptionR()
		{
			// Option P	:4!c//4!a2!a2!c[3!c]	(Qualifier)(Identifier Code)
			// Option Q	:4!c//4*35x	(Qualifier)(Name and Address)
			// Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)

			const string input = "PAYA/ABCERDFG/azxcvbnmzxcvbnmzxcvbnmzxcvbnmnbvcx";
			var sequenceF = new SequenceF();
			sequenceF.ParseField95A(input);

			Assert.AreEqual("azxcvbnmzxcvbnmzxcvbnmzxcvbnmnbvcx//", sequenceF.Party);
		}
	}
}