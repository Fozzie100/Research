﻿using System;
using System.Globalization;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SubsequenceE1_Tests
	{
		[TestMethod]
		public void Can_ParseField22H()
		{
			var subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			string input = "TEMP/ABCEDFGT/TEMP";

			subsequenceE1.ParseField22(input);

			Assert.AreEqual("TEMP", subsequenceE1.IndicatorType);
			Assert.AreEqual("TEMP", subsequenceE1.Indicator);

			input = "CRDB//NELP";
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			subsequenceE1.ParseField22(input);

			Assert.AreEqual("CRDB", subsequenceE1.IndicatorType);
			Assert.AreEqual("NELP", subsequenceE1.Indicator);
		}

		[TestMethod]
		public void Can_ParseField36B()
		{
			var subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			string input = "ENTL//UNIT/3,4";

			subsequenceE1.ParseField36B(input);

			Assert.AreEqual("UNIT", subsequenceE1.EntitledQuantityType);
			Assert.AreEqual(3.4m, subsequenceE1.EntitledQuantity);
		}


		[TestMethod]
		public void Can_ParseField11A()
		{
			var subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			string input = "OPTN//EUR";

			subsequenceE1.ParseField11A(input);
			Assert.AreEqual("EUR", subsequenceE1.CurrencyOption);
		}

		/// <summary>
		/// Trading Period Start,End
		/// </summary>
		[TestMethod]
		public void Can_ParseField69A()
		{
			var subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			// Option A
			string input = "TRDP//20120423/20120424";
			subsequenceE1.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120423", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120424", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodEnd);

			// Option B
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			input = "TRDP//20120423120000/20120424120000";
			subsequenceE1.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120423120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120424120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodEnd);
			
			// Option C
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			input = "TRDP//20120423/ONGO";
			subsequenceE1.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120423", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodStart);
			Assert.AreEqual(null, subsequenceE1.TradingPeriodEnd);

			// Option D
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			input = "TRDP//20120423120000/UKWN";
			subsequenceE1.ParseField69A(input);
			Assert.AreEqual(DateTime.ParseExact("20120423120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodStart);
			Assert.AreEqual(null, subsequenceE1.TradingPeriodEnd);

			// Option E
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			input = "TRDP//UKWN/20120424";
			subsequenceE1.ParseField69A(input);
			Assert.AreEqual(null, subsequenceE1.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120424", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodEnd);

			// Option F
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			input = "TRDP//UKWN/20120424120000";
			subsequenceE1.ParseField69A(input);
			Assert.AreEqual(null, subsequenceE1.TradingPeriodStart);
			Assert.AreEqual(DateTime.ParseExact("20120424120000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture), subsequenceE1.TradingPeriodEnd);

			// Option J
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			input = "TRDP//UKWN";
			subsequenceE1.ParseField69A(input);
			Assert.IsNull(subsequenceE1.TradingPeriodStart);
			Assert.IsNull(subsequenceE1.TradingPeriodEnd);
		}

		[TestMethod]
		public void Can_ParseField90A()
		{
			// Option A
			string input = "MRKT//PREM/34,5";
			var subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			subsequenceE1.ParseField90A(input);
			Assert.AreEqual(34.5m, subsequenceE1.MarketPrice);
			Assert.IsNull(subsequenceE1.PriceCurrency);

			// Option B
			input = "MRKT//PREM/EUR4,5";
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			subsequenceE1.ParseField90A(input);
			Assert.AreEqual(4.5m, subsequenceE1.MarketPrice);
			Assert.AreEqual("EUR", subsequenceE1.PriceCurrency);

			// Option C
			input = "MRKT//UKWN";
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			subsequenceE1.ParseField90A(input);
			Assert.IsNull(subsequenceE1.MarketPrice);
		}

		[TestMethod]
		public void Can_ParseField92A()
		{
			/*
			// Option A	:4!c//[N]15d	(Qualifier)(Sign)(Rate)
			var subsequenceE1 = new SubsequenceE1();
			string input = "ADEX//N4,75";
			subsequenceE1.ParseField92(input);
			Assert.AreEqual(InstrRateType);
			Assert.AreEqual(4.75m, subsequenceE1.InstrRate);

			// Option D :4!c//15d/15d	(Qualifier)(Quantity)(Quantity)
			input = "ADEX//3,4/5,6";
			subsequenceE1 = new SubsequenceE1();
			subsequenceE1.ParseField92(input);
			Assert.AreEqual(InstrRateType);
			Assert.AreEqual();

			// Option K :4!c//4!c	(Qualifier)(Rate Type Code)
			input = "ADSR//UKWN";
			subsequenceE1 = new SubsequenceE1();
			subsequenceE1.ParseField92(input);
			Assert.AreEqual(InstrRateType);
			Assert.AreEqual();

			// Option L	:4!c//3!a15d/3!a15d	(Qualifier)(First Currency Code)(Amount)(Second Currency Code)(Amount)
			input = "NEWO//EUR43,5/BGN5,6";
			subsequenceE1 = new SubsequenceE1();
			subsequenceE1.ParseField92(input);
			Assert.AreEqual(InstrRateType);
			Assert.AreEqual();


			// Option M	:4!c//3!a15d/15d	(Qualifier)(Currency Code)(Amount)(Quantity)
			input = "TRAT//EUR3,5/5,";
			subsequenceE1 = new SubsequenceE1();
			subsequenceE1.ParseField92(input);
			Assert.AreEqual();

			// Option N	:4!c//15d/3!a15d	(Qualifier)(Quantity)(Currency Code)(Amount)
			input = "TRAT//5/EUR5,13";
			subsequenceE1 = new SubsequenceE1();
			subsequenceE1.ParseField92(input);
			Assert.AreEqual();
			*/
		}

		[TestMethod]
		public void Can_ParseField98A()
		{
			var subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			// Option A
			string input = "PAYD//20120401";
			subsequenceE1.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120401", "yyyyMMdd", CultureInfo.InvariantCulture), subsequenceE1.PayDate);

			// Option C
			input = "PAYD//20120401120000";
			subsequenceE1 = new SubsequenceE1("", "", 0, 0);
			subsequenceE1.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120401120000", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), subsequenceE1.PayDate);
		}
	}
}