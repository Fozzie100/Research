﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SwiftMessage564Test
	{
		[TestMethod]
		public void TestMethod1()
		{

			List<string> lines = new List<string> {"${1:F01XLONGB2LASMD1234123456}{2:I564XXXXXXXX0XXXXN}{4:", 
				":16R:GENL", 
				":20C::CORP//600049278", 
				"/GUARANTY TRUST BANK/GDR",
				":20C::SEME//LSE60026", 
				":23G:REPL", 
				":22F::CAEV//DVCA", 
				":22F::CAMV//MAND",
				":98C::PREP//20120328082703",
				":25D::PROC//PREC",
				":16R:LINK",
				":22F::LINK//INFO",
				":13A::LINK//564",
				":20C::PREV//LSE60016",
				":16S:LINK",
				":16S:GENL"
			};

			var message = new SwiftMessage564(lines);
			message.Parse();

		}
	}
}
