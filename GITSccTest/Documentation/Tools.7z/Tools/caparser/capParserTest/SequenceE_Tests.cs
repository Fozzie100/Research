﻿using System;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SequenceE_Tests
	{
		[TestMethod]
		public void Can_ParseField22F()
		{
			string input = "CAOP//SECU";
			var sequenceE = new SequenceE("", "");
			sequenceE.ParseField22(input);

			Assert.AreEqual("SECU", sequenceE.CorpActionOptionCode);

			input = "OSTA//SECU";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField22(input);

			Assert.AreEqual("OSTA//SECU;", sequenceE.Indicator);
		}

		[TestMethod]
		public void Can_ParseField92A()
		{
			var sequenceE = new SequenceE("", "");

			// Option A
			string input = "GRSS//N12,3";
			sequenceE.ParseField92A(input);

			Assert.AreEqual(-12.3m, sequenceE.DividendGrossRate);
			Assert.IsNull(sequenceE.RateCurrency);

			// Option F
			input = "GRSS//BEL12,3";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField92A(input);

			Assert.AreEqual(12.3m, sequenceE.DividendGrossRate);
			Assert.AreEqual("BEL", sequenceE.RateCurrency);

			//Option K
			input = "GRSS//UKWN";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField92A(input);

			Assert.IsNull(sequenceE.DividendGrossRate);
			Assert.IsNull(sequenceE.RateCurrency);
		}

		[TestMethod]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void ThEx_ParseField92A()
		{
			var sequenceE = new SequenceE("", "");
			string input = "GRSS/abcdfgtr/RTEW/BEL12345678987";
			sequenceE.ParseField92A(input);
		}

		[TestMethod]
		public void Can_ParseField90A()
		{
			var sequenceE = new SequenceE("", "");

			// Option A
			string input = "OFFR//DISC/12,3";
			sequenceE.ParseField90A(input);

			Assert.AreEqual(null, sequenceE.PriceCurrency);
			Assert.AreEqual(12.3m, sequenceE.GenericCashPriceReceived);

			// Option B
			input = "CINL//ACTU/BEL12,4";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField90A(input);

			Assert.AreEqual("BEL", sequenceE.PriceCurrency);
			Assert.AreEqual(12.4m, sequenceE.CashinLieuSharesPrice);
			Assert.AreEqual("ACTU", sequenceE.PriceAmountType);

			// Option E
			input = "OSUB//UKWN";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField90A(input);

			Assert.AreEqual(null, sequenceE.PriceCurrency);
			Assert.AreEqual(null, sequenceE.OverSubDepositPrice);
			Assert.AreEqual(null, sequenceE.PriceAmountType);

			// Option F
			input = "PRPP//ACTU/BEL12,9/AMOR/123,";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField90A(input);

			Assert.AreEqual("BEL", sequenceE.PriceCurrency);
			Assert.AreEqual(12.9m, sequenceE.GenericCashPricePaid);
			Assert.AreEqual("ACTU", sequenceE.PriceAmountType);


			// Option J
			// Not implemented
		}

		[TestMethod]
		public void Can_ParseField36A()
		{
			var sequenceE = new SequenceE("", "");

			string input = "MAEX//FAMT/15,2";
			sequenceE.ParseField36A(input);

			Assert.AreEqual("MAEX", sequenceE.InstrumentQuantityType);
			Assert.AreEqual("FAMT", sequenceE.InstrumentQuantityTypeCode);
			Assert.AreEqual(15.2m, sequenceE.InstrumentQuantity);

			input = "MILT//UNIT";
			sequenceE = new SequenceE("", "");
			sequenceE.ParseField36A(input);

			Assert.AreEqual("MILT", sequenceE.InstrumentQuantityType);
			Assert.AreEqual("UNIT", sequenceE.InstrumentQuantityTypeCode);
			Assert.AreEqual(null, sequenceE.InstrumentQuantity);
		}

		[TestMethod]
		public void Can_Parse94C()
		{
			var sequenceE = new SequenceE("", "");
			string input = "NDOM//BEL";
			sequenceE.ParseField94C(input);
			Assert.AreEqual("BEL", sequenceE.CountryNonDomicile);

			input = "DOMI//GRC";
			sequenceE.ParseField94C(input);
			Assert.AreEqual("GRC", sequenceE.CountryDomicile);
		}

		[TestMethod]
		public void Can_Parse98A()
		{
			var sequence = new SequenceE("", "");
			string input = "DVCP//20120101";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.DepositoryCoverExpiration);

			input = "EARD//20120101";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.EarlyResponseDeadline);

			input = "EXPI//20120101";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.ExpiryDate);

			input = "MKDT//20120101120000";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101120000", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), sequence.MarketDeadline);

			input = "PODT//20120101";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.ProtectDate);

			input = "SUBS//20120101";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.SubscriptionCostDebit);

			input = "RDDT//20120101";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.ResponseDeadline);

			input = "CVPR//20120101";
			sequence.ParseField98A(input);
			Assert.AreEqual(DateTime.ParseExact("20120101", "yyyyMMdd", CultureInfo.InvariantCulture), sequence.CoverExpiration);
		}
	}
}