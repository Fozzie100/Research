﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SubsequenceE1a_Tests
	{
		[TestMethod]
		public void Can_ParseField_94B()
		{
			var subsequenceE1A = new SubsequenceE1A("", "", 0, 0);
			string input = "PLIS//EXCH/XNYS";
			subsequenceE1A.FIParseField94B(input);

			Assert.AreEqual("EXCH", subsequenceE1A.PlaceListingType);
			Assert.AreEqual("XNYS", subsequenceE1A.PlaceListing);
		}

		[TestMethod]
		public void Can_ParseField_22F()
		{
			var subsequenceE1A = new SubsequenceE1A("", "", 0, 0);
			string input = "MICO/A001";
			subsequenceE1A.FIParseField22F(input);

			Assert.AreEqual("A001", subsequenceE1A.MICO);
		}

		[TestMethod]
		public void Can_ParseField12A()
		{
			var subsequenceE1A = new SubsequenceE1A("", "", 0, 0);
			string input = "CLAS//ESVUFA";
			subsequenceE1A.FIParseField12A(input);

			Assert.AreEqual("CLAS", subsequenceE1A.InstrTypeCode);
			Assert.AreEqual("ESVUFA", subsequenceE1A.InstrType);
		}

		[TestMethod]
		public void Can_ParseField11A()
		{
			var subsequenceE1A = new SubsequenceE1A("", "", 0, 0);
			string input = "DENO//BGL";
			subsequenceE1A.FIParseField11A(input);

			Assert.AreEqual("BGL", subsequenceE1A.InstrCurrency);
		}

		//[TestMethod]
		//public void Can_ParseField98A()
		//{
		//    var subsequenceE1A = new SubsequenceE1a();
		//    string input = "COUP//20120315";
		//    subsequenceE1A.FIParseField98A(input);

		//    Assert.AreEqual("COUP", subsequenceE1A.DateType);
		//    Assert.AreEqual(DateTime.ParseExact("20120315", "yyyyMMdd", CultureInfo.InvariantCulture), subsequenceE1A.Date);
		//}

		[TestMethod]
		public void Can_ParseField90A()
		{
			var subsequenceE1A = new SubsequenceE1A("", "", 0, 0);

			// Option A
			string input = "ISSU/DISC/123456789,";
			subsequenceE1A.FIParseField90A(input);

			Assert.AreEqual("DISC", subsequenceE1A.InstrPriceType);
			Assert.AreEqual(123456789m, subsequenceE1A.InstrPrice);
			

			// Option B:	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
			input = "ISSU//ACTU/EUR4,5";
			subsequenceE1A = new SubsequenceE1A("", "", 0, 0);
			subsequenceE1A.FIParseField90A(input);
			Assert.AreEqual("ACTU", subsequenceE1A.InstrPriceType);
			Assert.AreEqual("EUR", subsequenceE1A.InstrPriceCurrency);
			Assert.AreEqual(4.5m, subsequenceE1A.InstrPrice);


			// Option E
			input = "ISSU//UKWN";
			subsequenceE1A = new SubsequenceE1A("", "", 0, 0);
			subsequenceE1A.FIParseField90A(input);
			Assert.IsNull(subsequenceE1A.InstrPrice);
		}

		// Rate
		[TestMethod]
		public void Can_ParseField92A()
		{
			var subsequenceE1A = new SubsequenceE1A("", "", 0, 0);

			// Option A
			string input = "INTR//N45,";
			subsequenceE1A.FIParseField92A(input);

			Assert.AreEqual("INTR", subsequenceE1A.InstrRateType);
			Assert.AreEqual(-45m, subsequenceE1A.InstrRate);

			// Option K
			input = "PRFC//UKWN";
			subsequenceE1A = new SubsequenceE1A("", "", 0, 0);
			subsequenceE1A.FIParseField92A(input);

			Assert.IsNull(subsequenceE1A.InstrRate);
		}

		[TestMethod]
		public void Can_ParseField36B()
		{
			var subsequenceE1A = new SubsequenceE1A("", "", 0, 0);

			// Option B
			string input = "MINO//AMOR/3,";
			subsequenceE1A.FIParseField36B(input);

			Assert.AreEqual("AMOR", subsequenceE1A.InstrQuantityType);
			Assert.AreEqual(3m, subsequenceE1A.InstrMinNomQuantity);

			// There are other properties  / cases
		}
	}
}