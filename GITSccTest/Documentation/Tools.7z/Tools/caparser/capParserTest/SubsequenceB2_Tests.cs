﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using SWIFTUtils;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace capParserTest
{
	[TestClass]
	public class SubsequenceB2_Tests
	{
		//Option B	:4!c/[8c]/4!c/[N]15d	(Qualifier)(Data Source Scheme)(Quantity Type Code)(Sign)(Balance)
		// Option C	:4!c//4!c/4!c/[N]15d	(Qualifier)(Quantity Type Code)(Balance Type Code)(Sign)(Balance)
		[TestMethod]
		public void Can_ParseField93A()
		{
			// Option B
			string input = "ELIG//FAMT/N12,9";
			var subsequenceB2 = new SubsequenceB2();
			subsequenceB2.ParseField93A(input);

			Assert.AreEqual("ELIG", subsequenceB2.BalanceType);
			Assert.AreEqual("FAMT", subsequenceB2.BalanceQuantityType);
			Assert.AreEqual(-12.9m, subsequenceB2.Balance);

			// Option C
			input = "PEND//FAMT/ELIG/12,4";
			subsequenceB2.ParseField93A(input);

			Assert.AreEqual("PEND", subsequenceB2.BalanceType);
			Assert.AreEqual("FAMT", subsequenceB2.BalanceQuantityType);
			Assert.AreEqual(12.4m, subsequenceB2.Balance);
		}
	}
}