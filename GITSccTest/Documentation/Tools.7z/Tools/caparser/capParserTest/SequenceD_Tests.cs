﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SequenceD_Tests
	{
		///			Option A	:4!c//4!c/15d	(Qualifier)(Percentage Type Code)(Price)
		///			Option B	:4!c//4!c/3!a15d	(Qualifier)(Amount Type Code)(Currency Code)(Price)
		///			Option E	:4!c//4!c	(Qualifier)(Price Code)
		
		[TestMethod]
		public void Can_ParseField90A()
		{
			var sequenceD = new SequenceD();

			// Option A
			var input = "MAXP//DISC/12,";
			sequenceD.ParseField90("90A", input);

			Assert.AreEqual("DISC", sequenceD.PricePercentType);
			Assert.AreEqual(12m, sequenceD.PriceMax);

			// Option B
			sequenceD = new SequenceD();
			input = "MINP//DISC/EUR12,3";
			sequenceD.ParseField90("90B", input);

			Assert.AreEqual("DISC", sequenceD.PriceAmountType);
			Assert.AreEqual(12.3m, sequenceD.PriceMin);

			// Option E
			sequenceD = new SequenceD();
			input = "MINP//UKWN";
			sequenceD.ParseField90("90E", input);

			Assert.AreEqual(null, sequenceD.PriceAmountType);
			Assert.AreEqual(null, sequenceD.PricePercentType);
			Assert.AreEqual(null, sequenceD.PriceMin);
		}

		[TestMethod]
		public void Can_ParseField22F()
		{
			var sequenceD = new SequenceD();
			string input = "DIVI//REGL";

			sequenceD.ParseField22F(input);
	
			Assert.AreEqual("REGL", sequenceD.DividendType);


			input = "CONV//FINL";
			sequenceD.ParseField22F(input);

			Assert.AreEqual("CONV", sequenceD.IndicatorType);
			Assert.AreEqual("FINL", sequenceD.IndicatorValue);
		}

		[TestMethod]
		public void Can_ParseField92()
		{
			var sequenceD = new SequenceD();
			string input = "INTR//N15,5";

			sequenceD.ParseField92("92A", input);

			Assert.AreEqual(-15.5m, sequenceD.InterestRate);



			input = "NWFC//EUR12,4";
			sequenceD = new SequenceD();
			sequenceD.ParseField92("92F", input);

			Assert.AreEqual("EUR", sequenceD.RateCurrency);
			Assert.AreEqual(12.4m, sequenceD.Rate);


			input = "PTSC//ANYA";
			sequenceD = new SequenceD();
			sequenceD.ParseField92("92K", input);

			Assert.AreEqual(null, sequenceD.Rate);
			Assert.AreEqual("ANYA", sequenceD.RateType);
		}
	}
}