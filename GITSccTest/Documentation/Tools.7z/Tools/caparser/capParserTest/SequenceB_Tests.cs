﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SequenceB_Tests
	{
		[TestMethod]
		public void Can_ParseField36B()
		{
			var sequenceB = new SequenceB();
			string input = "MINO//FAMT/12,4";
			sequenceB.ParseField36B(input);

			Assert.AreEqual("FAMT", sequenceB.InstrQuantityType);
			Assert.AreEqual(12.4m, sequenceB.InstrMinimumNominalQuantity);

			input = "SIZE//AMOR/12,5";
			sequenceB.ParseField36B(input);

			Assert.AreEqual(12.5m, sequenceB.InstrContractSize);
			Assert.AreEqual("AMOR", sequenceB.InstrQuantityType);
		}
	}
}
