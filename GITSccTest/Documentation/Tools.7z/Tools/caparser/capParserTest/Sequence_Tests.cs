﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class Sequence_Tests
	{
		[TestMethod]
		public void Can_ParseSEDOL_Entity_35B()
		{
			string input = "/GB/B45M5X6/FORESIGHT VCT PLC/INFRASTRUCTURE SHS GBP0.01";

			string sedol, entity;
			var sequenceE = new SequenceE("", "");
			sequenceE.ParseField35B(input, out sedol, out entity);

			Assert.AreEqual("B45M5X6", sedol);
			Assert.AreEqual("FORESIGHT VCT PLC/INFRASTRUCTURE SHS GBP0.01", entity);
		}
	}
}