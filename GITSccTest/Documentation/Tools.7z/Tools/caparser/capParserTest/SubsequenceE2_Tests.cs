﻿using System;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SWIFTUtils;

namespace capParserTest
{
	[TestClass]
	public class SubsequenceE2_Tests
	{
		[TestMethod]
		public void Can_ParseField36B()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);

			// Option H
			string input = "CRDB//CRED";
			subsequenceE2.ParseField22A(input);

			Assert.AreEqual("CRDB", subsequenceE2.IndicatorType);
			Assert.AreEqual("CRED", subsequenceE2.Indicator);

			input = "NELP/ABCD/NELC";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField22A(input);

			Assert.AreEqual("NELP", subsequenceE2.IndicatorType);
			Assert.AreEqual("NELC", subsequenceE2.Indicator);
		}

		[TestMethod]
		public void Can_ParseField97A()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			string input = "CASH//123455678901234567890";

			subsequenceE2.ParseField97A(input);

			Assert.AreEqual("123455678901234567890", subsequenceE2.CashAccount);
		}

		[TestMethod]
		public void Can_ParseField19B()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			string input = "GRSS//EUR12,4";

			subsequenceE2.ParseField19B(input);

			Assert.AreEqual("GRSS", subsequenceE2.AmountType);
			Assert.AreEqual("EUR", subsequenceE2.AmountCurrency);
			Assert.AreEqual(12.4m, subsequenceE2.Amount);
		}

		[TestMethod]
		public void Can_ParseField98A()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			// Option A
			string input = "PAYD//20120426";

			subsequenceE2.ParseField98B(input);
			Assert.AreEqual(DateTime.ParseExact("20120426", "yyyyMMdd", CultureInfo.InvariantCulture), subsequenceE2.PayDate);

			// Option C
			input = "PAYD//20120426120101";
			subsequenceE2.ParseField98B(input);
			Assert.AreEqual(DateTime.ParseExact("20120426120101", "yyyyMMddHHmmss", CultureInfo.InvariantCulture), subsequenceE2.PayDate);
		}

		[TestMethod]
		public void Can_ParseField92A()
		{
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			
			// Option A
			string input = "FDIV//N12,1";
			subsequenceE2.ParseField92("92A", input);

			//Assert.AreEqual("FDIV", subsequenceE2.RateType);
			Assert.AreEqual(-12.1m, subsequenceE2.FinalDividendRate);
			Assert.AreEqual(null, subsequenceE2.RateCurrency);

			// Option B
			input = "EXCH//EUR/GBP/12,2";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField92("92B", input);

			//Assert.AreEqual("EXCH", subsequenceE2.RateType);
			Assert.AreEqual(12.2m, subsequenceE2.ExchangeRate);
			Assert.AreEqual("EUR/GBP", subsequenceE2.RateCurrency);

			// Option F
			input = "NRES//EUR12,3";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField92("92F", input);

			//Assert.AreEqual("EXCH", subsequenceE2.RateType);
			Assert.AreEqual(12.3m, subsequenceE2.NonResidentRate);
			Assert.AreEqual("EUR", subsequenceE2.RateCurrency);

			// Option K
			input = "EXCH//NILP";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField92("92K", input);

			//Assert.AreEqual("EXCH", subsequenceE2.RateType);
			//Assert.AreEqual("NILP", subsequenceE2.RateCurrency);
			Assert.AreEqual(null, subsequenceE2.ExchangeRate);
		}

		[TestMethod]
		public void Can_ParseField90A()
		{
			// Option A
			string input = "EXER//PREM/34,5";
			var subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField90A(input);
			Assert.AreEqual(34.5m, subsequenceE2.Price);
			Assert.IsNull(subsequenceE2.PriceCurrency);

			// Option B
			input = "OFFR//PREM/EUR4,5";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField90A(input);
			Assert.AreEqual(4.5m, subsequenceE2.Price);
			Assert.AreEqual("EUR", subsequenceE2.PriceCurrency);

			// Option C
			input = "PRPP//UKWN";
			subsequenceE2 = new SubsequenceE2("", "", 0, 0);
			subsequenceE2.ParseField90A(input);
			Assert.IsNull(subsequenceE2.Price);
		}
	}
}