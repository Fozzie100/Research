﻿using System;
using System.Globalization;
using System.IO;

namespace FileArchiver
{
	/// <summary>
	/// Folder path creator for creating date folders in the format YYYY\MM MONTHNAME
	/// </summary>
	public static class YearSortedMonthFolderPathCreator
	{
		/// <summary>
		/// Creates the Date part of a folder path
		/// </summary>
		/// <param name="dateTime">DateTime</param>
		/// <returns>string</returns>
		public static string CreatePath(DateTime dateTime)
		{
			string monthName = string.Concat(dateTime.Month.ToString("00"), " ", CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(dateTime.Month));
			return Path.Combine(dateTime.Year.ToString(), monthName);
		}
	}
}