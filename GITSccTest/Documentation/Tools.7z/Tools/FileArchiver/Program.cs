﻿using System;
using System.Globalization;
using System.IO;

namespace FileArchiver
{
	class Program
	{
		static void Main(string[] args)
		{
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(HandleUnhandledException);

			if (args.Length != 5)
			{
				Console.WriteLine("FileArchiver.exe required 5 arguments, number of arguments provided : " + args.Length);
				foreach (string arg in args)
				{
					Console.WriteLine(arg);
				}
				Console.WriteLine("FileArchiver.exe SourceFilePath DestinationFolderRoot FileDate SearchPattern RaiseErrorOnNoFile");
				return;
			}

			string sourceFolderPath = args[0];
			string destinationFolderRoot = args[1];
			string fileDate = args[2];
			//string fileName = args[3];
			string searchPattern = args[3];
			string errorOnNoFilesFlag = args[4];
			bool errorOnNoFiles = (errorOnNoFilesFlag == "1");

			Console.WriteLine("File Archiver");
			Console.WriteLine(string.Format("Source Folder '{0}'", sourceFolderPath));
			Console.WriteLine(string.Format("Destination Folder '{0}'", destinationFolderRoot));
			Console.WriteLine(string.Format("File Date '{0}'", fileDate));
			Console.WriteLine(string.Format("Search Pattern '{0}'", searchPattern));

			if (!Directory.Exists(sourceFolderPath))
			{
				throw new DirectoryNotFoundException(string.Format("Source Directory '{0}' cannot be located", sourceFolderPath));
			}
			Console.WriteLine("Source Directory Located");
			if (!Directory.Exists(destinationFolderRoot))
			{
				throw new DirectoryNotFoundException(string.Format("Destination Directory '{0}' cannot be located", destinationFolderRoot));
			}
			Console.WriteLine("Destination Directory Located");

			DateTime fileDateTime;
			try
			{
				fileDateTime = DateTime.ParseExact(fileDate, "yyyyMMdd", CultureInfo.InvariantCulture);
			}
			catch (Exception ex)
			{
				throw new ArgumentOutOfRangeException(string.Format("Unable to convert value '{0}' to datetime", fileDate), ex);
			}
			Console.WriteLine("File DateTime successfully parsed");

			string monthFolderPath = Path.Combine(destinationFolderRoot, YearSortedMonthFolderPathCreator.CreatePath(fileDateTime));
			Console.WriteLine(string.Format("Month Folder path generated '{0}'", monthFolderPath));
			if (!Directory.Exists(monthFolderPath))
			{
				Console.WriteLine("Month Folder path does not exist");
				Directory.CreateDirectory(monthFolderPath);
				Console.WriteLine("Successfully created Month Folder path");
			}

			//string sourceFilePath = Path.Combine(sourceFolderPath, fileName);
			//if (!File.Exists(sourceFilePath))
			//{
			//    throw new FileNotFoundException(string.Format("Sourec File '{0}' cannot be located", sourceFilePath));
			//}

			string[] filePaths = Directory.GetFiles(sourceFolderPath, searchPattern, SearchOption.TopDirectoryOnly);
			Console.WriteLine(string.Format("Number of files to copy '{0}'", filePaths.Length));

			if (errorOnNoFiles && (filePaths.Length == 0))
			{
				throw new ArgumentOutOfRangeException(string.Format("No files found matching search pattern '{0}'"), searchPattern);
			}
			foreach (string sourceFilePath in filePaths)
			{
				string fileName = Path.GetFileName(sourceFilePath);
				Console.WriteLine(string.Format("About to copy file '{0}'", fileName));
				string destinationFilePath = Path.Combine(monthFolderPath, fileName);
				if (File.Exists(destinationFilePath))
				{
					Console.WriteLine(string.Format("File '{0}' already exists, deleting", fileName));
					File.Delete(destinationFilePath);
				}
				Console.WriteLine(string.Format("Moving '{0}'", fileName));
				File.Move(sourceFilePath, destinationFilePath);
				Console.WriteLine(string.Format("File '{0}' successfully moved", fileName));
			}
		}

		private static void HandleUnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			var ex = e.ExceptionObject as Exception;
			Console.Write(ex.Message);
			throw ex;
		}
	}
}