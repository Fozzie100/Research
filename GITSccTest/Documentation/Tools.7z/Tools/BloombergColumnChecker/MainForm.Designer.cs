﻿namespace BloombergColumnChecker
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.uiFieldsTextBox = new System.Windows.Forms.TextBox();
			this.uiLocateNewFieldsButton = new System.Windows.Forms.Button();
			this.uiTableNameTextBox = new System.Windows.Forms.TextBox();
			this.uiResultsTextBox = new System.Windows.Forms.TextBox();
			this.uiSchemaTextBox = new System.Windows.Forms.TextBox();
			this.uiResultsTabControl = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.uiExistingTablesTextBox = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.uiResultsTabControl.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiFieldsTextBox
			// 
			this.uiFieldsTextBox.Location = new System.Drawing.Point(6, 5);
			this.uiFieldsTextBox.Multiline = true;
			this.uiFieldsTextBox.Name = "uiFieldsTextBox";
			this.uiFieldsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiFieldsTextBox.Size = new System.Drawing.Size(418, 231);
			this.uiFieldsTextBox.TabIndex = 0;
			// 
			// uiLocateNewFieldsButton
			// 
			this.uiLocateNewFieldsButton.Location = new System.Drawing.Point(6, 29);
			this.uiLocateNewFieldsButton.Name = "uiLocateNewFieldsButton";
			this.uiLocateNewFieldsButton.Size = new System.Drawing.Size(75, 23);
			this.uiLocateNewFieldsButton.TabIndex = 1;
			this.uiLocateNewFieldsButton.Text = "Locate New Fields";
			this.uiLocateNewFieldsButton.UseVisualStyleBackColor = true;
			this.uiLocateNewFieldsButton.Click += new System.EventHandler(this.uiLocateNewFieldsButton_Click);
			// 
			// uiTableNameTextBox
			// 
			this.uiTableNameTextBox.Location = new System.Drawing.Point(112, 3);
			this.uiTableNameTextBox.Name = "uiTableNameTextBox";
			this.uiTableNameTextBox.Size = new System.Drawing.Size(100, 20);
			this.uiTableNameTextBox.TabIndex = 2;
			this.uiTableNameTextBox.Text = "bloomberg_out";
			// 
			// uiResultsTextBox
			// 
			this.uiResultsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiResultsTextBox.Location = new System.Drawing.Point(6, 58);
			this.uiResultsTextBox.Multiline = true;
			this.uiResultsTextBox.Name = "uiResultsTextBox";
			this.uiResultsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiResultsTextBox.Size = new System.Drawing.Size(475, 155);
			this.uiResultsTextBox.TabIndex = 3;
			// 
			// uiSchemaTextBox
			// 
			this.uiSchemaTextBox.Location = new System.Drawing.Point(6, 3);
			this.uiSchemaTextBox.Name = "uiSchemaTextBox";
			this.uiSchemaTextBox.Size = new System.Drawing.Size(100, 20);
			this.uiSchemaTextBox.TabIndex = 4;
			this.uiSchemaTextBox.Text = "loader";
			// 
			// uiResultsTabControl
			// 
			this.uiResultsTabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiResultsTabControl.Controls.Add(this.tabPage1);
			this.uiResultsTabControl.Controls.Add(this.tabPage2);
			this.uiResultsTabControl.Location = new System.Drawing.Point(6, 242);
			this.uiResultsTabControl.Name = "uiResultsTabControl";
			this.uiResultsTabControl.SelectedIndex = 0;
			this.uiResultsTabControl.Size = new System.Drawing.Size(495, 242);
			this.uiResultsTabControl.TabIndex = 5;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.uiSchemaTextBox);
			this.tabPage1.Controls.Add(this.uiResultsTextBox);
			this.tabPage1.Controls.Add(this.uiTableNameTextBox);
			this.tabPage1.Controls.Add(this.uiLocateNewFieldsButton);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(487, 216);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Loader Table";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.textBox1);
			this.tabPage2.Controls.Add(this.button1);
			this.tabPage2.Controls.Add(this.uiExistingTablesTextBox);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(487, 216);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Schema Table";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// uiExistingTablesTextBox
			// 
			this.uiExistingTablesTextBox.Location = new System.Drawing.Point(6, 6);
			this.uiExistingTablesTextBox.Name = "uiExistingTablesTextBox";
			this.uiExistingTablesTextBox.Size = new System.Drawing.Size(201, 20);
			this.uiExistingTablesTextBox.TabIndex = 0;
			this.uiExistingTablesTextBox.Text = "bl_security,bl_prices,bl_prices_derived";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(6, 32);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(6, 61);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBox1.Size = new System.Drawing.Size(475, 149);
			this.textBox1.TabIndex = 2;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(513, 484);
			this.Controls.Add(this.uiResultsTabControl);
			this.Controls.Add(this.uiFieldsTextBox);
			this.Name = "MainForm";
			this.Text = "Form1";
			this.uiResultsTabControl.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox uiFieldsTextBox;
		private System.Windows.Forms.Button uiLocateNewFieldsButton;
		private System.Windows.Forms.TextBox uiTableNameTextBox;
		private System.Windows.Forms.TextBox uiResultsTextBox;
		private System.Windows.Forms.TextBox uiSchemaTextBox;
		private System.Windows.Forms.TabControl uiResultsTabControl;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox uiExistingTablesTextBox;
	}
}

