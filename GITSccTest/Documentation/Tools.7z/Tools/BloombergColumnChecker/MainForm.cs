﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BloombergColumnChecker
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void uiLocateNewFieldsButton_Click(object sender, EventArgs e)
		{
			string[] fieldToCheck = uiFieldsTextBox.Text.Split(Environment.NewLine.ToCharArray());
			List<string> existingColumns = new List<string>();
			DataTable definedColumnDataTable = new DataTable("DefinedColumns");
			List<string> newColumnDefinitions = new List<string>();

			string sqlStatement = "SELECT DatabaseObjects.name, TableColumn.Name AS ColumnName FROM sysobjects DatabaseObjects INNER JOIN SysColumns AS TableColumn ON DatabaseObjects.id = TableColumn.id  WHERE DatabaseObjects.name = @TableName";
			using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Prime"].ConnectionString))
			{
				connection.Open();
				using (SqlCommand command = connection.CreateCommand())
				{
					command.CommandText = sqlStatement;
					command.CommandType = CommandType.Text;
					command.Parameters.AddWithValue("@TableName", uiTableNameTextBox.Text);
					using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
					{
						while (reader.Read())
						{
							existingColumns.Add(reader["ColumnName"].ToString());
						}
						reader.Close();
					}
				}
				using (SqlDataAdapter adapter = new SqlDataAdapter("select * from BLOOMBERG.bo_dictionary", connection))
				{
					adapter.Fill(definedColumnDataTable);
				}
			}
			string[] missingFields = fieldToCheck.Except(existingColumns).ToArray();
			foreach (string missingField in missingFields)
			{
				DataRow[] fieldRows = definedColumnDataTable.Select(string.Concat("field_mnemonic = '", missingField, "'"));
				if (fieldRows.Length > 0)
				{
					DataRow fieldRow = fieldRows[0];
					newColumnDefinitions.Add(string.Concat("\t[", missingField, "] ", fieldRow["prime_type"]));
				}
				else
				{
				}
			}
			if (newColumnDefinitions.Count == 0)
			{
				uiResultsTextBox.Text = "NO NEW COLUMNS REQUIRED";
			}
			else
			{
				StringBuilder sqlBuilder = new StringBuilder();
				sqlBuilder.AppendFormat("ALTER TABLE [{0}].[{1}]", uiSchemaTextBox.Text, uiTableNameTextBox.Text);
				sqlBuilder.Append(Environment.NewLine);
				sqlBuilder.Append("ADD");
				sqlBuilder.Append(Environment.NewLine);
				sqlBuilder.Append(string.Join(string.Concat(",", Environment.NewLine), newColumnDefinitions.ToArray()));
				sqlBuilder.Append(Environment.NewLine);
				sqlBuilder.Append("GO");
				uiResultsTextBox.Text = sqlBuilder.ToString();
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			DataTable definedColumnDataTable = new DataTable("DefinedColumns");


			string[] fieldToCheck = uiFieldsTextBox.Text.Split(Environment.NewLine.ToCharArray());
			string[] tableNames = uiExistingTablesTextBox.Text.Split(',');
			List<string> newColumnDefinitions = new List<string>();
			
			string tableNameInStatement = string.Concat("('", string.Join("', '", tableNames), "'");
			List<string> existingColumns = new List<string>();

			string sqlStatement = "SELECT DatabaseObjects.name, TableColumn.Name AS ColumnName FROM sysobjects DatabaseObjects INNER JOIN SysColumns AS TableColumn ON DatabaseObjects.id = TableColumn.id  WHERE DatabaseObjects.name in " + tableNameInStatement + ")";
			using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Prime"].ConnectionString))
			{
				connection.Open();
				using (SqlCommand command = connection.CreateCommand())
				{
					command.CommandText = sqlStatement;
					command.CommandType = CommandType.Text;
					command.Parameters.AddWithValue("@TableName", uiTableNameTextBox.Text);
					using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
					{
						while (reader.Read())
						{
							string columnName = reader["ColumnName"].ToString();
							if (!existingColumns.Contains(columnName, StringComparer.OrdinalIgnoreCase))
							{
								existingColumns.Add(columnName.ToUpper()); //todo to lower is because db cols are all lower case
							}
						}
						reader.Close();
					}
				}
				using (SqlDataAdapter adapter = new SqlDataAdapter("select * from BLOOMBERG.bo_dictionary", connection))
				{
					adapter.Fill(definedColumnDataTable);
				}
			}
			//string[] missingFields = fieldToCheck.Except(existingColumns).ToArray();
			//textBox1.Text = string.Join(Environment.NewLine, missingFields);

			string[] missingFields = fieldToCheck.Except(existingColumns).ToArray();
			foreach (string missingField in missingFields)
			{
				DataRow[] fieldRows = definedColumnDataTable.Select(string.Concat("field_mnemonic = '", missingField, "'"));
				if (fieldRows.Length > 0)
				{
					DataRow fieldRow = fieldRows[0];
					newColumnDefinitions.Add(string.Concat("\t[", missingField, "] ", fieldRow["prime_type"]));
				}
				else
				{
				}
			}
			if (newColumnDefinitions.Count == 0)
			{
				uiResultsTextBox.Text = "NO NEW COLUMNS REQUIRED";
			}
			else
			{
				StringBuilder sqlBuilder = new StringBuilder();
				sqlBuilder.AppendFormat("ALTER TABLE [{0}].[{1}]", uiSchemaTextBox.Text, uiTableNameTextBox.Text);
				sqlBuilder.Append(Environment.NewLine);
				sqlBuilder.Append("ADD");
				sqlBuilder.Append(Environment.NewLine);
				sqlBuilder.Append(string.Join(string.Concat(",", Environment.NewLine), newColumnDefinitions.ToArray()));
				sqlBuilder.Append(Environment.NewLine);
				sqlBuilder.Append("GO");
				textBox1.Text = sqlBuilder.ToString();
			}
		}
	}
}
