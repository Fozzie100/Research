﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BloombergColumnChecker
{
	public partial class ScriptBloombergTable : Form
	{
		public ScriptBloombergTable()
		{
			InitializeComponent();
		}

		private void uiLocateNewFieldsButton_Click(object sender, EventArgs e)
		{
			List<string> newColumnDefinitions = new List<string>();
			string[] columnNames = uiFieldsTextBox.Text.Split(Environment.NewLine.ToCharArray());
			DataTable definedColumnDataTable = new DataTable("DefinedColumns");
			using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Prime"].ConnectionString))
			{
				connection.Open();
				using (SqlDataAdapter adapter = new SqlDataAdapter("select * from BLOOMBERG.bo_dictionary", connection))
				{
					adapter.Fill(definedColumnDataTable);
				}
			}

			foreach (string columnName in columnNames)
			{
				if (!string.IsNullOrEmpty(columnName))
				{
					DataRow[] fieldRows = definedColumnDataTable.Select(string.Concat("field_mnemonic = '", columnName, "'"));
					if (fieldRows.Length > 0)
					{
						DataRow fieldRow = fieldRows[0];
						newColumnDefinitions.Add(string.Concat("\t[", columnName.ToLower(), "] ", fieldRow["prime_type"]));
					}
					else
					{
					}
				}
			}
			uiResultsTextBox.Text = string.Join("," + Environment.NewLine, newColumnDefinitions.ToArray());
		}
	}
}
