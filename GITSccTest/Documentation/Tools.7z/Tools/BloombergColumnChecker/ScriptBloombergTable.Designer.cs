﻿namespace BloombergColumnChecker
{
	partial class ScriptBloombergTable
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.uiFieldsTextBox = new System.Windows.Forms.TextBox();
			this.uiLocateNewFieldsButton = new System.Windows.Forms.Button();
			this.uiResultsTextBox = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// uiFieldsTextBox
			// 
			this.uiFieldsTextBox.Location = new System.Drawing.Point(12, 2);
			this.uiFieldsTextBox.Multiline = true;
			this.uiFieldsTextBox.Name = "uiFieldsTextBox";
			this.uiFieldsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiFieldsTextBox.Size = new System.Drawing.Size(418, 231);
			this.uiFieldsTextBox.TabIndex = 1;
			// 
			// uiLocateNewFieldsButton
			// 
			this.uiLocateNewFieldsButton.Location = new System.Drawing.Point(25, 239);
			this.uiLocateNewFieldsButton.Name = "uiLocateNewFieldsButton";
			this.uiLocateNewFieldsButton.Size = new System.Drawing.Size(75, 23);
			this.uiLocateNewFieldsButton.TabIndex = 2;
			this.uiLocateNewFieldsButton.Text = "Locate New Fields";
			this.uiLocateNewFieldsButton.UseVisualStyleBackColor = true;
			this.uiLocateNewFieldsButton.Click += new System.EventHandler(this.uiLocateNewFieldsButton_Click);
			// 
			// uiResultsTextBox
			// 
			this.uiResultsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.uiResultsTextBox.Location = new System.Drawing.Point(12, 281);
			this.uiResultsTextBox.Multiline = true;
			this.uiResultsTextBox.Name = "uiResultsTextBox";
			this.uiResultsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiResultsTextBox.Size = new System.Drawing.Size(475, 155);
			this.uiResultsTextBox.TabIndex = 4;
			// 
			// ScriptBloombergTable
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(569, 523);
			this.Controls.Add(this.uiResultsTextBox);
			this.Controls.Add(this.uiLocateNewFieldsButton);
			this.Controls.Add(this.uiFieldsTextBox);
			this.Name = "ScriptBloombergTable";
			this.Text = "ScriptBloombergTable";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox uiFieldsTextBox;
		private System.Windows.Forms.Button uiLocateNewFieldsButton;
		private System.Windows.Forms.TextBox uiResultsTextBox;
	}
}