﻿using System.Collections.Generic;
using System.IO;
using Ftse.Research.Framework.IO;

namespace DatabaseScriptBuilder
{
	/// <summary>
	/// Generator class used to combine files
	/// </summary>
	public static class ScriptGenerator
	{
		/// <summary>
		/// Generates a script for a set of Settings
		/// </summary>
		/// <param name="settings">ScriptGenerationSettings specifying the settings to apply when generating</param>
		public static void GenerateScript(ScriptGenerationSettings settings)
		{
			List<string> fileContents = new List<string>();

			if (settings.OutputUsingStatement)
			{
				fileContents.Add(string.Concat("USE ", settings.DatabaseName));
				fileContents.Add("GO");
				fileContents.Add(string.Empty);
			}

			DirectoryInfo directoryInfo = new DirectoryInfo(settings.SourceDirectoryPath);
			foreach (FileInfo file in directoryInfo.GetFiles("*.sql"))
			{
				if (settings.OutputFileNames)
				{
					fileContents.Add("PRINT ''");
					fileContents.Add(string.Format("PRINT ' ----- STARTING EXECUTION OF {0} ----- '", file.Name));
					fileContents.Add(string.Empty);
				}
				string[] fileContent = TextFileReader.ReadFile(file.FullName);
				fileContents.AddRange(fileContent);
				fileContents.Add(string.Empty);
			}
			WriteLines(settings.GeneratedFilePath, fileContents);
		}

		#region Private Methods
		/// <summary>
		/// Writes strings to a file
		/// </summary>
		/// <param name="filePath">Path to the file</param>
		/// <param name="lines">string array to write</param>
		public static void WriteLines(string filePath, List<string> lines)
		{
			if (lines != null)
			{
				using (TextWriter writer = new StreamWriter(filePath))
				{
					foreach (string line in lines.ToArray())
					{
						writer.WriteLine(line);
					}
				}
			}
		}
		#endregion
	}
}