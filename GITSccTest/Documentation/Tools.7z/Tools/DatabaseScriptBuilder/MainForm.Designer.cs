﻿namespace DatabaseScriptBuilder
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.uiSourceFolderTextBox = new System.Windows.Forms.TextBox();
			this.uiSourceFolderLabel = new System.Windows.Forms.Label();
			this.uiGenerateButton = new System.Windows.Forms.Button();
			this.uiDatabaseNameLabel = new System.Windows.Forms.Label();
			this.uiDatabaseNameTextBox = new System.Windows.Forms.TextBox();
			this.uiBrowseForSourceFolderButton = new System.Windows.Forms.Button();
			this.uiOutputFileLabel = new System.Windows.Forms.Label();
			this.uiOutputFileTextBox = new System.Windows.Forms.TextBox();
			this.uiFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.uiMainMenuStrip = new System.Windows.Forms.MenuStrip();
			this.uiFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.uiExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.uiOptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.uiOutputUsingStatementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.uiOutputFileNamesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.uiClearSavedSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.uiSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
			this.uiBrowseForSaveFileButton = new System.Windows.Forms.Button();
			this.uiMainMenuStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiSourceFolderTextBox
			// 
			this.uiSourceFolderTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiSourceFolderTextBox.Location = new System.Drawing.Point(92, 54);
			this.uiSourceFolderTextBox.Name = "uiSourceFolderTextBox";
			this.uiSourceFolderTextBox.Size = new System.Drawing.Size(527, 20);
			this.uiSourceFolderTextBox.TabIndex = 4;
			// 
			// uiSourceFolderLabel
			// 
			this.uiSourceFolderLabel.AutoSize = true;
			this.uiSourceFolderLabel.Location = new System.Drawing.Point(7, 57);
			this.uiSourceFolderLabel.Name = "uiSourceFolderLabel";
			this.uiSourceFolderLabel.Size = new System.Drawing.Size(73, 13);
			this.uiSourceFolderLabel.TabIndex = 3;
			this.uiSourceFolderLabel.Text = "Source Folder";
			// 
			// uiGenerateButton
			// 
			this.uiGenerateButton.Image = ((System.Drawing.Image)(resources.GetObject("uiGenerateButton.Image")));
			this.uiGenerateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.uiGenerateButton.Location = new System.Drawing.Point(575, 107);
			this.uiGenerateButton.Name = "uiGenerateButton";
			this.uiGenerateButton.Size = new System.Drawing.Size(73, 23);
			this.uiGenerateButton.TabIndex = 8;
			this.uiGenerateButton.Text = "Generate";
			this.uiGenerateButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.uiGenerateButton.UseVisualStyleBackColor = true;
			this.uiGenerateButton.Click += new System.EventHandler(this.uiGenerateButton_Click);
			// 
			// uiDatabaseNameLabel
			// 
			this.uiDatabaseNameLabel.AutoSize = true;
			this.uiDatabaseNameLabel.Location = new System.Drawing.Point(7, 31);
			this.uiDatabaseNameLabel.Name = "uiDatabaseNameLabel";
			this.uiDatabaseNameLabel.Size = new System.Drawing.Size(53, 13);
			this.uiDatabaseNameLabel.TabIndex = 1;
			this.uiDatabaseNameLabel.Text = "Database";
			// 
			// uiDatabaseNameTextBox
			// 
			this.uiDatabaseNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiDatabaseNameTextBox.Location = new System.Drawing.Point(92, 28);
			this.uiDatabaseNameTextBox.Name = "uiDatabaseNameTextBox";
			this.uiDatabaseNameTextBox.Size = new System.Drawing.Size(556, 20);
			this.uiDatabaseNameTextBox.TabIndex = 2;
			// 
			// uiBrowseForSourceFolderButton
			// 
			this.uiBrowseForSourceFolderButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.uiBrowseForSourceFolderButton.Image = ((System.Drawing.Image)(resources.GetObject("uiBrowseForSourceFolderButton.Image")));
			this.uiBrowseForSourceFolderButton.Location = new System.Drawing.Point(625, 51);
			this.uiBrowseForSourceFolderButton.Name = "uiBrowseForSourceFolderButton";
			this.uiBrowseForSourceFolderButton.Size = new System.Drawing.Size(23, 23);
			this.uiBrowseForSourceFolderButton.TabIndex = 5;
			this.uiBrowseForSourceFolderButton.UseVisualStyleBackColor = true;
			this.uiBrowseForSourceFolderButton.Click += new System.EventHandler(this.uiBrowseForSourceFolderButton_Click);
			// 
			// uiOutputFileLabel
			// 
			this.uiOutputFileLabel.AutoSize = true;
			this.uiOutputFileLabel.Location = new System.Drawing.Point(7, 83);
			this.uiOutputFileLabel.Name = "uiOutputFileLabel";
			this.uiOutputFileLabel.Size = new System.Drawing.Size(58, 13);
			this.uiOutputFileLabel.TabIndex = 6;
			this.uiOutputFileLabel.Text = "Output File";
			// 
			// uiOutputFileTextBox
			// 
			this.uiOutputFileTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.uiOutputFileTextBox.Location = new System.Drawing.Point(92, 80);
			this.uiOutputFileTextBox.Name = "uiOutputFileTextBox";
			this.uiOutputFileTextBox.Size = new System.Drawing.Size(527, 20);
			this.uiOutputFileTextBox.TabIndex = 7;
			this.uiOutputFileTextBox.Text = "release.sql";
			// 
			// uiMainMenuStrip
			// 
			this.uiMainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiFileToolStripMenuItem,
            this.uiOptionsToolStripMenuItem});
			this.uiMainMenuStrip.Location = new System.Drawing.Point(0, 0);
			this.uiMainMenuStrip.Name = "uiMainMenuStrip";
			this.uiMainMenuStrip.Size = new System.Drawing.Size(655, 24);
			this.uiMainMenuStrip.TabIndex = 0;
			this.uiMainMenuStrip.Text = "menuStrip1";
			// 
			// uiFileToolStripMenuItem
			// 
			this.uiFileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiExitToolStripMenuItem});
			this.uiFileToolStripMenuItem.Name = "uiFileToolStripMenuItem";
			this.uiFileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
			this.uiFileToolStripMenuItem.Text = "File";
			// 
			// uiExitToolStripMenuItem
			// 
			this.uiExitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("uiExitToolStripMenuItem.Image")));
			this.uiExitToolStripMenuItem.Name = "uiExitToolStripMenuItem";
			this.uiExitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
			this.uiExitToolStripMenuItem.Text = "Exit";
			this.uiExitToolStripMenuItem.Click += new System.EventHandler(this.uiExitToolStripMenuItem_Click);
			// 
			// uiOptionsToolStripMenuItem
			// 
			this.uiOptionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiOutputUsingStatementToolStripMenuItem,
            this.uiOutputFileNamesToolStripMenuItem,
            this.uiClearSavedSettingsToolStripMenuItem});
			this.uiOptionsToolStripMenuItem.Name = "uiOptionsToolStripMenuItem";
			this.uiOptionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
			this.uiOptionsToolStripMenuItem.Text = "Options";
			// 
			// uiOutputUsingStatementToolStripMenuItem
			// 
			this.uiOutputUsingStatementToolStripMenuItem.Checked = true;
			this.uiOutputUsingStatementToolStripMenuItem.CheckOnClick = true;
			this.uiOutputUsingStatementToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
			this.uiOutputUsingStatementToolStripMenuItem.Name = "uiOutputUsingStatementToolStripMenuItem";
			this.uiOutputUsingStatementToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
			this.uiOutputUsingStatementToolStripMenuItem.Text = "Output Using Statement";
			this.uiOutputUsingStatementToolStripMenuItem.Click += new System.EventHandler(this.uiOutputUsingStatementToolStripMenuItem_Click);
			// 
			// uiOutputFileNamesToolStripMenuItem
			// 
			this.uiOutputFileNamesToolStripMenuItem.Checked = true;
			this.uiOutputFileNamesToolStripMenuItem.CheckOnClick = true;
			this.uiOutputFileNamesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
			this.uiOutputFileNamesToolStripMenuItem.Name = "uiOutputFileNamesToolStripMenuItem";
			this.uiOutputFileNamesToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
			this.uiOutputFileNamesToolStripMenuItem.Text = "Output File Names";
			this.uiOutputFileNamesToolStripMenuItem.Click += new System.EventHandler(this.uiOutputFileNamesToolStripMenuItem_Click);
			// 
			// uiClearSavedSettingsToolStripMenuItem
			// 
			this.uiClearSavedSettingsToolStripMenuItem.Name = "uiClearSavedSettingsToolStripMenuItem";
			this.uiClearSavedSettingsToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
			this.uiClearSavedSettingsToolStripMenuItem.Text = "Clear Saved Settings";
			this.uiClearSavedSettingsToolStripMenuItem.Click += new System.EventHandler(this.uiClearSavedSettingsToolStripMenuItem_Click);
			// 
			// uiBrowseForSaveFileButton
			// 
			this.uiBrowseForSaveFileButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.uiBrowseForSaveFileButton.Image = ((System.Drawing.Image)(resources.GetObject("uiBrowseForSaveFileButton.Image")));
			this.uiBrowseForSaveFileButton.Location = new System.Drawing.Point(625, 78);
			this.uiBrowseForSaveFileButton.Name = "uiBrowseForSaveFileButton";
			this.uiBrowseForSaveFileButton.Size = new System.Drawing.Size(23, 23);
			this.uiBrowseForSaveFileButton.TabIndex = 8;
			this.uiBrowseForSaveFileButton.UseVisualStyleBackColor = true;
			this.uiBrowseForSaveFileButton.Click += new System.EventHandler(this.uiBrowseForSaveFileButton_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(655, 138);
			this.Controls.Add(this.uiBrowseForSaveFileButton);
			this.Controls.Add(this.uiOutputFileTextBox);
			this.Controls.Add(this.uiOutputFileLabel);
			this.Controls.Add(this.uiBrowseForSourceFolderButton);
			this.Controls.Add(this.uiDatabaseNameLabel);
			this.Controls.Add(this.uiDatabaseNameTextBox);
			this.Controls.Add(this.uiGenerateButton);
			this.Controls.Add(this.uiSourceFolderLabel);
			this.Controls.Add(this.uiSourceFolderTextBox);
			this.Controls.Add(this.uiMainMenuStrip);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.uiMainMenuStrip;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Database Script Builder";
			this.uiMainMenuStrip.ResumeLayout(false);
			this.uiMainMenuStrip.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox uiSourceFolderTextBox;
		private System.Windows.Forms.Label uiSourceFolderLabel;
		private System.Windows.Forms.Button uiGenerateButton;
		private System.Windows.Forms.Label uiDatabaseNameLabel;
		private System.Windows.Forms.TextBox uiDatabaseNameTextBox;
		private System.Windows.Forms.Button uiBrowseForSourceFolderButton;
		private System.Windows.Forms.Label uiOutputFileLabel;
		private System.Windows.Forms.TextBox uiOutputFileTextBox;
		private System.Windows.Forms.FolderBrowserDialog uiFolderBrowserDialog;
		private System.Windows.Forms.MenuStrip uiMainMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem uiFileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem uiExitToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem uiOptionsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem uiOutputUsingStatementToolStripMenuItem;
		private System.Windows.Forms.SaveFileDialog uiSaveFileDialog;
		private System.Windows.Forms.Button uiBrowseForSaveFileButton;
		private System.Windows.Forms.ToolStripMenuItem uiClearSavedSettingsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem uiOutputFileNamesToolStripMenuItem;
	}
}

