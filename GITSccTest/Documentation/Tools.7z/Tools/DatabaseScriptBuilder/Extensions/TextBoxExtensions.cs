﻿using System.Windows.Forms;

namespace DatabaseScriptBuilder.Extensions
{
	/// <summary>
	/// Class containing Extension methods for TextBoxes
	/// </summary>
	public static class TextBoxExtensions
	{
		/// <summary>
		/// Checks to see whether a TextBox contains any Text
		/// </summary>
		/// <param name="textBox">TextBox</param>
		/// <returns>boolean</returns>
		public static bool IsEmpty(this TextBox textBox)
		{
			return string.IsNullOrWhiteSpace(textBox.Text);
		}
	}
}