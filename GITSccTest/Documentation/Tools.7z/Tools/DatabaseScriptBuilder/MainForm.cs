﻿using System;
using System.IO;
using System.Windows.Forms;
using DatabaseScriptBuilder.Extensions;
using DatabaseScriptBuilder.Properties;

namespace DatabaseScriptBuilder
{
	/// <summary>
	/// Main Application form
	/// </summary>
	public partial class MainForm : Form
	{
		#region Constructors
		/// <summary>
		/// Creates a new instance of MainForm
		/// </summary>
		public MainForm()
		{
			InitializeComponent();
		}
		#endregion

		#region Overridden Methods
		/// <summary>
		/// Event raised when the form loads
		/// </summary>
		/// <param name="e">EventArgs object</param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			uiDatabaseNameTextBox.Text = Settings.Default.LastDatabaseName;
			uiSourceFolderTextBox.Text = Settings.Default.LastSourceFolder;
			uiOutputFileTextBox.Text = Settings.Default.LastGeneratedFile;
			uiOutputUsingStatementToolStripMenuItem.Checked = Settings.Default.OutputUsingStatement;
			uiOutputFileNamesToolStripMenuItem.Checked = Settings.Default.OutputFileNames;
		}
		#endregion

		#region Control Event Handlers
		/// <summary>
		/// Event raised when the Browse For Save File button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiBrowseForSaveFileButton_Click(object sender, EventArgs e)
		{
			uiSaveFileDialog.FileName = uiOutputFileTextBox.Text;
			uiSaveFileDialog.Filter = "Sql Script|*.sql";
			if (uiSaveFileDialog.ShowDialog(this) == DialogResult.OK)
			{
				string filePath = uiOutputFileTextBox.Text;
				uiOutputFileTextBox.Text = uiSaveFileDialog.FileName;
			}
		}

		/// <summary>
		/// Event raised when the Browse For Source button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiBrowseForSourceFolderButton_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(uiSourceFolderTextBox.Text))
			{
				uiFolderBrowserDialog.SelectedPath = uiSourceFolderTextBox.Text;
			}
			if (uiFolderBrowserDialog.ShowDialog(this) == DialogResult.OK)
			{
				uiSourceFolderTextBox.Text = uiFolderBrowserDialog.SelectedPath;
			}
		}

		/// <summary>
		/// Event raised when the Clear Saved Settings ToolStripMenuItem is clicked
		/// </summary>
		/// <param name="sender">ToolStripMenuItem raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiClearSavedSettingsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Settings.Default.Reset();
			uiDatabaseNameTextBox.Text = Settings.Default.LastDatabaseName;
			uiSourceFolderTextBox.Text = string.Empty;
			uiOutputFileTextBox.Text = string.Empty;
		}

		/// <summary>
		/// Event raised when the Exit ToolStripMenuItem is clicked
		/// </summary>
		/// <param name="sender">ToolStripMenuItem raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiExitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		/// <summary>
		/// Event raised when the Generate button is clicked
		/// </summary>
		/// <param name="sender">Button raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiGenerateButton_Click(object sender, EventArgs e)
		{
			if (uiDatabaseNameTextBox.IsEmpty() || uiSourceFolderTextBox.IsEmpty() || uiOutputFileTextBox.IsEmpty())
			{
				MessageBox.Show(this, "Please ensure a database name, source folder and output file path have been entered", "Required fields empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			if (!Directory.Exists(uiSourceFolderTextBox.Text))
			{
				MessageBox.Show(this, "Source Folder cannot be located", "Invalid Source Folder", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			try
			{
				FileInfo info = new FileInfo(uiOutputFileTextBox.Text);
				if (info.FullName != uiOutputFileTextBox.Text)
				{
					uiOutputFileTextBox.Text = info.FullName;
				}
			}
			catch
			{
				MessageBox.Show(this, "Unable to use the supplied output file path", "Invalid Output File Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			ScriptGenerationSettings generationSettings = new ScriptGenerationSettings
			{
				OutputUsingStatement = Settings.Default.OutputUsingStatement,
				DatabaseName = uiDatabaseNameTextBox.Text,
				OutputFileNames = Settings.Default.OutputFileNames,
				SourceDirectoryPath = uiSourceFolderTextBox.Text,
				GeneratedFilePath = uiOutputFileTextBox.Text
			};
			ScriptGenerator.GenerateScript(generationSettings);

			//store the settings for next time the application is opened
			Settings.Default.LastDatabaseName = uiDatabaseNameTextBox.Text;
			Settings.Default.LastSourceFolder = uiSourceFolderTextBox.Text;
			Settings.Default.LastGeneratedFile = uiOutputFileTextBox.Text;
			Settings.Default.Save();

			MessageBox.Show(this, string.Format("Successfully generated script to {0}", uiOutputFileTextBox.Text), "Script File Generated", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		/// <summary>
		/// Event raised when the Output File Names ToolStripMenuItem is clicked
		/// </summary>
		/// <param name="sender">ToolStripMenuItem raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiOutputFileNamesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Settings.Default.OutputFileNames = uiOutputFileNamesToolStripMenuItem.Checked;
			Settings.Default.Save();
		}

		/// <summary>
		/// Event raised when the Output Using Statement ToolStripMenuItem is clicked
		/// </summary>
		/// <param name="sender">ToolStripMenuItem raising the event</param>
		/// <param name="e">EventArgs object</param>
		private void uiOutputUsingStatementToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Settings.Default.OutputUsingStatement = uiOutputUsingStatementToolStripMenuItem.Checked;
		}
		#endregion
	}
}