﻿
namespace DatabaseScriptBuilder
{
	/// <summary>
	/// Settings Container for Script Generation
	/// </summary>
	public class ScriptGenerationSettings
	{
		/// <summary>
		/// Database name to apply the script to
		/// </summary>
		public string DatabaseName { get; set; }

		/// <summary>
		/// Flag determining whether to output a using statement in the file
		/// </summary>
		public bool OutputUsingStatement { get; set; }

		/// <summary>
		/// Flag determining whether to print the name of each file
		/// </summary>
		public bool OutputFileNames { get; set; }
		
		/// <summary>
		/// Folder to traverse when generating the file
		/// </summary>
		public string SourceDirectoryPath { get; set; }

		/// <summary>
		/// Path the generated File will be put
		/// </summary>
		public string GeneratedFilePath { get; set; }
	}
}