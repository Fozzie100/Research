﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;

namespace FileUtility
{
    public partial class frmFileSearchUtility : Form
    {
        #region Private Instance Fields

        private string ftpDIRListingsPath;
        private string loaderVendorPath;
        private string[] vendorList;
        private int dirListingFileCount;
        private int ftpFileLoadDays = 0;
        private DataTable dtFiles;
        private DataTable dtSearchFile;

        #endregion

        public frmFileSearchUtility()
        {
            InitializeComponent();
            initializeControls();
        }

        private void initializeControls()
        {
            ftpDIRListingsPath = ConfigurationManager.AppSettings["FTPDIRListingsPath"];
            loaderVendorPath = ConfigurationManager.AppSettings["LoaderVendorPath"];
            vendorList = ConfigurationManager.AppSettings["VendorList"].Split(',').ToArray();
            dirListingFileCount = Convert.ToInt32(ConfigurationManager.AppSettings["DIRListingFileCount"]);

            dtFiles = new DataTable();
            dtFiles.Columns.Add("vendor", typeof(string));
            dtFiles.Columns.Add("dir_listing_file_name", typeof(string));
            dtFiles.Columns.Add("ftp_file_name", typeof(string));
            dtFiles.Columns.Add("ftp_file_date_time", typeof(DateTime));
            dtFiles.Columns.Add("ftp_file_size", typeof(long));
            dtFiles.Columns.Add("loader_file_date_time", typeof(DateTime));
            dtFiles.Columns.Add("loader_file_size", typeof(long));
            dtFiles.Columns.Add("ftp_loader_time_diff", typeof(string));

            cbVendor.Items.AddRange(vendorList);
            lblDIRListingFile.Text = "DIR Listing File (Latest " + dirListingFileCount + ")";

            dtSearchFile = new DataTable();
            dtSearchFile.Columns.Add("file_name", typeof(string));
            dtSearchFile.Columns.Add("matched_file_name", typeof(string));
            dtSearchFile.Columns.Add("file_path", typeof(string));
            dtSearchFile.Columns.Add("file_date_time", typeof(DateTime));
            dtSearchFile.Columns.Add("file_size", typeof(long));
        }

        private void ProcessDirListingFile(string vendor, string dirListingFile)
        {
            string ftpFileName;
            DateTime ftpFileDate;
            long ftpFileSize;
            DateTime loaderFileDate = DateTime.Now;
            long loaderFileSize = 0;

            if (ConfigurationManager.AppSettings["FTPFileLoadDays_" + vendor] != null)
                ftpFileLoadDays = Convert.ToInt32(ConfigurationManager.AppSettings["FTPFileLoadDays_" + vendor]);
            else
                ftpFileLoadDays =  Convert.ToInt32(ConfigurationManager.AppSettings["FTPFileLoadDays"]);

            string updatedLoaderVendorPath = loaderVendorPath + dirListingFile.Substring(4, dirListingFile.IndexOf("_DIR_LISTING") - 4).Replace('-', '\\');
            updatedLoaderVendorPath = updatedLoaderVendorPath.Replace("wmrates\\save", "wmrates");
            string fileAllText = System.IO.File.ReadAllText(Path.Combine(ftpDIRListingsPath, dirListingFile));
            string[] fileContent = fileAllText.Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            FileInfo[] loaderFiles = new DirectoryInfo(updatedLoaderVendorPath).GetFiles("*.*", SearchOption.TopDirectoryOnly);

            foreach (string line in fileContent)
            {
                string[] spLine = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                if (spLine.Length >= 4 && line.Contains(":") && (spLine[0].StartsWith("-") || (vendor == "COPP_CLARK" && (spLine[1].EndsWith("AM") || spLine[1].EndsWith("PM")))))
                {
                    if (vendor == "BLOOMBERG" && !Regex.IsMatch(line.Substring(line.LastIndexOf(".") + 1), @"^\d+$"))
                        continue;

                    if (vendor == "COPP_CLARK")
                        ftpFileDate = DateTime.ParseExact(spLine[0] + spLine[1], "MM-dd-yyhh:mmtt", CultureInfo.InvariantCulture, DateTimeStyles.None);
                    else
                        ftpFileDate = DateTime.Parse(DateTime.Now.Year + " " + spLine[spLine.Length - 4] + " " + spLine[spLine.Length - 3] + " " + spLine[spLine.Length - 2]);

                    if (ftpFileDate.Date >= DateTime.Now.Date.AddDays(-ftpFileLoadDays) && ftpFileDate.Date <= DateTime.Now.Date.AddDays(ftpFileLoadDays))
                    {
                        ftpFileName = spLine[spLine.Length - 1];
                        if (vendor == "COPP_CLARK")
                            ftpFileSize = Int32.Parse(spLine[spLine.Length - 2]);
                        else
                            ftpFileSize = ftpFileSize = Int32.Parse(spLine[spLine.Length - 5]);

                        FileInfo loaderFileInfo = loaderFiles.FirstOrDefault(a => a.Name == ftpFileName);
                        if (loaderFileInfo == null)
                        {
                            dtFiles.Rows.Add(vendor, dirListingFile, ftpFileName, ftpFileDate, ftpFileSize, null, null, null);
                        }
                        else
                        {
                            loaderFileSize = loaderFileInfo.Length;
                            loaderFileDate = loaderFileInfo.LastWriteTime;
                            TimeSpan span = loaderFileDate.Subtract(ftpFileDate);
                            dtFiles.Rows.Add(vendor, dirListingFile, ftpFileName, ftpFileDate, ftpFileSize, loaderFileDate, loaderFileSize, span);
                        }
                    }
                }
            }
        }

        private void cbVendor_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                cbDirListingFile.Items.Clear();
                btnExportDataToCSV.Enabled = false;

                var files = new DirectoryInfo(ftpDIRListingsPath).GetFiles("ftse-" + cbVendor.SelectedItem + "*.*", SearchOption.TopDirectoryOnly)
                        .Where(f => f.Length > 0 && f.Name.IndexOf("-notices_DIR_LISTING") < 0)
                        .OrderByDescending(f => f.LastWriteTime)
                        .Take(dirListingFileCount)
                        .Select(f => f.Name).ToArray();

                cbDirListingFile.Items.AddRange(files.ToArray());

                dtFiles.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }

        }

        private void cbDirListingFile_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                dtFiles.Clear();
                ProcessDirListingFile(cbVendor.SelectedItem.ToString(), cbDirListingFile.SelectedItem.ToString());
                dgFiles.DataSource = dtFiles;
                btnExportDataToCSV.Enabled = dtFiles.Rows.Count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void btnExportDataToCSV_Click(object sender, EventArgs e)
        {
            try
            {
                if (saveFileAsCSV.ShowDialog() == DialogResult.OK)
                {
                    this.Cursor = Cursors.WaitCursor;
                    StringBuilder sbCSV = new StringBuilder();
                    int intColCount = dtFiles.Columns.Count;
                    foreach (DataColumn dc in dtFiles.Columns)
                    {
                        sbCSV.Append(dc.ColumnName);
                        if (dc.ColumnName != dtFiles.Columns[dtFiles.Columns.Count - 1].ColumnName)
                        {
                            sbCSV.Append(",");
                        }
                    }
                    sbCSV.Append("\n");

                    foreach (DataRowView dr in dtFiles.DefaultView)
                    {
                        for (int x = 0; x < intColCount; x++)
                        {
                            sbCSV.Append(dr[x].ToString());
                            if ((x + 1) != intColCount)
                            {
                                sbCSV.Append(",");
                            }
                        }
                        sbCSV.Append("\n");
                    }
                    using (StreamWriter sw = new StreamWriter(saveFileAsCSV.FileName))
                    {
                        sw.Write(sbCSV.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }

        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(dtFiles.Rows.Count > 0 && dgFiles.GetClipboardContent() != null)
                Clipboard.SetDataObject(dgFiles.GetClipboardContent());
        }

        private void btnSearchFileList_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    txtSearchFileList.Text = openFileDialog.FileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void btnSearchPath_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    txtSearchPath.Text = folderBrowserDialog.SelectedPath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnStartSearch_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtSearchFileList.Text == string.Empty || txtSearchPath.Text == string.Empty)
                {

                    MessageBox.Show("Please select the Search File List, Search Path");
                    return;
                }

                this.Cursor = Cursors.WaitCursor;
                dtSearchFile.Clear();
                dgSearchFile.DataSource = dtSearchFile;
                string fileAllText = System.IO.File.ReadAllText(txtSearchFileList.Text);
                string[] fileContent = fileAllText.Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                FileInfo[] allFiles = new DirectoryInfo(txtSearchPath.Text).GetFiles("*.*", SearchOption.AllDirectories);

                foreach (string line in fileContent)
                {
                    string[] spLine = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    if (spLine.Length >= 1)
                    {
                        string fileName = spLine[spLine.Length - 1];
                        List<FileInfo> filesMatched  = new List<FileInfo>(); 
                        if (cbCheckFileNameLike.Checked)
                            filesMatched  = allFiles.Where(f => f.Name.Contains(fileName)).ToList();
                        else
                            filesMatched = allFiles.Where(f => f.Name == fileName).ToList();

                        foreach (FileInfo fileInfo in filesMatched)
                        {
                            dtSearchFile.Rows.Add(fileName, fileInfo.Name, fileInfo.DirectoryName, fileInfo.LastWriteTime, fileInfo.Length);
                        }
                        if (filesMatched.Count == 0)
                        {
                            dtSearchFile.Rows.Add(fileName, null, null, null, null);
                        }
                    }
                }
                dgSearchFile.DataSource = dtSearchFile;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }

        }

        private void btnDestinationPath_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    txtDestinationPath.Text = folderBrowserDialog.SelectedPath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCopyFiles_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtDestinationPath.Text == string.Empty)
                {

                    MessageBox.Show("Please select the Destination Path");
                    return;
                }

                int cntr = 0;
                this.Cursor = Cursors.WaitCursor;
                foreach (DataRow drSearchFile in dtSearchFile.Rows)
                {
                    if(drSearchFile["matched_file_name"].ToString() != string.Empty)
                    {
                        File.Copy(Path.Combine(drSearchFile["file_path"].ToString(), drSearchFile["matched_file_name"].ToString()), Path.Combine(txtDestinationPath.Text, drSearchFile["matched_file_name"].ToString()), true);
                        cntr++;
                    }

                }
                MessageBox.Show(cntr + " Files copied successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

    }
}
