﻿namespace FileUtility
{
    partial class frmFileSearchUtility
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpSearchFileAndCopy = new System.Windows.Forms.TabPage();
            this.dgSearchFile = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MatchedFileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnDestinationPath = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDestinationPath = new System.Windows.Forms.TextBox();
            this.btnCopyFiles = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbCheckFileNameLike = new System.Windows.Forms.CheckBox();
            this.btnStartSearch = new System.Windows.Forms.Button();
            this.lblSearchPath = new System.Windows.Forms.Label();
            this.txtSearchPath = new System.Windows.Forms.TextBox();
            this.btnSearchPath = new System.Windows.Forms.Button();
            this.lblSearchFileList = new System.Windows.Forms.Label();
            this.txtSearchFileList = new System.Windows.Forms.TextBox();
            this.btnSearchFileList = new System.Windows.Forms.Button();
            this.tpFTPLoaderFileMismatch = new System.Windows.Forms.TabPage();
            this.dgFiles = new System.Windows.Forms.DataGridView();
            this.vendor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dir_listing_file_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FTPFileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FTPFileDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FTPFileSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaderFileDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaderFileSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FTPLoaderTimeDiff = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblDIRListingFile = new System.Windows.Forms.Label();
            this.cbDirListingFile = new System.Windows.Forms.ComboBox();
            this.lblVendor = new System.Windows.Forms.Label();
            this.cbVendor = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExportDataToCSV = new System.Windows.Forms.Button();
            this.saveFileAsCSV = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.tabControl1.SuspendLayout();
            this.tpSearchFileAndCopy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSearchFile)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tpFTPLoaderFileMismatch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFiles)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpSearchFileAndCopy);
            this.tabControl1.Controls.Add(this.tpFTPLoaderFileMismatch);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(980, 570);
            this.tabControl1.TabIndex = 0;
            // 
            // tpSearchFileAndCopy
            // 
            this.tpSearchFileAndCopy.Controls.Add(this.dgSearchFile);
            this.tpSearchFileAndCopy.Controls.Add(this.panel4);
            this.tpSearchFileAndCopy.Controls.Add(this.panel3);
            this.tpSearchFileAndCopy.Location = new System.Drawing.Point(4, 22);
            this.tpSearchFileAndCopy.Name = "tpSearchFileAndCopy";
            this.tpSearchFileAndCopy.Padding = new System.Windows.Forms.Padding(3);
            this.tpSearchFileAndCopy.Size = new System.Drawing.Size(972, 544);
            this.tpSearchFileAndCopy.TabIndex = 1;
            this.tpSearchFileAndCopy.Text = "Search File/Copy";
            this.tpSearchFileAndCopy.UseVisualStyleBackColor = true;
            // 
            // dgSearchFile
            // 
            this.dgSearchFile.AllowUserToAddRows = false;
            this.dgSearchFile.AllowUserToDeleteRows = false;
            this.dgSearchFile.AllowUserToOrderColumns = true;
            this.dgSearchFile.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgSearchFile.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dgSearchFile.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.MatchedFileName,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dgSearchFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgSearchFile.Location = new System.Drawing.Point(3, 79);
            this.dgSearchFile.Name = "dgSearchFile";
            this.dgSearchFile.ReadOnly = true;
            this.dgSearchFile.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgSearchFile.Size = new System.Drawing.Size(966, 400);
            this.dgSearchFile.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "file_name";
            this.dataGridViewTextBoxColumn3.HeaderText = "File Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 79;
            // 
            // MatchedFileName
            // 
            this.MatchedFileName.DataPropertyName = "matched_file_name";
            this.MatchedFileName.HeaderText = "Matched File Name";
            this.MatchedFileName.Name = "MatchedFileName";
            this.MatchedFileName.ReadOnly = true;
            this.MatchedFileName.Width = 124;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "file_path";
            this.dataGridViewTextBoxColumn2.HeaderText = "File Path";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 73;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "file_date_time";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn4.HeaderText = "File Date Time";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "file_size";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn5.HeaderText = "File Size";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 71;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnDestinationPath);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.txtDestinationPath);
            this.panel4.Controls.Add(this.btnCopyFiles);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(3, 479);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(966, 62);
            this.panel4.TabIndex = 15;
            // 
            // btnDestinationPath
            // 
            this.btnDestinationPath.Location = new System.Drawing.Point(698, 26);
            this.btnDestinationPath.Name = "btnDestinationPath";
            this.btnDestinationPath.Size = new System.Drawing.Size(97, 23);
            this.btnDestinationPath.TabIndex = 15;
            this.btnDestinationPath.Text = "Select";
            this.btnDestinationPath.UseVisualStyleBackColor = true;
            this.btnDestinationPath.Click += new System.EventHandler(this.btnDestinationPath_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(333, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Destination Path(File Copy)";
            // 
            // txtDestinationPath
            // 
            this.txtDestinationPath.Location = new System.Drawing.Point(336, 26);
            this.txtDestinationPath.Name = "txtDestinationPath";
            this.txtDestinationPath.Size = new System.Drawing.Size(356, 20);
            this.txtDestinationPath.TabIndex = 13;
            // 
            // btnCopyFiles
            // 
            this.btnCopyFiles.Location = new System.Drawing.Point(833, 26);
            this.btnCopyFiles.Name = "btnCopyFiles";
            this.btnCopyFiles.Size = new System.Drawing.Size(97, 23);
            this.btnCopyFiles.TabIndex = 6;
            this.btnCopyFiles.Text = "Copy Files";
            this.btnCopyFiles.UseVisualStyleBackColor = true;
            this.btnCopyFiles.Click += new System.EventHandler(this.btnCopyFiles_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cbCheckFileNameLike);
            this.panel3.Controls.Add(this.btnStartSearch);
            this.panel3.Controls.Add(this.lblSearchPath);
            this.panel3.Controls.Add(this.txtSearchPath);
            this.panel3.Controls.Add(this.btnSearchPath);
            this.panel3.Controls.Add(this.lblSearchFileList);
            this.panel3.Controls.Add(this.txtSearchFileList);
            this.panel3.Controls.Add(this.btnSearchFileList);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(966, 76);
            this.panel3.TabIndex = 12;
            // 
            // cbCheckFileNameLike
            // 
            this.cbCheckFileNameLike.AutoSize = true;
            this.cbCheckFileNameLike.Location = new System.Drawing.Point(23, 53);
            this.cbCheckFileNameLike.Name = "cbCheckFileNameLike";
            this.cbCheckFileNameLike.Size = new System.Drawing.Size(133, 17);
            this.cbCheckFileNameLike.TabIndex = 13;
            this.cbCheckFileNameLike.Text = "Search File Name Like";
            this.cbCheckFileNameLike.UseVisualStyleBackColor = true;
            // 
            // btnStartSearch
            // 
            this.btnStartSearch.Location = new System.Drawing.Point(794, 26);
            this.btnStartSearch.Name = "btnStartSearch";
            this.btnStartSearch.Size = new System.Drawing.Size(136, 30);
            this.btnStartSearch.TabIndex = 12;
            this.btnStartSearch.Text = "Start Search";
            this.btnStartSearch.UseVisualStyleBackColor = true;
            this.btnStartSearch.Click += new System.EventHandler(this.btnStartSearch_Click);
            // 
            // lblSearchPath
            // 
            this.lblSearchPath.AutoSize = true;
            this.lblSearchPath.Location = new System.Drawing.Point(411, 9);
            this.lblSearchPath.Name = "lblSearchPath";
            this.lblSearchPath.Size = new System.Drawing.Size(66, 13);
            this.lblSearchPath.TabIndex = 11;
            this.lblSearchPath.Text = "Search Path";
            // 
            // txtSearchPath
            // 
            this.txtSearchPath.Location = new System.Drawing.Point(414, 30);
            this.txtSearchPath.Name = "txtSearchPath";
            this.txtSearchPath.Size = new System.Drawing.Size(254, 20);
            this.txtSearchPath.TabIndex = 10;
            // 
            // btnSearchPath
            // 
            this.btnSearchPath.Location = new System.Drawing.Point(674, 30);
            this.btnSearchPath.Name = "btnSearchPath";
            this.btnSearchPath.Size = new System.Drawing.Size(25, 23);
            this.btnSearchPath.TabIndex = 9;
            this.btnSearchPath.Text = "...";
            this.btnSearchPath.UseVisualStyleBackColor = true;
            this.btnSearchPath.Click += new System.EventHandler(this.btnSearchPath_Click);
            // 
            // lblSearchFileList
            // 
            this.lblSearchFileList.AutoSize = true;
            this.lblSearchFileList.Location = new System.Drawing.Point(20, 9);
            this.lblSearchFileList.Name = "lblSearchFileList";
            this.lblSearchFileList.Size = new System.Drawing.Size(244, 13);
            this.lblSearchFileList.TabIndex = 8;
            this.lblSearchFileList.Text = "Search File List(File name must be the first column)";
            // 
            // txtSearchFileList
            // 
            this.txtSearchFileList.Location = new System.Drawing.Point(23, 30);
            this.txtSearchFileList.Name = "txtSearchFileList";
            this.txtSearchFileList.ReadOnly = true;
            this.txtSearchFileList.Size = new System.Drawing.Size(254, 20);
            this.txtSearchFileList.TabIndex = 7;
            // 
            // btnSearchFileList
            // 
            this.btnSearchFileList.Location = new System.Drawing.Point(283, 30);
            this.btnSearchFileList.Name = "btnSearchFileList";
            this.btnSearchFileList.Size = new System.Drawing.Size(24, 23);
            this.btnSearchFileList.TabIndex = 6;
            this.btnSearchFileList.Text = "...";
            this.btnSearchFileList.UseVisualStyleBackColor = true;
            this.btnSearchFileList.Click += new System.EventHandler(this.btnSearchFileList_Click);
            // 
            // tpFTPLoaderFileMismatch
            // 
            this.tpFTPLoaderFileMismatch.Controls.Add(this.dgFiles);
            this.tpFTPLoaderFileMismatch.Controls.Add(this.panel2);
            this.tpFTPLoaderFileMismatch.Controls.Add(this.panel1);
            this.tpFTPLoaderFileMismatch.Location = new System.Drawing.Point(4, 22);
            this.tpFTPLoaderFileMismatch.Name = "tpFTPLoaderFileMismatch";
            this.tpFTPLoaderFileMismatch.Padding = new System.Windows.Forms.Padding(3);
            this.tpFTPLoaderFileMismatch.Size = new System.Drawing.Size(972, 544);
            this.tpFTPLoaderFileMismatch.TabIndex = 0;
            this.tpFTPLoaderFileMismatch.Text = "FTP Loader File Mismatch";
            this.tpFTPLoaderFileMismatch.UseVisualStyleBackColor = true;
            // 
            // dgFiles
            // 
            this.dgFiles.AllowUserToAddRows = false;
            this.dgFiles.AllowUserToDeleteRows = false;
            this.dgFiles.AllowUserToOrderColumns = true;
            this.dgFiles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgFiles.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dgFiles.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vendor,
            this.dir_listing_file_name,
            this.FTPFileName,
            this.FTPFileDateTime,
            this.FTPFileSize,
            this.LoaderFileDateTime,
            this.LoaderFileSize,
            this.FTPLoaderTimeDiff});
            this.dgFiles.ContextMenuStrip = this.contextMenuStrip1;
            this.dgFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgFiles.Location = new System.Drawing.Point(3, 67);
            this.dgFiles.Name = "dgFiles";
            this.dgFiles.ReadOnly = true;
            this.dgFiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgFiles.Size = new System.Drawing.Size(966, 398);
            this.dgFiles.TabIndex = 13;
            // 
            // vendor
            // 
            this.vendor.DataPropertyName = "vendor";
            this.vendor.HeaderText = "Vendor";
            this.vendor.Name = "vendor";
            this.vendor.ReadOnly = true;
            this.vendor.Visible = false;
            this.vendor.Width = 66;
            // 
            // dir_listing_file_name
            // 
            this.dir_listing_file_name.DataPropertyName = "dir_listing_file_name";
            this.dir_listing_file_name.HeaderText = "Dir Listing File Name";
            this.dir_listing_file_name.Name = "dir_listing_file_name";
            this.dir_listing_file_name.ReadOnly = true;
            this.dir_listing_file_name.Visible = false;
            this.dir_listing_file_name.Width = 128;
            // 
            // FTPFileName
            // 
            this.FTPFileName.DataPropertyName = "ftp_file_name";
            this.FTPFileName.HeaderText = "FTP File Name";
            this.FTPFileName.Name = "FTPFileName";
            this.FTPFileName.ReadOnly = true;
            this.FTPFileName.Width = 102;
            // 
            // FTPFileDateTime
            // 
            this.FTPFileDateTime.DataPropertyName = "ftp_file_date_time";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.FTPFileDateTime.DefaultCellStyle = dataGridViewCellStyle10;
            this.FTPFileDateTime.HeaderText = "FTP File Date Time";
            this.FTPFileDateTime.Name = "FTPFileDateTime";
            this.FTPFileDateTime.ReadOnly = true;
            this.FTPFileDateTime.Width = 123;
            // 
            // FTPFileSize
            // 
            this.FTPFileSize.DataPropertyName = "ftp_file_size";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.FTPFileSize.DefaultCellStyle = dataGridViewCellStyle11;
            this.FTPFileSize.HeaderText = "FTP File Size";
            this.FTPFileSize.Name = "FTPFileSize";
            this.FTPFileSize.ReadOnly = true;
            this.FTPFileSize.Width = 94;
            // 
            // LoaderFileDateTime
            // 
            this.LoaderFileDateTime.DataPropertyName = "loader_file_date_time";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.LoaderFileDateTime.DefaultCellStyle = dataGridViewCellStyle12;
            this.LoaderFileDateTime.HeaderText = "Loader File DateTime";
            this.LoaderFileDateTime.Name = "LoaderFileDateTime";
            this.LoaderFileDateTime.ReadOnly = true;
            this.LoaderFileDateTime.Width = 133;
            // 
            // LoaderFileSize
            // 
            this.LoaderFileSize.DataPropertyName = "loader_file_size";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.LoaderFileSize.DefaultCellStyle = dataGridViewCellStyle13;
            this.LoaderFileSize.HeaderText = "Loader File Size";
            this.LoaderFileSize.Name = "LoaderFileSize";
            this.LoaderFileSize.ReadOnly = true;
            this.LoaderFileSize.Width = 107;
            // 
            // FTPLoaderTimeDiff
            // 
            this.FTPLoaderTimeDiff.DataPropertyName = "ftp_loader_time_diff";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.FTPLoaderTimeDiff.DefaultCellStyle = dataGridViewCellStyle14;
            this.FTPLoaderTimeDiff.HeaderText = "FTP Loader Time Diff";
            this.FTPLoaderTimeDiff.Name = "FTPLoaderTimeDiff";
            this.FTPLoaderTimeDiff.ReadOnly = true;
            this.FTPLoaderTimeDiff.Width = 133;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(103, 26);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblDIRListingFile);
            this.panel2.Controls.Add(this.cbDirListingFile);
            this.panel2.Controls.Add(this.lblVendor);
            this.panel2.Controls.Add(this.cbVendor);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(966, 64);
            this.panel2.TabIndex = 12;
            // 
            // lblDIRListingFile
            // 
            this.lblDIRListingFile.AutoSize = true;
            this.lblDIRListingFile.Location = new System.Drawing.Point(295, 9);
            this.lblDIRListingFile.Name = "lblDIRListingFile";
            this.lblDIRListingFile.Size = new System.Drawing.Size(125, 13);
            this.lblDIRListingFile.TabIndex = 11;
            this.lblDIRListingFile.Text = "DIR Listing File (Latest 5)";
            // 
            // cbDirListingFile
            // 
            this.cbDirListingFile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDirListingFile.FormattingEnabled = true;
            this.cbDirListingFile.Location = new System.Drawing.Point(298, 24);
            this.cbDirListingFile.Name = "cbDirListingFile";
            this.cbDirListingFile.Size = new System.Drawing.Size(339, 21);
            this.cbDirListingFile.TabIndex = 10;
            this.cbDirListingFile.SelectedIndexChanged += new System.EventHandler(this.cbDirListingFile_SelectedIndexChanged);
            // 
            // lblVendor
            // 
            this.lblVendor.AutoSize = true;
            this.lblVendor.Location = new System.Drawing.Point(12, 8);
            this.lblVendor.Name = "lblVendor";
            this.lblVendor.Size = new System.Drawing.Size(41, 13);
            this.lblVendor.TabIndex = 4;
            this.lblVendor.Text = "Vendor";
            // 
            // cbVendor
            // 
            this.cbVendor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbVendor.FormattingEnabled = true;
            this.cbVendor.Location = new System.Drawing.Point(12, 24);
            this.cbVendor.Name = "cbVendor";
            this.cbVendor.Size = new System.Drawing.Size(229, 21);
            this.cbVendor.TabIndex = 3;
            this.cbVendor.SelectedIndexChanged += new System.EventHandler(this.cbVendor_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnExportDataToCSV);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 465);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(966, 76);
            this.panel1.TabIndex = 11;
            // 
            // btnExportDataToCSV
            // 
            this.btnExportDataToCSV.Enabled = false;
            this.btnExportDataToCSV.Location = new System.Drawing.Point(15, 21);
            this.btnExportDataToCSV.Name = "btnExportDataToCSV";
            this.btnExportDataToCSV.Size = new System.Drawing.Size(136, 30);
            this.btnExportDataToCSV.TabIndex = 6;
            this.btnExportDataToCSV.Text = "Export Data To CSV";
            this.btnExportDataToCSV.UseVisualStyleBackColor = true;
            this.btnExportDataToCSV.Click += new System.EventHandler(this.btnExportDataToCSV_Click);
            // 
            // saveFileAsCSV
            // 
            this.saveFileAsCSV.DefaultExt = "csv";
            this.saveFileAsCSV.Filter = "CSV Files | *.csv";
            // 
            // openFileDialog
            // 
            this.openFileDialog.DefaultExt = "txt";
            this.openFileDialog.Filter = "TXT Files | *.txt|CSV Files|*.csv";
            // 
            // folderBrowserDialog
            // 
            this.folderBrowserDialog.ShowNewFolderButton = false;
            // 
            // frmFileSearchUtility
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 570);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmFileSearchUtility";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "File Utility";
            this.tabControl1.ResumeLayout(false);
            this.tpSearchFileAndCopy.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgSearchFile)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tpFTPLoaderFileMismatch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgFiles)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpSearchFileAndCopy;
        private System.Windows.Forms.TabPage tpFTPLoaderFileMismatch;
        private System.Windows.Forms.DataGridView dgFiles;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendor;
        private System.Windows.Forms.DataGridViewTextBoxColumn dir_listing_file_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn FTPFileName;
        private System.Windows.Forms.DataGridViewTextBoxColumn FTPFileDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn FTPFileSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaderFileDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaderFileSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn FTPLoaderTimeDiff;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblDIRListingFile;
        private System.Windows.Forms.ComboBox cbDirListingFile;
        private System.Windows.Forms.Label lblVendor;
        private System.Windows.Forms.ComboBox cbVendor;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnExportDataToCSV;
        private System.Windows.Forms.SaveFileDialog saveFileAsCSV;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSearchFileList;
        private System.Windows.Forms.TextBox txtSearchFileList;
        private System.Windows.Forms.Button btnSearchFileList;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label lblSearchPath;
        private System.Windows.Forms.TextBox txtSearchPath;
        private System.Windows.Forms.Button btnSearchPath;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button btnStartSearch;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnCopyFiles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDestinationPath;
        private System.Windows.Forms.Button btnDestinationPath;
        private System.Windows.Forms.DataGridView dgSearchFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn MatchedFileName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.CheckBox cbCheckFileNameLike;


    }
}

