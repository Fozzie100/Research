SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [PERFAT].[job_add] 
--test riw
@PortfolioId1					 int	,
@PortfolioId2					 int	,
@UserId						     int	,
@email                 varchar(max) = null,
@JobName               varchar(255),
@CurrencyId						 int	,
@IsLong								 bit	,
@BenchmarkId1					 int = null,
@BenchmarkId2					 int = null,
@ComparisonName1			 varchar(max) ,
@ComparisonName2			 varchar(max) ,
@FrequencyId					 int ,
@PeriodStart					 datetime ,
@PeriodEnd						 datetime ,
@InvestmentApproachId  int ,
@AnalysisTypeId			   int ,
--@ReportOutputTypeId	   int ,
@IncludeStockLevel		 int ,
@mathregion						 int = 0
AS

SET NOCOUNT ON

INSERT INTO Job 
(
  portfolio_id1 ,
  portfolio_id2 ,
  job_name,
  user_id ,
  currency_id ,
  is_long ,
  benchmark_id1,
  benchmark_id2,
	comparison_name1,
	comparison_name2,
  frequency_id ,
  period_start ,
  period_end,
  investment_approach_id,
  analysis_type_id,
--report_output_type_id ,
  include_stock_level,
  email,
  math_region
) 
Values 
(
  @PortfolioId1					,
  @PortfolioId2					,
  @JobName              ,
  @UserId						    ,
  @CurrencyId						,
  @IsLong							  ,
  @BenchmarkId1					,
  @BenchmarkId2					,
	@ComparisonName1			,
	@ComparisonName2			,
  @FrequencyId					,
  @PeriodStart					,
  @PeriodEnd						,
  @InvestmentApproachId ,
  @AnalysisTypeId			  ,
--@ReportOutputTypeId	  ,
  @IncludeStockLevel		,
  @email,
  @mathregion
)

RETURN @@IDENTITY
GO
