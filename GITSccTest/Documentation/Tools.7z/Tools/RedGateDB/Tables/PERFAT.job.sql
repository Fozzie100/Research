CREATE TABLE [PERFAT].[job]
(
[job_id] [int] NOT NULL IDENTITY(1, 1),
[user_id] [int] NOT NULL,
[portfolio_id1] [int] NULL,
[portfolio_id2] [int] NULL,
[job_name] [varchar] (255) COLLATE Latin1_General_CI_AS NOT NULL,
[currency_id] [int] NOT NULL,
[is_long] [bit] NOT NULL CONSTRAINT [DF_Job_Long] DEFAULT ((1)),
[benchmark_id_old] [int] NULL,
[benchmark_id1] [int] NULL,
[benchmark_id2] [int] NULL,
[comparison_name1] [varchar] (max) COLLATE Latin1_General_CI_AS NULL,
[comparison_name2] [varchar] (max) COLLATE Latin1_General_CI_AS NULL,
[frequency_id] [int] NOT NULL,
[period_start] [datetime] NOT NULL,
[period_end] [datetime] NOT NULL,
[investment_approach_id] [int] NOT NULL,
[analysis_type_id] [int] NOT NULL,
[include_stock_level] [bit] NOT NULL,
[created] [datetime] NOT NULL CONSTRAINT [DF_job_requested] DEFAULT (getdate()),
[extracted] [datetime] NULL,
[math_ended] [datetime] NULL,
[completed] [datetime] NULL,
[failed] [datetime] NULL,
[output_path] [varchar] (max) COLLATE Latin1_General_CI_AS NULL,
[last_accessed] [datetime] NULL,
[ssrs_reportname] [varchar] (max) COLLATE Latin1_General_CI_AS NULL,
[report_output_type_id] [int] NULL,
[cancelled] [datetime] NULL,
[math_error] [varchar] (max) COLLATE Latin1_General_CI_AS NULL,
[email] [varchar] (max) COLLATE Latin1_General_CI_AS NULL,
[math_region] [int] NOT NULL CONSTRAINT [DF_job_math_region] DEFAULT ((0))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [PERFAT].[job] ADD CONSTRAINT [PK_job] PRIMARY KEY CLUSTERED  ([job_id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_userid] ON [PERFAT].[job] ([user_id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
