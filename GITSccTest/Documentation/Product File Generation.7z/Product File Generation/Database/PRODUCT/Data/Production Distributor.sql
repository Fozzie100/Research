USE EXPORT
GO

DELETE FROM EXPORT.PRODUCT.ProductDistributor
DELETE FROM export.product.FileDistributor
DELETE FROM export.product.FtpDistributor
DELETE FROM export.product.Distributor
DBCC CHECKIDENT ('PRODUCT.FileDistributor', reseed, 0)
DBCC CHECKIDENT ('PRODUCT.FtpDistributor', reseed, 0)
DBCC CHECKIDENT ('PRODUCT.Distributor', reseed, 0)

--Setup File Distributors
DECLARE @ItemKey INT
INSERT INTO EXPORT.PRODUCT.FileDistributor (DestinationDirectory, OverwriteFiles)
VALUES ('\\ukubs-ra01\Research_Analytics\ReleaseBuild\ProductFileGenerator\Delivery\Product', 1)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Product To File System', @ItemKey, 'Product', 'File System', 1)

INSERT INTO EXPORT.PRODUCT.FtpDistributor (RemoteDirectory, FtpUserName, FtpPassword, DownloadBufferSize, TimeoutInMinutes)
VALUES ('ftp://ukubs-l01-ddb01//usr/dds/product_files/', 'upload', '9yqghqav9q37tyq580t00087t', 1048576, 5)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Product To Development DDS UKUBS', @ItemKey, 'Product', 'Ftp', 1)

INSERT INTO EXPORT.PRODUCT.FtpDistributor (RemoteDirectory, FtpUserName, FtpPassword, DownloadBufferSize, TimeoutInMinutes)
VALUES ('ftp://ukhsl-l01-ddb01//usr/dds/product_files/', 'upload', '9yqghqav9q37tyq580t00087t', 1048576, 5)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Product To Development DDS UKHSL', @ItemKey, 'Product', 'Ftp', 1)

INSERT INTO EXPORT.PRODUCT.FileDistributor (DestinationDirectory, OverwriteFiles)
VALUES ('C:\TEMP\Product\Delivery\Product', 1)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Local Product To File System', @ItemKey, 'Product', 'File System', 1)

INSERT INTO EXPORT.PRODUCT.FileDistributor (DestinationDirectory, OverwriteFiles)
VALUES ('\\ftse.com\fileserver\Userfiles\Research_Analytics\Private\ReleaseBuild\Spreadsheets\Reports\event_monitor\FlatFiles', 1)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Event Monitor Product Files', @ItemKey, 'Product', 'File System', 1)

INSERT INTO EXPORT.PRODUCT.FileDistributor (DestinationDirectory, OverwriteFiles)
VALUES ('\\ukubs-ra01\Research_Analytics\ReleaseBuild\ProductFileGenerator\Delivery\Ini', 1)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Ini To File System', @ItemKey, 'Ini', 'File System', 1)

INSERT INTO EXPORT.PRODUCT.FtpDistributor (RemoteDirectory, FtpUserName, FtpPassword, DownloadBufferSize, TimeoutInMinutes)
VALUES ('ftp://ukubs-l01-ddb01//usr/dds/tag_files/', 'upload', '9yqghqav9q37tyq580t00087t', 1048576, 5)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Ini To Development DDS UKUBS', @ItemKey, 'Ini', 'Ftp', 1)

INSERT INTO EXPORT.PRODUCT.FtpDistributor (RemoteDirectory, FtpUserName, FtpPassword, DownloadBufferSize, TimeoutInMinutes)
VALUES ('ftp://ukhsl-l01-ddb01//usr/dds/tag_files/', 'upload', '9yqghqav9q37tyq580t00087t', 1048576, 5)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Ini To Development DDS UKUBS', @ItemKey, 'Ini', 'Ftp', 1)

INSERT INTO EXPORT.PRODUCT.FileDistributor (DestinationDirectory, OverwriteFiles)
VALUES ('C:\TEMP\Product\Delivery\Ini', 1)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Local Ini To File System', @ItemKey, 'Ini', 'File System', 1)

INSERT INTO EXPORT.PRODUCT.FileDistributor (DestinationDirectory, OverwriteFiles)
VALUES ('\\ftse.com\fileserver\Userfiles\Research_Analytics\Private\ReleaseBuild\Spreadsheets\Reports\event_monitor\FlatFiles', 1)
SET @ItemKey = SCOPE_IDENTITY()

INSERT INTO EXPORT.PRODUCT.Distributor (Name, ItemKey, FileType, DistributionType, Active) 
VALUES ('Event Monitor Ini Files', @ItemKey, 'Ini', 'File System', 1)

/*
INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId, Sequence) VALUES (208, 2, 1)
INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId, Sequence) VALUES (208, 3, 2)
*/
/*
select * from EXPORT.PRODUCT.product where productid = 208
*/
select * from export.product.ProductDistributor
select * from export.product.Distributor
select * from EXPORT.PRODUCT.FileDistributor
select * from EXPORT.PRODUCT.FtpDistributor
select * from EXPORT.PRODUCT.ProductDistributionView