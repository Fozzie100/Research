SET IDENTITY_INSERT [PRODUCT].[FileColumnCategory] ON
GO

INSERT INTO [PRODUCT].[FileColumn] (Id, Name) VALUES (1, 'All Columns')
GO

SET IDENTITY_INSERT [PRODUCT].[FileColumnCategory] OFF
GO