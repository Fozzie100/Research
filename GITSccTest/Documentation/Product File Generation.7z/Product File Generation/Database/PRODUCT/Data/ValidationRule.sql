INSERT INTO PRODUCT.ValidationRule (Name, Description, DataType) VALUES ('Nullable', 'Whether the column will allow null values', 'Boolean')
INSERT INTO PRODUCT.ValidationRule (Name, Description, DataType) VALUES ('FixedLength', 'Length the value retrieved must be', 'Integer')
INSERT INTO PRODUCT.ValidationRule (Name, Description, DataType) VALUES ('MaximumLength', 'Maximum Length allowed for column values', 'Integer')
INSERT INTO PRODUCT.ValidationRule (Name, Description, DataType) VALUES ('MinimumLength', 'Minimum Length allowed for column values', 'Integer')