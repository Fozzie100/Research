USE EXPORT
GO

TRUNCATE TABLE PRODUCT.ValueFormatter
GO

SET IDENTITY_INSERT PRODUCT.ValueFormatter ON
GO

INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (1, 'CamelCase', 'Camel Case', 'Ftse.Research.ProductFiles.ValueFormatting.CamelCaseFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (2, 'LowerCase', 'Lower Case', 'Ftse.Research.ProductFiles.ValueFormatting.LowerCaseFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (3, 'UpperCase', 'Upper Case', 'Ftse.Research.ProductFiles.ValueFormatting.UpperCaseFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (4, 'Prefix', 'Prefix', 'Ftse.Research.ProductFiles.ValueFormatting.PrefixFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (5, 'Suffix', 'Suffix', 'Ftse.Research.ProductFiles.ValueFormatting.SuffixFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (6, 'TrimmedDecimal', 'Trimmed Decimal Places', 'Ftse.Research.ProductFiles.ValueFormatting.NumericTrimFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (7, 'RoundedDecimal', 'Rounded Decimal Places', 'Ftse.Research.ProductFiles.ValueFormatting.NumericRoundFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (8, 'PaddedLeft', 'Padded Left', 'Ftse.Research.ProductFiles.ValueFormatting.LeftPaddingFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (9, 'PaddedRight', 'Padded Right', 'Ftse.Research.ProductFiles.ValueFormatting.RightPaddingFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (10, 'ZeroToNull', 'Zero converted to empty string', 'Ftse.Research.ProductFiles.ValueFormatting.ZeroToNullFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (11, 'NullToZero', 'Empty String converted to zero', 'Ftse.Research.ProductFiles.ValueFormatting.NullToZeroFormatter, Ftse.Research.ProductFiles')
INSERT INTO PRODUCT.ValueFormatter (ValueFormatterId, Name, Description, TypeName) VALUES (12, 'Date', 'Formatted Date', 'Ftse.Research.ProductFiles.ValueFormatting.DateFormatter, Ftse.Research.ProductFiles')

SET IDENTITY_INSERT PRODUCT.ValueFormatter OFF
GO
