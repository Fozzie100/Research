USE EXPORT
GO

DELETE FROM PRODUCT.SectionContentType
GO

SET NOCOUNT ON

SET IDENTITY_INSERT PRODUCT.SectionContentType ON
GO

INSERT INTO PRODUCT.SectionContentType (SectionContentTypeId, [Description], UserSelectable) VALUES (1, 'Manually Created', 0)
INSERT INTO PRODUCT.SectionContentType (SectionContentTypeId, [Description], UserSelectable) VALUES (2, 'Instrument', 1)
INSERT INTO PRODUCT.SectionContentType (SectionContentTypeId, [Description], UserSelectable) VALUES (3, 'Index', 1)
INSERT INTO PRODUCT.SectionContentType (SectionContentTypeId, [Description], UserSelectable) VALUES (4, 'Currency', 1)

SET IDENTITY_INSERT PRODUCT.SectionContentType OFF
GO

SET NOCOUNT OFF

SELECT * FROM PRODUCT.SectionContentType