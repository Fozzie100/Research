USE EXPORT
GO

DELETE FROM [PRODUCT].[FileColumn] WHERE FileColumnId > 1
GO

SET IDENTITY_INSERT [PRODUCT].[FileColumn] ON
GO

--INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (1, 1, 'Undefined Column', 'Undefined Column', '')
--GO

DECLARE @FileColumnId INT
--CONS
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (2, 1, 'Instrument Identifier', 'CONS', 'PRODUCT.bulkget_instr_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'CONS', 0)
--SEDOL
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (3, 1, 'Instrument Identifier', 'SEDOL', 'PRODUCT.bulkget_instr_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'SEDOL', 0)
--CUSIP
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (4, 1, 'Security Identifier', 'CUSIP', 'PRODUCT.bulkget_sec_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'CUSIP', 0)
SET @FileColumnId = @@Identity
--CONSTITUENT NAME
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (5, 1, 'Test Columns', 'Constituent Name', 'PRODUCT.bulkget_instr_attribute')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', 'LGNM', 0)

--Country Code
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (6, 1, 'Test Columns', 'Country Code', 'PRODUCT.bulkget_instr_ftse_country')
SET @FileColumnId = @@Identity

--ISO Code
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (7, 1, 'Test Columns', 'ISO Code', 'PRODUCT.bulkget_instr_attribute')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', 'CURRENCY', 0)

--Price Close
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (8, 1, 'Test Columns', 'Price Close', 'PRODUCT.bulkget_instr_daily_price_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Shares In Issue
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (9, 1, 'Test Columns', 'Shares In Issue', 'PRODUCT.bulkget_instr_daily_shares')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Large/Medium Classification
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (10, 1, 'Test Columns', 'Large/Medium Classification', 'PRODUCT.bulkget_constituent_dimension')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Dimension Name', '@dimension_name', NULL, 1)

--Exchange code
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (11, 1, 'Test Columns', 'Exchange code', 'PRODUCT.bulkget_instr_ftse_exchange')
SET @FileColumnId = @@Identity
--Supersector Code
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (12, 1, 'Classification', 'Supersector Code', 'PRODUCT.bulkget_instr_supersector_code')
SET @FileColumnId = @@Identity
--Subsector Code
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (13, 1, 'Classification', 'Subsector Code', 'PRODUCT.bulkget_instr_subsector_code')
SET @FileColumnId = @@Identity
--Sector Code
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (14, 1, 'Classification', 'Sector Code', 'PRODUCT.bulkget_instr_sector_code')
SET @FileColumnId = @@Identity
--Industry Code
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (15, 1, 'Classification', 'Industry Code', 'PRODUCT.bulkget_instr_industry_code')
SET @FileColumnId = @@Identity

--Index Marker
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (16, 1, 'Test Columns', 'Index Marker', 'PRODUCT.bulkget_instr_index_marker')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'List Code', '@list_code', NULL, 1)

--Market Cap Close before weighting
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (17, 1, 'Test Columns', 'Market Cap Close Before Weighting', 'PRODUCT.bulkget_instr_market_cap_close_before_weighting')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

--Market Cap Close After weighting
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (18, 1, 'Test Columns', 'Market Cap Close After Weighting', 'PRODUCT.bulkget_instr_market_cap_close_after_weighting')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

--Index Weight
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (19, 1, 'Test Columns', 'Index Weight', 'PRODUCT.bulkget_instr_index_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

--Weighting
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (20, 1, 'Test Columns', 'Weighting', 'PRODUCT.bulkget_instr_free_float')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Dividend Yield
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (21, 1, 'Test Columns', 'Weighting', 'PRODUCT.bulkget_instr_dividend_yield')
SET @FileColumnId = @@Identity

--Country Weight
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (22, 1, 'Test Columns', 'Country Weight', 'PRODUCT.bulkget_instr_country_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Industry Weight Close By Country
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (23, 1, 'Test Columns', 'Industry Weight Close By Country', 'PRODUCT.bulkget_instr_industry_weight_close_by_country')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Sector Weight By country
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (24, 1, 'Test Columns', 'Sector Weight Close By Country', 'PRODUCT.bulkget_instr_sector_weight_close_by_country')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (25, 1, 'Test Columns', 'Index Mnemonic', 'PRODUCT.bulkget_index_mnemonic')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (26, 1, 'Test Columns', 'Number Of Index Constituents', 'PRODUCT.bulkget_index_number_of_constituents')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (27, 1, 'Test Columns', 'Price Open', 'PRODUCT.bulkget_instr_daily_price_open
')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (28, 1, 'Test Columns', 'Market Cap Open Before Weighting', 'PRODUCT.bulkget_instr_market_cap_open_before_weighting')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (29, 1, 'Test Columns', 'Market Cap Open After Weighting', 'PRODUCT.bulkget_instr_market_cap_close_before_weighting')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (30, 1, 'Test Columns', 'Index Weight Open', 'PRODUCT.bulkget_instr_index_weight_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (31, 1, 'Test Columns', 'Country Weight Open', 'PRODUCT.bulkget_instr_country_weight_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (32, 1, 'Test Columns', 'Industry Weight Open By Country', 'PRODUCT.bulkget_instr_industry_weight_open_by_country')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (33, 1, 'Test Columns', 'Sector Weight Open By Country', 'PRODUCT.bulkget_instr_sector_weight_open_by_country')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (34, 1, 'Test Columns', 'Index Name', 'PRODUCT.bulkget_index_attribute')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (35, 1, 'Test Columns', 'Index Value', 'PRODUCT.bulkget_index_value')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (36, 1, 'Test Columns', 'Index Total Return', 'PRODUCT.bulkget_index_total_return')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (37, 1, 'Test Columns', 'Index Market Cap', 'PRODUCT.bulkget_index_market_cap')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (38, 1, 'Test Columns', 'Index XD Adjustment', 'PRODUCT.bulkget_index_xd_adjustment')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (39, 1, 'Test Columns', 'Index Dividend Yield Open', 'PRODUCT.bulkget_index_dividend_yield_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (40, 1, 'Test Columns', 'Instrument Dividend Yield Open', 'PRODUCT.bulkget_instr_dividend_yield_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (41, 1, 'Test Columns', 'Index Dividend Yield Close', 'PRODUCT.bulkget_index_dividend_yield_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (42, 1, 'Test Columns', 'Instrument Dividend Yield Close', 'PRODUCT.bulkget_instr_dividend_yield_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (43, 1, 'Test Columns', 'ISIN', 'PRODUCT.bulkget_sec_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'ISIN', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (44, 1, 'Test Columns', 'Subsector Name', 'PRODUCT.bulkget_instr_subsector_nm')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (45, 1, 'Test Columns', 'RIC', 'PRODUCT.bulkget_instr_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'RIC', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (46, 1, 'Test Columns', 'BB Unique', 'PRODUCT.bulkget_instr_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'BB_UNIQUE', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (47, 1, 'Test Columns', 'Currency', 'PRODUCT.bulkget_instr_ccy_identifier')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (48, 1, 'Test Columns', 'Entity Id', 'PRODUCT.bulkget_entity_id')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (49, 1, 'Test Columns', 'Secondary', 'PRODUCT.bulkget_instr_secondary')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (50, 1, 'Test Columns', 'Free Float', 'PRODUCT.bulkget_freefloat')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (51, 1, 'Test Columns', 'One Month Price Performance', 'PRODUCT.bulkget_instr_one_month_price_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (52, 1, 'Test Columns', 'One Month TRI Performance', 'PRODUCT.bulkget_instr_one_month_tri_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (53, 1, 'Test Columns', 'YTD Price Performance', 'PRODUCT.bulkget_instr_ytd_price_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (54, 1, 'Test Columns', 'YTD TRI Performance', 'PRODUCT.bulkget_instr_ytd_tri_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (55, 1, 'Test Columns', 'Corporate Action Story', 'PRODUCT.bulkget_instr_ca_story')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (56, 1, 'Test Columns', 'Corporate Action Type', 'PRODUCT.bulkget_instr_ca_type')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (57, 1, 'Test Columns', 'Daily Price Performace', 'PRODUCT.bulkget_instr_daily_price_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (58, 1, 'Test Columns', 'Daily TRI Performace', 'PRODUCT.bulkget_instr_daily_tri_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (59, 1, 'Test Columns', 'Dividend Currency', 'PRODUCT.bulkget_instr_dividend_currency')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (60, 1, 'Test Columns', 'High Price', 'PRODUCT.bulkget_instr_high_price')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (61, 1, 'Test Columns', 'Low Price', 'PRODUCT.bulkget_instr_low_price')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (62, 1, 'Test Columns', 'Daily Performance', 'PRODUCT.bulkget_index_daily_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (63, 1, 'Test Columns', 'Index Daily TRI Performance', 'PRODUCT.bulkget_index_daily_tri_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (64, 1, 'Test Columns', 'Index Monthly Performance', 'PRODUCT.bulkget_index_monthly_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (65, 1, 'Test Columns', 'Index Monthly TRI Performance', 'PRODUCT.bulkget_index_monthly_tri_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (66, 1, 'Test Columns', 'Index YTD Performance', 'PRODUCT.bulkget_index_ytd_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (67, 1, 'Test Columns', 'Index YTD TRI Performance', 'PRODUCT.bulkget_index_ytd_tri_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (68, 1, 'Test Columns', 'Index Industry Weight', 'PRODUCT.bulkget_index_industry_weight')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (69, 1, 'Test Columns', 'Dividend XD Date', 'PRODUCT.bulkget_instr_dividend_xd_date')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (70, 1, 'Test Columns', 'Previous Day Price', 'PRODUCT.bulkget_instr_previous_day_price')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (71, 1, 'Test Columns', 'Index Sector Code', 'PRODUCT.bulkget_index_sector_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (72, 1, 'Test Columns', 'Index Sub Sector Code', 'PRODUCT.bulkget_index_subsector_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (73, 1, 'Test Columns', 'Index Industry Code', 'PRODUCT.bulkget_index_industry_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (74, 1, 'Test Columns', 'Dividend Type', 'PRODUCT.bulkget_instr_dividend_type')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (75, 1, 'Test Columns', 'Dividend Announce Date', 'PRODUCT.bulkget_instr_dividend_announce_date')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (76, 1, 'Test Columns', 'Dividend Payment Date', 'PRODUCT.bulkget_instr_dividend_payment_date')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (77, 1, 'Test Columns', 'Adjusted Factor', 'PRODUCT.bulkget_instr_adjusted_factor')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (78, 1, 'Test Columns', 'Annual Dividend', 'PRODUCT.bulkget_instr_annual_dividend')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (79, 1, 'Test Columns', 'Dividend Amount', 'PRODUCT.bulkget_instr_dividend_amount')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (80, 1, 'Test Columns', 'Dividend Books Close Date', 'PRODUCT.bulkget_instr_dividend_books_close_date')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (81, 1, 'Test Columns', 'Volume', 'PRODUCT.bulkget_instr_volume')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (82, 1, 'Test Columns', 'Short Name', 'PRODUCT.bulkget_instr_short_name')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (83, 1, 'Test Columns', '90 Day Alpha', 'PRODUCT.bulkget_instr_ninety_day_alpha')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (84, 1, 'Test Columns', '90 Day Beta', 'PRODUCT.bulkget_instr_ninety_day_beta')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (85, 1, 'Test Columns', '90 Day Specific Risk', 'PRODUCT.bulkget_instr_ninety_day_specific_risk')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (86, 1, 'Test Columns', '90 Day Total Risk', 'PRODUCT.bulkget_instr_ninety_day_total_risk')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (87, 1, 'Test Columns', 'Literal Value', 'PRODUCT.bulkget_literal_value')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Value', '@value', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (88, 1, 'Test Columns', 'Domicile Code', 'PRODUCT.bulkget_entity_attribute')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', 'CDOM', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (89, 1, 'Test Columns', 'Local Market Code', 'PRODUCT.bulkget_instr_local_market_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (90, 1, 'Test Columns', 'ISO2 Country Code', 'PRODUCT.bulkget_instr_iso2_country')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (91, 1, 'Test Columns', 'ISO2 Domicile Code', 'PRODUCT.bulkget_instr_ISO2_domicile_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (92, 1, 'Test Columns', 'MIC Code', 'PRODUCT.bulkget_instr_mic_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (93, 1, 'Instrument Attribute', 'Security Name', 'PRODUCT.bulkget_instr_attribute')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', 'SLNG', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (95, 1, 'Instrument Attribute', 'ISIN-Instrument', 'PRODUCT.bulkget_instr_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'ISIN', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (96, 1, 'Instrument Attribute', 'CUSIP-Instrument', 'PRODUCT.bulkget_instr_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Identifier Type', '@p_type', 'CUSIP', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (97, 1, 'Instrument Attribute', 'ISO2 Domicile Code-CINC', 'PRODUCT.bulkget_instr_ISO2_domicile_code')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', 'CINC', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (98, 1, 'Test Columns', 'New Number of Constituents', 'PRODUCT.bulkget_index_new_number_of_constituents')
SET @FileColumnId = @@Identity
INSERT INTO EXPORT.[PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (99, 1, 'Test Columns', 'Old Number of Constituents', 'PRODUCT.bulkget_index_old_number_of_constituents')
SET @FileColumnId = @@Identity
INSERT INTO EXPORT.[PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (100, 1, 'Test Columns', 'FTSE Dividend Notes', 'PRODUCT.bulkget_instr_ftse_dividend_notes')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (101, 1, 'Test Columns', 'FTSE Dividend Code', 'PRODUCT.bulkget_instr_ftse_dividend_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (102, 1, 'Test Columns', 'ISO Currency Code', 'PRODUCT.bulkget_instr_iso_currency_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (103, 1, 'Test Columns', 'Previous Divisor', 'PRODUCT.bulkget_index_previous_divisor')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (104, 1, 'Test Columns', 'New Divisor', 'PRODUCT.bulkget_index_new_divisor')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (105, 1, 'Test Columns', 'XD Adjustment Value', 'PRODUCT.bulkget_index_xd_adjustment_value')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (106, 1, 'Test Columns', 'New Market Capitalisation', 'PRODUCT.bulkget_index_new_market_capitalisation')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (107, 1, 'Test Columns', 'EX Dividend Date', 'PRODUCT.bulkget_instr_ex_dividend_date')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (108, 1, 'Test Columns', 'Previous Market Capitalisation', 'PRODUCT.bulkget_index_previous_market_capitalisation')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (109, 1, 'Test Columns', 'XD Adjustment Value', 'PRODUCT.bulkget_instr_xd_adjustment_value')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (110, 1, 'Test Columns', 'Last Modified Date', 'PRODUCT.bulkget_instr_last_modified_date')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (111, 1, 'Test Columns', 'New Investibility Weight', 'PRODUCT.bulkget_instr_new_investibility_weight')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (112, 1, 'Test Columns', 'Previous Investibility Weight', 'PRODUCT.bulkget_instr_previous_investibility_weight')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (113, 1, 'Test Columns', 'Amendment Code', 'PRODUCT.bulkget_instr_amendment_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (114, 1, 'Test Columns', 'Amendment Notes', 'PRODUCT.bulkget_instr_amendment_notes')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (115, 1, 'Test Columns', 'Previous Shares In Issue', 'PRODUCT.bulkget_instr_previous_shares_in_issue')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (116, 1, 'Test Columns', 'New Shares In Issue', 'PRODUCT.bulkget_instr_new_shares_in_issue')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (117, 1, 'Test Columns', 'Adjusted Price', 'PRODUCT.bulkget_instr_adjusted_price')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (118, 1, 'Test Columns', 'Price Adjustment Factor', 'PRODUCT.bulkget_instr_price_adjustment_factor')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (119, 1, 'Test Columns', 'New Subsector Code', 'PRODUCT.bulkget_instr_new_subsector_code')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (120, 1, 'Test Columns', 'Closing Subsector Code', 'PRODUCT.bulkget_instr_closing_subsector_code')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (121, 1, 'Test Columns', 'Effective Date', 'PRODUCT.bulkget_instr_effective_date')
SET @FileColumnId = @@Identity

--Industry Weight Close
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (122, 1, 'Test Columns', 'Industry Weight Close', 'PRODUCT.bulkget_instr_industry_weight_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Industry Weight Open
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (123, 1, 'Test Columns', 'Industry Weight Open', 'PRODUCT.bulkget_instr_industry_weight_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Sector Weight Close
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (124, 1, 'Test Columns', 'Sector Weight Close', 'PRODUCT.bulkget_instr_sector_weight_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

--Sector Weight Open
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (125, 1, 'Test Columns', 'Sector Weight Open', 'PRODUCT.bulkget_instr_sector_weight_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (126, 1, 'Test Columns', 'Growth Weight Factor Close', 'PRODUCT.bulkget_instr_growth_weight_factor_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (127, 1, 'Test Columns', 'Market Cap Growth Close', 'PRODUCT.bulkget_instr_market_cap_growth_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (128, 1, 'Test Columns', 'Value Weight Factor Close', 'PRODUCT.bulkget_instr_value_weight_factor_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (129, 1, 'Test Columns', 'Market Cap Value Close', 'PRODUCT.bulkget_instr_market_cap_value_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (130, 1, 'Test Columns', 'World Growth Percent Weight', 'PRODUCT.bulkget_instr_world_growth_percent_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (131, 1, 'Test Columns', 'World Value Percent Weight', 'PRODUCT.bulkget_instr_world_value_percent_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (132, 1, 'Test Columns', 'Country Growth Percent Weight', 'PRODUCT.bulkget_instr_country_growth_percent_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (133, 1, 'Test Columns', 'Country Value Percent Weight', 'PRODUCT.bulkget_instr_country_value_percent_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (133, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (134, 1, 'Test Columns', 'Industry Growth Percent Weight', 'PRODUCT.bulkget_instr_industry_growth_percent_weight')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (135, 1, 'Test Columns', 'Industry Value Percent Weight', 'PRODUCT.bulkget_instr_industry_value_percent_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (136, 1, 'Test Columns', 'Sector Growth Percent Weight', 'PRODUCT.bulkget_instr_sector_growth_percent_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (137, 1, 'Test Columns', 'Sector Value Percent Weight', 'PRODUCT.bulkget_instr_sector_value_percent_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (138, 1, 'Test Columns', 'factor', 'PRODUCT.bulkget_instr_factor')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (141, 1, 'Test Columns', 'Growth Weight Factor Open', 'PRODUCT.bulkget_instr_growth_weight_factor_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (142, 1, 'Test Columns', 'Market Cap Growth Open', 'PRODUCT.bulkget_instr_market_cap_growth_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (143, 1, 'Test Columns', 'Value Weight Factor Open', 'PRODUCT.bulkget_instr_value_weight_factor_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (144, 1, 'Test Columns', 'Market Cap Value Open', 'PRODUCT.bulkget_instr_market_cap_value_open')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (145, 1, 'Test Columns', 'GWA Factor', 'PRODUCT.bulkget_instr_gwa_factor')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (146, 1, 'Test Columns', 'Market Cap After GWA Factor', 'PRODUCT.bulkget_instr_market_cap_after_gwa_factor')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (149, 1, 'Test Columns', 'Growth Weight Factor Tracker Section 2', 'PRODUCT.bulkget_instr_growth_weight_factor_tracker_section_2_tracker_section2')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (150, 1, 'Test Columns', 'Value Weight Factor Tracker Section 2', 'PRODUCT.bulkget_instr_value_weight_factor_tracker_section_2_tracker_section2')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (151, 1, 'Test Columns', 'Change In Market Cap', 'PRODUCT.bulkget_index_change_in_market_cap')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (152, 1, 'Test Columns', 'Dividend Yield Tracker Section 2', 'PRODUCT.bulkget_instr_dividend_yield_tracker_section_2_tracker_section2')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (153, 1, 'Test Columns', 'Current Factor', 'PRODUCT.bulkget_instr_current_factor')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (154, 1, 'Test Columns', 'New edhec Adjustment Factor', 'PRODUCT.bulkget_instr_new_edhec_adjustment_factor')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (155, 1, 'Test Columns', 'Secondary Line', 'PRODUCT.bulkget_instr_secondary_line')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (156, 1, 'Test Columns', 'Gross Market Cap', 'PRODUCT.bulkget_instr_gross_market_cap')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (157, 1, 'Test Columns', 'Net Market Cap', 'PRODUCT.bulkget_instr_net_market_cap')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (158, 1, 'Test Columns', 'XD Adjustment (YTD)', 'PRODUCT.bulkget_index_xd_adjustment_ytd')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (159, 1, 'Test Columns', 'SE Code/TIDM', 'PRODUCT.bulkget_instr_secode_tidm')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (160, 1, 'Test Columns', 'Previous Adjustment Factor', 'PRODUCT.bulkget_index_previous_adjustment_factor')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (161, 1, 'Test Columns', 'Investability Weight', 'PRODUCT.bulkget_instr_investability_weight')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (162, 1, 'Test Columns', 'Dividend Cover', 'PRODUCT.bulkget_index_dividend_cover')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (163, 1, 'Test Columns', 'Price/Earnings Ratio', 'PRODUCT.bulkget_index_price_earnings_ratio')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (164, 1, 'Test Columns', 'Value Date', 'PRODUCT.bulkget_index_value_date')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (165, 1, 'Test Columns', 'Secondary Line', 'PRODUCT.bulkget_index_secondary_line_tracker_section_3')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (166, 1, 'Test Columns', 'Index Month End Performance', 'PRODUCT.bulkget_index_month_end_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (167, 1, 'Test Columns', 'Price Return Quarter End', 'PRODUCT.PRODUCT.bulkget_instr_price_return_quarter_end')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (168, 1, 'Test Columns', 'Fundamental Cap', 'PRODUCT.bulkget_instr_fundamental_cap')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Scale Divisor', '@scale_divisor', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (169, 1, 'Test Columns', 'Fundamental Weight', 'PRODUCT.bulkget_instr_fundamental_weight')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (170, 1, 'Test Columns', 'Weight Of Index In A Comparative Index', 'PRODUCT.bulkget_index_weight_in_comparative_index')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Index Mnemonic', '@mnemonic', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (173, 1, 'Test Columns', 'Index Quarterly Performance', 'PRODUCT.bulkget_index_quarterly_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (174, 1, 'Test Columns', 'Index Quarterly TRI Performance', 'PRODUCT.bulkget_index_quarterly_tri_performance')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (175, 1, 'Test Columns', 'Index FTAD Code', 'PRODUCT.bulkget_index_attribute')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', 'FTAD', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (176, 1, 'Test Columns', 'Daily Change', 'PRODUCT.bulkget_instr_daily_change')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency Code', '@currency', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (177, 1, 'Test Columns', 'Value Date', 'PRODUCT.bulkget_instr_value_date')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (178, 1, 'Test Columns', 'Secondary Line - Tracker', 'PRODUCT.bulkget_instr_secondary_line_tracker_section2')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (179, 1, 'Test Columns', '90 Day Multi Index Alpha', 'PRODUCT.bulkget_instr_ninety_day_multi_alpha')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'List Code', '@list_code', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (180, 1, 'Test Columns', '90 Day Multi Index Beta', 'PRODUCT.bulkget_instr_ninety_day_multi_beta')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'List Code', '@list_code', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (181, 1, 'Test Columns', '90 Day Multi Index Specific Risk', 'PRODUCT.bulkget_instr_ninety_day_multi_specific_risk')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'List Code', '@list_code', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (182, 1, 'Test Columns', '90 Day Multi Index Total Risk', 'PRODUCT.bulkget_instr_ninety_day_multi_total_risk')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'List Code', '@list_code', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (183, 1, 'Test Columns', 'Previous Divisor Constant', 'PRODUCT.bulkget_index_previous_divisor_constant')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (184, 1, 'Test Columns', 'New Divisor Constant', 'PRODUCT.bulkget_index_new_divisor_constant')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (185, 1, 'Test Columns', 'SuperSector Weight', 'PRODUCT.bulkget_instr_supersector_weight_close')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (186, 1, 'Test Columns', 'Weight In Index', 'PRODUCT.bulkget_instr_weight_in_index')
SET @FileColumnId = @@Identity

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (187, 1, 'Test Columns', 'Quarter Percent Change', 'PRODUCT.bulkget_instr_per_chg_qtr')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Currency', '@currency', NULL, 1)

--Index Marker
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (188, 1, 'Test Columns', 'Alt Index Marker', 'PRODUCT.bulkget_instr_alt_index_marker')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'List Code', '@list_code', NULL, 1)

--data date
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (189, 1, 'Test Columns', 'Data Date', 'PRODUCT.bulkget_instr_data_date')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Date Format', '@date_format', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (190, 1, 'Test Columns', 'Value Rank', 'PRODUCT.bulkget_instr_value_rank')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (191, 1, 'Test Columns', 'Growth Rank', 'PRODUCT.bulkget_instr_growth_rank')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (192, 1, 'Test Columns', 'Overall Rank', 'PRODUCT.bulkget_instr_overall_rank')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (193, 1, 'Test Columns', 'Year 3 Sales Growth', 'PRODUCT.bulkget_instr_year_3_sales_growth')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (194, 1, 'Test Columns', 'Year 3 EPS Growth', 'PRODUCT.bulkget_instr_year_3_eps_growth')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (195, 1, 'Test Columns', 'Year 2 Forward Sales', 'PRODUCT.bulkget_instr_year_2_forward_sales')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (196, 1, 'Test Columns', 'Year 2 Forward EPS', 'PRODUCT.bulkget_instr_year_2_forward_eps')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (197, 1, 'Test Columns', 'Return On Equity', 'PRODUCT.bulkget_instr_return_on_equity')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (198, 1, 'Test Columns', 'Price To Book', 'PRODUCT.bulkget_instr_price_to_book')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (199, 1, 'Test Columns', 'Price To Sales', 'PRODUCT.bulkget_instr_price_to_sales')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (200, 1, 'Test Columns', 'Price To Cash Flow', 'PRODUCT.bulkget_instr_price_to_cash_flow')
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Family Name', '@family_name', '[family_name]', 0)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (201, 1, 'Test Columns', 'Old Sector', 'PRODUCT.bulkget_index_old_sector')
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (202, 1, 'Test Columns', 'Old SubSector', 'PRODUCT.bulkget_index_old_subsector')
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (203, 1, 'Test Columns', 'Index GSIN', 'PRODUCT.bulkget_index_gsin')

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (204, 1, 'Test Columns', 'FTSE 4 Good Rating', 'PRODUCT.bulkget_instr_ftse_4_good_rating')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Value', '@value', NULL, 1)

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (205, 1, 'Test Columns', 'Local Code', 'PRODUCT.bulkget_instr_local_code')

INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (206, 1, 'Test Columns', 'OAWI Code', 'PRODUCT.bulkget_index_identifier')
SET @FileColumnId = @@Identity
INSERT INTO [PRODUCT].[FileColumnParameter] ([FileColumnId], [Description], [ParameterName], [DefaultValue], [UserInput]) VALUES (@FileColumnId, 'Attribute Name', '@attribute_code', 'OAWI', 0)
INSERT INTO [PRODUCT].[FileColumn] (FileColumnId, SectionContentTypeId, CategoryName, Name, ProcedureName) VALUES (207, 1, 'Test Columns', 'Undefined Column - Number', 'PRODUCT.bulkget_dummyvalue');

SET IDENTITY_INSERT [PRODUCT].[FileColumn] ON
GO

DECLARE @FileColumnId INT




SET IDENTITY_INSERT [PRODUCT].[FileColumn] OFF
GO
