SET IDENTITY_INSERT [PRODUCT].[DataSource] ON
GO

INSERT INTO [PRODUCT].[DataSource] (DataSourceId, Name, ConnectionString) VALUES (1, 'Prime on Development', 'Data Source=UKUBS-SQL05\SQL01BB;Initial Catalog=Prime;Integrated Security=True')
GO

INSERT INTO [PRODUCT].[DataSource] (DataSourceId, Name, ConnectionString) VALUES (2, 'RA on Development', 'Data Source=UKUBS-SQL05\SQL01BB;Initial Catalog=RA;Integrated Security=True')
GO

INSERT INTO [PRODUCT].[DataSource] (DataSourceId, Name, ConnectionString) VALUES (3, 'World Index on Development', 'Data Source=UKUBS-SQL05\SQL01BB;Initial Catalog=WORLD_INDEX;Integrated Security=True')
GO

INSERT INTO [PRODUCT].[DataSource] (DataSourceId, Name, ConnectionString) VALUES (4, 'Prime on Production', 'Data Source=UKUBS-SQL01RA\SQL01RA;Initial Catalog=Prime;Integrated Security=True')
GO

INSERT INTO [PRODUCT].[DataSource] (DataSourceId, Name, ConnectionString) VALUES (5, 'RA on Production', 'Data Source=UKUBS-SQL01RA\SQL01RA;Initial Catalog=RA;Integrated Security=True')
GO

INSERT INTO [PRODUCT].[DataSource] (DataSourceId, Name, ConnectionString) VALUES (6, 'Prime on Production', 'Data Source=UKUBS-SQL01RA\SQL01RA;Initial Catalog=WORLD_INDEX;Integrated Security=True')
GO

SET IDENTITY_INSERT [PRODUCT].[DataSource] OFF
GO