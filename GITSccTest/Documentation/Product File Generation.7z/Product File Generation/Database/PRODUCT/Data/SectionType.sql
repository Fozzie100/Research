SET IDENTITY_INSERT [PRODUCT].[SectionType] ON
GO

INSERT INTO [PRODUCT].[SectionType] (Id, Name) VALUES (1, 'Generated')
GO

INSERT INTO [PRODUCT].[SectionType] (Id, Name) VALUES (2, 'Stored Procedure')
GO

SET IDENTITY_INSERT [PRODUCT].[SectionType] OFF
GO