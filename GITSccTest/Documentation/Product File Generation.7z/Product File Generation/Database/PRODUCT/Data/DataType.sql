USE EXPORT
GO

SET IDENTITY_INSERT PRODUCT.DataType ON
GO

INSERT INTO PRODUCT.DataType (DataTypeId, Description) VALUES (1, 'String')
GO

INSERT INTO PRODUCT.DataType (DataTypeId, Description) VALUES (2, 'Number')
GO

INSERT INTO PRODUCT.DataType (DataTypeId, Description) VALUES (3, 'Date')
GO

SET IDENTITY_INSERT PRODUCT.DataType OFF
GO