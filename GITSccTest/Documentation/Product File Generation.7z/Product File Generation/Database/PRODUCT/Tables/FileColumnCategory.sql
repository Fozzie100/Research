IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[FileColumnCategory]') AND type in (N'U'))
	BEGIN
		DROP TABLE [PRODUCT].[FileColumnCategory]
		PRINT '<<< DROPPED TABLE [PRODUCT].[FileColumnCategory] >>>'
	END
GO

CREATE TABLE [PRODUCT].[FileColumnCategory]
(
	Id		[INT] IDENTITY(1,1) NOT NULL,
	Name	[VARCHAR](50) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[FileColumnCategory]
	ADD CONSTRAINT [pk_FileColumnCategory] PRIMARY KEY CLUSTERED 
	(
		Id
	)
GO

IF OBJECT_ID('[PRODUCT].[FileColumnCategory]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[FileColumnCategory] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[FileColumnCategory] >>>'
GO