IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[SectionColumnParameter]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[SectionColumnParameter]
	PRINT '<<< DROPPED TABLE [PRODUCT].[SectionColumnParameter] >>>'
END
GO

CREATE TABLE [PRODUCT].[SectionColumnParameter]
(
	[SectionColumnParameterId]	[INT] IDENTITY(1,1) NOT NULL,
	[SectionColumnId]			[INT] NOT NULL,
	[FileColumnParameterId]		[INT] NOT NULL,
	[Value]						[VARCHAR] (50) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[SectionColumnParameter]
	ADD CONSTRAINT [pk_SectionColumnParameter] PRIMARY KEY CLUSTERED 
	(
		SectionColumnParameterId
	)
GO

ALTER TABLE [PRODUCT].[SectionColumnParameter]
    ADD CONSTRAINT fk_SectionColumnParameter_SectionColumn
    FOREIGN KEY
    (
		SectionColumnId
	)
    REFERENCES [PRODUCT].[SectionColumn]
    (
		SectionColumnId
    ) ON DELETE CASCADE
GO


ALTER TABLE [PRODUCT].[SectionColumnParameter]
    ADD CONSTRAINT fk_SectionColumnParameter_FileColumnParameter
    FOREIGN KEY
    (
		FileColumnParameterId
	)
    REFERENCES [PRODUCT].[FileColumnParameter]
    (
		FileColumnParameterId
    )
GO
IF OBJECT_ID('[PRODUCT].[SectionColumnParameter]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[SectionColumnParameter] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[SectionColumnParameter] >>>'
GO