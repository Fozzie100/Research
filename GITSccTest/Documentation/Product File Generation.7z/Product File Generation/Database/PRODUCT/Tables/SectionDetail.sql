IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[SectionDetail]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[SectionDetail]
	PRINT '<<< DROPPED TABLE [PRODUCT].[SectionDetail] >>>'
END
GO

CREATE TABLE [PRODUCT].[SectionDetail]
(
	SectionDetailId		[INT] IDENTITY(1,1) NOT NULL,
	SectionId			[INT] NOT NULL,
	EffectiveDate		[DATE] NOT NULL,
	ExpiryDate			[DATE] NOT NULL CONSTRAINT DF_SectionDetail_ExpiryDate DEFAULT ('99991231'),
	OutputColumnNames	[BIT] NOT NULL CONSTRAINT DF_SectionDetail_OutputColumnNames DEFAULT (1),
	ProcedureName		[VARCHAR] (200) NOT NULL,
	HeaderText			VARCHAR(MAX),
	FooterText			VARCHAR(MAX)
)
GO

ALTER TABLE [PRODUCT].[SectionDetail]
	ADD CONSTRAINT [pk_SectionDetail] PRIMARY KEY CLUSTERED 
	(
		SectionDetailId
	)
GO

ALTER TABLE [PRODUCT].[SectionDetail]
    ADD CONSTRAINT fk_SectionDetail_Section
    FOREIGN KEY
    (
		SectionId
	)
    REFERENCES [PRODUCT].[Section]
    (
		SectionId
    ) ON DELETE CASCADE
GO

ALTER TABLE [PRODUCT].[SectionDetail]
	ADD CONSTRAINT [chk_SectionDetail_DatesInOrder] CHECK
	(
		EffectiveDate < ExpiryDate
	)
GO

IF OBJECT_ID('[PRODUCT].[SectionDetail]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[SectionDetail] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[SectionDetail] >>>'
GO