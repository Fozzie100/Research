IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ValueFormatterParameter]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ValueFormatterParameter]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ValueFormatterParameter] >>>'
END
GO

CREATE TABLE [PRODUCT].[ValueFormatterParameter]
(
	ValueFormatterParameterId	[INT] IDENTITY(1,1) NOT NULL,
	ValueFormatterId			[INT] NOT NULL,
	Name						[VARCHAR](200) NOT NULL,
	Description					[VARCHAR](50) NOT NULL,
	DataType					[VARCHAR](50) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[ValueFormatterParameter]
	ADD CONSTRAINT [pk_ValueFormatterParameter] PRIMARY KEY CLUSTERED 
	(
		ValueFormatterParameterId
	)
GO

ALTER TABLE [PRODUCT].[ValueFormatterParameter]
    ADD CONSTRAINT fk_ValueFormatterParameter_ValueFormatter
    FOREIGN KEY
    (
		ValueFormatterId
	)
    REFERENCES [PRODUCT].[ValueFormatter]
    (
		ValueFormatterId
    ) ON DELETE CASCADE
GO

CREATE UNIQUE INDEX IDX_ValueFormatterParameter_ValueFormatterAndName
ON PRODUCT.ValueFormatterParameter (ValueFormatterId, Name)
GO

IF OBJECT_ID('[PRODUCT].[ValueFormatterParameter]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ValueFormatterParameter] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ValueFormatterParameter] >>>'
GO