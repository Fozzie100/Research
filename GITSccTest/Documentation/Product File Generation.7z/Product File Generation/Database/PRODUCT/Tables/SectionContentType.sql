USE [EXPORT]
GO

/****** Object:  Table [PRODUCT].[DataType]    Script Date: 08/18/2014 12:47:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS(SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[SectionContentType]') AND type in (N'U'))		
BEGIN		
	PRINT 'Attempting to DROP TABLE [PRODUCT].[SectionContentType]';	
	DROP TABLE [PRODUCT].[SectionContentType];	
	IF OBJECT_ID('[PRODUCT].[SectionContentType]') IS NOT NULL	
	BEGIN	
		PRINT 'FAILED DROPPING TABLE [PRODUCT].[SectionContentType]';
		RAISERROR('FAILED DROPPING TABLE [PRODUCT].[SectionContentType]', 16, 1);
	END	
	ELSE	
	BEGIN	
		PRINT 'SUCCESS - DROPPED TABLE [PRODUCT].[SectionContentType]';
	END	
END		
ELSE		
BEGIN		
	PRINT 'Skipping DROP TABLE task - TABLE [PRODUCT].[SectionContentType] does not exist';	
END		
GO		
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[SectionContentType]') AND type in (N'U'))		
BEGIN		
	PRINT 'FAILED - Cannot create TABLE [PRODUCT].[SectionContentType] - TABLE already exists';	
	RAISERROR('FAILED - Cannot create TABLE [PRODUCT].[SectionContentType] - TABLE already exists', 16, 1);	
END		
ELSE		
BEGIN		
	PRINT 'Attempting to CREATE TABLE [PRODUCT].SectionContentType';	
END		
GO		
			
CREATE TABLE [PRODUCT].[SectionContentType](
	[SectionContentTypeId] [int] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](100) NOT NULL,
	[UserSelectable] [bit] NOT NULL CONSTRAINT [DF_SectionContentType_UserSelectable]  DEFAULT ((1)),
 CONSTRAINT [pk_SectionContentType] PRIMARY KEY CLUSTERED 
(
	[SectionContentTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[SectionContentType]') AND type in (N'U'))	
BEGIN	
	PRINT 'SUCCESS - CREATED TABLE [PRODUCT].[SectionContentType]';
END	
ELSE	
BEGIN	
	PRINT 'FAILED CREATING TABLE [PRODUCT].[SectionContentType]';
	RAISERROR('FAILED CREATING TABLE [PRODUCT].[SectionContentType]', 16, 1);
END	
GO	
