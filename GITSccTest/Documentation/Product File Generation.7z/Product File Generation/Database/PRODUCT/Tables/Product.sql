USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[Product]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[Product]
	PRINT '<<< DROPPED TABLE [PRODUCT].[Product] >>>'
END
GO

CREATE TABLE [PRODUCT].[Product]
(
	ProductId			[INT] IDENTITY(1,1) NOT NULL,
	ProductGroupId		[INT] NOT NULL,
	DataSourceId		[INT] NOT NULL,
	Name				[VARCHAR](100) NOT NULL,
	Code				[VARCHAR](50) NOT NULL,
	FileSuffix			[VARCHAR](50) NOT NULL,
	Delimiter			[CHAR] (1) NOT NULL,
	IsTemplate			[BIT] NOT NULL CONSTRAINT DF_Product_IsTemplate DEFAULT (0),
	TemplateProductId	INT
)
GO

ALTER TABLE [PRODUCT].[Product]
	ADD CONSTRAINT [pk_Product] PRIMARY KEY CLUSTERED 
	(
		ProductId
	)
GO

ALTER TABLE [PRODUCT].[Product]
    ADD CONSTRAINT fk_Product_DataSource
    FOREIGN KEY
    (
		DataSourceId
	)
    REFERENCES [PRODUCT].[DataSource]
    (
		DataSourceId
    )
GO

ALTER TABLE [PRODUCT].[Product]
    ADD CONSTRAINT fk_Product_ProductGroup
    FOREIGN KEY
    (
		ProductGroupId
	)
    REFERENCES [PRODUCT].[ProductGroup]
    (
		ProductGroupId
    )
GO

ALTER TABLE [PRODUCT].[Product]
    ADD CONSTRAINT fk_Product_TemplateProduct
    FOREIGN KEY
    (
		TemplateProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    )
GO

CREATE UNIQUE INDEX IDX_Product_Code
ON PRODUCT.Product (Code)
GO

IF OBJECT_ID('[PRODUCT].[Product]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[Product] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[Product] >>>'
GO