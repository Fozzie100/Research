USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[FileDistributor]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[FileDistributor]
	PRINT '<<< DROPPED TABLE [PRODUCT].[FileDistributor] >>>'
END
GO

CREATE TABLE [PRODUCT].[FileDistributor]
(
	[Id]					[INT] IDENTITY(1,1) NOT NULL,
	[DestinationDirectory]	[VARCHAR](MAX) NOT NULL,
	[OverwriteFiles]		[BIT] NOT NULL CONSTRAINT DF_FileDistributor_OverwriteFiles DEFAULT (1)
)
GO

ALTER TABLE [PRODUCT].[FileDistributor]
	ADD CONSTRAINT [pk_FileDistributor] PRIMARY KEY CLUSTERED 
	(
		Id
	)
GO

IF OBJECT_ID('[PRODUCT].[FileDistributor]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[FileDistributor] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[FileDistributor] >>>'
GO