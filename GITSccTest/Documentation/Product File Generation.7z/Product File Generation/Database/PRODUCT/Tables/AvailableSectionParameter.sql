IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[AvailableSectionParameter]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[AvailableSectionParameter]
	PRINT '<<< DROPPED TABLE [PRODUCT].[AvailableSectionParameter] >>>'
END
GO

CREATE TABLE [PRODUCT].[AvailableSectionParameter]
(
	[AvailableSectionParameterId]	[INT] IDENTITY(1,1) NOT NULL,
	[AvailableSectionId]			[INT] NOT NULL,
	[Name]							[VARCHAR](50) NOT NULL,
	[Description]					[VARCHAR](200) NOT NULL,
	[DataType]					[VARCHAR](200) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[AvailableSectionParameter]
	ADD CONSTRAINT [pk_AvailableSectionParameter] PRIMARY KEY CLUSTERED 
	(
		AvailableSectionParameterId
	)
GO

ALTER TABLE [PRODUCT].[AvailableSectionParameter]
    ADD CONSTRAINT fk_AvailableSectionParameter_AvailableSection
    FOREIGN KEY
    (
		AvailableSectionId
	)
    REFERENCES [PRODUCT].[AvailableSection]
    (
		AvailableSectionId
    )
GO

CREATE UNIQUE INDEX IDX_AvailableSectionParameter_AvailableSectionAndName
ON PRODUCT.AvailableSectionParameter (AvailableSectionId, Name)
GO

IF OBJECT_ID('[PRODUCT].[AvailableSectionParameter]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[AvailableSectionParameter] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[AvailableSectionParameter] >>>'
GO