USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[file_column_mapping]') AND type in (N'U'))
BEGIN
	DROP TABLE [WORLD_INDEX].[file_column_mapping]
	PRINT '<<< DROPPED TABLE [WORLD_INDEX].[file_column_mapping] >>>'
END
GO

CREATE TABLE [WORLD_INDEX].[file_column_mapping]
(
	[column_name]	            [VARCHAR] (200) NOT NULL,
	[product_type_id]           [INT],
	[product_column_type_id]    [INT],
	[file_column_id]	        [INT] NOT NULL
)
GO

CREATE UNIQUE INDEX IDX_file_column_mapping_ColumnName ON WORLD_INDEX.file_column_mapping
(
    product_type_id,
    product_column_type_id
)
GO

IF OBJECT_ID('[WORLD_INDEX].[file_column_mapping]') IS NOT NULL
	PRINT '<<< CREATED TABLE [WORLD_INDEX].[file_column_mapping] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [WORLD_INDEX].[file_column_mapping] >>>'
GO