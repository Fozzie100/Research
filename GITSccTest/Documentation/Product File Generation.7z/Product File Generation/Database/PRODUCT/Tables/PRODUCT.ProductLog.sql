USE [EXPORT]
GO

/****** Object:  Table [PRODUCT].[ProductLog]    Script Date: 26/05/2015 12:27:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductLog]') AND type in (N'U'))
BEGIN
	PRINT 'DROP TABLE [PRODUCT].[ProductLog]'
	DROP TABLE [PRODUCT].[ProductLog]
END

/****** Object:  Table [PRODUCT].[ProductLog]    Script Date: 26/05/2015 12:27:59 ******/
GO

CREATE TABLE [PRODUCT].[ProductLog](
	[RowID] [int] IDENTITY(1,1) NOT NULL,
	[ProductId] [INT] NOT NULL,
	[DataDate] [DATE] NOT NULL,
	[ProductGenerationFilePath] [VARCHAR](500) NULL,
	[IniGenerationFilePath] [VARCHAR](500) NULL,
	[ProductArchiveFilePath] [VARCHAR](500) NULL,
	[IniArchiveFilePath] [VARCHAR](500) NULL,
	[ProductFileStartTime] DATETIME NOT NULL,
	[ProductFileEndTime] DATETIME NOT NULL,
	[ProductFileSizeBytes] BIGINT NOT NULL,
	[ProductFileRowCount] INT NOT NULL,
	[ProductFileColCount] INT NOT NULL,
	[ProductFileDurationTimeSeconds]  AS (DATEDIFF(SECOND,[ProductFileStartTime],[ProductFileEndTime])) PERSISTED,
	[InsertUserName] [varchar](64) NOT NULL,
	[InsertDatetime] [datetime] NOT NULL,
CONSTRAINT [PRODUCT_ProductLog_pk] PRIMARY KEY CLUSTERED 
(
	[RowID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX [ix_ic_audit] ON [PRODUCT].[ProductLog]
(
	[DataDate] ASC,
	[ProductId] ASC
	
)INCLUDE (ProductFileStartTime, ProductFileEndTime, ProductFileSizeBytes, ProductFileRowCount, ProductFileDurationTimeSeconds) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [PRODUCT].[ProductLog] ADD  CONSTRAINT [DF_Product_ProductLog_InsertUserName]  DEFAULT (suser_sname()) FOR [InsertUserName]
GO

ALTER TABLE [PRODUCT].[ProductLog] ADD  CONSTRAINT [DF_Product_ProductLog_InsertDatetime]  DEFAULT (getdate()) FOR [InsertDatetime]
GO

