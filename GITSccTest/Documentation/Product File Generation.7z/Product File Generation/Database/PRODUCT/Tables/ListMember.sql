IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ListMember]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ListMember]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ListMember] >>>'
END
GO

CREATE TABLE [PRODUCT].[ListMember]
(
	list_code       [VARCHAR](100) NOT NULL,
	value			[VARCHAR](100) NOT NULL,
	sort_code       [VARCHAR](6),
	effective_date	[DATE] NOT NULL,
	expiration_date [DATE] NOT NULL CONSTRAINT DF_ListMember_expiration_date DEFAULT ('99991231')
)
GO

ALTER TABLE [PRODUCT].[ListMember]
	ADD CONSTRAINT [pk_ListMember] PRIMARY KEY CLUSTERED 
	(
		list_code,
		value
	)
GO

ALTER TABLE [PRODUCT].[ListMember]
    ADD CONSTRAINT fk_ListMember_List
    FOREIGN KEY
    (
		list_code
	)
    REFERENCES [PRODUCT].[List]
    (
		list_code
    ) ON DELETE CASCADE
GO


IF OBJECT_ID('[PRODUCT].[ListMember]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ListMember] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ListMember] >>>'
GO