USE [EXPORT]
GO

/****** Object:  Table [PRODUCT].[DataType]    Script Date: 08/18/2014 12:47:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS(SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DataType]') AND type in (N'U'))			
BEGIN			
	PRINT 'Attempting to DROP TABLE [PRODUCT].[DataType]';		
	DROP TABLE [PRODUCT].[DataType];		
	IF OBJECT_ID('[PRODUCT].[DataType]') IS NOT NULL		
	BEGIN		
		PRINT 'FAILED DROPPING TABLE [PRODUCT].[DataType]';	
		RAISERROR('FAILED DROPPING TABLE [PRODUCT].[DataType]', 16, 1);	
	END		
	ELSE		
	BEGIN		
		PRINT 'SUCCESS - DROPPED TABLE [PRODUCT].[DataType]';	
	END		
END			
ELSE			
BEGIN			
	PRINT 'Skipping DROP TABLE task - TABLE [PRODUCT].[DataType] does not exist';		
END			
GO			
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DataType]') AND type in (N'U'))			
BEGIN			
	PRINT 'FAILED - Cannot create TABLE [PRODUCT].[DataType] - TABLE already exists';		
	RAISERROR('FAILED - Cannot create TABLE [PRODUCT].[DataType] - TABLE already exists', 16, 1);		
END			
ELSE			
BEGIN			
	PRINT 'Attempting to CREATE TABLE [PRODUCT].DataType';		
END			
GO			
	
CREATE TABLE [PRODUCT].[DataType](
	[DataTypeId] [int] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](50) NOT NULL,
 CONSTRAINT [pk_DataType] PRIMARY KEY CLUSTERED 
(
	[DataTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DataType]') AND type in (N'U'))	
BEGIN	
	PRINT 'SUCCESS - CREATED TABLE [PRODUCT].[DataType]';
END	
ELSE	
BEGIN	
	PRINT 'FAILED CREATING TABLE [PRODUCT].[DataType]';
	RAISERROR('FAILED CREATING TABLE [PRODUCT].[DataType]', 16, 1);
END	
GO	
