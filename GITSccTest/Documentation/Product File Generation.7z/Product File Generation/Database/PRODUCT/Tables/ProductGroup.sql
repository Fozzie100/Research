IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductGroup]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ProductGroup]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ProductGroup] >>>'
END
GO

CREATE TABLE [PRODUCT].[ProductGroup]
(
	ProductGroupId			[INT] IDENTITY(1,1) NOT NULL,
	ParentProductGroupId	[INT] NULL,
	Name					[VARCHAR](200) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[ProductGroup]
	ADD CONSTRAINT [pk_ProductGroup] PRIMARY KEY CLUSTERED 
	(
		ProductGroupId
	)
GO

ALTER TABLE [PRODUCT].[ProductGroup]
    ADD CONSTRAINT fk_ProductGroup_ParentProductGroup
    FOREIGN KEY
    (
		ParentProductGroupId
	)
    REFERENCES [PRODUCT].[ProductGroup]
    (
		ProductGroupId
    )
GO

CREATE UNIQUE INDEX IDX_ProductGroup_ParentAndName
ON PRODUCT.ProductGroup (ProductGroupId, Name)
GO

IF OBJECT_ID('[PRODUCT].[ProductGroup]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ProductGroup] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ProductGroup] >>>'
GO