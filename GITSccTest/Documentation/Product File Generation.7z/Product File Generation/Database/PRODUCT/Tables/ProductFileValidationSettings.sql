USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductFileValidationSettings]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ProductFileValidationSettings]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ProductFileValidationSettings] >>>'
END
GO

CREATE TABLE [PRODUCT].[ProductFileValidationSettings]
(
	ProductId					[INT] NOT NULL,
	AllowZeroByteFile			[BIT] NOT NULL CONSTRAINT DF_ProductFileValidationSettings_AllowZeroByteFile DEFAULT (0),
	ExpectedFileSize			[INT],
	FileSizePercentageTolerance	[INT],
	NumberOfLines				[INT],
	NumberOfColumns				[INT]	
)
GO

ALTER TABLE [PRODUCT].[ProductFileValidationSettings]
	ADD CONSTRAINT [pk_ProductFileValidationSettings] PRIMARY KEY CLUSTERED 
	(
		ProductId
	)
GO

ALTER TABLE [PRODUCT].[ProductFileValidationSettings]
    ADD CONSTRAINT fk_ProductFileValidationSettings_Product
    FOREIGN KEY
    (
		ProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    ) ON DELETE CASCADE
GO

IF OBJECT_ID('[PRODUCT].[ProductFileValidationSettings]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ProductFileValidationSettings] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ProductFileValidationSettings] >>>'
GO