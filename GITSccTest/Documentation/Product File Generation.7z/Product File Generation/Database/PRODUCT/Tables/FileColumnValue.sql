IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[FileColumnValue]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[FileColumnValue]
	PRINT '<<< DROPPED TABLE [PRODUCT].[FileColumnValue] >>>'
END
GO

CREATE TABLE [PRODUCT].[FileColumnValue]
(
	ProductCode VARCHAR(30) NOT NULL,
	FileDate	DATE NOT NULL,
	Source		VARCHAR(10) NOT NULL,
	RowIndex    INT NOT NULL,
	ColumnIndex INT NOT NULL,
	ColumnName	VARCHAR(100) NOT NULL,
	Value		VARCHAR(MAX) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[FileColumnValue]
	ADD CONSTRAINT [pk_FileColumnValue] PRIMARY KEY CLUSTERED 
	(
		ProductCode,
		FileDate,
		Source,
		RowIndex,
		ColumnIndex
	)
GO

IF OBJECT_ID('[PRODUCT].[FileColumnValue]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[FileColumnValue] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[FileColumnValue] >>>'
GO