USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductTokenValue]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ProductTokenValue]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ProductTokenValue] >>>'
END
GO

CREATE TABLE [PRODUCT].[ProductTokenValue]
(
	ProductTokenValueId	[INT] IDENTITY(1,1) NOT NULL,
	ProductId		[INT] NOT NULL,
	EffectiveDate	[DATE] NOT NULL CONSTRAINT DF_ProductTokenValue_EffectiveDate DEFAULT ('19000101'),
	ExpiryDate		[DATE] NOT NULL CONSTRAINT DF_ProductTokenValue_ExpiryDate DEFAULT ('99991231'),
	Token			VARCHAR(MAX),
	Value			VARCHAR(MAX)
)
GO

ALTER TABLE [PRODUCT].[ProductTokenValue]
	ADD CONSTRAINT [pk_ProductTokenValue] PRIMARY KEY CLUSTERED 
	(
		ProductTokenValueId
	)
GO

ALTER TABLE [PRODUCT].[ProductTokenValue]
    ADD CONSTRAINT fk_ProductTokenValue_Product
    FOREIGN KEY
    (
		ProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    ) ON DELETE CASCADE
GO

ALTER TABLE [PRODUCT].[ProductTokenValue]
	ADD CONSTRAINT [chk_ProductTokenValue_DatesInOrder] CHECK
	(
		EffectiveDate < ExpiryDate
	)
GO

IF OBJECT_ID('[PRODUCT].[ProductTokenValue]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ProductTokenValue] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ProductTokenValue] >>>'
GO