IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ValueFormatter]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ValueFormatter]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ValueFormatter] >>>'
END
GO

CREATE TABLE [PRODUCT].[ValueFormatter]
(
	ValueFormatterId	[INT] IDENTITY(1,1) NOT NULL,
	Name				[VARCHAR] (20) NOT NULL,
	Description			[VARCHAR](50) NOT NULL,
	TypeName			[VARCHAR](200) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[ValueFormatter]
	ADD CONSTRAINT [pk_ValueFormatter] PRIMARY KEY CLUSTERED 
	(
		ValueFormatterId
	)
GO

CREATE UNIQUE INDEX IDX_ValueFormatter_Name
ON PRODUCT.ValueFormatter (Name)
GO

IF OBJECT_ID('[PRODUCT].[ValueFormatter]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ValueFormatter] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ValueFormatter] >>>'
GO