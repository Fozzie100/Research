USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductDistributor]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ProductDistributor]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ProductDistributor] >>>'
END
GO

CREATE TABLE [PRODUCT].[ProductDistributor]
(
	ProductId			INT NOT NULL,
	DistributorId		INT NOT NULL
)
GO

ALTER TABLE [PRODUCT].[ProductDistributor]
	ADD CONSTRAINT [pk_ProductDistributor] PRIMARY KEY CLUSTERED 
	(
		ProductId,
		DistributorId
	)
GO

ALTER TABLE [PRODUCT].[ProductDistributor]
    ADD CONSTRAINT fk_ProductDistributor_Product
    FOREIGN KEY
    (
		ProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    ) ON DELETE CASCADE
GO

ALTER TABLE [PRODUCT].[ProductDistributor]
    ADD CONSTRAINT fk_ProductDistributor_Distributor
    FOREIGN KEY
    (
		DistributorId
	)
    REFERENCES [PRODUCT].[Distributor]
    (
		DistributorId
    ) ON DELETE CASCADE
GO

IF OBJECT_ID('[PRODUCT].[ProductDistributor]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ProductDistributor] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ProductDistributor] >>>'
GO