IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[List]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[List]
	PRINT '<<< DROPPED TABLE [PRODUCT].[List] >>>'
END
GO

CREATE TABLE [PRODUCT].[List]
(
	list_code   [VARCHAR](100) NOT NULL,
	name        [VARCHAR](100) NOT NULL,
)
GO

ALTER TABLE [PRODUCT].[List]
	ADD CONSTRAINT [pk_List] PRIMARY KEY CLUSTERED 
	(
		list_code
	)
GO

IF OBJECT_ID('[PRODUCT].[List]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[List] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[List] >>>'
GO