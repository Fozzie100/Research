IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[FileColumn]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[FileColumn]
	PRINT '<<< DROPPED TABLE [PRODUCT].[FileColumn] >>>'
END
GO

CREATE TABLE [PRODUCT].[FileColumn]
(
	FileColumnId	        [INT] IDENTITY(1,1) NOT NULL,
	SectionContentTypeId    [INT] NOT NULL,
	Name			        [VARCHAR](50) NOT NULL,
	DataTypeId              INT NOT NULL CONSTRAINT DF_FileColumn_DataTypeId DEFAULT(1),
	CategoryName	        [VARCHAR](50) NOT NULL,
	ProcedureName	        [VARCHAR](200) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[FileColumn]
	ADD CONSTRAINT [pk_FileColumn] PRIMARY KEY CLUSTERED 
	(
		FileColumnId
	)
GO

ALTER TABLE [PRODUCT].[FileColumn]
    ADD CONSTRAINT fk_FileColumn_SectionContentType
    FOREIGN KEY
    (
		SectionContentTypeId
	)
    REFERENCES [PRODUCT].[SectionContentType]
    (
		SectionContentTypeId
    )
GO

ALTER TABLE [PRODUCT].[FileColumn]
    ADD CONSTRAINT fk_FileColumn_DataType
    FOREIGN KEY
    (
		DataTypeId
	)
    REFERENCES [PRODUCT].[DataType]
    (
		DataTypeId
    )
GO

CREATE UNIQUE INDEX IDX_FileColumn_Name
ON PRODUCT.FileColumn (Name)
GO

IF OBJECT_ID('[PRODUCT].[FileColumn]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[FileColumn] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[FileColumn] >>>'
GO