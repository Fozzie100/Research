IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[SectionDetailParameter]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[SectionDetailParameter]
	PRINT '<<< DROPPED TABLE [PRODUCT].[SectionDetailParameter] >>>'
END
GO

CREATE TABLE [PRODUCT].[SectionDetailParameter]
(
	SectionDetailParameterId	[INT] IDENTITY(1,1) NOT NULL,
	SectionDetailId				[INT] NOT NULL,
	ParameterName				[VARCHAR](50) NOT NULL,
	Value						[VARCHAR](100)
)
GO

ALTER TABLE [PRODUCT].[SectionDetailParameter]
	ADD CONSTRAINT [pk_SectionDetailParameter] PRIMARY KEY CLUSTERED 
	(
		SectionDetailParameterId
	)
GO

ALTER TABLE [PRODUCT].[SectionDetailParameter]
    ADD CONSTRAINT fk_SectionDetailParameter_Section
    FOREIGN KEY
    (
		SectionDetailId
	)
    REFERENCES [PRODUCT].[SectionDetail]
    (
		SectionDetailId
    ) ON DELETE CASCADE
GO

IF OBJECT_ID('[PRODUCT].[SectionDetailParameter]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[SectionDetailParameter] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[SectionDetailParameter] >>>'
GO