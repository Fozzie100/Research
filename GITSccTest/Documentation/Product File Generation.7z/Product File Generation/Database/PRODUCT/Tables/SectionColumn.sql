IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[SectionColumn]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[SectionColumn]
	PRINT '<<< DROPPED TABLE [PRODUCT].[SectionColumn] >>>'
END
GO

CREATE TABLE [PRODUCT].[SectionColumn]
(
	[SectionColumnId]	[INT] IDENTITY(1,1) NOT NULL,
	[SectionId]			[INT] NOT NULL,
	[FileColumnId]		[INT] NOT NULL,
	[Sequence]			[INT] NOT NULL,
	[Description]		[VARCHAR](100) NOT NULL,
	[SortOrder]			[INT] NULL,
	[EffectiveDate]		[DATE] NOT NULL,
	[ExpiryDate]		[DATE] NOT NULL  CONSTRAINT DF_SectionColumn_ExpiryDate DEFAULT ('99991231'),
	[QuoteValues]		[BIT] NOT NULL CONSTRAINT DF_SectionColumn_QuoteValues DEFAULT(0),
	ValidationRules		[VARCHAR](MAX) NULL,
	FormatArguments		[VARCHAR](MAX) NULL,
)
GO

ALTER TABLE [PRODUCT].[SectionColumn]
	ADD CONSTRAINT [pk_SectionColumn] PRIMARY KEY CLUSTERED 
	(
		SectionColumnId
	)
GO

ALTER TABLE [PRODUCT].[SectionColumn]
    ADD CONSTRAINT fk_SectionColumn_Section
    FOREIGN KEY
    (
		SectionId
	)
    REFERENCES [PRODUCT].[Section]
    (
		SectionId
    ) ON DELETE CASCADE
GO

ALTER TABLE [PRODUCT].[SectionColumn]
    ADD CONSTRAINT fk_SectionColumn_FileColumn
    FOREIGN KEY
    (
		FileColumnId
	)
    REFERENCES [PRODUCT].[FileColumn]
    (
		FileColumnId
    )
GO

IF OBJECT_ID('[PRODUCT].[SectionColumn]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[SectionColumn] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[SectionColumn] >>>'
GO