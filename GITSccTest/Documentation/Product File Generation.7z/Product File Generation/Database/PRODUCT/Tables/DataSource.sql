IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DataSource]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[DataSource]
	PRINT '<<< DROPPED TABLE [PRODUCT].[DataSource] >>>'
END
GO

CREATE TABLE [PRODUCT].[DataSource]
(
	DataSourceId		[INT] IDENTITY(1,1) NOT NULL,
	Name				[VARCHAR](50) NOT NULL,
	ConnectionString	[VARCHAR](MAX) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[DataSource]
	ADD CONSTRAINT [pk_DataSource] PRIMARY KEY CLUSTERED 
	(
		DataSourceId
	)
GO

IF OBJECT_ID('[PRODUCT].[DataSource]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[DataSource] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[DataSource] >>>'
GO