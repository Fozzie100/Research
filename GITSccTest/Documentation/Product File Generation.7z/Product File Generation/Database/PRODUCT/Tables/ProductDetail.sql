IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductDetail]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ProductDetail]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ProductDetail] >>>'
END
GO

CREATE TABLE [PRODUCT].[ProductDetail]
(
	ProductDetailId	[INT] IDENTITY(1,1) NOT NULL,
	ProductId		[INT] NOT NULL,
	EffectiveDate	[DATE] NOT NULL,
	ExpiryDate		[DATE] NOT NULL CONSTRAINT DF_ProductDetail_ExpiryDate DEFAULT ('99991231'),
	HeaderText		VARCHAR(MAX),
	FooterText		VARCHAR(MAX)
)
GO

ALTER TABLE [PRODUCT].[ProductDetail]
	ADD CONSTRAINT [pk_ProductDetail] PRIMARY KEY CLUSTERED 
	(
		ProductDetailId
	)
GO

ALTER TABLE [PRODUCT].[ProductDetail]
    ADD CONSTRAINT fk_ProductDetail_Product
    FOREIGN KEY
    (
		ProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    ) ON DELETE CASCADE
GO

ALTER TABLE [PRODUCT].[ProductDetail]
	ADD CONSTRAINT [chk_ProductDetail_DatesInOrder] CHECK
	(
		EffectiveDate < ExpiryDate
	)
GO

IF OBJECT_ID('[PRODUCT].[ProductDetail]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ProductDetail] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ProductDetail] >>>'
GO