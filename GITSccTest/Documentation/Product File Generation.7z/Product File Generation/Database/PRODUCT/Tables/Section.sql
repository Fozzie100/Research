IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[Section]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[Section]
	PRINT '<<< DROPPED TABLE [PRODUCT].[Section] >>>'
END
GO

CREATE TABLE [PRODUCT].[Section]
(
	SectionId		        [INT] IDENTITY(1,1) NOT NULL,
	ProductId		        [INT] NOT NULL,
    SectionContentTypeId    [INT] NOT NULL,	
	SectionType		        [VARCHAR](50) NOT NULL,
	Name			        [VARCHAR](50) NOT NULL,
	Sequence		        [INT] NOT NULL
)
GO

ALTER TABLE [PRODUCT].[Section]
	ADD CONSTRAINT [pk_Section] PRIMARY KEY CLUSTERED 
	(
		SectionId
	)
GO

ALTER TABLE [PRODUCT].[Section]
    ADD CONSTRAINT fk_Section_Product
    FOREIGN KEY
    (
		ProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    ) ON DELETE CASCADE
GO

ALTER TABLE [PRODUCT].[Section]
    ADD CONSTRAINT fk_Section_SectionContentType
    FOREIGN KEY
    (
		SectionContentTypeId
	)
    REFERENCES [PRODUCT].[SectionContentType]
    (
		SectionContentTypeId
    )
GO

IF OBJECT_ID('[PRODUCT].[Section]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[Section] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[Section] >>>'
GO