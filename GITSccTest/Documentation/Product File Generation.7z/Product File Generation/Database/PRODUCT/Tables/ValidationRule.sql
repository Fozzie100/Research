IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ValidationRule]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ValidationRule]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ValidationRule] >>>'
END
GO

CREATE TABLE [PRODUCT].[ValidationRule]
(
	Name			[VARCHAR](200) NOT NULL,
	Description		[VARCHAR](50) NOT NULL,
	DataType		[VARCHAR](200) NULL
)
GO

ALTER TABLE [PRODUCT].[ValidationRule]
	ADD CONSTRAINT [pk_ValidationRule] PRIMARY KEY CLUSTERED 
	(
		Name
	)
GO

IF OBJECT_ID('[PRODUCT].[ValidationRule]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ValidationRule] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ValidationRule] >>>'
GO