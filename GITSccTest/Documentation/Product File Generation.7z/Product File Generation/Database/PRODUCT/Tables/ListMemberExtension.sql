USE [EXPORT]
GO

IF OBJECT_ID('[PRODUCT].[ListMemberExtension]') IS NOT NULL 
BEGIN
	DROP TABLE [PRODUCT].[ListMemberExtension]
	PRINT 'DROPPED TABLE [PRODUCT].[ListMemberExtension]'
END
GO

CREATE TABLE [PRODUCT].[ListMemberExtension]
(
	list_code	VARCHAR(100)	NULL,
	mnemonic	VARCHAR(20)		NULL,
	icb_level	INT				NULL,
	sort		VARCHAR(3)		NULL
)ON [PRIMARY]
GO

PRINT 'CREATED TABLE [PRODUCT].[ListMemberExtension]'