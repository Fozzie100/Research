IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductDestination]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ProductDestination]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ProductDestination] >>>'
END
GO

CREATE TABLE [PRODUCT].[ProductDestination]
(
	ProductDestinationId	[INT] IDENTITY(1,1) NOT NULL,
	ProductId		[INT] NOT NULL,
	Path			[VARCHAR] (MAX) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[ProductDestination]
	ADD CONSTRAINT [pk_ProductDestination] PRIMARY KEY CLUSTERED 
	(
		ProductDestinationId
	)
GO

ALTER TABLE [PRODUCT].[ProductDestination]
    ADD CONSTRAINT fk_ProductDestination_Product
    FOREIGN KEY
    (
		ProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    ) ON DELETE CASCADE
GO

IF OBJECT_ID('[PRODUCT].[ProductDestination]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ProductDestination] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ProductDestination] >>>'
GO