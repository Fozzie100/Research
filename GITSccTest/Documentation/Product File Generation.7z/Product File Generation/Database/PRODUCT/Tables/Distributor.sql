USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[Distributor]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[Distributor]
	PRINT '<<< DROPPED TABLE [PRODUCT].[Distributor] >>>'
END
GO

CREATE TABLE [PRODUCT].[Distributor]
(
	DistributorId		INT IDENTITY(1,1) NOT NULL,
	Name				VARCHAR(100) NOT NULL,
	ItemKey				INT NOT NULL,
	FileType			VARCHAR(50) NOT NULL,
	DistributionType	VARCHAR(100) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[Distributor]
	ADD CONSTRAINT [pk_Distributor] PRIMARY KEY CLUSTERED 
	(
		DistributorId
	)
GO

CREATE UNIQUE INDEX IDX_Distributor_Name
ON PRODUCT.Distributor (Name)
GO

IF OBJECT_ID('[PRODUCT].[Distributor]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[Distributor] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[Distributor] >>>'
GO