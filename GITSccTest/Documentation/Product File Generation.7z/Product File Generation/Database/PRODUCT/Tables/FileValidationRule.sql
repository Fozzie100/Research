IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[FileValidationRule]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[FileValidationRule]
	PRINT '<<< DROPPED TABLE [PRODUCT].[FileValidationRule] >>>'
END
GO

CREATE TABLE [PRODUCT].[FileValidationRule]
(
	Name			[VARCHAR](200) NOT NULL,
	Description		[VARCHAR](50) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[FileValidationRule]
	ADD CONSTRAINT [pk_FileValidationRule] PRIMARY KEY CLUSTERED 
	(
		Name
	)
GO

IF OBJECT_ID('[PRODUCT].[FileValidationRule]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[FileValidationRule] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[FileValidationRule] >>>'
GO