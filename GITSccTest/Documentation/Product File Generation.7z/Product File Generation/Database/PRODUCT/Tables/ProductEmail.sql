USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductEmail]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[ProductEmail]
	PRINT '<<< DROPPED TABLE [PRODUCT].[ProductEmail] >>>'
END
GO

CREATE TABLE [PRODUCT].[ProductEmail]
(
	ProductEmailId	[INT] IDENTITY(1,1) NOT NULL,
	ProductId		[INT] NOT NULL,
	EffectiveDate	[DATE] NOT NULL,
	ExpiryDate		[DATE] NOT NULL CONSTRAINT DF_ProductEmail_ExpiryDate DEFAULT ('99991231'),
	SubjectText		VARCHAR(MAX),
	BodyText		VARCHAR(MAX),
	FromAddress		VARCHAR(MAX),
	ToAddresses		VARCHAR(MAX),
	CcAddresses		VARCHAR(MAX),
	BccAddresses	VARCHAR(MAX)
)
GO

ALTER TABLE [PRODUCT].[ProductEmail]
	ADD CONSTRAINT [pk_ProductEmail] PRIMARY KEY CLUSTERED 
	(
		ProductEmailId
	)
GO

ALTER TABLE [PRODUCT].[ProductEmail]
    ADD CONSTRAINT fk_ProductEmail_Product
    FOREIGN KEY
    (
		ProductId
	)
    REFERENCES [PRODUCT].[Product]
    (
		ProductId
    ) ON DELETE CASCADE
GO

ALTER TABLE [PRODUCT].[ProductEmail]
	ADD CONSTRAINT [chk_ProductEmail_DatesInOrder] CHECK
	(
		EffectiveDate < ExpiryDate
	)
GO

IF OBJECT_ID('[PRODUCT].[ProductEmail]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[ProductEmail] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[ProductEmail] >>>'
GO