IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[AvailableSection]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[AvailableSection]
	PRINT '<<< DROPPED TABLE [PRODUCT].[AvailableSection] >>>'
END
GO

CREATE TABLE [PRODUCT].[AvailableSection]
(
	AvailableSectionId	[INT] IDENTITY(1,1) NOT NULL,
	Name				[VARCHAR](50) NOT NULL,
	StoredProcedure		[VARCHAR](200) NOT NULL
)
GO

ALTER TABLE [PRODUCT].[AvailableSection]
	ADD CONSTRAINT [pk_AvailableSection] PRIMARY KEY CLUSTERED 
	(
		AvailableSectionId
	)
GO

CREATE UNIQUE INDEX IDX_AvailableSection_Name
ON PRODUCT.AvailableSection (Name)
GO

IF OBJECT_ID('[PRODUCT].[AvailableSection]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[AvailableSection] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[AvailableSection] >>>'
GO