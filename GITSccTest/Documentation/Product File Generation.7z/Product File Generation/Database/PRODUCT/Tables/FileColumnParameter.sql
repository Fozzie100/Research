IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[FileColumnParameter]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[FileColumnParameter]
	PRINT '<<< DROPPED TABLE [PRODUCT].[FileColumnParameter] >>>'
END
GO

CREATE TABLE [PRODUCT].[FileColumnParameter]
(
	[FileColumnParameterId]	[INT] IDENTITY(1,1) NOT NULL,
	[FileColumnId]			[INT] NOT NULL,
	[Description]			[VARCHAR](100) NOT NULL,
	[ParameterName]			[VARCHAR](50) NOT NULL,
	[DefaultValue]			[VARCHAR](100),
	[UserInput]				[BIT] NOT NULL CONSTRAINT DF_FileColumnParameter_UserInput DEFAULT (0)
)
GO

ALTER TABLE [PRODUCT].[FileColumnParameter]
	ADD CONSTRAINT [pk_FileColumnParameter] PRIMARY KEY CLUSTERED 
	(
		FileColumnParameterId
	)
GO

ALTER TABLE [PRODUCT].[FileColumnParameter]
    ADD CONSTRAINT fk_FileColumnParameter_FileColumn
    FOREIGN KEY
    (
		FileColumnId
	)
    REFERENCES [PRODUCT].[FileColumn]
    (
		FileColumnId
    ) ON DELETE CASCADE
GO

IF OBJECT_ID('[PRODUCT].[FileColumnParameter]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[FileColumnParameter] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[FileColumnParameter] >>>'
GO