USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[FtpDistributor]') AND type in (N'U'))
BEGIN
	DROP TABLE [PRODUCT].[FtpDistributor]
	PRINT '<<< DROPPED TABLE [PRODUCT].[FtpDistributor] >>>'
END
GO

CREATE TABLE [PRODUCT].[FtpDistributor]
(
	[Id]					[INT] IDENTITY(1,1) NOT NULL,
	[RemoteDirectory]		[VARCHAR](200) NOT NULL,
	[FtpUserName]			[VARCHAR](200) NOT NULL,
	[FtpPassword]			[VARCHAR](200) NOT NULL,
	[DownloadBufferSize]	[INT] NOT NULL CONSTRAINT DF_PRODUCT_FtpDistributor_DownloadBufferSize DEFAULT (1048576),
	[TimeoutInMinutes]		[INT] NOT NULL CONSTRAINT DF_PRODUCT_FtpDistributor_Timeout DEFAULT (5)
)
GO

ALTER TABLE [PRODUCT].[FtpDistributor]
	ADD CONSTRAINT [pk_FtpDistributor] PRIMARY KEY CLUSTERED 
	(
		Id
	)
GO

IF OBJECT_ID('[PRODUCT].[FtpDistributor]') IS NOT NULL
	PRINT '<<< CREATED TABLE [PRODUCT].[FtpDistributor] >>>'
ELSE
	PRINT '<<< FAILED CREATING TABLE [PRODUCT].[FtpDistributor] >>>'
GO