USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[CreateProductGroup]') AND type in (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [PRODUCT].[CreateProductGroup]
	PRINT 'DROPPED PROCEDURE [PRODUCT].[CreateProductGroup]'
END
GO

CREATE PROCEDURE [PRODUCT].[CreateProductGroup]
(
	@ProductGroupId         INT OUTPUT,
	@name                   VARCHAR(200),
	@ParentProductGroupId   INT = NULL
)
AS  

	SET NOCOUNT ON;

    SELECT @ProductGroupId = ProductGroupId FROM PRODUCT.ProductGroup where Name = @name
    IF (@ProductGroupId IS NULL)
    BEGIN
        INSERT INTO PRODUCT.ProductGroup (ParentProductGroupId, Name)
        VALUES (@ParentProductGroupId, @name)
        SELECT @ProductGroupId = SCOPE_IDENTITY()
    END
	
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[CreateProductGroup]') AND type in (N'P', N'PC'))
BEGIN
	PRINT 'CREATED [PRODUCT].[CreateProductGroup]'
END
GO