USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DisplayProductTokens]') AND type in (N'P', N'PC'))
BEGIN
    DROP PROCEDURE [PRODUCT].[DisplayProductTokens]
    PRINT 'DROPPED PROCEDURE [PRODUCT].[DisplayProductTokens]'
END
GO

CREATE PROCEDURE [PRODUCT].[DisplayProductTokens]
(
    @code       VARCHAR(50),
    @productId  INT	= NULL
)
AS  

    SET NOCOUNT ON;

    IF @productId IS NULL
    BEGIN
        SET @productId = (SELECT ProductId FROM PRODUCT.Product WHERE code = @code)		
    END
    DECLARE @regular_expression VARCHAR(MAX) = '\[([^]]+)\]'

    DECLARE @tokens TABLE
    (
        token   VARCHAR(MAX)
    )
    INSERT INTO @tokens
    SELECT      Match AS Token
    FROM        PRODUCT.ProductDetail
    CROSS APPLY UTILITY.dbo.RegExMatches(HeaderText, @regular_expression, 0)
    WHERE       ProductId = @productId
    UNION
    SELECT      Match AS Token
    FROM        PRODUCT.ProductDetail
    CROSS APPLY UTILITY.dbo.RegExMatches(FooterText, @regular_expression, 0)
    WHERE       ProductId = @productId
    UNION
    SELECT      Match AS Token
    FROM        PRODUCT.SectionDetail
    INNER JOIN  PRODUCT.Section
    ON          Section.SectionId = SectionDetail.SectionId
    CROSS APPLY UTILITY.dbo.RegExMatches(HeaderText, @regular_expression, 0)
    WHERE       ProductId = @productId
    UNION
    SELECT      Match AS Token
    FROM        PRODUCT.SectionDetail
    INNER JOIN  PRODUCT.Section
    ON          Section.SectionId = SectionDetail.SectionId
    CROSS APPLY UTILITY.dbo.RegExMatches(FooterText, @regular_expression, 0)
    WHERE       ProductId = @productId
    UNION
    SELECT      Match AS Token
    FROM        PRODUCT.SectionDetailParameter
    INNER JOIN  PRODUCT.SectionDetail
    ON          SectionDetailParameter.SectionDetailId = SectionDetail.SectionDetailId
    INNER JOIN  PRODUCT.Section
    ON          Section.SectionId = SectionDetail.SectionId
    CROSS APPLY UTILITY.dbo.RegExMatches(Value, @regular_expression, 0)	
    WHERE       ProductId =  @productId
    UNION
    SELECT      Match AS Token
    FROM        PRODUCT.SectionColumnParameter
    INNER JOIN  PRODUCT.SectionColumn
    ON          SectionColumnParameter.SectionColumnId = SectionColumn.SectionColumnId
    INNER JOIN  PRODUCT.Section
    ON          Section.SectionId = SectionColumn.SectionId
    CROSS APPLY UTILITY.dbo.RegExMatches(Value, @regular_expression, 0)	
    WHERE       ProductId =  @productId
    UNION
    SELECT      Match AS Token
    FROM        PRODUCT.SectionColumnParameter
    INNER JOIN  PRODUCT.SectionColumn
    ON          SectionColumnParameter.SectionColumnId = SectionColumn.SectionColumnId
    INNER JOIN  PRODUCT.Section
    ON          Section.SectionId = SectionColumn.SectionId
    INNER JOIN  PRODUCT.FileColumn
    ON          FileColumn.FileColumnId = SectionColumn.FileColumnId
    INNER JOIN  PRODUCT.FileColumnParameter
    ON          FileColumn.FileColumnId = FileColumnParameter.FileColumnId
    CROSS APPLY UTILITY.dbo.RegExMatches(FileColumnParameter.DefaultValue, @regular_expression, 0)	
    WHERE       ProductId =  @productId

    --Delete any known about tokens
    DELETE FROM @tokens
    WHERE       token IN ('[DD]', '[MM]', '[YYYY]')

    SELECT      *
    FROM        @tokens
    ORDER BY    token

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DisplayProductTokens]') AND type in (N'P', N'PC'))
BEGIN
    PRINT 'CREATED [PRODUCT].[DisplayProductTokens]'
END
GO