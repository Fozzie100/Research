USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DisplayProduct]') AND type in (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [PRODUCT].[DisplayProduct]
	PRINT 'DROPPED PROCEDURE [PRODUCT].[DisplayProduct]'
END
GO

CREATE PROCEDURE [PRODUCT].[DisplayProduct]
(
	@code		VARCHAR(50),
	@productId	INT	= NULL,
	@date		DATETIME = NULL
)
AS  

	SET NOCOUNT ON;

	IF @date IS NULL
	BEGIN
		SET @date = GETDATE()
	END

	IF @productId IS NULL
	BEGIN
		SET @productId = (SELECT ProductId FROM PRODUCT.Product WHERE code = @code)		
	END

	SELECT  'Product' AS Type,
	        *
	FROM    PRODUCT.ProductDetailView
	WHERE   ProductId = @productId
	AND     @date BETWEEN ISNULL(EffectiveDate, DATEADD(dd, -1, GETDATE())) AND ISNULL(ExpiryDate, DATEADD(dd, 1, GETDATE()))

    SELECT      'Section' AS Type,
                *
	FROM        PRODUCT.ProductSectionDetailView AS a
	WHERE       ProductId = @productId
	ORDER BY    Sequence

	SELECT		'Section Parameter' AS Type,
				*
	FROM		PRODUCT.ProductSectionParameterDetailView
	WHERE		ProductId = @productId
    AND			@date BETWEEN EffectiveDate AND ExpiryDate 
    ORDER BY    Sequence

	SELECT      'Column' AS Type,
		        *
	FROM        PRODUCT.ProductColumnDetailView
	WHERE       ProductId = @productId
	AND         @date BETWEEN EffectiveDate AND ExpiryDate 
	ORDER BY    SectionSequence, ColumnSequence
	            
	
	SELECT  'Column Parameter' AS Type,
	    	*
	FROM    PRODUCT.ProductParameterDetailView
	WHERE   ProductId = @productId
	AND     @date BETWEEN EffectiveDate AND ExpiryDate ORDER BY Sequence

	SELECT  'Distribution' AS Type,
		    *
	FROM    PRODUCT.ProductDistributionView
	WHERE   ProductId = @productId
		
	SELECT  'Email' AS Type,
		    *
	FROM    PRODUCT.ProductEmail
	WHERE   ProductId = @productId
	AND     @date BETWEEN EffectiveDate AND ExpiryDate
	
	SELECT  'Token' AS Type,
		    *
	FROM    PRODUCT.ProductTokenValue
	WHERE   ProductId = @productId
	AND     @date BETWEEN EffectiveDate AND ExpiryDate
	
GO

GRANT EXECUTE ON [PRODUCT].[DisplayProduct] TO Public
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DisplayProduct]') AND type in (N'P', N'PC'))
BEGIN
	PRINT 'CREATED [PRODUCT].[DisplayProduct]'
END
GO
