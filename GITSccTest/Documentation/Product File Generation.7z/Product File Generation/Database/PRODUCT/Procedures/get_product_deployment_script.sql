USE EXPORT
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[get_product_deployment_script]') AND type in (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [PRODUCT].[get_product_deployment_script]
	PRINT '<<< DROPPED [PRODUCT].[get_product_deployment_script] >>>'
END
GO

CREATE PROCEDURE [PRODUCT].[get_product_deployment_script]
(
	 @productCode VARCHAR(55)
)
AS

SET NOCOUNT ON

BEGIN TRY 

	DECLARE 
		 @ProductId INT
		,@ProductGroupName VARCHAR(200)
		,@TemplateProductCode VARCHAR(50)
		,@SectionId INT
		,@SectionDetailId INT
		,@SectionDetailParameterId INT
		,@SectionColumnId INT
		,@SectionColumnParameterId INT
		,@DistributorId INT
		,@ProductEmailId INT
		,@ProductTokenValueId INT
		,@RunDate DATE = CAST(GETDATE() AS DATE)

	SELECT 
		@ProductId = ProductId, @ProductGroupName = ProductGroup, @TemplateProductCode = TemplateProductCode
	FROM PRODUCT.ProductDetailView 
	WHERE Code = @productCode
	
	IF @ProductId IS NULL
	BEGIN	
		RAISERROR ('Invalid Product code', 16, 1)
		RETURN
	END

	IF OBJECT_ID('tempdb..#tempSQL') IS NOT NULL
		DROP TABLE #tempSQL

	CREATE TABLE #tempSQL 
	(
		id INT IDENTITY (1,1), 
		txt VARCHAR (MAX)
	)

	INSERT INTO #tempSQL
	SELECT 
		 'SET NOCOUNT ON' + CHAR(10) + CHAR(10)
		+ 'USE EXPORT' + CHAR(10)
		+ 'GO' + CHAR(10) + CHAR(10)
		+ 'DECLARE' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ' @ProductId INT' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@ProductCode VARCHAR(50) = ' + '''' + @productCode + '''' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@ProductGroupId INT' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@ProductGroupName VARCHAR(200) = ' + '''' + @ProductGroupName + '''' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@TemplateProductCode VARCHAR(50) = ' + ISNULL('''' + @TemplateProductCode + '''', 'NULL') + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@TemplateProductId INT' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@SectionId INT' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@SectionDetailId INT' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + ',@SectionColumnId INT' + CHAR(10)

	INSERT INTO #tempSQL
	SELECT 
		  'BEGIN TRY ' + CHAR(10) + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + 'BEGIN TRAN' + CHAR(10) + CHAR(10)
		+ REPLICATE(CHAR(9), 2) + '--Delete if product already exist' + CHAR(10)
		+ REPLICATE(CHAR(9), 2) + 'DELETE FROM PRODUCT.Product WHERE Code = @ProductCode' + CHAR(10) + CHAR(10)

		+ REPLICATE(CHAR(9), 2) + '--Create Product Group if it doesnt exist' + CHAR(10)
		+ REPLICATE(CHAR(9), 2) + 'EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName' + CHAR(10) + CHAR(10)
		+ REPLICATE(CHAR(9), 2) + '--Get Template Product Id linked to the Product (if any)' + CHAR(10)
		+ REPLICATE(CHAR(9), 2) + 'SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1' + CHAR(10)

	--INSERT Product Script
	INSERT INTO #tempSQL
	SELECT 
		  REPLICATE(CHAR(9), 2) + 'INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)' + CHAR(10) 
		+ REPLICATE(CHAR(9), 2) + 'VALUES('
		+ '@ProductGroupId' 
		+ ', ' + ISNULL(CAST (DataSourceId AS VARCHAR), 'NULL') 
		+ ', ''' + Name + '''' 
		+ ', @ProductCode' 
		+ ', ''' + FileSuffix + '''' 
		+ ', ''' + Delimiter + '''' 
		+ ', ' +  ISNULL(CAST (IsTemplate AS CHAR(1)), 'NULL') 
		+ ', @TemplateProductId)' + CHAR(10) 
		+ REPLICATE(CHAR(9), 2) + 'SET @ProductId = SCOPE_IDENTITY()' + CHAR(10) 
	FROM   PRODUCT.Product
	WHERE  ProductId = @ProductId

	--INSERT ProductDetail Script
	INSERT INTO #tempSQL
	SELECT 
		  REPLICATE(CHAR(9), 2) + 'INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)' + CHAR(10) 
		+ REPLICATE(CHAR(9), 2) + 'VALUES('
		+ '@ProductId' 
		+ ', ' + ISNULL('''' + CAST (EffectiveDate AS VARCHAR) + '''', 'NULL') 
		+ ', ' + ISNULL('''' + CAST (ExpiryDate AS VARCHAR) + '''', 'NULL') 
		+ ', ' + ISNULL('''' + HeaderText + '''', 'NULL')
		+ ', ' + ISNULL('''' + FooterText + '''', 'NULL') +')' + CHAR(10) 
	FROM   PRODUCT.ProductDetail
	WHERE  ProductId = @ProductId
	AND @RunDate BETWEEN EffectiveDate AND ExpiryDate

	--UPDATE t 
	--SET txt = REPLACE (txt,'''NULL''', 'NULL')
	--FROM  #tempSQL t

	--Section
	IF OBJECT_ID('tempdb..#section') IS NOT NULL
		DROP TABLE #section

	CREATE TABLE #section
	(
		Id INT IDENTITY (1,1), 
		SectionId INT
	) 
     
     INSERT INTO #section 
     SELECT a.SectionId
     FROM   PRODUCT.Section a
     WHERE  ProductId = @ProductId
     ORDER BY a.SectionId, a.Sequence

     DECLARE @s_count INT 
     SELECT  @s_count = COUNT(1) FROM #section  
     DECLARE @s_ctr INT = 1

     IF OBJECT_ID ('tempdb..#sectionColumn') IS NOT NULL 
        DROP TABLE #sectionColumn
       
	CREATE TABLE #sectionColumn
	(
		Id INT IDENTITY (1,1), 
		SectionColumnId INT
	) 
      
     -- Section loop starts     
	WHILE (@s_ctr <= @s_count)
	BEGIN 
	        
		SELECT @SectionId =  SectionId FROM  #section WHERE Id = @s_ctr 

		INSERT INTO #tempSQL
		SELECT 			  
			  REPLICATE(CHAR(9), 3) + 'INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)' + CHAR(10) 
			+ REPLICATE(CHAR(9), 3) + 'VALUES('
			+ '@ProductId' 
			+ ', ' + ISNULL('''' + SectionType + '''', 'NULL')
			+ ', ' + ISNULL('''' + Name + '''', 'NULL')
			+ ', ' + ISNULL(CAST (Sequence AS VARCHAR), 'NULL') + ')' + CHAR(10) 
			+ REPLICATE(CHAR(9), 3) + 'SET @SectionId = SCOPE_IDENTITY()' + CHAR(10) 
		FROM   PRODUCT.Section
		WHERE  SectionId = @SectionId
	       
		--SectionDetail
		IF OBJECT_ID ('tempdb..#sectionDetail') IS NOT NULL 
			DROP TABLE #sectionDetail

		CREATE TABLE #sectionDetail
		(
			Id INT IDENTITY (1,1), 
			SectionDetailId INT
		) 

		INSERT INTO #sectionDetail
		SELECT SectionDetailId
		FROM   PRODUCT.SectionDetail
		WHERE  SectionId = @SectionId
			
		DECLARE @sd_count INT 
		SELECT  @sd_count = COUNT(1) FROM #sectionDetail
		DECLARE @sd_ctr INT = 1 

		-- SectionDetail loop starts  
		WHILE (@sd_ctr <= @sd_count)
		BEGIN
			SELECT @SectionDetailId =  SectionDetailId FROM  #sectionDetail WHERE Id = @sd_ctr 

			INSERT INTO #tempSQL
			SELECT 
				  REPLICATE(CHAR(9), 4) + 'INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)' + CHAR(10) 
				+ REPLICATE(CHAR(9), 4) + 'VALUES('
				+ '@SectionId' 
				+ ', ' + ISNULL('''' + CAST (EffectiveDate AS VARCHAR) + '''', 'NULL') 
				+ ', ' + ISNULL('''' + CAST (ExpiryDate AS VARCHAR) + '''', 'NULL') 
				+ ', ' + ISNULL(CAST (OutputColumnNames AS CHAR(1)), 'NULL') 
				+ ', ' + ISNULL('''' + ProcedureName + '''', 'NULL')
				+ ', ' + ISNULL('''' + HeaderText + '''', 'NULL')
				+ ', ' + ISNULL('''' + FooterText + '''', 'NULL') + ')' + CHAR(10) 
				+ REPLICATE(CHAR(9), 4) + 'SET @SectionDetailId = SCOPE_IDENTITY()' + CHAR(10) 
			FROM   PRODUCT.SectionDetail
			WHERE  SectionDetailId = @SectionDetailId
			AND @RunDate BETWEEN EffectiveDate AND ExpiryDate

			--SectionDetailParameter
			IF OBJECT_ID ('tempdb..#sectionDetailParameter') IS NOT NULL 
				DROP TABLE #sectionDetailParameter
       
			CREATE TABLE #sectionDetailParameter
			(
				Id INT IDENTITY (1,1), 
				SectionDetailParameterId INT
			) 

			INSERT INTO #sectionDetailParameter
			SELECT SectionDetailParameterId
			FROM   PRODUCT.SectionDetailParameter
			WHERE  SectionDetailId = @SectionDetailId
			
			DECLARE @sdp_count INT 
			SELECT  @sdp_count = COUNT(1) FROM #sectionDetailParameter
			DECLARE @sdp_ctr INT = 1 

			--SectionDetailParameter loop starts  
			WHILE (@sdp_ctr <= @sdp_count)
			BEGIN
				SELECT @SectionDetailParameterId =  SectionDetailParameterId FROM  #sectionDetailParameter WHERE Id = @sdp_ctr 

				INSERT INTO #tempSQL
				SELECT 
					  REPLICATE(CHAR(9), 5) + 'INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)' + CHAR(10) 
					+ REPLICATE(CHAR(9), 5) + 'VALUES('
					+ '@SectionDetailId' 
					+ ', ' + ISNULL('''' + ParameterName + '''', 'NULL')
					+ ', ' + ISNULL('''' + Value + '''', 'NULL') + ')' + CHAR(10) 
				FROM   PRODUCT.SectionDetailParameter
				WHERE  SectionDetailParameterId = @SectionDetailParameterId

				SET @sdp_ctr= @sdp_ctr+1
			END 
			--SectionDetailParameter loop ends

			SET @sd_ctr= @sd_ctr+1
		END 
		-- SectionDetail loop ends

		--SectionColumn
		TRUNCATE TABLE #sectionColumn

		INSERT INTO #sectionColumn
		SELECT SectionColumnId
		FROM   PRODUCT.SectionColumn
		WHERE  SectionId = @SectionId
		ORDER BY Sequence
			
		DECLARE @sc_count INT 
		SELECT  @sc_count = COUNT(1) FROM #sectionColumn
		DECLARE @sc_ctr INT = 1 

		-- SectionColumn loop starts  
		WHILE (@sc_ctr <= @sc_count)
		BEGIN
			SELECT @SectionColumnId =  SectionColumnId FROM  #sectionColumn WHERE Id = @sc_ctr 

			INSERT INTO #tempSQL
			SELECT 
				  REPLICATE(CHAR(9), 4) + 'INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)' + CHAR(10) 
				+ REPLICATE(CHAR(9), 4) + 'VALUES('
				+ '@SectionId' 
				+ ', ' + ISNULL(CAST (FileColumnId AS VARCHAR), 'NULL')
				+ ', ' + ISNULL(CAST (Sequence AS VARCHAR), 'NULL')
				+ ', ' + ISNULL('''' + Description + '''', 'NULL')
				+ ', ' + ISNULL(CAST (SortOrder AS VARCHAR), 'NULL')
				+ ', ' + ISNULL('''' + CAST (EffectiveDate AS VARCHAR) + '''', 'NULL') 
				+ ', ' + ISNULL('''' + CAST (ExpiryDate AS VARCHAR) + '''', 'NULL') 
				+ ', ' + ISNULL(CAST (QuoteValues AS CHAR(1)), 'NULL') 
				+ ', ' + ISNULL('''' + ValidationRules + '''', 'NULL')
				+ ', ' + ISNULL('''' + FormatArguments + '''', 'NULL') + ')' + CHAR(10) 
				+ REPLICATE(CHAR(9), 4) + 'SET @SectionColumnId = SCOPE_IDENTITY()' + CHAR(10) 
			FROM   PRODUCT.SectionColumn
			WHERE  SectionColumnId = @SectionColumnId
			AND @RunDate BETWEEN EffectiveDate AND ExpiryDate

			-- SectionColumnParameter
			IF OBJECT_ID ('tempdb..#sectionColumnParameter') IS NOT NULL 
				DROP TABLE #sectionColumnParameter
       
			CREATE TABLE #sectionColumnParameter
			(
				Id INT IDENTITY (1,1), 
				SectionColumnParameterId INT
			) 

			INSERT INTO #sectionColumnParameter
			SELECT SectionColumnParameterId
			FROM   PRODUCT.SectionColumnParameter
			WHERE  SectionColumnId = @SectionColumnId
			
			DECLARE @scp_count INT 
			SELECT  @scp_count = COUNT(1) FROM #sectionColumnParameter
			DECLARE @scp_ctr INT = 1 

			-- SectionColumnParameter loop starts  
			WHILE (@scp_ctr <= @scp_count)
			BEGIN
				SELECT @SectionColumnParameterId =  SectionColumnParameterId FROM  #sectionColumnParameter WHERE Id = @scp_ctr 

				INSERT INTO #tempSQL
				SELECT 
					  REPLICATE(CHAR(9), 5) + 'INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)' + CHAR(10) 
					+ REPLICATE(CHAR(9), 5) + 'VALUES('
					+ '@SectionColumnId' 
					+ ', ' + ISNULL(CAST (FilecolumnParameterId AS VARCHAR), 'NULL')
					+ ', ' + ISNULL('''' + Value + '''', 'NULL') + ')' + CHAR(10) 
				FROM   PRODUCT.SectionColumnParameter
				WHERE  SectionColumnParameterId = @SectionColumnParameterId

				SET @scp_ctr= @scp_ctr+1
			END 
			-- SectionColumnParameter loop ends

			SET @sc_ctr= @sc_ctr+1
		END 
		-- SectionColumn loop ends

		SET @s_ctr =@s_ctr+1
	END
    -- Section loop ends 

	--ProductFileValidationSettings
	INSERT INTO #tempSQL
	SELECT 
		  REPLICATE(CHAR(9), 2) + 'INSERT INTO PRODUCT.ProductFileValidationSettings(ProductId, AllowZeroByteFile, ExpectedFileSize, FileSizePercentageTolerance, NumberOfLines, NumberOfColumns)' + CHAR(10) 
		+ REPLICATE(CHAR(9), 2) + 'VALUES('
		+ '@ProductId' 
		+ ', ' + ISNULL(CAST (AllowZeroByteFile AS CHAR(1)), 'NULL') 
		+ ', ' + ISNULL(CAST (ExpectedFileSize AS VARCHAR), 'NULL')
		+ ', ' + ISNULL(CAST (FileSizePercentageTolerance AS VARCHAR), 'NULL')
		+ ', ' + ISNULL(CAST (NumberOfLines AS VARCHAR), 'NULL')
		+ ', ' + ISNULL(CAST (NumberOfColumns AS VARCHAR), 'NULL') + ')' + CHAR(10) 
	FROM   PRODUCT.ProductFileValidationSettings
	WHERE  ProductId = @ProductId
	--ProductFileValidationSettings ends

	--ProductDistributor
	IF OBJECT_ID ('tempdb..#productDistributor') IS NOT NULL 
		DROP TABLE #productDistributor
       
	CREATE TABLE #productDistributor
	(
		Id INT IDENTITY (1,1), 
		DistributorId INT
	) 

	INSERT INTO #productDistributor
	SELECT DistributorId
	FROM   PRODUCT.ProductDistributor
	WHERE  ProductId = @ProductId
			
	DECLARE @pdi_count INT 
	SELECT  @pdi_count = COUNT(1) FROM #productDistributor
	DECLARE @pdi_ctr INT = 1 

	--ProductDistributor loop starts  
	WHILE (@pdi_ctr <= @pdi_count)
	BEGIN
		SELECT @DistributorId =  DistributorId FROM  #productDistributor WHERE Id = @pdi_ctr 

		INSERT INTO #tempSQL
		SELECT 
			  REPLICATE(CHAR(9), 2) + 'INSERT INTO PRODUCT.ProductDistributor(ProductId, DistributorId)' + CHAR(10) 
			+ REPLICATE(CHAR(9), 2) + 'VALUES('
			+ '@ProductId' 
			+ ', ' + CAST (@DistributorId AS VARCHAR) + ')' + CHAR(10) 

		SET @pdi_ctr= @pdi_ctr+1
	END 
	--ProductDistributor loop ends

	--ProductEmail
	IF OBJECT_ID ('tempdb..#productEmail') IS NOT NULL 
		DROP TABLE #productEmail
       
	CREATE TABLE #productEmail
	(
		Id INT IDENTITY (1,1), 
		ProductEmailId INT
	) 

	INSERT INTO #productEmail
	SELECT ProductEmailId
	FROM   PRODUCT.ProductEmail
	WHERE  ProductId = @ProductId
			
	DECLARE @pem_count INT 
	SELECT  @pem_count = COUNT(1) FROM #productEmail
	DECLARE @pem_ctr INT = 1 

	--ProductEmail loop starts  
	WHILE (@pem_ctr <= @pem_count)
	BEGIN
		SELECT @ProductEmailId =  ProductEmailId FROM #productEmail WHERE Id = @pem_ctr 

		INSERT INTO #tempSQL
		SELECT 
			  REPLICATE(CHAR(9), 2) + 'INSERT INTO PRODUCT.ProductEmail(ProductId, EffectiveDate, ExpiryDate, SubjectText, BodyText, FromAddress, ToAddresses, CcAddresses, BccAddresses)' + CHAR(10) 
			+ REPLICATE(CHAR(9), 2) + 'VALUES('
			+ '@ProductId' 
			+ ', ' + ISNULL('''' + CAST (EffectiveDate AS VARCHAR) + '''', 'NULL') 
			+ ', ' + ISNULL('''' + CAST (ExpiryDate AS VARCHAR) + '''', 'NULL') 
			+ ', ' + ISNULL('''' + SubjectText + '''', 'NULL')
			+ ', ' + ISNULL('''' + BodyText + '''', 'NULL')
			+ ', ' + ISNULL('''' + FromAddress + '''', 'NULL')
			+ ', ' + ISNULL('''' + ToAddresses + '''', 'NULL')
			+ ', ' + ISNULL('''' + CcAddresses + '''', 'NULL')
			+ ', ' + ISNULL('''' + BccAddresses + '''', 'NULL') + ')' + CHAR(10) 
		FROM   PRODUCT.ProductEmail
		WHERE  ProductEmailId = @ProductEmailId
		AND @RunDate BETWEEN EffectiveDate AND ExpiryDate

		SET @pem_ctr= @pem_ctr+1
	END 
	--ProductEmail loop ends

	--ProductTokenValue
	IF OBJECT_ID ('tempdb..#productTokenValue') IS NOT NULL 
		DROP TABLE #productTokenValue
       
	CREATE TABLE #productTokenValue
	(
		Id INT IDENTITY (1,1), 
		ProductTokenValueId INT
	) 

	INSERT INTO #productTokenValue
	SELECT ProductTokenValueId
	FROM   PRODUCT.ProductTokenValue
	WHERE  ProductId = @ProductId
			
	DECLARE @ptv_count INT 
	SELECT  @ptv_count = COUNT(1) FROM #productTokenValue
	DECLARE @ptv_ctr INT = 1 

	--ProductTokenValue loop starts  
	WHILE (@ptv_ctr <= @ptv_count)
	BEGIN
		SELECT @ProductTokenValueId =  ProductTokenValueId FROM  #productTokenValue WHERE Id = @ptv_ctr 

		INSERT INTO #tempSQL
		SELECT 
			  REPLICATE(CHAR(9), 2) + 'INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)' + CHAR(10) 
			+ REPLICATE(CHAR(9), 2) + 'VALUES('
			+ '@ProductId' 
			+ ', ' + ISNULL('''' + CAST (EffectiveDate AS VARCHAR) + '''', 'NULL') 
			+ ', ' + ISNULL('''' + CAST (ExpiryDate AS VARCHAR) + '''', 'NULL') 
			+ ', ' + ISNULL('''' + Token + '''', 'NULL')
			+ ', ' + ISNULL('''' + Value + '''', 'NULL') + ')' + CHAR(10) 
		FROM   PRODUCT.ProductTokenValue
		WHERE  ProductTokenValueId = @ProductTokenValueId
		AND @RunDate BETWEEN EffectiveDate AND ExpiryDate

		SET @ptv_ctr= @ptv_ctr+1
	END 
	--ProductTokenValue loop ends
      
	INSERT INTO #tempSQL
	SELECT
		  REPLICATE(CHAR(9), 2) + '--Display Product Details' + CHAR(10)
		+ REPLICATE(CHAR(9), 2) + 'EXEC PRODUCT.displayproduct @ProductCode' + CHAR(10) + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + 'COMMIT TRAN' + CHAR(10) + CHAR(10)
		+ 'END TRY' + CHAR(10)
		+ 'BEGIN CATCH' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + 'DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + 'SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + 'IF @@TRANCOUNT > 0 ROLLBACK TRAN' + CHAR(10)
		+ REPLICATE(CHAR(9), 1) + 'RAISERROR(' + '''Error with code %d on line %d: %s''' + ', 16, 1, @error, @errorLine, @message)' + CHAR(10)
		+ 'END CATCH'

	SELECT txt FROM  #tempSQL order by id

END TRY

BEGIN CATCH	
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT;
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE();

	IF @@TRANCOUNT > 0 ROLLBACK TRAN

	RAISERROR('get_product_deployment_script: Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message);
END CATCH
GO

PRINT '<<< CREATED [PRODUCT].[get_product_deployment_script] >>>'
GO

