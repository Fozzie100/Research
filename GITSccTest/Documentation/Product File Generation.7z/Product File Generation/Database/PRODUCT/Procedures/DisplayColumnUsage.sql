USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DisplayColumnUsage]') AND type in (N'P', N'PC'))
BEGIN
    DROP PROCEDURE [PRODUCT].[DisplayColumnUsage]
    PRINT 'DROPPED PROCEDURE [PRODUCT].[DisplayColumnUsage]'
END
GO

CREATE PROCEDURE [PRODUCT].[DisplayColumnUsage]
(
    @procedure_name VARCHAR(MAX)
)
AS  

    SET NOCOUNT ON;

    --CHECK FOR SCHEMA
    SET @procedure_name = 
        CASE WHEN LEFT(@procedure_name, 7) = 'PRODUCT' THEN @procedure_name
        ELSE 'PRODUCT.' + @procedure_name
        END

    DECLARE @FileColumnId INT 
    SELECT  @FileColumnId = FileColumnId
    FROM    PRODUCT.FileColumn AS fc
    WHERE   fc.ProcedureName = @procedure_name

    SELECT  FileColumnId,
            Name
    FROM    PRODUCT.FileColumn AS fc
    WHERE   fc.FileColumnId = @FileColumnId

    SELECT  fcp.ParameterName,
            fcp.Description,
            fcp.DefaultValue
    FROM    PRODUCT.FileColumnParameter AS fcp
    WHERE   fcp.FileColumnId = @FileColumnId


    SELECT          p.Code AS product_code,
                    s.Sequence AS section,
                    sc.Description AS product_file_column_name,
                    sc.Sequence AS product_file_column_index
    FROM            PRODUCT.FileColumn AS fc
    INNER JOIN      PRODUCT.SectionColumn AS sc
    ON              fc.FileColumnId = sc.FileColumnId
    INNER JOIN      PRODUCT.Section AS s
    ON              sc.SectionId = s.SectionId
    INNER JOIN      PRODUCT.Product AS p
    ON              s.ProductId = p.ProductId
    WHERE           fc.ProcedureName = @procedure_name
    ORDER BY        p.Code

    SELECT          p.Code AS product_code,
                    sc.Description AS product_file_column_name,
                    fcp.ParameterName AS parameter_name,
                    scp.Value as parameter_value
    FROM            PRODUCT.FileColumn AS fc
    INNER JOIN      PRODUCT.SectionColumn AS sc
    ON              fc.FileColumnId = sc.FileColumnId
    INNER JOIN      PRODUCT.FileColumnParameter AS fcp
    ON              fc.FileColumnId = fcp.FileColumnId
    INNER JOIN      PRODUCT.SectionColumnParameter AS scp
    ON              scp.SectionColumnId = sc.SectionColumnId
    AND             scp.FileColumnParameterId = fcp.FileColumnParameterId
    INNER JOIN      PRODUCT.Section AS s
    ON              sc.SectionId = s.SectionId
    INNER JOIN      PRODUCT.Product AS p
    ON              s.ProductId = p.ProductId
    WHERE           fc.ProcedureName = @procedure_name
    ORDER BY        p.Code

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT].[DisplayColumnUsage]') AND type in (N'P', N'PC'))
BEGIN
    PRINT 'CREATED [PRODUCT].[DisplayColumnUsage]'
END
GO