USE [EXPORT]
GO

/****** Object:  StoredProcedure [PRODUCT].[CreateProductLog]    Script Date: 26/05/2015 14:14:05 ******/

IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[PRODUCT].[CreateProductLog]')
                    AND type IN ( N'P', N'PC' ) )
BEGIN
	PRINT 'DROP SPROC [PRODUCT].[CreateProductLog]'
    DROP PROCEDURE [PRODUCT].[CreateProductLog]

END
GO
/*****************************************************************************************************************************  
 Procedure:  	PRODUCT.CreateProductLog
 Description:	Logs Product file production metrics.
											
				
 Used By:    	PRIME - ProductFileGenerator
   
 ---------------------------------------------------------------------------------------------------------------------------  
 Revision History:  Name:  	Date:   		Description:
					
					PP		26/05/2015		Created

*****************************************************************************************************************************/
CREATE PROCEDURE  [PRODUCT].[CreateProductLog] (@ProductCode VARCHAR(50),
												@DataDate DATE,
												@ProductGenerationFilePath VARCHAR(500),
           										@IniGenerationFilePath VARCHAR(500),
           										@ProductArchiveFilePath VARCHAR(500),
           										@IniArchiveFilePath VARCHAR(500),
												@ProductFileStartTime DATETIME,
												@ProductFileEndTime DATETIME,
												@ProductFileSizeBytes BIGINT,
												@ProductFileRowCount INT,
												@ProductFileColCount INT
												
												)
AS
BEGIN           											     
DECLARE @ProductId INT

	SELECT @ProductId = ProductId
	FROM PRODUCT.Product
	WHERE Code = @ProductCode
	
	INSERT INTO [EXPORT].[PRODUCT].[ProductLog]
			   ([ProductId]
			   ,[DataDate]
			   ,[ProductGenerationFilePath]
			   ,[IniGenerationFilePath]
			   ,[ProductArchiveFilePath]
			   ,[IniArchiveFilePath]

			   ,[ProductFileStartTime] 
			   ,[ProductFileEndTime]
			   ,[ProductFileSizeBytes]
			   ,[ProductFileRowCount]
			   ,[ProductFileColCount])
		 VALUES
			   (@ProductId,
			   @DataDate,
			   @ProductGenerationFilePath,
			   @IniGenerationFilePath,
			   @ProductArchiveFilePath,
			   @IniArchiveFilePath,
			   @ProductFileStartTime,
			   @ProductFileEndTime,
			   @ProductFileSizeBytes,
			   @ProductFileRowCount,
			   @ProductFileColCount
			   )

END

GO


