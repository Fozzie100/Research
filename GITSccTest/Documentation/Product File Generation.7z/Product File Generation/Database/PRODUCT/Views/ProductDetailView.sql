IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductDetailView]'))
BEGIN
	DROP VIEW [PRODUCT].[ProductDetailView]
	PRINT '<<< DROPPED VIEW [PRODUCT].[ProductDetailView] >>>'
END
GO

CREATE VIEW [PRODUCT].[ProductDetailView]
AS

	SELECT
		Product.ProductId,
		ProductGroup.Name AS ProductGroup,
		DataSource.Name AS DataSource,
		Product.Name,
		Product.Code,
		Product.FileSuffix,
		Product.Delimiter,
		ProductDetail.EffectiveDate,
		ProductDetail.ExpiryDate, 
		ProductDetail.HeaderText,
		ProductDetail.FooterText,
		Product.IsTemplate,
		Product.TemplateProductId,
		Template.Code AS TemplateProductCode
	FROM
		PRODUCT.Product
	INNER JOIN
		PRODUCT.DataSource
	ON
		Product.DataSourceId = DataSource.DataSourceId
	INNER JOIN
		PRODUCT.ProductGroup
	ON
		Product.ProductGroupId = ProductGroup.ProductGroupId
	LEFT OUTER JOIN
		PRODUCT.ProductDetail
	ON
		Product.ProductId = ProductDetail.ProductId
	LEFT OUTER JOIN
		PRODUCT.Product AS Template
	ON
		Product.TemplateProductId = Template.ProductId
		
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductDetailView]'))
	PRINT '<<< CREATED VIEW [PRODUCT].[ProductDetailView] >>>'
ELSE
	PRINT '<<< FAILED VIEW [PRODUCT].[ProductDetailView] >>>'
GO