IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductParameterDetailView]'))
BEGIN
	DROP VIEW [PRODUCT].[ProductParameterDetailView]
	PRINT '<<< DROPPED VIEW [PRODUCT].[ProductParameterDetailView] >>>'
END
GO

CREATE VIEW [PRODUCT].[ProductParameterDetailView]
AS

	SELECT
		Section.ProductId,
		Section.SectionId,
		SectionColumn.FileColumnId,
		SectionColumn.SectionColumnId,
		SectionColumnParameterId,
		SectionColumn.Sequence,
		FileColumnParameter.FileColumnParameterId,
		SectionColumn.Description AS SectionColumnDescription,
		SectionColumn.EffectiveDate,
		SectionColumn.ExpiryDate,		
		FileColumnParameter.Description AS ParameterDescription, 
		FileColumnParameter.ParameterName,
		FileColumnParameter.DefaultValue,
		SectionColumnParameter.Value AS UserProvidedValue
	FROM
		PRODUCT.SectionColumn
	INNER JOIN
		PRODUCT.FileColumn
	ON
		PRODUCT.FileColumn.FileColumnId = SectionColumn.FileColumnId
	INNER JOIN
		PRODUCT.Section
	ON
		SectionColumn.SectionId = Section.SectionId
	INNER JOIN
		PRODUCT.FileColumnParameter
	ON
		FileColumn.FileColumnId = FileColumnParameter.FileColumnId
	LEFT OUTER JOIN
		PRODUCT.SectionColumnParameter
	ON
		SectionColumnParameter.SectionColumnId = SectionColumn.SectionColumnId
	AND
		SectionColumnParameter.FileColumnParameterId = FileColumnParameter.FileColumnParameterId

GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductParameterDetailView]'))
	PRINT '<<< CREATED VIEW [PRODUCT].[ProductParameterDetailView] >>>'
ELSE
	PRINT '<<< FAILED VIEW [PRODUCT].[ProductParameterDetailView] >>>'
GO