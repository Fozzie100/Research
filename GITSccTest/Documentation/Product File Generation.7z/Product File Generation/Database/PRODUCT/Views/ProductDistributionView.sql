USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductDistributionView]'))
BEGIN
	DROP VIEW [PRODUCT].[ProductDistributionView]
	PRINT '<<< DROPPED VIEW [PRODUCT].[ProductDistributionView] >>>'
END
GO

CREATE VIEW [PRODUCT].[ProductDistributionView]
AS

	SELECT  pd.ProductId,
	        p.Code,
	        d.Name,
		    d.ItemKey,
		    d.FileType,
		    d.DistributionType,
		    CASE    WHEN d.Active = 1 THEN 'Active'
		            ELSE 'Inactive'
		            END AS Active,				
		    CASE    WHEN UPPER(d.DistributionType) = 'FILE SYSTEM' THEN filed.DestinationDirectory
			        WHEN UPPER(d.DistributionType) = 'FTP' THEN ftp.RemoteDirectory
			        END AS Destination
	FROM            PRODUCT.ProductDistributor AS pd
	INNER JOIN      PRODUCT.Distributor AS d
	ON              pd.DistributorId = d.DistributorId
	INNER JOIN      PRODUCT.Product AS p
	ON              pd.ProductId = p.ProductId
    LEFT OUTER JOIN PRODUCT.FtpDistributor AS ftp
	ON              d.ItemKey = ftp.Id
	LEFT OUTER JOIN PRODUCT.FileDistributor AS filed
	ON              d.ItemKey = filed.Id

GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductDistributionView]'))
	PRINT '<<< CREATED VIEW [PRODUCT].[ProductDistributionView] >>>'
ELSE
	PRINT '<<< FAILED VIEW [PRODUCT].[ProductDistributionView] >>>'
GO