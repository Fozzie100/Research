IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductColumnDetailView]'))
BEGIN
	DROP VIEW [PRODUCT].[ProductColumnDetailView]
	PRINT '<<< DROPPED VIEW [PRODUCT].[ProductColumnDetailView] >>>'
END
GO

CREATE VIEW [PRODUCT].[ProductColumnDetailView]
AS

	SELECT
		Section.ProductId,
		SectionColumn.SectionId,
		Section.Name AS SectionName,
		FileColumn.FileColumnId,
		SectionColumnId,
		Section.Sequence AS SectionSequence,
		SectionColumn.Sequence AS ColumnSequence,
		SectionColumn.Description AS SectionColumnHeading,
		FileColumn.Name AS FileColumnName,
		FileColumn.ProcedureName,
		SectionColumn.SortOrder,
		SectionColumn.EffectiveDate,
		SectionColumn.ExpiryDate,
		CASE WHEN SectionColumn.QuoteValues = 1 THEN 'YES' ELSE 'NO' END AS QuoteValues,
		SectionColumn.ValidationRules,
		SectionColumn.FormatArguments
	FROM
		PRODUCT.FileColumn
	INNER JOIN
		PRODUCT.SectionColumn
	ON
		FileColumn.FileColumnId = SectionColumn.FileColumnId
	INNER JOIN
		PRODUCT.Section
	ON
		Section.SectionId = SectionColumn.SectionId

GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductColumnDetailView]'))
	PRINT '<<< CREATED VIEW [PRODUCT].[ProductColumnDetailView] >>>'
ELSE
	PRINT '<<< FAILED VIEW [PRODUCT].[ProductColumnDetailView] >>>'
GO