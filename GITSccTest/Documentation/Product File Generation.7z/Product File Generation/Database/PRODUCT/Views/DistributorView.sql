USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[DistributorView]'))
BEGIN
	DROP VIEW [PRODUCT].[DistributorView]
	PRINT '<<< DROPPED VIEW [PRODUCT].[DistributorView] >>>'
END
GO

CREATE VIEW [PRODUCT].[DistributorView]
AS

	SELECT
		Distributor.DistributorId,
		Distributor.Name,
		Distributor.ItemKey,
		Distributor.FileType,
		Distributor.DistributionType,
		CASE 
			WHEN Distributor.Active = 1 THEN 'Active'
			ELSE 'Inactive'
		END AS Active,		
		CASE
			WHEN UPPER(Distributor.DistributionType) = 'FILE SYSTEM'
				THEN FileDistributor.DestinationDirectory
			WHEN UPPER(Distributor.DistributionType) = 'FTP'
				THEN FtpDistributor.RemoteDirectory
		END AS Destination
	FROM
		PRODUCT.Distributor
	LEFT OUTER JOIN
		PRODUCT.FtpDistributor
	ON
		Distributor.ItemKey = FtpDistributor.Id
	LEFT OUTER JOIN
		PRODUCT.FileDistributor
	ON
		Distributor.ItemKey = FileDistributor.Id

GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[DistributorView]'))
	PRINT '<<< CREATED VIEW [PRODUCT].[DistributorView] >>>'
ELSE
	PRINT '<<< FAILED VIEW [PRODUCT].[DistributorView] >>>'
GO