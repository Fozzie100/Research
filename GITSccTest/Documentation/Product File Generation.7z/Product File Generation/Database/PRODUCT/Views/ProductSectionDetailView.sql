IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductSectionDetailView]'))
BEGIN
	DROP VIEW [PRODUCT].[ProductSectionDetailView]
	PRINT '<<< DROPPED VIEW [PRODUCT].[ProductSectionDetailView] >>>'
END
GO

CREATE VIEW [PRODUCT].[ProductSectionDetailView]
AS

	SELECT
		Section.SectionId,
		SectionDetail.SectionDetailId,
		Section.ProductId,
		Section.Name,
		Section.SectionType,
		Section.Sequence,
		SectionDetail.ProcedureName, 
		SectionDetail.EffectiveDate,
		SectionDetail.ExpiryDate,
		SectionDetail.OutputColumnNames,
		SectionDetail.HeaderText,
		SectionDetail.FooterText
	FROM
		PRODUCT.Section
	INNER JOIN
		PRODUCT.SectionDetail
	ON
		Section.SectionId = SectionDetail.SectionId

GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductSectionDetailView]'))
	PRINT '<<< CREATED VIEW [PRODUCT].[ProductSectionDetailView] >>>'
ELSE
	PRINT '<<< FAILED VIEW [PRODUCT].[ProductSectionDetailView] >>>'
GO