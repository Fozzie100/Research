USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductSectionParameterDetailView]'))
BEGIN
	DROP VIEW [PRODUCT].[ProductSectionParameterDetailView]
	PRINT '<<< DROPPED VIEW [PRODUCT].[ProductSectionParameterDetailView] >>>'
END
GO

CREATE VIEW [PRODUCT].[ProductSectionParameterDetailView]
AS

	SELECT
		Section.ProductId,
		Section.SectionId,
		Section.Sequence,
		SectionDetail.SectionDetailId,
		SectionDetailParameterId,
		SectionDetail.EffectiveDate,
		SectionDetail.ExpiryDate,			
		Section.Name AS SectionName,
		ParameterName,
		Value
	FROM
		PRODUCT.Section
	INNER JOIN
		PRODUCT.SectionDetail
	ON
		Section.SectionId = SectionDetail.SectionId
	INNER JOIN
		PRODUCT.SectionDetailParameter
	ON
		SectionDetail.SectionDetailId = SectionDetailParameter.SectionDetailId

GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[PRODUCT].[ProductSectionParameterDetailView]'))
	PRINT '<<< CREATED VIEW [PRODUCT].[ProductSectionParameterDetailView] >>>'
ELSE
	PRINT '<<< FAILED VIEW [PRODUCT].[ProductSectionParameterDetailView] >>>'
GO