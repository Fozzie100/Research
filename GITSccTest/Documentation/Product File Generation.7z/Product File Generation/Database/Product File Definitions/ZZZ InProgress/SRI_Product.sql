USE PRIME
GO

--DROP PROCEDURE [PRODUCT].[SRI_Product]
GO

ALTER PROCEDURE [PRODUCT].[SRI_Product]
(
	@p_date DATETIME,
	@scheme VARCHAR(32),
	@universe VARCHAR(32),
	@format VARCHAR(2),
	@delimiter VARCHAR(1)
)
AS
	
	CREATE TABLE #keys (
	instrument_id                 INT,
	data_date                     DATETIME,
	previous_instrument_id        INT,
	previous_scheme_data_date     DATETIME,
	previous_pillar_data_date     DATETIME,
	previous_theme_data_date      DATETIME,
	not_researched                INT,
	f4g                           VARCHAR(2),
	f4g_excluded_activity         VARCHAR(2),
	txt                           VARCHAR(MAX),
	[Cons Code]						VARCHAR(50),
	[SEDOL] VARCHAR(50),
	[ISIN] VARCHAR(50),
	[Local Identifier] VARCHAR(50),
	[CUSIP]VARCHAR(50),
	[Constituent name] VARCHAR(200),
	[Country code] VARCHAR(50),
	[ISO Code] VARCHAR(50),
	[Exchange code] VARCHAR(50),
	[Industry Code] VARCHAR(50),
	[Supersector Code] VARCHAR(50),
	[Sector Code] VARCHAR(50),
	[Subsector Code] VARCHAR(50),
	[Overall Rating (Absolute)] VARCHAR(50),
	[Overall Rating (Sector Relative)] VARCHAR(50),
	[Previous Overall Rating (Sector Relative)] VARCHAR(50),
	[Environmental Pillar Risk] VARCHAR(50),
	[Previous Environmental Pillar Risk] VARCHAR(50),
	[Environmental Pillar Score (Absolute)] VARCHAR(50),
	[Environmental Pillar Score (Sector Relative)] VARCHAR(50),
	[Previous Environmental Pillar Score (Sector Relative)] VARCHAR(50),
	[Social Pillar Risk] VARCHAR(50),
	[Previous Social Pillar Risk] VARCHAR(50),
	[Social Pillar Score (Absolute)] VARCHAR(50),
	[Social Pillar Score (Sector Relative)] VARCHAR(50),
	[Previous Social Pillar Score (Sector Relative)] VARCHAR(50),
	[Governance Pillar Risk] VARCHAR(50),
	[Previous Governance Pillar Risk] VARCHAR(50),
	[Governance Pillar Score (Absolute)] VARCHAR(50),
	[Governance Pillar Score (Sector Relative)] VARCHAR(50),
	[Previous Governance Pillar Score (Sector Relative)] VARCHAR(50),
	[Included in F4G Series] VARCHAR(50),
	[F4G Excluded Activity] VARCHAR(50),
	[Environmental Management Risk] VARCHAR(50),
	[Previous Environmental Management Risk] VARCHAR(50),
	[Environmental Management Score] VARCHAR(50),
	[Previous Environmental Management Score] VARCHAR(50),
	[Climate Change Risk] VARCHAR(50),
	[Previous Climate Change Risk] VARCHAR(50),
	[Climate Change Score] VARCHAR(50),
	[Previous Climate Change Score] VARCHAR(50),
	[Human and Labour Rights Risk] VARCHAR(50),
	[Previous Human and Labour Rights Risk] VARCHAR(50),
	[Human and Labour Rights Score] VARCHAR(50),
	[Previous Human and Labour Rights Score] VARCHAR(50),
	[Supply Chain Labour Standards Risk] VARCHAR(50),
	[Previous Supply Chain Labour Standards Risk] VARCHAR(50),
	[Supply Chain Labour Standards Score] VARCHAR(50),
	[Previous Supply Chain Labour Standards Score] VARCHAR(50),
	[Countering Bribery Risk] VARCHAR(50),
	[Previous Countering Bribery Risk] VARCHAR(50),
	[Countering Bribery Score] VARCHAR(50),
	[Previous Countering Bribery Score] VARCHAR(50),
	[Corporate Governance Risk] VARCHAR(50),
	[Previous Corporate Governance Risk] VARCHAR(50),
	[Corporate Governance Score] VARCHAR(50),
	[Previous Corporate Governance Score] VARCHAR(50)
	)

	CREATE TABLE #text (text  VARCHAR(MAX))

	DECLARE @logdir VARCHAR(128)
	DECLARE @logfile VARCHAR(256)
	DECLARE @message VARCHAR(MAX)
	SELECT @logdir = '\\' + LEFT(@@SERVERNAME, CHARINDEX('\', @@SERVERNAME))

	print @logdir


	CREATE TABLE #LogData (logfile VARCHAR(128))
	INSERT INTO #LogData VALUES(@logdir + 'AppLog\PRODUCTS\' + @scheme + @universe + '.' + CONVERT(VARCHAR, getdate(), 112) + '.log')	

	SELECT @logfile = logfile
	FROM #LogData
	
	EXEC UTILITY.dbo.CreateLogFile 'starts', @logfile
	
	SET @message = 'inserting instruments'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	IF @universe = 'FULL'
		
		
		INSERT INTO #keys(instrument_id)
		SELECT sd.instrument_id
		FROM   RA.sri.schemes s
		       INNER JOIN RA.sri.scheme_data_snapshot sd
		ON     sd.scheme_id = s.scheme_id
		AND    sd.day = @p_date
		WHERE  s.scheme_mnemonic = @scheme
		AND    @p_date BETWEEN s.start_date AND s.end_date

  ELSE IF @universe IN ('SP')

		INSERT INTO #keys(instrument_id)
		SELECT sd.instrument_id
		FROM   RA.sri.schemes s
		       INNER JOIN RA.sri.scheme_data_snapshot sd
		ON     sd.scheme_id = s.scheme_id
		AND    sd.day = @p_date
             inner join WORLD_INDEX.dbo.instrument i
    ON     i.code = sd.instrument_id
    AND    i.country = @universe
		WHERE  s.scheme_mnemonic = @scheme
		AND    @p_date BETWEEN s.start_date AND s.end_date

	ELSE
	
		INSERT INTO #keys(instrument_id)
		SELECT constituent_code
		FROM   WORLD_INDEX.dbo.ccr_snapshot c, WORLD_INDEX.dbo.index_constituent_v v
		WHERE  c.xtype = 'DG'
		AND    c.xref = @universe
		AND    c.day = @p_date
		AND    v.index_code = c.instrument
		AND    v.day = c.day
	
	
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	-- Data date.
	SET @message = 'inserting dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	UPDATE k
	SET    k.previous_instrument_id = k.instrument_id,
	       k.data_date = (SELECT MAX(sd.data_date)
	                      FROM   RA.sri.schemes s
	                             INNER JOIN RA.sri.scheme_data_snapshot sd
	                      ON     sd.scheme_id = s.scheme_id
	                      AND    sd.instrument_id = k.instrument_id
	                      AND    sd.day = @p_date
	                      WHERE  s.scheme_mnemonic = @scheme
		                    AND    @p_date BETWEEN s.start_date AND s.end_date
	                     )
	FROM   #keys k

	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	-- Data date.
	SET @message = 'inserting previous dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	-- Previous data date.

	UPDATE k
	SET    k.previous_scheme_data_date = (SELECT MAX(sd.data_date)
	                                      FROM   RA.sri.schemes s
	                                      INNER JOIN RA.sri.scheme_data_snapshot sd
       	                                ON     sd.scheme_id = s.scheme_id
	                                      AND    sd.instrument_id = k.previous_instrument_id
	                                      AND    sd.day = k.data_date - 1
	                                      WHERE  s.scheme_mnemonic = @scheme
		                                    AND    @p_date BETWEEN s.start_date AND s.end_date
	                                     )
	FROM   #keys k
	
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' previous dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	-- Data date.
	SET @message = 'inserting pillar dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	
	
	UPDATE k
	SET    k.previous_pillar_data_date = (SELECT MAX(pd.data_date)
		                                    FROM   RA.sri.schemes s
			                                         INNER JOIN RA.sri.scheme_structure ss
		                                    ON     ss.scheme_id = s.scheme_id
		                                    AND    @p_date BETWEEN ss.start_date AND ss.end_date
			                                         INNER JOIN RA.sri.pillars p
		                                    ON     p.pillar_id = ss.pillar_id
		                                    AND    @p_date BETWEEN p.start_date AND p.end_date
	                                             INNER JOIN RA.sri.pillar_data_snapshot pd
       	                                ON     pd.pillar_id = p.pillar_id
	                                      AND    pd.instrument_id = k.previous_instrument_id
	                                      AND    pd.day = k.data_date - 1
		                                    WHERE  s.scheme_mnemonic = @scheme
		                                    AND    @p_date BETWEEN s.start_date AND s.end_date
	                                     )
	FROM   #keys k

	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' pillar dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	-- Data date.
	SET @message = 'inserting theme dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	UPDATE k
	SET    k.previous_theme_data_date = (SELECT MAX(td.data_date)
			                                 FROM   RA.sri.schemes s
				                                      INNER JOIN RA.sri.scheme_structure ss
			                                 ON     ss.scheme_id = s.scheme_id
			                                 AND    @p_date BETWEEN ss.start_date AND ss.end_date
				                                      INNER JOIN RA.sri.pillars p
			                                 ON     p.pillar_id = ss.pillar_id
			                                 AND    @p_date BETWEEN p.start_date AND p.end_date
				                                      INNER JOIN RA.sri.pillar_structure ps
			                                 ON     ps.pillar_id = ss.pillar_id
			                                 AND    @p_date BETWEEN ps.start_date AND ps.end_date
				                                      INNER JOIN RA.sri.themes t
			                                 ON     t.theme_id = ps.theme_id
			                                 AND    @p_date BETWEEN t.start_date AND t.end_date
	                                            INNER JOIN RA.sri.theme_data_snapshot td
       	                               ON     td.theme_id = t.theme_id
	                                     AND    td.instrument_id = k.previous_instrument_id
	                                     AND    td.day = k.data_date - 1
			                                 WHERE  s.scheme_mnemonic = @scheme
			                                 AND    @p_date BETWEEN s.start_date AND s.end_date
                                      )
	FROM   #keys k

	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' theme dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	SET @message = 'inserting instrument id'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	-- Previous instrument id. (check for demergers)
	UPDATE k
	SET    k.previous_instrument_id = d.parent_instrument_id
	FROM   #keys k
	       INNER JOIN RA.sri.demerger_data d
	ON     d.demerged_instrument_id = k.instrument_id
	AND    d.effective_date <= k.data_date
	WHERE  k.previous_scheme_data_date IS NULL

	UPDATE k
	SET    k.data_date = (SELECT MAX(sd.data_date)
	                      FROM   RA.sri.schemes s
	                             INNER JOIN RA.sri.scheme_data_snapshot sd
	                      ON     sd.scheme_id = s.scheme_id
	                      AND    sd.instrument_id = k.previous_instrument_id
	                      AND    sd.day = @p_date
	                      WHERE  s.scheme_mnemonic = @scheme
		                    AND    @p_date BETWEEN s.start_date AND s.end_date
	                     )
	FROM   #keys k
  WHERE  k.data_date IS NULL
  
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' instrument ids'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	SET @message = 'inserting previous scheme dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	  
  
	UPDATE k
	SET    k.previous_scheme_data_date = (SELECT MAX(sd.data_date)
	                                      FROM   RA.sri.schemes s
	                                      INNER JOIN RA.sri.scheme_data_snapshot sd
       	                                ON     sd.scheme_id = s.scheme_id
	                                      AND    sd.instrument_id = k.previous_instrument_id
	                                      AND    sd.day = k.data_date - 1
	                                      WHERE  s.scheme_mnemonic = @scheme
		                                    AND    @p_date BETWEEN s.start_date AND s.end_date
	                                     )
	FROM   #keys k
	WHERE  k.previous_scheme_data_date IS NULL
	
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' theme dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	SET @message = 'inserting previous pillar dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	UPDATE k
	SET    k.previous_pillar_data_date = (SELECT MAX(pd.data_date)
		                                    FROM   RA.sri.schemes s
			                                         INNER JOIN RA.sri.scheme_structure ss
		                                    ON     ss.scheme_id = s.scheme_id
		                                    AND    @p_date BETWEEN ss.start_date AND ss.end_date
			                                         INNER JOIN RA.sri.pillars p
		                                    ON     p.pillar_id = ss.pillar_id
		                                    AND    @p_date BETWEEN p.start_date AND p.end_date
	                                             INNER JOIN RA.sri.pillar_data_snapshot pd
       	                                ON     pd.pillar_id = p.pillar_id
	                                      AND    pd.instrument_id = k.previous_instrument_id
	                                      AND    pd.day = k.data_date - 1
		                                    WHERE  s.scheme_mnemonic = @scheme
		                                    AND    @p_date BETWEEN s.start_date AND s.end_date
	                                     )
	FROM   #keys k
	WHERE  k.previous_pillar_data_date IS NULL
	
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' previous pillar dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	SET @message = 'inserting previous theme dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	UPDATE k
	SET    k.previous_theme_data_date = (SELECT MAX(td.data_date)
			                                 FROM   RA.sri.schemes s
				                                      INNER JOIN RA.sri.scheme_structure ss
			                                 ON     ss.scheme_id = s.scheme_id
			                                 AND    @p_date BETWEEN ss.start_date AND ss.end_date
				                                      INNER JOIN RA.sri.pillars p
			                                 ON     p.pillar_id = ss.pillar_id
			                                 AND    @p_date BETWEEN p.start_date AND p.end_date
				                                      INNER JOIN RA.sri.pillar_structure ps
			                                 ON     ps.pillar_id = ss.pillar_id
			                                 AND    @p_date BETWEEN ps.start_date AND ps.end_date
				                                      INNER JOIN RA.sri.themes t
			                                 ON     t.theme_id = ps.theme_id
			                                 AND    @p_date BETWEEN t.start_date AND t.end_date
	                                            INNER JOIN RA.sri.theme_data_snapshot td
       	                               ON     td.theme_id = t.theme_id
	                                     AND    td.instrument_id = k.previous_instrument_id
	                                     AND    td.day = k.data_date - 1
			                                 WHERE  s.scheme_mnemonic = @scheme
			                                 AND    @p_date BETWEEN s.start_date AND s.end_date
                                      )
	FROM   #keys k
	WHERE  k.previous_theme_data_date IS NULL
	
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' previous theme dates'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	SET @message = 'inserting not researched'
	EXEC UTILITY.dbo.Message @message, @logfile
		
	-- Not researched.
	UPDATE k
	SET    not_researched = (SELECT COUNT(1)
	                         FROM   RA.sri.schemes s
	                                INNER JOIN RA.sri.scheme_data sd
	                         ON     sd.scheme_id = s.scheme_id
	                         AND    sd.instrument_id = k.instrument_id
	                         AND    sd.data_date = k.data_date
	                         AND    sd.status = 'nc'
	                         WHERE  s.scheme_mnemonic = @scheme
	                        )
	FROM   #keys k 
	
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' not researched'
	EXEC UTILITY.dbo.Message @message, @logfile
	

	SET @message = 'inserting f4g flags'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	
	-- f4g flags.
	UPDATE k
	SET    k.f4g = c.f4g, k.f4g_excluded_activity = c.f4g_excluded_activity
	FROM   #keys k 
	       INNER JOIN RA.sri.schemes s
	ON     s.scheme_mnemonic = @scheme
	       INNER JOIN RA.sri.company_snapshot c
	ON     c.scheme_id = s.scheme_id
	AND    c.instrument_id = k.instrument_id
	AND    c.day = @p_date
	/*
	SELECT * 
	FROM   #keys
	WHERE  instrument_id IN (
	1728748
  )*/
	
	SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' f4g flags'
	EXEC UTILITY.dbo.Message @message, @logfile

	SET @message = 'updating text'
	EXEC UTILITY.dbo.Message @message, @logfile
		
	-- Now the text.
	--Breaks this into bits so that it runs fairly quickly at all times
	DECLARE @id INT
	CREATE TABLE #instruments
	(
		id INT identity(1, 1),
		instrument_id INT 
	)
	
	INSERT INTO #instruments
	SELECT distinct instrument_id 
	FROM #keys
	
	SELECT @id = 0
	WHILE EXISTS(SELECT * from #instruments WHERE id > @id)
	BEGIN
		UPDATE k
		SET 
			txt = '',
			[cons Code] = 'C' + 
							RTRIM(COALESCE((	SELECT xref from WORLD_INDEX.dbo.ccr_snapshot
																WHERE     instrument = k.instrument_id
																AND    xtype = 'CONS'
																AND    day = @p_date), '')),
			[SEDOL] =		RTRIM(COALESCE((	SELECT xref from WORLD_INDEX.dbo.ccr_snapshot
																WHERE     instrument = k.instrument_id
																AND    xtype = 'SEDL'
																AND    day = @p_date), '')),														
			[ISIN] = 			RTRIM(COALESCE((	SELECT xref from WORLD_INDEX.dbo.ccr_snapshot
																WHERE     instrument = k.instrument_id
																AND    xtype = 'ISIN'
																AND    day = @p_date), '')),									
			[CUSIP] = 			RTRIM(COALESCE((	SELECT xref from WORLD_INDEX.dbo.ccr_snapshot
																WHERE     instrument = k.instrument_id
																AND    xtype = 'CUSIP'
																AND    day = @p_date), '')),																
			[Local Identifier] = c4.xref,
			[Constituent name] = i.legal_name,
			[Country code] = CASE WHEN i.country = 'IND' THEN 'IDA' ELSE RTRIM(COALESCE(i.country, '')) END,
			[ISO Code] = CASE WHEN c6.xref = 'PNC' THEN 'GBX' ELSE RTRIM(COALESCE(c6.xref, '')) END,
			[Exchange code] = RTRIM(l.report_name),
			[Industry Code] = WORLD_INDEX.dbo.icb_industry(ss.subsector),
			[Supersector Code] = WORLD_INDEX.dbo.icb_supersector(ss.subsector),
			[Sector Code] = WORLD_INDEX.dbo.icb_sector(ss.subsector),
			[Subsector Code] = ss.subsector,
			[Overall Rating (Absolute)] = CASE WHEN @format IN ('A', 'S') THEN RA.sri.nformat(sd.rating_absolute, 1, 'nc') ELSE '' END,
			[Overall Rating (Sector Relative)] = CASE WHEN @format IN ('A', 'S') THEN RA.sri.nformat(sd.rating_sector_relative, 6, 'nc') ELSE '' END,
			[Previous Overall Rating (Sector Relative)] = CASE WHEN @format = 'A' THEN RA.sri.nformat(sdp.rating_sector_relative, 6, 'nc') ELSE '' END
		FROM   #instruments instr
		INNER JOIN #keys k
		ON		 k.instrument_id = instr.instrument_id
			AND instr.id BETWEEN @id AND @id + 99
		INNER JOIN WORLD_INDEX.dbo.instrument i
		ON     i.code = k.instrument_id
					 INNER JOIN RA.sri.schemes s
		ON     s.scheme_mnemonic = @scheme
		AND    @p_date BETWEEN s.start_date AND s.end_date
					 LEFT OUTER JOIN WORLD_INDEX.dbo.instrument_exchange_snapshot x
		ON     x.instrument = k.instrument_id
		AND    x.day = @p_date
					 LEFT OUTER JOIN WORLD_INDEX.dbo.lookup l
		ON     l.lookup_type = 'WIEXCH'
		AND    l.lookup_code = x.exchange
					 LEFT OUTER JOIN WORLD_INDEX.dbo.market m
		ON     m.code = x.exchange
					 LEFT OUTER JOIN WORLD_INDEX.dbo.ccr_snapshot c4
		ON     c4.instrument = k.instrument_id
		AND    c4.xtype = m.local_code_type
		AND    c4.day = @p_date
					 LEFT OUTER JOIN WORLD_INDEX.dbo.ccr_snapshot c6
		ON     c6.instrument = i.currency
		AND    c6.xtype = 'ISO'
		AND    c6.day = @p_date
					 LEFT OUTER JOIN WORLD_INDEX.dbo.instrument_industry_snapshot ss
		ON     ss.instrument = k.instrument_id
		AND    ss.source = 'ICB'
		AND    ss.day = @p_date
					 LEFT OUTER JOIN RA.sri.scheme_data_snapshot sd
		ON     sd.scheme_id = s.scheme_id
		AND    sd.instrument_id = k.instrument_id
		AND    sd.day = k.data_date
					 LEFT OUTER JOIN RA.sri.scheme_data sdp
		ON     sdp.scheme_id = s.scheme_id
		AND    sdp.instrument_id = k.previous_instrument_id
		AND    sdp.data_date = k.previous_scheme_data_date
		       
		SET @message = 'updated ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' text values:@id=' + CONVERT(varchar, @id)
		EXEC UTILITY.dbo.Message @message, @logfile
		
		SELECT @id = @id + 100
	END	

	SET @message = 'updating pillar data'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	
	-- Add in the pillar data.
	DECLARE c_pillars CURSOR FOR
		SELECT p.pillar_id
		FROM   RA.sri.schemes s
			     INNER JOIN RA.sri.scheme_structure ss
		ON     ss.scheme_id = s.scheme_id
		AND    @p_date BETWEEN ss.start_date AND ss.end_date
			     INNER JOIN RA.sri.pillars p
		ON     p.pillar_id = ss.pillar_id
		AND    @p_date BETWEEN p.start_date AND p.end_date
		AND    CASE WHEN @format = 'EP' AND p.pillar_mnemonic = 'ENVIRONMENT' THEN 'Y'
		            WHEN @format = 'SP' AND p.pillar_mnemonic = 'SOCIAL'      THEN 'Y'
		            WHEN @format = 'GP' AND p.pillar_mnemonic = 'GOVERNANCE'  THEN 'Y'
		            WHEN @format IN ('A', 'S') THEN 'Y'
		            ELSE 'N'
		        END = 'Y'
		WHERE  s.scheme_mnemonic = @scheme
		AND    @p_date BETWEEN s.start_date AND s.end_date
		ORDER BY p.pillar_id

	DECLARE @pillar_id  INT
	
	OPEN c_pillars
	FETCH NEXT FROM c_pillars INTO @pillar_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	
		UPDATE k
		SET    
			[Previous Governance Pillar Risk] = RA.sri.nformat(pd.risk, 6, 'nc'),
			[Governance Pillar Score (Absolute)] = CASE WHEN @format != 'S' THEN RA.sri.nformat(pdp.risk, 6, 'nc') ELSE '' END,
			[Governance Pillar Score (Sector Relative)] = RA.sri.nformat(pd.score, 1, 'nc'),
			[Previous Governance Pillar Score (Sector Relative)] = RA.sri.nformat(pd.score_sector_relative, 6, 'nc')--,
			--[Previous Environmental Pillar Score (Sector Relative)] = CASE WHEN @format != 'S' THEN RA.sri.nformat(pdp.score_sector_relative, 6, 'nc') ELSE '' END
		FROM   #keys k
		       LEFT OUTER JOIN RA.sri.pillar_data_snapshot pd
		ON     pd.pillar_id = @pillar_id
		AND    pd.instrument_id = k.instrument_id
		AND    pd.day = k.data_date
		       LEFT OUTER JOIN RA.sri.pillar_data pdp
		ON     pdp.pillar_id = @pillar_id
		AND    pdp.instrument_id = k.previous_instrument_id
		AND    pdp.data_date = k.previous_pillar_data_date
		
		SET @message = 'inserted ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' rows for pillar_id=' + CONVERT(VARCHAR, @pillar_id)
		EXEC UTILITY.dbo.Message @message, @logfile
	
		FETCH NEXT FROM c_pillars INTO @pillar_id
		
    END
    
    CLOSE c_pillars
    DEALLOCATE c_pillars
    
	-- F4G flags
	-- 20110321 take f4g flags from #keys

	IF @format = 'A'
	BEGIN
		
		UPDATE k
		SET    k.txt = k.txt + COALESCE(k.f4g, 'nc') + @delimiter
		FROM   #keys k

		UPDATE k
		SET    k.txt = k.txt + COALESCE(k.f4g_excluded_activity, 'nc') + @delimiter
		FROM   #keys k
		
	END

	-- Add theme data.
	SET @message = 'Adding theme data'
	EXEC UTILITY.dbo.Message @message, @logfile
	
	IF @format != 'S'
	BEGIN
		DECLARE c_themes CURSOR FOR
			SELECT t.theme_id
			FROM   RA.sri.schemes s
				   INNER JOIN RA.sri.scheme_structure ss
			ON     ss.scheme_id = s.scheme_id
			AND    @p_date BETWEEN ss.start_date AND ss.end_date
				   INNER JOIN RA.sri.pillars p
			ON     p.pillar_id = ss.pillar_id
			AND    @p_date BETWEEN p.start_date AND p.end_date
			AND    CASE WHEN @format = 'EP' AND p.pillar_mnemonic = 'ENVIRONMENT' THEN 'Y'
			            WHEN @format = 'SP' AND p.pillar_mnemonic = 'SOCIAL'      THEN 'Y'
				        WHEN @format = 'GP' AND p.pillar_mnemonic = 'GOVERNANCE'  THEN 'Y'
					    WHEN @format IN ('A', 'S') THEN 'Y'
						ELSE 'N'
				    END = 'Y'
				   INNER JOIN RA.sri.pillar_structure ps
			ON     ps.pillar_id = ss.pillar_id
			AND    @p_date BETWEEN ps.start_date AND ps.end_date
				   INNER JOIN RA.sri.themes t
			ON     t.theme_id = ps.theme_id
			AND    @p_date BETWEEN t.start_date AND t.end_date
			WHERE  s.scheme_mnemonic = @scheme
			AND    @p_date BETWEEN s.start_date AND s.end_date
			ORDER BY ps.pillar_id, ps.theme_id
				
		DECLARE @theme_id  INT

		OPEN c_themes
		FETCH NEXT FROM c_themes INTO @theme_id
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
		
			UPDATE k
			SET    k.txt = k.txt +
				   RA.sri.nformat(td.risk, 6, 'nc') + @delimiter +
				   RA.sri.nformat(tdp.risk, 6, 'nc') + @delimiter +
				   case when td.risk = 0 then 'na'  else RA.sri.nformat(td.score, 6, 'nc')  end + @delimiter +
				   case when tdp.risk = 0 then 'na' else RA.sri.nformat(tdp.score, 6, 'nc') end + @delimiter
			FROM   #keys k
             LEFT OUTER JOIN RA.sri.theme_data_snapshot td
			ON     td.theme_id = @theme_id
			AND    td.instrument_id = k.instrument_id
			AND    td.day = k.data_date
             LEFT OUTER JOIN RA.sri.theme_data tdp
			ON     tdp.theme_id = @theme_id
			AND    tdp.instrument_id = k.previous_instrument_id
			AND    tdp.data_date = k.previous_theme_data_date
		
		SET @message = 'updated ' + CONVERT(VARCHAR,@@ROWCOUNT) + ' rows for theme_id=' + CONVERT(VARCHAR, @theme_id)
		EXEC UTILITY.dbo.Message @message, @logfile
	
		
			FETCH NEXT FROM c_themes INTO @theme_id
			
		END
	    
		CLOSE c_themes
		DEALLOCATE c_themes

	END
	
  SET @message = 'inserting to #text'
	EXEC UTILITY.dbo.Message @message, @logfile
	
    SELECT * FROM   #keys
    
  SET @message = 'DONE'
	EXEC UTILITY.dbo.Message @message, @logfile

GO