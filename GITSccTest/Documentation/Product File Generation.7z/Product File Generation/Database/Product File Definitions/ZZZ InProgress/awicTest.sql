USE EXPORT
GO

DECLARE @ProductCode VARCHAR(10) = 'awicTest'

DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1,1,'All-world Constituents', @ProductCode, '<%d><%m>.csv', ',')
SET @ProductId = @@IDENTITY
INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '<%d>/<%m>/<%Y>(C) FTSE International Limited <%Y>. All Rights Reserved
FTSE All World Indices Constituent Data', 'XXXXXXXXXX,,,,,,,,,,,')
DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'Generated', 'Stock Prices', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.get_index_constituents', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@family_name', 'GEISAC')
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@index_name', 'AWORLDS')
DECLARE @SectionColumnId INT
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 2, 1, 'Cons code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 3, 2, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 4, 3, 'CUSIP', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 5, 4, 'Constituent name', null, '19000101', '99991231', 1, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 6, 5, 'Country code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 7, 6, 'ISO code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 8, 7, 'Price', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 9, 8, 'Shares in Issue', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 9, 'Weighting', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 10, 'Industry Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 11, 'Sector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 12, 'Subsector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 13, 'Dividend Yield', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 14, 'Mkt Cap (USD) before investibility weight', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 15, 'Mkt Cap (USD) after investibility weight', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 16, '%Wt A-W', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 17, '%Wt A-W (ex US)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 18, '%Wt A-W (ex UK)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 19, '%Wt A-W (ex Japan)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 20, '%Wt A-W Asia Pacific (ex Japan)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 21, '%Wt A-W (ex South Africa)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 22, '%Wt A-W Europe (ex UK)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 23, '%Wt A-W North America', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 24, '%Wt A-W Europe-Asia Pacific', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 25, '%Wt A-W Asia-Pacific', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 26, '%Wt A-W Nordic', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 27, '%Wt A-W Europe', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 28, '%Wt A-W Eurobloc', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 29, '%Wt A-W Europe (ex Eurobloc)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 30, '%Wt A-W Europe (ex Ebloc & UK)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 31, '%Wt A-W (ex Eurobloc)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 32, '%Wt A-W Americas', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 33, '%Wt A-W Developed', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 34, '%Wt A-W Advanced Emerging', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 35, '%Wt A-W Emerging', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 36, '%Wt A-W Developed (ex US)', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 37, '%Wt Country', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 38, '%Wt Industry', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 39, '%Wt Sector', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 40, 'Index Marker', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 41, 'Large/Medium Classification', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 42, 'Exchange code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 43, 'Supersector Code', null, '19000101', '99991231', 0, NULL, NULL)

--declare @ProductId int = 104
--SELECT * FROM Export.PRODUCT.ProductDetailView WHERE ProductId = @ProductId
--SELECT * FROM Export.PRODUCT.ProductsectionDetailView WHERE ProductId = @ProductId
--SELECT * FROM Export.PRODUCT.ProductSectionParameterDetailView WHERE ProductId = @ProductId
SELECT * FROM Export.PRODUCT.ProductColumnDetailView WHERE ProductId = @ProductId
SELECT * FROM Export.PRODUCT.ProductParameterDetailView WHERE ProductId = @ProductId