USE EXPORT
GO

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1,1,'Global Fundamental Constituent file', 'gfc', '<%d><%m>.csv', ',')
SET @ProductId = @@IDENTITY
INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', 'Global Fundamental Constituent file. <%d>/<%m>/<%Y>,,,,,,,,,,,
Valuation ratios compiled by FTSE Analytics,,,,,,,,,,,', 'XXXXXXXXXX')
DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section 1', 1)
SET @SectionId = @@IDENTITY
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.gfc', NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'CONS CODE', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'STOCK NAME', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'SALES GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'EPS GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 'FORECAST SALES GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 7, 'FORECAST EPS GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 8, 'ROE', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 9, 'PRICE TO BOOK', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 10, 'PRICE TO SALES', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 11, 'PRICE TO CASH FLOW', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 12, 'PRICE EARNINGS', null, '19000101', '99991231', 0, NULL, NULL)