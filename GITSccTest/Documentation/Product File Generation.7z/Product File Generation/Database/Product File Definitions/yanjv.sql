USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'yanjv'

DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1,2,'FTSE China A50 Index HKD TRI (custom) Valuation Service', @ProductCode, '[DD][MM].csv', ',')
SET @ProductId = @@IDENTITY
INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY](C) FTSE International Limited [YYYY]. All Rights Reserved
FTSE China A50 Index HKD TRI (custom) Valuation Service
', 'XXXXXXXXXX')
DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, '[REPORTS].[rpt_cny_hkd_xina50]', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@index_mnemonic', '[index_mnemonic]')
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@display_index_mnemonic', '[display_index_mnemonic]')
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@display_index_sector_name', '[display_index_sector_name]')



-- token value 
INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[index_mnemonic]','XINA50' )

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[display_index_mnemonic]','XIN9HKTR' )

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[display_index_sector_name]', 'FTSE CHINA A50 INDEX HKD TRI (custom)')


DECLARE @SectionColumnId INT

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'FTSE Index Code', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'Index/Sector Name', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Number of Constituents', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'CNY TRI Index', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'HKD TRI Index', null, '19000101', '99991231', 0, NULL, NULL)


INSERT INTO EXPORT.PRODUCT.ProductFileValidationSettings (ProductId, NumberOfLines ) 
VALUES (@ProductId,6)


             
  DECLARE @server VARCHAR(20)                   
  SELECT @server = LEFT(@@SERVERNAME, CHARINDEX('\', @@SERVERNAME))

  
  IF @server LIKE '%SPES%'
  BEGIN
    INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 25) --dds 1 product
	INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 26) --dds 2 product
	INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 27) --dds 1 ini
	INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 28) --dds 2 ini
	 
  END 
  

   INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 29) -- FileSystem



EXEC Export.PRODUCT.DisplayProduct 'yanjv'