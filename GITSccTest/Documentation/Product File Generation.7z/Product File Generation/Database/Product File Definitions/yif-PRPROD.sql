USE EXPORT
GO
--This script need testing. 
DECLARE @ProductCode VARCHAR(50) = 'yif'

DELETE FROM EXPORT.PRODUCT.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO EXPORT.PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1, 1,'ICB Universe', @ProductCode, '[DD][MM].txt', '|')
SET @ProductId = @@IDENTITY
INSERT INTO EXPORT.PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) [YYYY] Industry Classification Benchmark (ICB) All Rights Reserved
Vanguard Custom ICB Universe
', 'XXXXXXXXXX')
DECLARE @SectionId INT
INSERT INTO EXPORT.PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'Generated', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO EXPORT.PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.if_1', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
DECLARE @SectionColumnId INT
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 2, 1, 'Unique Identifier', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 95, 2, 'ISIN Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 3, 3, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 96, 4, 'CUSIP', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 89, 5, 'Local Market Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 93, 6, 'Security Name', null, '19000101', '99991231', 1, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 48, 7, 'Company Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 171, 8, 'Nationality (FTSE)', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 172, 9, 'Nationality (ISO)', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 90, 10, 'Country Of Listing', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 91, 11, 'Domicile Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 97, 12, 'Country Of Incorporation', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 92, 13, 'MIC Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 15, 14, 'ICB Industry Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 12, 15, 'ICB Supersector Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 14, 16, 'ICB Sector Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 13, 17, 'ICB Subsector Code', null, '19000101', '99991231', 0, NULL, NULL)


--Distribute to DDS

--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2)
--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3)
--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7)
--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8)

EXEC EXPORT.PRODUCT.DisplayProduct 'yif'


