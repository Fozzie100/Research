USE EXPORT
GO

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
EXEC PRODUCT.CreateProductGroup @ProductGroupId output, 'All Products'

DECLARE @ProductCode VARCHAR(50) = 'SAMPLE'

DELETE FROM EXPORT.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO EXPORT.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (@ProductGroupId, 1,'Sample Product File', @ProductCode, '[DD][MM].csv', ',')
SET @ProductId = @@IDENTITY
INSERT INTO EXPORT.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD][MM][YYYY] First Line
Second Line
', NULL)
DECLARE @SectionId INT
INSERT INTO EXPORT.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO EXPORT.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.sample', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
--If stored procedure requires any parameters
INSERT INTO EXPORT.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@parameter1', 'value')

INSERT INTO EXPORT.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Unique Identifier', null, '19000101', '99991231', 0, NULL, NULL)

--Distribute to DDS
INSERT INTO EXPORT.Product.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2)
INSERT INTO EXPORT.Product.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3)
INSERT INTO EXPORT.Product.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7)
INSERT INTO EXPORT.Product.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8)

EXEC EXPORT.PRODUCT.DisplayProduct @ProductCode