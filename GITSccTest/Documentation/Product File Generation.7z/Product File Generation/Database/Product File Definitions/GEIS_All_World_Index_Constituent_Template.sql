USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'geis_aw_ic_template'
DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'Templates'

DECLARE @ProductId INT
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 1, 'GEIS All World Index Constituent Template', @ProductCode, '<%d><%m>.csv', ',', 1, NULL)
SET @ProductId = @@IDENTITY

-- Header & Footer
DECLARE 
	 @Header varchar(250) = '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved' + CHAR(13) + '[product_title]' + CHAR(13) + ' ' + CHAR(13)
	,@Footer varchar(50) = 'XXXXXXXXXX'

INSERT INTO PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', @Header, @Footer)

DECLARE @SectionId INT
INSERT INTO PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'Generated', 'Stock Prices', 1)
SET @SectionId = @@IDENTITY

DECLARE @SectionDetailId INT
INSERT INTO PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.get_index_constituents', NULL, NULL)
SET @SectionDetailId = @@IDENTITY

INSERT INTO PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@list_code', 'AWIC2')

DECLARE @SectionColumnId INT
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 2, 1, 'Cons code', 2, '19000101', '99991231', 0, NULL, 'Prefix -Value=C')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 3, 2, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 4, 3, 'CUSIP', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 5, 4, 'Constituent name', null, '19000101', '99991231', 1, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 6, 5, 'Country code', 1, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 7, 6, 'ISO code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 11, 7, 'Exchange code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 8, 8, 'Price', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 9, 9, 'Shares in Issue', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 20, 10, 'Weighting', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 15, 11, 'Industry Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 14, 12, 'Sector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 13, 13, 'Subsector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 42, 14, 'Dividend Yield', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 17, 15, 'Mkt Cap (USD) before investibility weight', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 13, 'USD')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 163, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 18, 16, 'Mkt Cap (USD) after investibility weight', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 15, 'USD')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 165, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 17, '%Wt A-W', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWORLDS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 18, '%Wt A-W (ex US)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWXUSAS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 19, '%Wt A-W (ex UK)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWXUKS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 20, '%Wt A-W (ex Japan)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWXJAS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 21, '%Wt A-W Asia Pacific (ex Japan)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWPACXJA')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 22, '%Wt A-W (ex South Africa)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWXSAFS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 23, '%Wt A-W Europe (ex UK)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWEXUKS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 24, '%Wt A-W North America', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWNAMERS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 25, '%Wt A-W Europe-Asia Pacific', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWEURPS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 26, '%Wt A-W Asia-Pacific', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWPACS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 27, '%Wt A-W Nordic', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWNORDS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 28, '%Wt A-W Europe', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWEURS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 29, '%Wt A-W Eurobloc', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWEBLOCS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 30, '%Wt A-W Europe (ex Eurobloc)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWEXEBS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 31, '%Wt A-W Europe (ex Ebloc & UK)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWEXBXKS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 32, '%Wt A-W (ex Eurobloc)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWXEBS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 33, '%Wt A-W Americas', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWAMERS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 34, '%Wt A-W Developed', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 35, '%Wt A-W Advanced Emerging', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWAE')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 36, '%Wt A-W Secondary Emerging', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWE')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 19, 37, '%Wt A-W Developed (ex US)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 17, 'AWDXUS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 22, 38, '%Wt Country', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 23, 39, '%Wt Industry', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 24, 40, '%Wt Sector', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 16, 41, 'Index Marker', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 11, 'AWIC_MARKER')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 10, 42, 'Large/Medium Classification', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 9, 'SIZE')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 12, 43, 'Supersector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

--display product details
EXEC PRODUCT.displayproduct @ProductCode
