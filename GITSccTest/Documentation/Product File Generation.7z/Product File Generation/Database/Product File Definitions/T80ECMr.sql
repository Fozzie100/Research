USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'T80ECMr'
DECLARE @ProductTitle VARCHAR(255)

SELECT @ProductTitle = 'FTSE Target 80% Exposure Commodity Index Review' 

select @ProductTitle
DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT

INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1,	2,	@ProductTitle, @ProductCode, '<%d><%m>.csv', ',')
SET @ProductId = @@IDENTITY

INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved ' + CHAR(13)
+ @ProductTitle + CHAR(13) + ' '
+ CHAR(13), 'XXXXXXXXXX')


DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
select @SectionId [SectionId]
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.T80ECMr', NULL, NULL)

SET @SectionDetailId = @@IDENTITY

--INSERT INTO Export.PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) 
--VALUES (@SectionDetailId, '@source', '[source]')



DECLARE @SectionColumnId INT
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'IndexId', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'Cons ID', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Constituent Futures Contract Name', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'Commodity Category', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'Target Contract ID', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 'Target Contract Name', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 7, 'Target Contract Delivery Month', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 8, 'Wt Momentum Long Strategy', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 9, 'Wt Futures Curve Long Strategy', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 10, 'Wt Breakout Strategy', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 11, 'Wt Trend Following Strategy', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 12, 'Wt Overall Commodity', null, '19000101', '99991231', 0, NULL, NULL)

--create validation settings
--INSERT INTO Export.PRODUCT.ProductFileValidationSettings (ProductId, NumberOfLines) VALUES (@ProductId, 7)

--create distributors
DELETE FROM Export.PRODUCT.ProductDistributor WHERE ProductId = @ProductId
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 22) --annual
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2) --dds 1 product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3) --dds 2 product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7) --dds 1 ini
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8) --dds 2 ini

exec Export.PRODUCT.DisplayProduct @ProductCode


