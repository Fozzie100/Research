USE [EXPORT]; 
DECLARE @ProductGroupName varchar(200)='FTSE ORB product files';
DECLARE @ProductGroupId INT, @DataSourceId INT=1;
DECLARE @ProductGroupIdForDailyRun INT=2;

----------------------------------------------------------------------------------------------------
--ProductGroup
IF(SELECT COUNT(*) FROM [PRODUCT].[ProductGroup] WHERE [Name]=@ProductGroupName)=0
BEGIN
	INSERT INTO [PRODUCT].[ProductGroup]([Name]) VALUES (@ProductGroupName)
	SELECT @ProductGroupId=ProductGroupId from [PRODUCT].[ProductGroup] WHERE Name=@ProductGroupName; 
END
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
--Product
IF(SELECT COUNT(*) FROM [EXPORT].[PRODUCT].[Product] WHERE [Code] IN ('orbvlst','orbc','orbco','orbv','orbt','orbh'))=0
BEGIN
	INSERT INTO [EXPORT].[PRODUCT].[Product]([ProductGroupId],[DataSourceId],[Name],[Code],[FileSuffix],[Delimiter],[IsTemplate])  SELECT  @ProductGroupId, @DataSourceId,'FTSE ORB Valuation WEB','orbvlst','lst.csv',',',0
	INSERT INTO [EXPORT].[PRODUCT].[Product]([ProductGroupId],[DataSourceId],[Name],[Code],[FileSuffix],[Delimiter],[IsTemplate])  SELECT  @ProductGroupId,@DataSourceId,'FTSE ORB Constituent','orbc','[DD][MM].csv',',',0
	INSERT INTO [EXPORT].[PRODUCT].[Product]([ProductGroupId],[DataSourceId],[Name],[Code],[FileSuffix],[Delimiter],[IsTemplate])  SELECT  @ProductGroupIdForDailyRun,@DataSourceId,'FTSE ORB Open Constituent','orbco','[DD][MM].csv',',',0
	INSERT INTO [EXPORT].[PRODUCT].[Product]([ProductGroupId],[DataSourceId],[Name],[Code],[FileSuffix],[Delimiter],[IsTemplate])  SELECT  @ProductGroupId,@DataSourceId,'FTSE ORB Valuation','orbv','[DD][MM].csv',',',0
	INSERT INTO [EXPORT].[PRODUCT].[Product]([ProductGroupId],[DataSourceId],[Name],[Code],[FileSuffix],[Delimiter],[IsTemplate])  SELECT  @ProductGroupId,@DataSourceId,'FTSE ORB Tracker','orbt','[DD][MM].csv',',',0
	INSERT INTO [EXPORT].[PRODUCT].[Product]([ProductGroupId],[DataSourceId],[Name],[Code],[FileSuffix],[Delimiter],[IsTemplate])  SELECT  @ProductGroupId,@DataSourceId,'FTSE ORB History','orbh','[DD][MM].csv',',',0
END
----------------------------------------------------------------------------------------------------

DECLARE @ProductId_FTSE_ORB_Valuation_WEB INT = (SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Valuation WEB'); --387
DECLARE @ProductId_FTSE_ORB_Constituent INT = (SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Constituent'); --400
DECLARE @ProductId_FTSE_ORB_Open_Constituent INT = (SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Open Constituent');--401
DECLARE @ProductId_FTSE_ORB_Valuation INT = (SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Valuation');--402
DECLARE @ProductId_FTSE_ORB_Tracker INT = (SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Tracker');--403
DECLARE @ProductId_FTSE_ORB_History INT = (SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB History');--404

---------------------------------------------------------------------------------------------------------
--ProductDetail
IF(SELECT COUNT(*) FROM [EXPORT].[PRODUCT].[ProductDetail] 
					WHERE [ProductId] IN (@ProductId_FTSE_ORB_Valuation_WEB,@ProductId_FTSE_ORB_Constituent,@ProductId_FTSE_ORB_Open_Constituent,
										  @ProductId_FTSE_ORB_Valuation,@ProductId_FTSE_ORB_Tracker,@ProductId_FTSE_ORB_History)
	)=0
BEGIN
	INSERT INTO [EXPORT].[PRODUCT].[ProductDetail]([ProductId],[HeaderText],[FooterText],EffectiveDate) SELECT @ProductId_FTSE_ORB_Valuation_WEB,'<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved FTSE ORB Valuation Service  ','XXXXXXXXXX','1900-01-01'
	INSERT INTO [EXPORT].[PRODUCT].[ProductDetail]([ProductId],[HeaderText],[FooterText],EffectiveDate) SELECT @ProductId_FTSE_ORB_Constituent,'<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved FTSE ORB Constituent Service  ','XXXXXXXXXX','1900-01-01'
	INSERT INTO [EXPORT].[PRODUCT].[ProductDetail]([ProductId],[HeaderText],[FooterText],EffectiveDate) SELECT @ProductId_FTSE_ORB_Open_Constituent,'<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved FTSE ORB Open Constituent Service  ','XXXXXXXXXX','1900-01-01'
	INSERT INTO [EXPORT].[PRODUCT].[ProductDetail]([ProductId],[HeaderText],[FooterText],EffectiveDate) SELECT @ProductId_FTSE_ORB_Valuation,'<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved FTSE ORB Valuation Service  ','XXXXXXXXXX','1900-01-01'
	INSERT INTO [EXPORT].[PRODUCT].[ProductDetail]([ProductId],[HeaderText],[FooterText],EffectiveDate) SELECT @ProductId_FTSE_ORB_Tracker,'<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved FTSE ORB Tracker Service  ','XXXXXXXXXX','1900-01-01'
	INSERT INTO [EXPORT].[PRODUCT].[ProductDetail]([ProductId],[HeaderText],[FooterText],EffectiveDate) SELECT @ProductId_FTSE_ORB_History,'<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved FTSE ORB History Service  ','XXXXXXXXXX','1900-01-01'
END
----------------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------------------
--Section
IF(SELECT COUNT(*) FROM [EXPORT].[PRODUCT].[Section] 
					WHERE [ProductId] IN (@ProductId_FTSE_ORB_Valuation_WEB,@ProductId_FTSE_ORB_Constituent,@ProductId_FTSE_ORB_Open_Constituent,
										  @ProductId_FTSE_ORB_Valuation,@ProductId_FTSE_ORB_Tracker,@ProductId_FTSE_ORB_History)
	)=0
BEGIN
	INSERT INTO [EXPORT].[PRODUCT].[Section]([ProductId],[SectionType],[Name],[Sequence])SELECT @ProductId_FTSE_ORB_Valuation_WEB,'StoredProcedure','Section 1',1
	INSERT INTO [EXPORT].[PRODUCT].[Section]([ProductId],[SectionType],[Name],[Sequence])SELECT @ProductId_FTSE_ORB_Constituent,'StoredProcedure','Section 1',1
	INSERT INTO [EXPORT].[PRODUCT].[Section]([ProductId],[SectionType],[Name],[Sequence])SELECT @ProductId_FTSE_ORB_Open_Constituent,'StoredProcedure','Section 1',1
	INSERT INTO [EXPORT].[PRODUCT].[Section]([ProductId],[SectionType],[Name],[Sequence])SELECT @ProductId_FTSE_ORB_Valuation,'StoredProcedure','Section 1',1
	INSERT INTO [EXPORT].[PRODUCT].[Section]([ProductId],[SectionType],[Name],[Sequence])SELECT @ProductId_FTSE_ORB_Tracker,'StoredProcedure','Section 1',1
	INSERT INTO [EXPORT].[PRODUCT].[Section]([ProductId],[SectionType],[Name],[Sequence])SELECT @ProductId_FTSE_ORB_History,'StoredProcedure','Section 1',1
END
----------------------------------------------------------------------------------------------------

DECLARE @SectionId_FTSE_ORB_Valuation_WEB INT = (SELECT SectionId FROM EXPORT.PRODUCT.Section WHERE ProductId =(SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Valuation WEB')); --1061, 387
DECLARE @SectionId_FTSE_ORB_Constituent INT = (SELECT SectionId FROM EXPORT.PRODUCT.Section WHERE ProductId =(SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Constituent')); --1073, 400
DECLARE @SectionId_FTSE_ORB_Open_Constituent INT = (SELECT SectionId FROM EXPORT.PRODUCT.Section WHERE ProductId =(SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Open Constituent'));--1074, 401
DECLARE @SectionId_FTSE_ORB_Valuation INT = (SELECT SectionId FROM EXPORT.PRODUCT.Section WHERE ProductId =(SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Valuation'));--1075, 402
DECLARE @SectionId_FTSE_ORB_Tracker INT = (SELECT SectionId FROM EXPORT.PRODUCT.Section WHERE ProductId =(SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB Tracker'));--1076, 403
DECLARE @SectionId_FTSE_ORB_History INT = (SELECT SectionId FROM EXPORT.PRODUCT.Section WHERE ProductId =(SELECT ProductId FROM EXPORT.PRODUCT.Product WHERE Name ='FTSE ORB History'));--1077, 404


---------------------------------------------------------------------------------------------------------
--SectionDetail
IF(SELECT COUNT(*) FROM [EXPORT].[PRODUCT].[SectionDetail] 
					WHERE [SectionId] IN (@SectionId_FTSE_ORB_Valuation_WEB,@SectionId_FTSE_ORB_Constituent,@SectionId_FTSE_ORB_Open_Constituent,
										  @SectionId_FTSE_ORB_Valuation,@SectionId_FTSE_ORB_Tracker,@SectionId_FTSE_ORB_History)
	)=0
BEGIN
	INSERT INTO [EXPORT].[PRODUCT].[SectionDetail]([SectionId],[EffectiveDate],[OutputColumnNames],[ProcedureName]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,'1900-01-01',1,'PRIME.BOND.bond_index_valuation_file'
	INSERT INTO [EXPORT].[PRODUCT].[SectionDetail]([SectionId],[EffectiveDate],[OutputColumnNames],[ProcedureName]) SELECT @SectionId_FTSE_ORB_Constituent,'1900-01-01',1,'PRIME.BOND.bond_index_constituent_file'
	INSERT INTO [EXPORT].[PRODUCT].[SectionDetail]([SectionId],[EffectiveDate],[OutputColumnNames],[ProcedureName]) SELECT @SectionId_FTSE_ORB_Open_Constituent,'1900-01-01',1,'PRIME.BOND.bond_index_open_constituent_file'
	INSERT INTO [EXPORT].[PRODUCT].[SectionDetail]([SectionId],[EffectiveDate],[OutputColumnNames],[ProcedureName]) SELECT @SectionId_FTSE_ORB_Valuation,'1900-01-01',1,'PRIME.BOND.bond_index_valuation_file'
	INSERT INTO [EXPORT].[PRODUCT].[SectionDetail]([SectionId],[EffectiveDate],[OutputColumnNames],[ProcedureName]) SELECT @SectionId_FTSE_ORB_Tracker,'1900-01-01',1,'PRIME.BOND.bond_index_tracker_file'
	INSERT INTO [EXPORT].[PRODUCT].[SectionDetail]([SectionId],[EffectiveDate],[OutputColumnNames],[ProcedureName]) SELECT @SectionId_FTSE_ORB_History,'1900-01-01',1,'PRIME.BOND.bond_index_history_file'
END
----------------------------------------------------------------------------------------------------



---------------------------------------------------------------------------------------------------------
--SectionColumn
IF(SELECT COUNT(*) FROM [EXPORT].[PRODUCT].[SectionColumn] 
					WHERE [SectionId] IN (@SectionId_FTSE_ORB_Valuation_WEB,@SectionId_FTSE_ORB_Constituent,@SectionId_FTSE_ORB_Open_Constituent,
										  @SectionId_FTSE_ORB_Valuation,@SectionId_FTSE_ORB_Tracker,@SectionId_FTSE_ORB_History)
	)=0
BEGIN
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,1,'Name','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,2,'Code','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,3,'Currency','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,4,'Price Index','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,5,'Total Return Index','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,6,'Coupon','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,7,'Nominal Amount','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,8,'Time to Maturity','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,9,'Gross Redemption Yield','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,10,'Macaulay Duration','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,11,'Mod.Duration','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,12,'Convexity','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation_WEB,1,13,'Number of Bonds','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,1,'Index Code','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,2,'ISIN','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,3,'Bond Name','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,4,'Currency','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,5,'Coupon','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,6,'Issue Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,7,'Maturity Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,8,'Coupons per Year','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,9,'Previous Coupon Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,10,'Settlement date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,11,'Next Coupon Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,12,'Issue Amount','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,13,'Outstanding Amount','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,14,'Day Count','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,15,'Calculation type','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,16,'Accrued Days','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,17,'Price','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,18,'Accrued Interest','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,19,'Coupon Paid','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,20,'Time to Maturity','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,21,'Current Yield','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,22,'Gross Redemption Yield','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,23,'Duration','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,24,'Mod.Duration','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Constituent,1,25,'Convexity','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,1,'Index Code','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,2,'ISIN','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,3,'Bond Name','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,4,'Currency','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,5,'Coupon','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,6,'Issue Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,7,'Maturity Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,8,'Coupons per Year','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,9,'Previous Coupon Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,10,'Settlement date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,11,'Next Coupon Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,12,'Issue Amount','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,13,'Outstanding Amount','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,14,'Day Count','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,15,'Calculation type','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,16,'Accrued Days','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,17,'Price','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,18,'Accrued Interest','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,19,'Coupon Paid','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Open_Constituent,1,20,'Time to Maturity','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,1,'Name','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,2,'Code','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,3,'Currency','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,4,'Price Index','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,5,'Total Return Index','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,6,'Coupon','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,7,'Nominal Amount','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,8,'Time to Maturity','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,9,'Gross Redemption Yield','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,10,'Macaulay Duration','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,11,'Mod.Duration','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,12,'Convexity','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Valuation,1,13,'Number of Bonds','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,1,'Index code','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,2,'Effective date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,3,'Bond ISIN','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,4,'Name','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,5,'Currency','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,6,'Coupon','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,7,'Issue date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,8,'Maturity date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,9,'Coupons per Year','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,10,'Next Coupon Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,11,'Current amount outstanding','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,12,'New amount outstanding','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_Tracker,1,13,'Change','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,1,'Value Date','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,2,'FTSEORB pri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,3,'FTSEORB tri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,4,'FTORBFG pri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,5,'FTORBFG tri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,6,'FTORBNFG pri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,7,'FTORBNFG tri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,8,'FTORB5UG pri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,9,'FTORB5UG tri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,10,'FTORB5OG pri','1900-01-01',0
	INSERT INTO [EXPORT].[PRODUCT].[SectionColumn]([SectionId],[FileColumnId],[Sequence],[Description],[EffectiveDate],[QuoteValues]) SELECT @SectionId_FTSE_ORB_History,1,11,'FTORB5OG tri','1900-01-01',0
END 
----------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------------------------------
----Distributor data from RA
----ProductId	DistributorId	DistributorId	Name	ItemKey	FileType	DistributionType	Active
----387	14	14	FTSE.com WebServer 1	5	Product	Ftp	1
----400	2	2	Product To Production DDS UKUBS	1	Product	Ftp	1
----400	3	3	Product To Production DDS UKHSL	2	Product	Ftp	1
----400	7	7	Ini To Production DDS UKUBS	3	Ini	Ftp	1
----400	8	8	Ini To Production DDS UKUBS	4	Ini	Ftp	1
----401	2	2	Product To Production DDS UKUBS	1	Product	Ftp	1
----401	3	3	Product To Production DDS UKHSL	2	Product	Ftp	1
----401	7	7	Ini To Production DDS UKUBS	3	Ini	Ftp	1
----401	8	8	Ini To Production DDS UKUBS	4	Ini	Ftp	1
----402	2	2	Product To Production DDS UKUBS	1	Product	Ftp	1
----402	3	3	Product To Production DDS UKHSL	2	Product	Ftp	1
----402	7	7	Ini To Production DDS UKUBS	3	Ini	Ftp	1
----402	8	8	Ini To Production DDS UKUBS	4	Ini	Ftp	1
----403	2	2	Product To Production DDS UKUBS	1	Product	Ftp	1
----403	3	3	Product To Production DDS UKHSL	2	Product	Ftp	1
----403	7	7	Ini To Production DDS UKUBS	3	Ini	Ftp	1
----403	8	8	Ini To Production DDS UKUBS	4	Ini	Ftp	1
----404	2	2	Product To Production DDS UKUBS	1	Product	Ftp	1
----404	3	3	Product To Production DDS UKHSL	2	Product	Ftp	1
----404	7	7	Ini To Production DDS UKUBS	3	Ini	Ftp	1
----404	8	8	Ini To Production DDS UKUBS	4	Ini	Ftp	1

-----------------------------------------------------------------------------------------------------------------------------------------
--ProductDistributor
IF(SELECT COUNT(*) FROM [EXPORT].[PRODUCT].[ProductDistributor] 
					WHERE [ProductId] IN (@ProductId_FTSE_ORB_Valuation_WEB,@ProductId_FTSE_ORB_Constituent,@ProductId_FTSE_ORB_Open_Constituent,
										  @ProductId_FTSE_ORB_Valuation,@ProductId_FTSE_ORB_Tracker,@ProductId_FTSE_ORB_History)
	)=0
BEGIN
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Valuation_WEB,14
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Constituent ,2
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Constituent ,3
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Constituent ,7
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Constituent ,8
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Open_Constituent,2
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Open_Constituent,3
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Open_Constituent,7
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Open_Constituent,8
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Valuation,2
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Valuation,3
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Valuation,7
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Valuation,8
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Tracker,2
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Tracker,3
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Tracker,7
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_Tracker,8
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_History,2
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_History,3
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_History,7
	INSERT INTO [EXPORT].[PRODUCT].[ProductDistributor] ([ProductId] ,[DistributorId]) SELECT @ProductId_FTSE_ORB_History,8
END
----------------------------------------------------------------------------------------------------



---------------------------------------------------------------------------------------------------------------------------------------------
--SectionDetailParameter
IF(SELECT COUNT(*) FROM [EXPORT].[PRODUCT].[SectionDetailParameter] 
					WHERE [SectionDetailId] IN (SELECT sd.SectionDetailId FROM EXPORT.PRODUCT.SectionDetail sd WHERE sd.SectionId IN (  
														@SectionId_FTSE_ORB_Valuation_WEB,@SectionId_FTSE_ORB_Constituent,@SectionId_FTSE_ORB_Open_Constituent,
														@SectionId_FTSE_ORB_Valuation,@SectionId_FTSE_ORB_Tracker,@SectionId_FTSE_ORB_History))
	)=0
BEGIN
	INSERT INTO [EXPORT].[PRODUCT].[SectionDetailParameter]([SectionDetailId],[ParameterName],[Value])
	SELECT sd.SectionDetailId, '@family' as ParameterName,'ORB' as Value FROM EXPORT.PRODUCT.SectionDetail sd WHERE sd.SectionId IN (  
	@SectionId_FTSE_ORB_Valuation_WEB,@SectionId_FTSE_ORB_Constituent,@SectionId_FTSE_ORB_Open_Constituent,
	@SectionId_FTSE_ORB_Valuation,@SectionId_FTSE_ORB_Tracker,@SectionId_FTSE_ORB_History)
END
----------------------------------------------------------------------------------------------------
