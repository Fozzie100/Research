USE EXPORT
GO

--select * from CUSTOM.net_of_tax_products WHERE product_id = 3
--select * from CUSTOM.net_of_tax_product_details where nt_product_id = 3

DECLARE @ProductCode VARCHAR(50) = 'adfc'
DECLARE @ProductTitle NVARCHAR(255) = 'Developed Fundamental Constituent file.'

DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1,2,@ProductTitle, @ProductCode, '[DD][MM].csv', ',')
SET @ProductId = @@IDENTITY

INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', 'Valuation ratios compiled by FTSE Analytics [DD]/[MM]/[YYYY]' + CHAR(13)
+ @ProductTitle + CHAR(13) + ' '
+ CHAR(13), 'XXXXXXXXXX')

DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
select @SectionId [SectionId]
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'FTSE.adfi', NULL, NULL)

SET @SectionDetailId = @@IDENTITY

--INSERT INTO Export.PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) 
--VALUES (@SectionDetailId, '@nt_product_id', '[nt_product_id]')

DECLARE @SectionColumnId INT
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'CONS CODE', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'STOCK NAME', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'SALES GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'EPS GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 'FORECAST SALES GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 7, 'FORECAST EPS GROWTH', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 8, 'ROE', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 9, 'PRICE TO BOOK', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 10, 'PRICE TO SALES', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 11, 'PRICE TO CASH FLOW', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 12, 'PRICE EARNINGS', null, '19000101', '99991231', 0, NULL, NULL)

--create validation settings
--INSERT INTO Export.PRODUCT.ProductFileValidationSettings (ProductId, NumberOfLines) VALUES (@ProductId, 7)

--create distributors
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 22) --annual
--COMMENT OUT FOR BB
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 25) --dds 1 product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 26) --dds 2 product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 27) --dds 1 ini
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 28) --dds 2 ini

exec Export.PRODUCT.DisplayProduct @ProductCode

--select * from Export.PRODUCT.DistributorView 
--exec Export.PRODUCT.DisplayProduct 'fjdncv'

