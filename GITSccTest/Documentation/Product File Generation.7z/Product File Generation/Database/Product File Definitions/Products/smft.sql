USE EXPORT
GO

SET NOCOUNT ON
GO

DECLARE @ProductCode VARCHAR(10) = 'smft'
DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'ALL World Series Tracker'

--Get Product Group Template code 
DECLARE @productGroupTemplateCode VARCHAR(255) = 'geis_tracker_multi_day_aw_series_incl_cusip2'

DECLARE @TemplateProductId INT
DECLARE @ProductTitle VARCHAR(255) = 'FTSE Global Small Cap 5-Day Tracker'
SELECT @TemplateProductId = ProductId FROM PRODUCT.Product where Code = @productGroupTemplateCode and IsTemplate = 1

DECLARE @ProductId INT
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 1, @ProductTitle, @ProductCode, '<%d><%m>.csv', ',', 0, @TemplateProductId)
SET @ProductId = @@IDENTITY

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[product_title]', @ProductTitle)

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[tracker_days]', '5')

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[list_code]', 'SMIT')

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[index_marker_type]', 'DG')

--display product details
EXEC PRODUCT.displayproduct @ProductCode
