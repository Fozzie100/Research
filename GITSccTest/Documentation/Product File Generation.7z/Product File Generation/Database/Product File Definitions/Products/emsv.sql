USE EXPORT
GO

DECLARE @ProductCode VARCHAR(10) = 'emsv'
DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'ALL World Daily'

--Get Product Group Template code 
DECLARE @productGroupTemplateCode VARCHAR(255) = 'geis_iv_europe_smid'

DECLARE @TemplateProductId INT
DECLARE @ProductTitle VARCHAR(255) = 'FTSE Europe SMID Index Valuation Service'
SELECT @TemplateProductId = ProductId FROM PRODUCT.Product where Code = @productGroupTemplateCode and IsTemplate = 1

DECLARE @ProductId INT
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 1, @ProductTitle, @ProductCode, '<%d><%m>.csv', ',', 0, @TemplateProductId)
SET @ProductId = @@IDENTITY

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[product_title]', @ProductTitle)

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[local_currency_value]', 'NEUTRAL')

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[list_code_value]', 'EMSV')

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[index_attr_fld_code]', 'FTAD')

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[snap]', 'EOD')

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[index_name_code]', 'NAME')

--display product details
EXEC PRODUCT.displayproduct @ProductCode
