USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'geis_aw_av_template'
DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'Templates'

DECLARE @ProductId INT
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 1, 'GEIS All World Advanced Valuation Template', @ProductCode, '<%d><%m>.csv', ',', 1, NULL)
SET @ProductId = @@IDENTITY

-- Header & Footer
DECLARE 
	 @Header varchar(250) = '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved' + CHAR(13) + '[product_title]' + CHAR(13) + ' ' + CHAR(13)
	,@Footer varchar(50) = 'XXXXXXXXXX'

INSERT INTO PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', @Header, @Footer)

DECLARE @SectionId INT
INSERT INTO PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'Generated', 'Index Values', 1)
SET @SectionId = @@IDENTITY

DECLARE @SectionDetailId INT
INSERT INTO PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.get_valuationfile_indices', NULL, NULL)
SET @SectionDetailId = @@IDENTITY

INSERT INTO PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@list_code', '[list_code_value]')
INSERT INTO PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@show_blank_index', 0)

DECLARE @SectionColumnId INT
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 25, 1, 'Index Code', 1, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 34, 2, 'Index Sector/Name', null, '19000101', '99991231', 1, NULL, 'UpperCase')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 26, 3, 'Number of constituents', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 4, 'US dollar index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 5, 'Sterling index', NULL, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 6, 'Euro index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'EUR')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 7, 'Japanese yen index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'JPY')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 8, 'Local currency index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 9, 'US dollar TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'USD')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 10, 'Sterling TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'GBP')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 11, 'Euro TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'EUR')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 12, 'Japanese yen TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'JPY')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 13, 'Local currency TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, '[local_currency_value]')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 14, 'Mkt Cap ($)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'USD')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 15, 'Mkt Cap (Sterling)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'GBP')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 16, 'Mkt Cap (Euro)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'EUR')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 17, 'Mkt Cap (Yen)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'JPY')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 18, 'Mkt Cap (Local Index)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'LOC')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 38, 19, 'XD adjustment (YTD)', null, '19000101', '99991231', 0, NULL, 'NullToZero|RoundedDecimal -NumberOfDecimalPlaces=3')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 41, 20, 'Dividend yield', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 73, 21, 'Industry Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 71, 22, 'Sector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 72, 23, 'Subsector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 208, 24, 'Currency', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 62, 25, 'Daily Performance (USD)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 54, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 62, 26, 'Daily Performance (Local)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 54, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 62, 27, 'Daily Performance (GBP)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 54, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 62, 28, 'Daily Performance (EUR)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 54, 'EUR')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 63, 29, 'Daily Performance TRI (USD)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 55, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 63, 30, 'Daily Performance TRI (Local)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 55, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 63, 31, 'Daily Performance TRI (GBP)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 55, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 63, 32, 'Daily Performance TRI (EUR)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 55, 'EUR')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 186, 33, 'Weight in Index', null, '19000101', '99991231', 0, NULL, 'NullToZero|RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 68, 34, 'Weight in Industry', null, '19000101', '99991231', 0, NULL, 'NullToZero|RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 64, 35, 'Monthly Performance (USD)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 56, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 64, 36, 'Monthly Performance (Local)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 56, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 64, 37, 'Monthly Performance (GBP)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 56, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 64, 38, 'Monthly Performance (EUR)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 56, 'EUR')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 65, 39, 'Monthly Performance TRI (USD)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 57, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 65, 40, 'Monthly Performance TRI (Local)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 57, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 65, 41, 'Monthly Performance TRI (GBP)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 57, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 65, 42, 'Monthly Performance TRI (EUR))', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 57, 'EUR')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 66, 43, 'YTD Performance (USD)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 58, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 66, 44, 'YTD Performance (Local)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 58, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 66, 45, 'YTD Performance (GBP)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 58, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 66, 46, 'YTD Performance (EUR)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 58, 'EUR')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 67, 47, 'YTD TRI Performance (USD)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 59, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 67, 48, 'YTD TRI Performance (LOC)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 59, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 67, 49, 'YTD TRI Performance (GBP)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 59, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 67, 50, 'YTD TRI Performance (EUR)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 59, 'EUR')

--display product details
EXEC PRODUCT.displayproduct @ProductCode
