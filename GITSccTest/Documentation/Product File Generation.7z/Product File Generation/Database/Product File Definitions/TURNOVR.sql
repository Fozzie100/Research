USE EXPORT
GO

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
EXEC PRODUCT.CreateProductGroup @ProductGroupId output, 'All Products'

DECLARE @ProductCode VARCHAR(50) = 'turnovr'

DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 1,'FTSE Custom � Turnover Data File', @ProductCode, '[DD][MM].csv', ',', 0, NULL)
SET @ProductId = @@IDENTITY
INSERT INTO PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved
FTSE Custom - Turnover Data File
', 'XXXXXXXXXX')
DECLARE @SectionId INT
INSERT INTO PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.turnovr', NULL, NULL)
SET @SectionDetailId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Index Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'Index Name', null, '19000101', '99991231', 1, NULL, NULL)
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Index Currency', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'Effective Date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'One Way Turnover', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 'Constituent Additions', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 7, 'Constituent Deletions', null, '19000101', '99991231', 0, NULL, NULL)

--Distribute to DDS
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) values (@ProductId, 20)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) values (@ProductId, 21)