USE EXPORT
GO

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'ESG Scheme Data'


--Get Product Product Group Template code 
DECLARE @productGroupTemplateCode VARCHAR(255) = 'ESGRS_Template'

DECLARE @TemplateProductId INT
DECLARE @ProductTitle VARCHAR(255) = 'FTSE ESG Ratings (Global) - Summary'
--SELECT @TemplateProductId = ProductId FROM PRODUCT.Product where ProductGroupId = @productGroupId and IsTemplate = 1
SELECT @TemplateProductId = ProductId FROM PRODUCT.Product where Code = @productGroupTemplateCode and IsTemplate = 1


DECLARE @ProductCode VARCHAR(50) = 'ESGRGS'
DECLARE @date VARCHAR(255) = ''
DECLARE @mnemonic VARCHAR(50) = 'AWD'

--delete existing file
DELETE FROM Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@productGroupId, 2, @ProductTitle, @ProductCode, '[DD][MM].csv', ',', 0, @TemplateProductId)
SET @ProductId = @@IDENTITY

INSERT INTO Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', NULL, NULL)

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[mnemonic]', @mnemonic)

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[product_title]', @ProductTitle)

--create distributors
/* TEST:- SQL01BB */
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, (SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Development DDS 1'))	-- dds 1 product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, (SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Development DDS 1'))		-- dds 1 ini
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, (SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = '2014 Archive'))					-- annual

/* Production:- SQL01RA */
/*
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 2) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS UKUBS')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 3) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS UKHSL')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 7) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS UKUBS')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 8) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS UKUBS')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 22) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = '2014 Archive')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 25) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS ftpdc')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 26) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS ftpdc')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 27) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS ftasr')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 28) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS ftasr')
*/

exec PRODUCT.DisplayProduct @ProductCode

