USE EXPORT
GO

INSERT INTO PRODUCT.ProductGroup (ParentProductGroupId, Name) VALUES (NULL, 'Blackrock Indices - GPBLRH103 GPBLRH104');
DECLARE @iProductGroupId INT = NULL;
SET @iProductGroupId = (SELECT DISTINCT ProductGroupId FROM PRODUCT.ProductGroup WHERE Name = 'Blackrock Indices - GPBLRH103 GPBLRH104');
DECLARE @iDataSourceId INT = NULL;
SET @iDataSourceId = (SELECT DISTINCT DataSourceId FROM PRODUCT.DataSource WHERE Name LIKE 'Prime on %');
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId) VALUES (@iProductGroupId, @iDataSourceId, 'FTSE Custom BlackRock Hedged Indices', 'yljuv', '[DD][MM].csv', ',', 0, NULL);
DECLARE @iProductId INT = NULL;
SET @iProductId = (SELECT DISTINCT ProductId FROM PRODUCT.Product WHERE Name = 'FTSE Custom BlackRock Hedged Indices');
DECLARE @sHeader VARCHAR(MAX) = NULL;
SET @sHeader = '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved' + CHAR(13) + CHAR(10) + 'FTSE Custom BlackRock Hedged Indices' + CHAR(13) + CHAR(10);
INSERT INTO PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText) VALUES (@iProductId, '01 Jan 1900', '31 Dec 9999', @sHeader, 'XXXXXXXXXX');
DECLARE @iDistributorId INT = NULL;
SET @iDistributorId = (SELECT DistributorId FROM PRODUCT.Distributor WHERE Name='Product To File System')
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@iProductId, @iDistributorId);
SET @iDistributorId = (SELECT DistributorId FROM PRODUCT.Distributor WHERE Name='Product To Development DDS 1')
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@iProductId, @iDistributorId);
SET @iDistributorId = (SELECT DistributorId FROM PRODUCT.Distributor WHERE Name='Product To Development DDS 2')
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@iProductId, @iDistributorId);
SET @iDistributorId = (SELECT DistributorId FROM PRODUCT.Distributor WHERE Name='Ini To File System')
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@iProductId, @iDistributorId);
SET @iDistributorId = (SELECT DistributorId FROM PRODUCT.Distributor WHERE Name='Ini To Development DDS 1')
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@iProductId, @iDistributorId);
SET @iDistributorId = (SELECT DistributorId FROM PRODUCT.Distributor WHERE Name='Ini To Development DDS 2')
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@iProductId, @iDistributorId);
INSERT INTO PRODUCT.ProductFileValidationSettings (ProductId, AllowZeroByteFile, ExpectedFileSize, FileSizePercentageTolerance, NumberOfLines, NumberOfColumns) VALUES (@iProductId, 0, NULL, NULL, NULL, 6)
INSERT INTO PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@iProductId, 'StoredProcedure', 'Section 1', 1);
DECLARE @iSectionId INT = NULL;
SET @iSectionId = (SELECT SectionId FROM PRODUCT.Section WHERE ProductId = @iProductId);
DECLARE @iUndefineColumnFileColumnId INT = NULL;
SET @iUndefineColumnFileColumnId = (SELECT FileColumnId FROM PRODUCT.FileColumn WHERE Name = 'Undefined Column');
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) VALUES (@iSectionId, @iUndefineColumnFileColumnId, 1, 'Index Code', NULL, '01 Jan 1900', '31 Dec 9999', 0, NULL, NULL);
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) VALUES (@iSectionId, @iUndefineColumnFileColumnId, 2, 'Index Name', NULL, '01 Jan 1900', '31 Dec 9999', 0, NULL, NULL);
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) VALUES (@iSectionId, @iUndefineColumnFileColumnId, 3, 'Number of Constituents', NULL, '01 Jan 1900', '31 Dec 9999', 0, NULL, NULL);
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) VALUES (@iSectionId, @iUndefineColumnFileColumnId, 4, 'Index Value (GBP)', NULL, '01 Jan 1900', '31 Dec 9999', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=7');
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) VALUES (@iSectionId, @iUndefineColumnFileColumnId, 5, 'Total Return Index (GBP)', NULL, '01 Jan 1900', '31 Dec 9999', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=7');
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) VALUES (@iSectionId, @iUndefineColumnFileColumnId, 6, 'Mkt Cap (GBP)', NULL, '01 Jan 1900', '31 Dec 9999', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=7');
INSERT INTO PRODUCT.StoredProcedure (ProcedureName, CommandTimeoutSeconds) VALUES ('PRODUCT.yljuv', 30);
DECLARE @iStoredProcedureId INT = NULL;
SET @iStoredProcedureId = (SELECT StoredProcedureId FROM PRODUCT.StoredProcedure WHERE ProcedureName = 'PRODUCT.yljuv');
INSERT INTO PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText, StoredProcedureId) VALUES (@iSectionId, '01 Jan 1900', '31 Dec 9999', 1, 'PRODUCT.yljuv', NULL, NULL, @iStoredProcedureId);

EXEC EXPORT.PRODUCT.DisplayProduct 'yljuv';
