USE EXPORT
GO
--This script need testing. 
DECLARE @ProductCode VARCHAR(50) = 'tdom_template'

DELETE p--SELECT p.*
FROM   EXPORT.PRODUCT.Product p 
       INNER JOIN EXPORT.PRODUCT.Product pt
ON     p.TemplateProductId = pt.ProductId
AND    pt.Code = 'tdom_template' 

DELETE FROM EXPORT.PRODUCT.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO EXPORT.PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate)
VALUES (1, 1,'TAX Domicil', @ProductCode, '[DD][MM].txt', ',', 1)
SET @ProductId = @@IDENTITY
INSERT INTO EXPORT.PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

DECLARE @SectionId INT
INSERT INTO EXPORT.PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY

DECLARE @SectionDetailId INT
INSERT INTO EXPORT.PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.get_tax_domicile', NULL, NULL)
SET @SectionDetailId = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.SectionDetailParameter ( SectionDetailId, ParameterName, Value)
VALUES  (@SectionDetailId, '@index_mnemonic','[index_mnemonic]') 

DECLARE @SectionColumnId INT
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Unique Identifier', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Constituent name', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'Country code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'Country Of Calculation', null, '19000101', '99991231', 0, NULL, NULL)


--Distribute to DDS

--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2)
--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3)
--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7)
--INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8)

EXEC EXPORT.PRODUCT.DisplayProduct 'tdom_template'


