USE EXPORT
GO

SET NOCOUNT ON
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_tracker_multi_day_aw_series_incl_cusip2'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT

BEGIN TRY 

	BEGIN TRAN

		DELETE PRODUCT.Product WHERE TemplateProductId in (SELECT ProductId FROM PRODUCT.Product WHERE Code = @ProductCode AND TemplateProductId IS NULL)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'All World Series Tracker Multi Day incl cusip2', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'StoredProcedure', 'Section1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.index_instr_ca_changes_get', NULL, NULL)
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@tracker_days', '[tracker_days]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@index_marker_type', '[index_marker_type]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 1, 'last_updated', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'Date -Format=DD/MM/YYYY|PaddedRight -Length=10', 'Last Modified')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 2, 'effective_date', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'Date -Format=DD/MM/YYYY|PaddedRight -Length=10', 'Effective Date')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 3, 'constituent_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Cons Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 4, 'constituent_name', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Constituent Name')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 5, 'sedol', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'SEDOL')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 6, 'cusip', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'CUSIP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 7, 'country_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Country Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 8, 'exchange_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Exchange Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 9, 'currency_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'ISO Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 10, 'index_marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Index Marker')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 11, 'previous_subsector_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Current Subsector Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 12, 'new_subsector_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Subsector Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 13, 'closing_price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Closing Price')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 14, 'price_adjustment_factor', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Price Adjustment Factor')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 15, 'adjusted_price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Adjusted Price')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 16, 'previous_shares_in_issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0', 'Current Shares in Issue')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 17, 'new_shares_in_issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0', 'New Shares in Issue')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 18, 'previous_investibility_weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Current Investibility Weight')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 19, 'new_investibility_weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'New Investibility Weight')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 20, 'amendment_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Amendment Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 21, 'amendment_notes', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Amendment Notes')

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

