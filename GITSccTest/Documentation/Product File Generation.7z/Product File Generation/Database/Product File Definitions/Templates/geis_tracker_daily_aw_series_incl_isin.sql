USE EXPORT
GO

SET NOCOUNT ON
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_tracker_daily_aw_series_incl_isin'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT

BEGIN TRY 

	BEGIN TRAN

		DELETE PRODUCT.Product WHERE TemplateProductId in (SELECT ProductId FROM PRODUCT.Product WHERE Code = @ProductCode AND TemplateProductId IS NULL)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'All World Series Tracker Daily incl ISIN', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'StoredProcedure', 'Section1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.index_valuation_get', '[section1_header]' + CHAR(13) + CHAR(10), '[section1_footer]' + CHAR(13) + CHAR(10))
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@index_name_type', '[index_name_type]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@index_marker_type', '[index_marker_type]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@snap', '[snap]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@currency', '[currency]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@index_divisor', '[index_divisor]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 1, 'index_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Index Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 2, 'previous_constituents_number', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Old Number of Constituents')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 3, 'new_constituents_number', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'New Number of Constituents')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 4, 'close_cap', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Previous Market Capitalisation')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 5, 'open_cap', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'New Market Capitalisation')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 6, 'previous_ind_divisor', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Previous Divisor')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 7, 'new_ind_divisor', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'New Divisor')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 8, 'xd_adjustment', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=3', 'XD Adjustment Value')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'StoredProcedure', 'Section2', 2)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.index_instr_ca_changes_get', '[section2_header]' + CHAR(13) + CHAR(10), '[section2_footer]' + CHAR(13) + CHAR(10))
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@tracker_days', '[tracker_days]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@index_marker_type', '[index_marker_type]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 1, 'constituent_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Cons Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 2, 'constituent_name', NULL, '1900-01-01', '9999-12-31', 1, NULL, NULL, 'Constituent Name')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 3, 'sedol', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'SEDOL')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 4, 'isin', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'ISIN')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 5, 'country_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Country Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 6, 'exchange_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Exchange Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 7, 'currency_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'ISO Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 8, 'index_marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Index Marker')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 9, 'previous_subsector_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Closing Subsector Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 10, 'new_subsector_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'New Subsector Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 11, 'closing_price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Closing Price')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 12, 'price_adjustment_factor', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Price Adjustment Factor')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 13, 'adjusted_price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Adjusted Price')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 14, 'previous_shares_in_issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0', 'Previous Shares in Issue')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 15, 'new_shares_in_issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0', 'New Shares in Issue')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 16, 'previous_investibility_weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=3', 'Previous Investibility Weight')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 17, 'new_investibility_weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=3', 'New Investibility Weight')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 18, 'amendment_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Amendment Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 19, 'amendment_notes', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Amendment Notes')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'StoredProcedure', 'Section3', 3)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.index_dividend_changes_get', '[section3_header]' + CHAR(13) + CHAR(10), '[section3_footer]')
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@tracker_days', '[tracker_days]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@index_marker_type', '[index_marker_type]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 1, 'constituent_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Cons Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 2, 'constituent_name', NULL, '1900-01-01', '9999-12-31', 1, NULL, NULL, 'Constituent Name')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 3, 'sedol', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'SEDOL')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 4, 'isin', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'ISIN')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 5, 'country_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Country Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 6, 'exchange_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Exchange Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 7, 'subsector_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Subsector Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 8, 'shares_in_issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0', 'Shares in Issue')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 9, 'investibility_weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2', 'Investibility Weight')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 10, 'effective_date', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'Date -Format=DD/MM/YYYY|PaddedRight -Length=10', 'Ex-Dividend Date')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 11, 'net_amount', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Dividend Amount')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 12, 'currency_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'ISO Currency Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 13, 'index_marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Index Marker')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 14, 'xd_adjustment_value', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=3', 'XD Adjustment Value')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 15, 'freq_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'FTSE Dividend Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 16, 'internal_notes', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'FTSE Dividend Notes')

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

