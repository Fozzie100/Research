USE EXPORT
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_oc_world_americas'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT
	,@SectionColumnId INT

BEGIN TRY 

	BEGIN TRAN

		DELETE PRODUCT.Product where TemplateProductId in (select ProductId from PRODUCT.Product where Code = @ProductCode)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'World Open Constituents (Americas)', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'Generated', 'Section 1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.get_opening_constituent_list', NULL, NULL)
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 2, 1, 'Cons code', 2, '1900-01-01', '9999-12-31', 0, NULL, 'Prefix -Value=C')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 3, 2, 'SEDOL', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 4, 3, 'CUSIP', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 5, 4, 'Constituent Name', NULL, '1900-01-01', '9999-12-31', 1, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 6, 5, 'Country code', 1, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 7, 6, 'ISO Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 11, 7, 'Exchange Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 27, 8, 'Price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 9, 9, 'Shares in Issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 20, 10, 'Weighting', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 15, 11, 'Industry Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 14, 12, 'Sector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 13, 13, 'Subsector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 40, 14, 'Dividend Yield', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2|Suffix -Value=%')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 28, 15, 'Mkt cap (USD) before Investibility Weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 26, 'USD')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 164, '1000000')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 29, 16, 'Mkt cap (USD) after Investibility Weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 28, 'USD')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 176, '1000000')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 17, '% Wt World', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 18, '% Wt World (ex US)', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 19, '% Wt World (ex UK)', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 20, '% Wt World (ex Japan)', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 21, '% Wt World (ex South Africa)', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 22, '% Wt North America', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 23, '% Wt World (ex Eurobloc)', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 24, '% Wt Americas', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 25, '% Wt Country', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 26, '% Wt Industry', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 87, 27, '% Wt Sector', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 60, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 16, 28, 'Index Marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 11, 'WIC_IM')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 10, 29, 'Size Marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 9, 'AWGC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 12, 30, 'Supersector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

