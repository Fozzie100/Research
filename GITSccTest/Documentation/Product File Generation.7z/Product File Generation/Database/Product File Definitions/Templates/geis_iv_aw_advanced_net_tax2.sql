USE EXPORT
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_iv_aw_advanced_net_tax2'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT
	,@SectionColumnId INT

BEGIN TRY 

	BEGIN TRAN

		DELETE PRODUCT.Product where TemplateProductId in (select ProductId from PRODUCT.Product where Code = @ProductCode)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'FTSE All-World Advanced Net Tax Index Service', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'Generated', 'Section 1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.get_valuationfile_indices', NULL, NULL)
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code_value]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@show_blank_index', '0')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 25, 1, 'Index Code', 1, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 270, '[index_attr_fld_code]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 34, 2, 'Index Sector/Name', NULL, '1900-01-01', '9999-12-31', 1, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 32, '[index_name_code]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 26, 3, 'Number of constituents', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 35, 4, 'US dollar index', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 33, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 35, 5, 'Sterling index', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 33, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 35, 6, 'Euro index', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 33, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 35, 7, 'Japanese yen index', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 33, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 35, 8, 'Swiss franc index', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 33, 'CHF')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 35, 9, 'Local currency index', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 33, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 36, 10, 'US dollar TRI', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 34, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 36, 11, 'Sterling TRI', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 34, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 36, 12, 'Euro TRI', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 34, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 36, 13, 'Japanese yen TRI', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 34, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 36, 14, 'Swiss franc TRI', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 34, 'CHF')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 36, 15, 'Local currency TRI', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 34, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 37, 16, 'Mkt Cap ($)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 35, 'USD')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 202, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 37, 17, 'Mkt Cap (Sterling)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 35, 'GBP')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 202, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 37, 18, 'Mkt Cap (Euro)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 35, 'EUR')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 202, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 37, 19, 'Mkt Cap (Yen)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 35, 'JPY')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 202, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 37, 20, 'Mkt Cap ( Swiss franc)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 35, 'CHF')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 202, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 37, 21, 'Mkt Cap (Local Index)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 35, '[local_currency_value]')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 202, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 158, 22, 'XD adjustment (YTD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=3')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 140, '[snap]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 41, 23, 'Dividend yield', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 73, 24, 'Industry Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 71, 25, 'Sector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 72, 26, 'Subsector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 220, 27, 'Currency', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 62, 28, 'Daily Performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 54, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 62, 29, 'Daily Performance (Local)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 54, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 62, 30, 'Daily Performance (GBP)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 54, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 62, 31, 'Daily Performance (EUR)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 54, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 62, 32, 'Daily Performance (YEN)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 54, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 62, 33, 'Daily Performance (CHF)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 54, 'CHF')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 63, 34, 'Daily Performance TRI (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 55, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 63, 35, 'Daily Performance TRI (Local)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 55, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 63, 36, 'Daily Performance TRI (GBP)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 55, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 63, 37, 'Daily Performance TRI (EUR)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 55, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 63, 38, 'Daily Performance TRI (YEN)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 55, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 63, 39, 'Daily Performance TRI (CHF)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 55, 'CHF')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 1, 40, 'Weight in Index', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 68, 41, 'Weight in Industry', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 64, 42, 'Monthly Performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 56, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 64, 43, 'Monthly Performance (Local)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 56, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 64, 44, 'Monthly Performance (GBP)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 56, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 64, 45, 'Monthly Performance (EUR)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 56, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 64, 46, 'Monthly Performance (YEN)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 56, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 64, 47, 'Monthly Performance (CHF)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 56, 'CHF')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 65, 48, 'Monthly Performance TRI (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 57, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 65, 49, 'Monthly Performance TRI (Local)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 57, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 65, 50, 'Monthly Performance TRI (GBP)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 57, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 65, 51, 'Monthly Performance TRI (EUR))', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 57, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 65, 52, 'Monthly Performance TRI (YEN)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 57, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 65, 53, 'Monthly Performance TRI (CHF)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 57, 'CHF')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 66, 54, 'YTD Performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 58, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 66, 55, 'YTD Performance (Local)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 58, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 66, 56, 'YTD Performance (GBP)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 58, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 66, 57, 'YTD Performance (EUR)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 58, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 66, 58, 'YTD Performance (YEN)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 58, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 66, 59, 'YTD Performance (CHF)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 58, 'CHF')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 67, 60, 'YTD TRI Performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 59, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 67, 61, 'YTD TRI Performance (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 59, '[local_currency_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 67, 62, 'YTD TRI Performance (GBP)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 59, 'GBP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 67, 63, 'YTD TRI Performance (EUR)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 59, 'EUR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 67, 64, 'YTD TRI Performance (YEN)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 59, 'JPY')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 67, 65, 'YTD TRI Performance (CHF)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 59, 'CHF')

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

