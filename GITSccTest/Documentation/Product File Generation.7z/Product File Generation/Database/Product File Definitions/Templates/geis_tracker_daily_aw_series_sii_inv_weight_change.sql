USE EXPORT
GO

SET NOCOUNT ON
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_tracker_daily_aw_series_sii_inv_weight_change'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT

BEGIN TRY 

	BEGIN TRAN

		DELETE PRODUCT.Product WHERE TemplateProductId in (SELECT ProductId FROM PRODUCT.Product WHERE Code = @ProductCode AND TemplateProductId IS NULL)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'All World Series Tracker Daily with Share and Investibility weight changes', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'StoredProcedure', 'Section1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.index_instr_shares_investibility_weight_changes_get', NULL, NULL)
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@tracker_days', '[tracker_days]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code]')

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@index_marker_type', '[index_marker_type]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 1, 'constituent_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Cons Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 2, 'constituent_name', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Constituent Name')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 3, 'isin', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'ISIN Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 4, 'sedol', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'SEDOL')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 5, 'cusip', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'CUSIP')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 6, 'country_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Country Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 7, 'exchange_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'MIC Exchange Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 8, 'currency_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Currency Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 9, 'previous_shares_in_issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0', 'Previous Shares in Issue')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 10, 'new_shares_in_issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0', 'New Shares in Issue')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 11, 'previous_investibility_weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'Previous Investability Weight')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 12, 'new_investibility_weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6', 'New Investability Weight')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 13, 'amendment_code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Amendment Code')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments, DisplayName)
				VALUES(@SectionId, 1, 14, 'index_marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL, 'Index Marker')

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

