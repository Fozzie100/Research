USE EXPORT
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_cc_all_cap_advanced'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT
	,@SectionColumnId INT

BEGIN TRY 

	BEGIN TRAN
		DELETE PRODUCT.Product where TemplateProductId in (select ProductId from PRODUCT.Product where Code = @ProductCode)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'FTSE Global Equity Index Series Advanced Cons', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'Generated', 'Section 1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.get_index_constituents', NULL, NULL)
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 2, 1, 'Cons Code', 1, '1900-01-01', '9999-12-31', 0, NULL, 'Prefix -Value=C')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 18, 2, 'Net Market Cap (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 15, 'LOC')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 165, '1')

				--INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				--VALUES(@SectionId, 43, 3, 'ISIN', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				--SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 95, 3, 'ISIN', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 9, 4, 'Actual Shares in Issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 60, 5, 'High Price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 52, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 61, 6, 'Low Price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 53, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 81, 7, 'Volume', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 77, 8, 'Adjusted Factor', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 70, 9, 'Previous day''s price (unadjusted)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 130, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 55, 10, 'Corporate action story', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 56, 11, 'Corporate action type', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 59, 12, 'Dividend Currency', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 51, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 79, 13, 'Dividend Amount', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 85, '')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 75, 14, 'Dividend announcement date', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 80, 15, 'Dividend books close date', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 76, 16, 'Dividend payment date', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 74, 17, 'Dividend type', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 69, 18, 'Dividend XD Date', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 78, 19, 'Annual Dividend', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 150, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 42, 20, 'Dividend Yield', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 57, 21, 'Daily price performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 49, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 57, 22, 'Daily price performance (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 49, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 51, 23, '1 month price performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 45, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 51, 24, '1 month price performance (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 45, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 53, 25, 'YTD price performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 47, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 53, 26, 'YTD price performance (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 47, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 58, 27, 'Daily TRI performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 50, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 58, 28, 'Daily TRI performance (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 50, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 52, 29, '1 month TRI performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 46, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 52, 30, '1 month TRI performance (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 46, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 54, 31, 'YTD TRI performance (USD)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 48, 'USD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 54, 32, 'YTD TRI performance (LOC)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 48, 'LOC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 179, 33, 'Alpha (90-d)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 182, 'LCAC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 180, 34, 'Beta (90-d)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 183, 'LCAC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 181, 35, 'Specific Risk (90-d)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 184, 'LCAC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 86, 36, 'Total Risk (90-d)', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

