USE EXPORT
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_cc_developed_small_cap'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT
	,@SectionColumnId INT

BEGIN TRY 

	BEGIN TRAN
		DELETE PRODUCT.Product where TemplateProductId in (select ProductId from PRODUCT.Product where Code = @ProductCode)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'FTSE Developed Small Cap Constituents', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'Generated', 'Section 1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.get_index_constituents', NULL, NULL)
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 2, 1, 'Cons code', 2, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 3, 2, 'SEDOL', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 4, 3, 'CUSIP', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 5, 4, 'Constituent name', NULL, '1900-01-01', '9999-12-31', 1, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 6, 5, 'Country code', 1, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 7, 6, 'ISO code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 11, 7, 'Exchange code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 8, 8, 'Price', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 9, 9, 'Shares in Issue', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 20, 10, 'Weighting', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 15, 11, 'Industry Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 14, 12, 'Sector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 13, 13, 'Subsector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 42, 14, 'Dividend Yield', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 17, 15, 'Mkt Cap (USD) before investibility weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 13, 'USD')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 163, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 18, 16, 'Mkt Cap (USD) after investibility weight', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 15, 'USD')

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 165, '1')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 17, '% Wt Small Cap Developed', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCD')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 18, '% Wt Small Cap Developed ex Japan', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCDXJ')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 19, '% Wt Small Cap Developed ex UK', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCDXUK')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 20, '% Wt Small Cap Developed ex US', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCDXUS')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 21, '% Wt Small Cap Developed ex Eurobloc', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCDXEBS')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 22, '% Wt Small Cap Developed ex North America', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCDXNA')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 23, '% Wt Small Cap Asia Pacific', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCPACS')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 24, '% Wt Small Cap Asia Pacific ex Japan', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCPACXJA')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 25, '% Wt Small Cap Developed Europe', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCDEURS')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 26, '% Wt Small Cap Developed Europe ex UK', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCDEXUKS')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 27, '% Wt Small Cap Eurobloc', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCEBLOCS')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 19, 28, '% Wt Small Cap Nordic', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 17, 'SCNORDS')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 22, 29, '%Wt Dev Small Cap Country', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 23, 30, '%Wt Dev Small Cap Industry', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 24, 31, '%Wt Dev Small Cap Sector', NULL, '1900-01-01', '9999-12-31', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 16, 32, 'Index Marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 11, 'GEISSR')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 10, 33, 'Size Marker', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value)
					VALUES(@SectionColumnId, 9, 'AWGC')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 12, 34, 'Supersector Code', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

