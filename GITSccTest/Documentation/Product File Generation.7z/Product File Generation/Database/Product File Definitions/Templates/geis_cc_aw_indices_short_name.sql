USE EXPORT
GO

DECLARE
	 @ProductId INT
	,@ProductCode VARCHAR(50) = 'geis_cc_aw_indices_short_name'
	,@ProductGroupId INT
	,@ProductGroupName VARCHAR(200) = 'Templates'
	,@TemplateProductCode VARCHAR(50) = NULL
	,@TemplateProductId INT
	,@SectionId INT
	,@SectionDetailId INT
	,@SectionColumnId INT

BEGIN TRY 

	BEGIN TRAN
		DELETE PRODUCT.Product where TemplateProductId in (select ProductId from PRODUCT.Product where Code = @ProductCode)

		--Delete if product already exist
		DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

		--Create Product Group if it doesnt exist
		EXEC PRODUCT.CreateProductGroup @ProductGroupId output, @ProductGroupName

		--Get Template Product Id linked to the Product (if any)
		SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE Code = @TemplateProductCode and IsTemplate = 1

		INSERT INTO PRODUCT.Product(ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
		VALUES(@ProductGroupId, 1, 'All-World Short Name Constituents', @ProductCode, '<%d><%m>.csv', ',', 1, @TemplateProductId)
		SET @ProductId = SCOPE_IDENTITY()

		INSERT INTO PRODUCT.ProductDetail(ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
		VALUES(@ProductId, '1900-01-01', '9999-12-31', '<%d>/<%m>/<%Y> (C) FTSE International Limited 2001. All Rights Reserved
[product_title]
', 'XXXXXXXXXX')

			INSERT INTO PRODUCT.Section(ProductId, SectionType, Name, Sequence)
			VALUES(@ProductId, 'Generated', 'Section 1', 1)
			SET @SectionId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionDetail(SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
				VALUES(@SectionId, '1900-01-01', '9999-12-31', 1, 'PRODUCT.get_index_constituents', NULL, NULL)
				SET @SectionDetailId = SCOPE_IDENTITY()

					INSERT INTO PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName, Value)
					VALUES(@SectionDetailId, '@list_code', '[list_code_value]')

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 2, 1, 'Cons code', 1, '1900-01-01', '9999-12-31', 0, NULL, 'Prefix -Value=C')
				SET @SectionColumnId = SCOPE_IDENTITY()

				INSERT INTO PRODUCT.SectionColumn(SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments)
				VALUES(@SectionId, 82, 2, 'Short Constituent Name', NULL, '1900-01-01', '9999-12-31', 0, NULL, NULL)
				SET @SectionColumnId = SCOPE_IDENTITY()

		--Display Product Details
		EXEC PRODUCT.displayproduct @ProductCode

	COMMIT TRAN

END TRY
BEGIN CATCH
	DECLARE @error INT, @message VARCHAR(4000), @xstate INT, @errorLine INT
	SELECT @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE(), @errorLine = ERROR_LINE()
	IF @@TRANCOUNT > 0 ROLLBACK TRAN
	RAISERROR('Error with code %d on line %d: %s', 16, 1, @error, @errorLine, @message)
END CATCH

