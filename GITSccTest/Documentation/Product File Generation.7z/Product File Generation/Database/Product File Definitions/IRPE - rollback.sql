USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'IRPE'
DECLARE @ProductID INT
DECLARE @SectionID INT

SELECT @ProductID = ProductId
FROM EXPORT.PRODUCT.Product WHERE Code = @ProductCode
select @ProductID

SELECT @SectionID = SectionId
FROM PRODUCT.Section
WHERE ProductId = @ProductID

DELETE FROM EXPORT.PRODUCT.Product WHERE ProductId = @ProductID
DELETE FROM EXPORT.PRODUCT.ProductDetail WHERE ProductId = @ProductID
DELETE FROM EXPORT.PRODUCT.Section WHERE ProductId = @ProductID

DELETE sd
FROM PRODUCT.SectionDetail sd
INNER JOIN PRODUCT.Section s
ON s.SectionId = sd.SectionId
WHERE ProductId = @ProductID

DELETE sc
FROM PRODUCT.SectionColumn sc
INNER JOIN PRODUCT.SectionDetail sd
ON sc.SectionId = sd.SectionId
INNER JOIN PRODUCT.Section s
ON s.SectionId = sd.SectionId
WHERE ProductId = @ProductID

DELETE FROM PRODUCT.ProductDistributor
WHERE ProductId = @ProductID


