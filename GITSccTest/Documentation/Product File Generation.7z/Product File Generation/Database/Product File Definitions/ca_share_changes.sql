USE EXPORT
GO

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
EXEC PRODUCT.CreateProductGroup @ProductGroupId output, 'FREDD EXPORT'

DECLARE @ProductCode VARCHAR(50) = 'share_changes'

DELETE FROM EXPORT.PRODUCT.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO EXPORT.PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (@ProductGroupId, 1,'CORPORATE_ACTION', @ProductCode, '.csv', ',')
SET @ProductId = @@IDENTITY
INSERT INTO EXPORT.PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', NULL, NULL)
DECLARE @SectionId INT
INSERT INTO EXPORT.PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO EXPORT.PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, '[PRODUCT].[share_changes]', NULL, NULL)
SET @SectionDetailId = @@IDENTITY


INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'instrument', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'issue_date', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'source', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'shares', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'increment', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 'feed_date', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 7, 'Delete', null, '19000101', '99991231', 0, NULL, NULL)


EXEC EXPORT.PRODUCT.DisplayProduct @ProductCode

