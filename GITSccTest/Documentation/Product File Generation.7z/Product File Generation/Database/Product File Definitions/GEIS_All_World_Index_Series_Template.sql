USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'geis_aw_is_template'
DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'Templates'

DECLARE @ProductId INT
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 1, 'GEIS All World Index Series Template', @ProductCode, '<%d><%m>.csv', ',', 1, NULL)
SET @ProductId = @@IDENTITY

-- Header & Footer
DECLARE 
	 @Header varchar(250) = '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved' + CHAR(13) + '[product_title]' + CHAR(13) + ' ' + CHAR(13)
	,@Footer varchar(50) = 'XXXXXXXXXX'

INSERT INTO PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', @Header, @Footer)

DECLARE @SectionId INT
INSERT INTO PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'Generated', 'Index Values', 1)
SET @SectionId = @@IDENTITY

DECLARE @SectionDetailId INT
INSERT INTO PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.get_valuationfile_indices', NULL, NULL)
SET @SectionDetailId = @@IDENTITY

INSERT INTO PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@list_code', 'AWII')
INSERT INTO PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@show_blank_index', 0)

DECLARE @SectionColumnId INT
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 25, 1, 'Index Code', 1, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 34, 2, 'Index Sector/Name', null, '19000101', '99991231', 1, NULL, 'UpperCase')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 26, 3, 'Number of constituents', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 4, 'US dollar index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 5, 'Sterling index', NULL, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'GBP')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 6, 'Euro index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'EUR')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 7, 'Japanese yen index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, 'JPY')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 35, 8, 'Local currency index', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 33, '[local_currency_value]')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 9, 'US dollar TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'USD')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 10, 'Sterling TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'GBP')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 11, 'Euro TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'EUR')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 12, 'Japanese yen TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, 'JPY')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 36, 13, 'Local currency TRI', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=8')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 34, '[local_currency_value]')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 219, 'WI')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 14, 'Mkt Cap ($)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'USD')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 15, 'Mkt Cap (Sterling)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'GBP')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 16, 'Mkt Cap (Euro)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'EUR')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 17, 'Mkt Cap (Yen)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'JPY')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 37, 18, 'Mkt Cap (Local Index)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 35, 'LOC')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 202, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 38, 19, 'XD adjustment (YTD)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=3')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 41, 20, 'Dividend yield', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2')

--display product details
EXEC PRODUCT.displayproduct @ProductCode
