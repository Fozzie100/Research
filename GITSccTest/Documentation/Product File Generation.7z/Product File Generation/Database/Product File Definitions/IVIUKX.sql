USE EXPORT

DECLARE @ProductGroupId INT
DECLARE @ProductGroupName VARCHAR(50) = 'FTSE Implied Volatility UKX Index'
DECLARE @ProductGroupNameCount INT

SELECT @ProductGroupNameCount =  COUNT(Name) FROM Export.Product.ProductGroup WHERE Name  = @ProductGroupName 

IF @ProductGroupNameCount = 0
BEGIN
	INSERT INTO Export.PRODUCT.ProductGroup ( ParentProductGroupId, Name ) VALUES ( NULL , 'FTSE Implied Volatility UKX Index' )
	SET @ProductGroupId = @@IDENTITY
END
ELSE
BEGIN
	SELECT @ProductGroupId =  ProductGroupId FROM Export.Product.ProductGroup WHERE Name  = @ProductGroupName 
END

DECLARE @ProductCode VARCHAR(50) = 'IVIUKX'
DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @UKXProductID INT

INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix,Delimiter, IsTemplate,TemplateProductId)
VALUES (@ProductGroupId, 2, 'FTSE 100 Implied Volatility Index Valuation File', 'IVIUKX','[DD][MM].csv',',',0,NULL)
SET @UKXProductID = @@IDENTITY

INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@UKXProductID, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved 
FTSE 100 Implied Volatility Index Valuation File
', 'XXXXXXXXXX')

DECLARE @UKXSectionID INT

INSERT INTO Export.PRODUCT.Section (ProductId,SectionType,Name,Sequence)
VALUES (@UKXProductID,'StoredProcedure','Section 1',1)
SET @UKXSectionID = @@IDENTITY

DECLARE @UKXSectionDetailID INT

INSERT INTO Export.PRODUCT.SectionDetail (SectionId,EffectiveDate,ExpiryDate,OutputColumnNames,ProcedureName,HeaderText,FooterText)
VALUES (@UKXSectionID,'19000101', '99991231', 1, 'PRIME.PRODUCT.ivi_valuation',NULL,NULL)
SET @UKXSectionDetailID = @@IDENTITY

INSERT INTO Export.PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName,Value)
VALUES(@UKXSectionDetailID,'@index_code','IVIUKX')

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 1, 'Index Code', null, '19000101', '99991231', 0, NULL, 'UpperCase')
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 2, 'Index Name', null, '19000101', '99991231', 0, NULL, 'CamelCase')
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 3, 'Date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 4, 'Value', null, '19000101', '99991231', 0, NULL,'RoundedDecimal -NumberOfDecimalPlaces=6')

INSERT INTO Export.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,2)
INSERT INTO Export.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,3)
INSERT INTO Export.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,7)
INSERT INTO Export.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,8)