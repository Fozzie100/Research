USE EXPORT
GO

DECLARE @ProductGroupId INT = 12
DECLARE @index_mnemonic VARCHAR(32) = 'AWDEXUKS'
DECLARE @index_name VARCHAR(100) = 'FTSE Developed Europe ex UK Index'
DECLARE @ProductCode VARCHAR(10) = 'aw06femn'

DECLARE @TemplateProductId INT
SELECT @TemplateProductId = ProductId FROM PRODUCT.Product WHERE ProductGroupId = 6 AND Code = 'Event Monitor - GEISAC Code Name Changes'

DELETE FROM Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 2, 'Code and Name Changes (' + @index_name + ')', @ProductCode, '<%d><%m>.csv', ',', 0, @TemplateProductId)
SET @ProductId = @@IDENTITY
INSERT INTO Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
Code and Name Changes (' + @index_name + ')
', 'XXXXXXXXXX')

--Setup tokens required by template
INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[index_mnemonic]', @index_mnemonic)
INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[index_name]', @index_name)

--Setup distribution
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 5)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 10)

EXEC PRODUCT.DisplayProduct @ProductCode