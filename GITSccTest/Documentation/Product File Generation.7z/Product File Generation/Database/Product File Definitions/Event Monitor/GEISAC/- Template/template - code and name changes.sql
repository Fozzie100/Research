USE EXPORT
GO

DECLARE @ProductGroupId INT = 6
DECLARE @ProductCode VARCHAR(50) = 'Event Monitor - GEISAC Code Name Changes'

DELETE FROM Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 2, 'Code and Name Changes ([index_name])', @ProductCode, '<%d><%m>.csv', ',', 1, NULL)
SET @ProductId = @@IDENTITY
INSERT INTO Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved
Code and Name Changes ([index_name])
', 'XXXXXXXXXX')
DECLARE @SectionId INT
INSERT INTO Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section 1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.geisac_code_and_name_changes', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
INSERT INTO PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@index_mnemonic', '[index_mnemonic]')
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Country', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'Region', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Country Classification', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'Action Type', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'Action Description', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 'Multiple Event', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 7, 'Last Modified Date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 8, 'Effective Date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 9, 'Status', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 10, 'Cons Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 11, 'Sedol', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 12, 'ISIN', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 13, 'CUSIP', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 14, 'Reserved 1', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 15, 'Reserved 2', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 16, 'Exchange', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 17, 'Company Name', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 18, 'Size', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 19, 'New Sedol', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 20, 'New ISIN', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 21, 'New CUSIP', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 22, 'New Company Name', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 23, 'New Country', null, '19000101', '99991231', 0, NULL, NULL)



--Setup distribution
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 5)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8)
INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 10)

--Display the product
EXEC PRODUCT.DisplayProduct @ProductCode