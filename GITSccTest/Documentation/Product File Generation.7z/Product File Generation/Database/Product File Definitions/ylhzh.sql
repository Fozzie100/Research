USE Export
GO
DECLARE @ProductGroupId INT = NULL;
SET @ProductGroupId = (SELECT DISTINCT ProductGroupId FROM PRODUCT.Product WHERE Code='yalrh');
DECLARE @DataSourceId INT = NULL;
SET @DataSourceId = (SELECT DISTINCT DataSourceId FROM PRODUCT.Product WHERE Code = 'yalrh');
DECLARE @ProductTitle VARCHAR(100) = 'FTSE Hedging Service - ylhzh';
DECLARE @ProductCode VARCHAR(50) = 'ylhzh';
DECLARE @FileSuffix VARCHAR(50) = NULL;
SET @FileSuffix = (SELECT DISTINCT FileSuffix FROM PRODUCT.Product WHERE Code = 'yalrh');
DECLARE @Delimiter CHAR(1) = NULL;
SET @Delimiter = (SELECT DISTINCT Delimiter FROM PRODUCT.Product WHERE Code = 'yalrh');
DECLARE @IsTemplate BIT = NULL;
SET @IsTemplate = (SELECT DISTINCT IsTemplate FROM PRODUCT.Product WHERE Code = 'yalrh');
DECLARE @TemplateProductId INT = NULL;
SET @TemplateProductId = (SELECT DISTINCT TemplateProductId FROM PRODUCT.Product WHERE Code = 'yalrh');

DECLARE @ProductId INT = NULL;
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
	VALUES (@ProductGroupId, @DataSourceId, @ProductTitle, @ProductCode, @FileSuffix, @Delimiter, @IsTemplate, @TemplateProductId)
	;
SET @ProductId = @@IDENTITY;

INSERT INTO PRODUCT.ProductDistributor (ProductId, DistributorId)
	SELECT @ProductId, DistributorId FROM PRODUCT.ProductDistributor WHERE ProductId=410
	;
	
EXEC PRODUCT.DisplayProduct @ProductCode;

