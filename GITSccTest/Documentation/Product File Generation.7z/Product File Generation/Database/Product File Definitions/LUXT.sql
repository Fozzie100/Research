USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'LUXT'
DECLARE @ProductTitle VARCHAR(255) = 'Luxembourg UCITS Tax Rate Service'
DECLARE @ProductId INT
DECLARE @SectionId INT
DECLARE @SectionDetailId INT

INSERT INTO EXPORT.PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1,2,@ProductTitle, @ProductCode, '[DD][MM].csv', ',')

SET @ProductId = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved' + CHAR(13)
+ @ProductTitle + CHAR(13) + ' '
+ CHAR(13), 'XXXXXXXXXX')


INSERT INTO EXPORT.PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)

SET @SectionId = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCTS.dividend_tax_rates_daily', NULL, NULL)

SET @SectionDetailId = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) 
VALUES (@SectionDetailId, '@source', '[source]')

DECLARE @SectionColumnId INT
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Country', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'Country Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Current Tax Rate (%)', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'New Tax Rate (%)', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'Effective Date', null, '19000101', '99991231', 0, NULL, NULL)

--create distributors
INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 12) --annual
INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 2) --dds 1 product
INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 3) --dds 2 product
INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 7) --dds 1 ini
INSERT INTO EXPORT.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 8) --dds 2 ini


