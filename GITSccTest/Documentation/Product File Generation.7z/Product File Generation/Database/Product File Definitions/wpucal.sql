USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'wpucal'
DECLARE @ProductTitle VARCHAR(255)

SELECT @ProductTitle = 'FTSE WPU Futures Rollover And Rebalance Calendar'

select @ProductTitle

DELETE FROM Export.Product.Product WHERE Code = @ProductCode
DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (82,2,@ProductTitle, @ProductCode, '[DD][MM].csv', ',')
SET @ProductId = @@IDENTITY

INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved' + CHAR(13)
+ @ProductTitle + CHAR(13) + ' '
+ CHAR(13), 'XXXXXXXXXX')

DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
select @SectionId [SectionId]
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText, StoredProcedureId)
VALUES (@SectionId, '19000101', '99991231', 1, 'ANALYSTS.WPU_calendar_file', 'Futures Calendar', 'YYYYYYYYYY', 162)

SET @SectionDetailId = @@IDENTITY

INSERT INTO Export.PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) 
VALUES (@SectionDetailId, '@section_id', '1')


DECLARE @SectionColumnId INT
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Contract Date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'WPU Brent Oil Rollover', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Last Trading Day', null, '19000101', '99991231', 0, NULL, NULL)


INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section2', 2)
SET @SectionId = @@IDENTITY
select @SectionId [SectionId]
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText, StoredProcedureId)
VALUES (@SectionId, '19000101', '99991231', 1, 'ANALYSTS.WPU_calendar_file', '', 'YYYYYYYYYY', 162)

SET @SectionDetailId = @@IDENTITY

INSERT INTO Export.PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) 
VALUES (@SectionDetailId, '@section_id', '2')

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Contract Date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'WPU Gold Rollover', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Last Trading Day', null, '19000101', '99991231', 0, NULL, NULL)


INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section3', 3)
SET @SectionId = @@IDENTITY
select @SectionId [SectionId]
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText, StoredProcedureId)
VALUES (@SectionId, '19000101', '99991231', 1, 'ANALYSTS.WPU_calendar_file', 'Rebalance Calendar', 'YYYYYYYYYY', 162)

SET @SectionDetailId = @@IDENTITY

INSERT INTO Export.PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) 
VALUES (@SectionDetailId, '@section_id', '3')

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Date', null, '19000101', '99991231', 0, NULL, NULL)

--create validation settings
--INSERT INTO Export.PRODUCT.ProductFileValidationSettings (ProductId, NumberOfLines) VALUES (@ProductId, 7)

--create distributors
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 22) --annual
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 25) --ftpdc product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 27) --ftasr product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 26) --dtpdc ini
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 28) --ftasr ini

exec Export.PRODUCT.DisplayProduct @ProductCode


