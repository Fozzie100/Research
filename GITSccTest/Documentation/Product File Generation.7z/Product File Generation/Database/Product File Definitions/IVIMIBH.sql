USE EXPORT

DECLARE @ProductGroupId INT
DECLARE @ProductGroupName VARCHAR(50) = 'FTSE Implied Volatility MIB Index'
DECLARE @ProductGroupNameCount INT

SELECT @ProductGroupNameCount =  COUNT(Name) FROM EXPORT.PRODUCT.ProductGroup WHERE Name  = @ProductGroupName 

IF @ProductGroupNameCount = 0
BEGIN
	INSERT INTO EXPORT.PRODUCT.ProductGroup ( ParentProductGroupId, Name ) VALUES ( NULL , 'FTSE Implied Volatility MIB Index' )
	SET @ProductGroupId = @@IDENTITY
END
ELSE
BEGIN
	SELECT @ProductGroupId =  ProductGroupId FROM EXPORT.PRODUCT.ProductGroup WHERE Name  = @ProductGroupName 
END

DECLARE @ProductCode VARCHAR(50) = 'IVIMIBH'
DELETE FROM EXPORT.PRODUCT.Product WHERE Code = @ProductCode

DECLARE @MIBProductID INT

INSERT INTO EXPORT.PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix,Delimiter, IsTemplate,TemplateProductId)
VALUES (@ProductGroupId, 2, 'FTSE Implied Volatility MIB History File', 'IVIMIBH','[DD][MM].csv',',',0,NULL)
SET @MIBProductID = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@MIBProductID, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved 
FTSE IVI MIB History File

Index Code,IVMIB30,IVMIB60,IVMIB90,IVMIB180,IVMIB360
Index Name,FTSE MIB IVI 30 days,FTSE MIB IVI 60 days,FTSE MIB IVI 90 days,FTSE MIB IVI 180 days,FTSE MIB IVI 360 days', 'XXXXXXXXXX')

DECLARE @MIBSectionID INT

INSERT INTO EXPORT.PRODUCT.Section (ProductId,SectionType,Name,Sequence)
VALUES (@MIBProductID,'StoredProcedure','Section 1',1)
SET @MIBSectionID = @@IDENTITY

DECLARE @MIBSectionDetailID INT

INSERT INTO EXPORT.PRODUCT.SectionDetail (SectionId,EffectiveDate,ExpiryDate,OutputColumnNames,ProcedureName,HeaderText,FooterText)
VALUES (@MIBSectionID,'19000101', '99991231', 1, 'PRIME.PRODUCT.ivi_histvals',NULL,NULL)
SET @MIBSectionDetailID = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName,Value)
VALUES(@MIBSectionDetailID,'@index_code','IVIMIB')

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 1, 'Date', null, '19000101', '99991231', 0, NULL, 'UpperCase')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 2, '30days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 3, '60days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 4, '90days', null, '19000101', '99991231', 0, NULL,'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 5, '180days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 6, '360days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')

INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,2)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,3)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,7)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,8)