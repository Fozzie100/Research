USE EXPORT
GO

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
--exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'ESG Theme Data'
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'ESG Common Template'

DECLARE @ProductTitle VARCHAR(50) = 'ESG Theme Data Ratings File Template'
DECLARE @ProductCode VARCHAR(50) = 'ESGRT_Template'

/*
--DECLARE @PreviousTemplateProductID INT
--SELECT @PreviousTemplateProductID = ProductId FROM  Export.Product.Product WHERE Code = @ProductCode
--SELECT @PreviousTemplateProductID

---- remove procs that use template
--DELETE FROM Export.Product.Product WHERE TemplateProductID = @PreviousTemplateProductID
*/

-- remove previous instance of itself
DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@productGroupId, 2, @ProductTitle, @ProductCode, '[DD][MM].csv', ',', 1, NULL)
SET @ProductId = @@IDENTITY


-- Header & Footer
DECLARE @Header varchar(250) = '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved' + CHAR(13)+ '[product_title]' + CHAR(13) + ' ' + CHAR(13)
, @Footer varchar(50) = 'XXXXXXXXXX'

INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', @Header, @Footer)

DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
select @SectionId [SectionId]


DECLARE @procName VARCHAR(MAX) = 'SRI.get_daily_theme_data_ratings'
DECLARE @procID INT
IF NOT EXISTS(       SELECT TOP 1 1 
                           FROM Export.PRODUCT.StoredProcedure
                           WHERE ProcedureName = @procName
                     )
BEGIN
       INSERT INTO Export.PRODUCT.StoredProcedure(ProcedureName, CommandTimeoutSeconds)
       SELECT        @procName
                     ,      30
END

       SELECT @procID = StoredProcedureId
       FROM Export.PRODUCT.StoredProcedure
       WHERE ProcedureName = @procName


DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText, StoredProcedureId)
VALUES (@SectionId, '19000101', '99991231', 1, @procName, NULL, NULL, @procID)

SET @SectionDetailId = @@IDENTITY

INSERT INTO Export.PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) 
VALUES (@SectionDetailId, '@mnemonic', '[mnemonic]')


DECLARE @TemplateProductGroupId int

SELECT @TemplateProductGroupId = ProductGroupId 
FROM EXPORT.PRODUCT.ProductGroup pg
WHERE pg.Name = 'Template Group'

/*
--UPDATE prod
--SET prod.ProductGroupId = @TemplateProductGroupId
--FROM Export.Product.Product prod
--where prod.ProductGroupId  = @ProductGroupId
*/

DECLARE @SectionColumnId INT
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'Cons Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'ISIN', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'Local Market', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'CUSIP', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 'Constituent Name', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 7, 'Country Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 8, 'ISO Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 9, 'Exchange Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 10, 'Industry Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 11, 'Supersector Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 12, 'Sector Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 13, 'Subsector Code', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 14, 'Theme', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 15, 'Exposure', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 16, 'Previous Exposure', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 17, 'Score', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 18, 'Previous Score', null, '19000101', '99991231', 0, NULL, NULL)

--create distributors
/* TEST:- SQL01BB */
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, (SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Development DDS 1'))	-- dds 1 product
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, (SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Development DDS 1'))		-- dds 1 ini
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, (SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = '2014 Archive'))					-- annual


/* Production:- SQL01RA */  
/*
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 2) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS UKUBS')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 3) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS UKHSL')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 7) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS UKUBS')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 8) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS UKUBS')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 22) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = '2014 Archive')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 25) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS ftpdc')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 26) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS ftpdc')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 27) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Product To Production DDS ftasr')
INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) 
	VALUES (@ProductId, 28) --(SELECT [DistributorId] FROM [Export].[PRODUCT].[DistributorView] dv where dv.Name = 'Ini To Production DDS ftasr')
*/




exec Export.PRODUCT.DisplayProduct @ProductCode




