USE EXPORT

DECLARE @ProductGroupId INT
DECLARE @ProductGroupName VARCHAR(50) = 'FTSE Implied Volatility MIB Index'
DECLARE @ProductGroupNameCount INT

SELECT @ProductGroupNameCount =  COUNT(Name) FROM EXPORT.PRODUCT.ProductGroup WHERE Name  = @ProductGroupName 

IF @ProductGroupNameCount = 0
BEGIN
	INSERT INTO EXPORT.PRODUCT.ProductGroup ( ParentProductGroupId, Name ) VALUES ( NULL , 'FTSE Implied Volatility MIB Index' )
	SET @ProductGroupId = @@IDENTITY
END
ELSE
BEGIN
	SELECT @ProductGroupId =  ProductGroupId FROM EXPORT.PRODUCT.ProductGroup WHERE Name  = @ProductGroupName 
END

DECLARE @ProductCode VARCHAR(50) = 'IVIMIB'
DELETE FROM EXPORT.PRODUCT.Product WHERE Code = @ProductCode

DECLARE @MIBProductID INT

INSERT INTO EXPORT.PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix,Delimiter, IsTemplate,TemplateProductId)
VALUES (@ProductGroupId, 2, 'FTSE MIB Implied Volatility Index Valuation File', 'IVIMIB','[DD][MM].csv',',',0,NULL)
SET @MIBProductID = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@MIBProductID, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved 
FTSE 100 Implied Volatility Index Valuation File
', 'XXXXXXXXXX')

DECLARE @MIBSectionID INT

INSERT INTO EXPORT.PRODUCT.Section (ProductId,SectionType,Name,Sequence)
VALUES (@MIBProductID,'StoredProcedure','Section 1',1)
SET @MIBSectionID = @@IDENTITY

DECLARE @MIBSectionDetailID INT

INSERT INTO EXPORT.PRODUCT.SectionDetail (SectionId,EffectiveDate,ExpiryDate,OutputColumnNames,ProcedureName,HeaderText,FooterText)
VALUES (@MIBSectionID,'19000101', '99991231', 1, 'PRIME.PRODUCT.ivi_valuation',NULL,NULL)
SET @MIBSectionDetailID = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName,Value)
VALUES(@MIBSectionDetailID,'@index_code','IVIMIB')

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 1, 'Index Code', null, '19000101', '99991231', 0, NULL, 'UpperCase')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 2, 'Index Name', null, '19000101', '99991231', 0, NULL, 'CamelCase')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 3, 'Date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@MIBSectionID, 1, 4, 'Value', null, '19000101', '99991231', 0, NULL,'RoundedDecimal -NumberOfDecimalPlaces=6')

INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,2)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,3)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,7)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@MIBProductID,8)