USE EXPORT

DECLARE @ProductGroupId INT
DECLARE @ProductGroupName VARCHAR(50) = 'FTSE Implied Volatility UKX Index'
DECLARE @ProductGroupNameCount INT

SELECT @ProductGroupNameCount =  COUNT(Name) FROM EXPORT.PRODUCT.ProductGroup WHERE Name  = @ProductGroupName 

IF @ProductGroupNameCount = 0
BEGIN
	INSERT INTO EXPORT.PRODUCT.ProductGroup ( ParentProductGroupId, Name ) VALUES ( NULL , 'FTSE Implied Volatility UKX Index' )
	SET @ProductGroupId = @@IDENTITY
END
ELSE
BEGIN
	SELECT @ProductGroupId =  ProductGroupId FROM EXPORT.PRODUCT.ProductGroup WHERE Name  = @ProductGroupName 
END

DECLARE @ProductCode VARCHAR(50) = 'IVIUKXH'
DELETE FROM EXPORT.PRODUCT.Product WHERE Code = @ProductCode

DECLARE @UKXProductID INT

INSERT INTO EXPORT.PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix,Delimiter, IsTemplate,TemplateProductId)
VALUES (@ProductGroupId, 2, 'FTSE Implied Volatility UKX History File', 'IVIUKXH','[DD][MM].csv',',',0,NULL)
SET @UKXProductID = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@UKXProductID, '19000101', '99991231', '[DD]/[MM]/[YYYY] (C) FTSE International Limited [YYYY]. All Rights Reserved 
FTSE IVI UKX History File

Index Code,IVUKX30,IVUKX60,IVUKX90,IVUKX180,IVUKX360
Index Name,FTSE 100 IVI 30 days,FTSE 100 IVI 60 days,FTSE 100 IVI 90 days,FTSE 100 IVI 180 days,FTSE 100 IVI 360 days', 'XXXXXXXXXX')

DECLARE @UKXSectionID INT

INSERT INTO EXPORT.PRODUCT.Section (ProductId,SectionType,Name,Sequence)
VALUES (@UKXProductID,'StoredProcedure','Section 1',1)
SET @UKXSectionID = @@IDENTITY

DECLARE @UKXSectionDetailID INT

INSERT INTO EXPORT.PRODUCT.SectionDetail (SectionId,EffectiveDate,ExpiryDate,OutputColumnNames,ProcedureName,HeaderText,FooterText)
VALUES (@UKXSectionID,'19000101', '99991231', 1, 'PRIME.PRODUCT.ivi_histvals',NULL,NULL)
SET @UKXSectionDetailID = @@IDENTITY

INSERT INTO EXPORT.PRODUCT.SectionDetailParameter(SectionDetailId, ParameterName,Value)
VALUES(@UKXSectionDetailID,'@index_code','IVIUKX')

INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 1, 'Date', null, '19000101', '99991231', 0, NULL, 'UpperCase')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 2, '30days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 3, '60days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 4, '90days', null, '19000101', '99991231', 0, NULL,'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 5, '180days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
INSERT INTO EXPORT.PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@UKXSectionID, 1, 6, '360days', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')

INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,2)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,3)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,7)
INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId) VALUES (@UKXProductID,8)