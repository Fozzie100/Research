USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'yapbv'
DECLARE @TemplateProductId INT
SELECT @TemplateProductId = ProductId FROM PRODUCT.Product where Code = 'Xinhua Template'

DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (1,2,'FTSE China A50 Index HKD TRI (custom) Valuation Service', @ProductCode, '[DD][MM].csv', ',',0, @TemplateProductId)
SET @ProductId = @@IDENTITY
INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', NULL, NULL)



-- token value 
INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[index_mnemonic]','XINA50N' )

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[display_index_mnemonic]','XIN9HKNR'  )

INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[display_index_sector_name]', 'FTSE China A50 Net Tax HKD Index (Custom FX)')


INSERT INTO PRODUCT.ProductTokenValue (ProductId, EffectiveDate, ExpiryDate, Token, Value)
VALUES (@ProductId, '19000101', '99991231', '[product_header]', 'FTSE China A50 Net Tax HKD Index (Custom FX)')



             
  DECLARE @server VARCHAR(20)                   
  SELECT @server = LEFT(@@SERVERNAME, CHARINDEX('\', @@SERVERNAME))

  
  IF @server LIKE '%SPES%'
  BEGIN
    INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 25) --dds 1 product
	INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 26) --dds 2 product
	INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 27) --dds 1 ini
	INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 28) --dds 2 ini
  END 
  
 
   INSERT INTO Export.PRODUCT.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 29) -- FileSystem




EXEC Export.PRODUCT.DisplayProduct @productcode

--EXEC Export.PRODUCT.DisplayProduct  'yapbv'