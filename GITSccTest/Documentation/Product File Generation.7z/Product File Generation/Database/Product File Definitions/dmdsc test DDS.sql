USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'dmdsc'

DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (1,2,'FTSE TEST DDS', @ProductCode, '[DD][MM].csv', ',')
SET @ProductId = @@IDENTITY
INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY](C) FTSE International Limited [YYYY]. All Rights Reserved
FTSE TEST  DDS
', 'XXXXXXXXXX')
DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, '[PRODUCT].[test_dds]', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@index_mnemonic', '[index_mnemonic]')

DECLARE @SectionColumnId INT



INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'legal_name', null, '19000101', '99991231', 0, NULL, NULL)


INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId )
VALUES (@ProductId,22)

INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId )
VALUES (@ProductId,25)

INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId )
VALUES (@ProductId,26)

INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId )
VALUES (@ProductId,27)

INSERT INTO EXPORT.PRODUCT.ProductDistributor(ProductId,DistributorId )
VALUES (@ProductId,28)

EXEC Export.PRODUCT.DisplayProduct 'dmdsc'




--SELECT * FROM PRODUCT.Distributor

-- run it on Appbox 
--D:\Research_Analytics\ReleaseBuild\ProductFileGenerator\ProductFileGenerator.exe -productcode=dmdsc -[index_mnemonic]=ASX  -datadate=20141008 -ftp 

