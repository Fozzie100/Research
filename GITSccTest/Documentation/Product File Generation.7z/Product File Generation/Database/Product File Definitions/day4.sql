USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'day4'

DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter)
VALUES (38, 2,'Horizon 4', @ProductCode, '<%d><%m>.csv', ',')
SET @ProductId = @@IDENTITY
INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', NULL, NULL)
DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 0, 'ANALYSTS.HORIZON_factors_ff', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@family', 'HORIZON1')
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@offset', '4')
DECLARE @SectionColumnId INT
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'sedol', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'factor', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'blank', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'ftype', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'effective_date', null, '19000101', '99991231', 0, NULL, NULL)
INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 6, 't', null, '19000101', '99991231', 0, NULL, NULL)

--Set up distribution locally to start with
INSERT INTO Export.Product.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 4)
INSERT INTO Export.Product.ProductDistributor (ProductId, DistributorId) VALUES (@ProductId, 9)

--Distribute Emails
INSERT INTO Export.Product.ProductEmail(ProductId, EffectiveDate, ExpiryDate, SubjectText, BodyText, FromAddress, ToAddresses, CcAddresses, BccAddresses)
VALUES (@ProductId, '19000101', '99991231', 'Horizon File 4', '', 'Product File Generator <noreply@ftse.com>', 'roy.james@ftse.com,dominic.stone@ftse.com', NULL, NULL)

--display product details
EXEC EXPORT.product.displayproduct @ProductCode