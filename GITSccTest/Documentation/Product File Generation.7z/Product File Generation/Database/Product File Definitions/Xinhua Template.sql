USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'Xinhua Template'

DELETE FROM Export.Product.Product WHERE Code = @ProductCode

DECLARE @ProductId INT
INSERT INTO Export.Product.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter,IsTemplate,TemplateProductId)
VALUES (1,2,'FTSE China A50 Index HKD TRI (custom) Valuation Service', @ProductCode, '[DD][MM].csv', ',',1,null)
SET @ProductId = @@IDENTITY
INSERT INTO Export.Product.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', '[DD]/[MM]/[YYYY](C) FTSE International Limited [YYYY]. All Rights Reserved
[product_header]
', 'XXXXXXXXXX')
DECLARE @SectionId INT
INSERT INTO Export.Product.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'StoredProcedure', 'Section1', 1)
SET @SectionId = @@IDENTITY
DECLARE @SectionDetailId INT
INSERT INTO Export.Product.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, '[REPORTS].[rpt_cny_hkd_xina50]', NULL, NULL)
SET @SectionDetailId = @@IDENTITY
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@index_mnemonic', '[index_mnemonic]')
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@display_index_mnemonic', '[display_index_mnemonic]')
INSERT INTO Export.Product.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@display_index_sector_name', '[display_index_sector_name]')




DECLARE @SectionColumnId INT

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 1, 'FTSE Index Code', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 2, 'Index/Sector Name', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 3, 'Number of Constituents', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 4, 'CNY TRI Index', null, '19000101', '99991231', 0, NULL, NULL)

INSERT INTO Export.Product.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 1, 5, 'HKD TRI Index', null, '19000101', '99991231', 0, NULL, NULL)


-- template does not need Distibutor it has to be in the product file level 

EXEC Export.PRODUCT.DisplayProduct @productcode

--EXEC Export.PRODUCT.DisplayProduct 'yapbv'

--EXEC Export.PRODUCT.DisplayProduct 'Xinhua Template'

