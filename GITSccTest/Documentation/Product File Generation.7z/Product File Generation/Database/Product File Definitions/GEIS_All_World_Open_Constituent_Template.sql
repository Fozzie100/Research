USE EXPORT
GO

DECLARE @ProductCode VARCHAR(50) = 'geis_aw_oc_template'
DELETE FROM PRODUCT.Product WHERE Code = @ProductCode

--Create Product Group if it doesnt exist
DECLARE @ProductGroupId INT
exec EXPORT.PRODUCT.CreateProductGroup @ProductGroupId output, 'Templates'

DECLARE @ProductId INT
INSERT INTO PRODUCT.Product (ProductGroupId, DataSourceId, Name, Code, FileSuffix, Delimiter, IsTemplate, TemplateProductId)
VALUES (@ProductGroupId, 1, 'GEIS All World Open Constituent Template', @ProductCode, '<%d><%m>.csv', ',', 1, NULL)
SET @ProductId = @@IDENTITY

-- Header & Footer
DECLARE 
	 @Header varchar(250) = '<%d>/<%m>/<%Y> (C) FTSE International Limited <%Y>. All Rights Reserved' + CHAR(13) + '[product_title]' + CHAR(13) + ' ' + CHAR(13)
	,@Footer varchar(50) = 'XXXXXXXXXX'

INSERT INTO PRODUCT.ProductDetail (ProductId, EffectiveDate, ExpiryDate, HeaderText, FooterText)
VALUES (@ProductId, '19000101', '99991231', @Header, @Footer)

DECLARE @SectionId INT
INSERT INTO PRODUCT.Section (ProductId, SectionType, Name, Sequence) VALUES (@ProductId, 'Generated', 'Stock Prices', 1)
SET @SectionId = @@IDENTITY

DECLARE @SectionDetailId INT
INSERT INTO PRODUCT.SectionDetail (SectionId, EffectiveDate, ExpiryDate, OutputColumnNames, ProcedureName, HeaderText, FooterText)
VALUES (@SectionId, '19000101', '99991231', 1, 'PRODUCT.get_opening_constituent_list', NULL, NULL)
SET @SectionDetailId = @@IDENTITY

INSERT INTO PRODUCT.SectionDetailParameter (SectionDetailId, ParameterName, Value) VALUES (@SectionDetailId, '@list_code', 'AWIC')

DECLARE @SectionColumnId INT
INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 2, 1, 'Cons code', 2, '19000101', '99991231', 0, NULL, 'Prefix -Value=C')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 3, 2, 'SEDOL', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 4, 3, 'CUSIP', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 5, 4, 'Constituent name', null, '19000101', '99991231', 1, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 6, 5, 'Country code', 1, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 7, 6, 'ISO code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 11, 7, 'Exchange code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 27, 8, 'Price', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 9, 9, 'Shares in Issue', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=0')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 20, 10, 'Weighting', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 15, 11, 'Industry Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 14, 12, 'Sector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 13, 13, 'Subsector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 40, 14, 'Dividend Yield', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=2|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 28, 15, 'Mkt Cap (USD) before investibility weight', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 164, 1000000)
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 26, 'USD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 29, 16, 'Mkt Cap (USD) after investibility weight', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 28, 'USD')
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 176, 1000000)

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 17, '%Wt A-W', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWORLDS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 18, '%Wt A-W (ex US)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWXUSAS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 19, '%Wt A-W (ex UK)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWXUKS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 20, '%Wt A-W (ex Japan)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWXJAS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 21, '%Wt A-W Asia Pacific (ex Japan)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWPACXJA')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 22, '%Wt A-W (ex South Africa)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWXSAFS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 23, '%Wt A-W Europe (ex UK)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWEXUKS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 24, '%Wt A-W North America', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWNAMERS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 25, '%Wt A-W Europe-Asia Pacific', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWEURPS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 26, '%Wt A-W Asia-Pacific', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWPACS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 27, '%Wt A-W Nordic', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWNORDS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 28, '%Wt A-W Europe', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWEURS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 29, '%Wt A-W Eurobloc', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWEBLOCS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 30, '%Wt A-W Europe (ex Eurobloc)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWEXEBS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 31, '%Wt A-W Europe (ex Ebloc & UK)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWEXBXKS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 32, '% Wt A-W (ex Eurobloc)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWXEBS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 33, '%Wt A-W Americas', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWAMERS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 34, '%Wt A-W Developed', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWD')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 35, '%Wt A-W Advanced Emerging', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWAE')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 36, '%Wt A-W Emerging', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWE')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 30, 37, '%Wt A-W Developed (ex US)', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 24, 'AWDXUS')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 31, 38, '%Wt Country', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 32, 39, '%Wt Industry', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 33, 40, '%Wt Sector', null, '19000101', '99991231', 0, NULL, 'RoundedDecimal -NumberOfDecimalPlaces=6|Suffix -Value=%')
SET @SectionColumnId = @@IDENTITY

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 16, 41, 'Index Marker', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 11, 'AWIC_MARKER')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 10, 42, 'Large/Medium Classification', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY
INSERT INTO PRODUCT.SectionColumnParameter(SectionColumnId, FilecolumnParameterId, Value) VALUES (@SectionColumnId, 9, 'SIZE')

INSERT INTO PRODUCT.SectionColumn (SectionId, FileColumnId, Sequence, Description, SortOrder, EffectiveDate, ExpiryDate, QuoteValues, ValidationRules, FormatArguments) 
VALUES (@SectionId, 12, 43, 'Supersector Code', null, '19000101', '99991231', 0, NULL, NULL)
SET @SectionColumnId = @@IDENTITY

--display product details
EXEC PRODUCT.displayproduct @ProductCode
