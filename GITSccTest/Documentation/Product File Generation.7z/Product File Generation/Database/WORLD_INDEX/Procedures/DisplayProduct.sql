USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[DisplayProduct]') AND type in (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [WORLD_INDEX].[DisplayProduct]
	PRINT 'DROPPED PROCEDURE [WORLD_INDEX].[DisplayProduct]'
END
GO

CREATE PROCEDURE [WORLD_INDEX].[DisplayProduct]
(
	@code   VARCHAR(50)
)
AS  

	SET NOCOUNT ON;

	DECLARE @product_id INT
    SELECT  @product_id = product_id
    FROM    WORLD_INDEX.dbo.product where file_prefix = @code
    
    --Product
    SELECT      'Product' AS [type],
                product_id,
                file_prefix as code,
                p.file_name,
                product_name,
                g.description AS product_group,
                product_type_id
    FROM        WORLD_INDEX.dbo.product AS p
    INNER JOIN  WORLD_INDEX.dbo.product_group AS g
    ON          p.product_group_id = g.product_group_id
    WHERE       product_id = @product_id
    
    --Sections (Note we join onto column to get which sections have data within them)
    SELECT      'Section' AS [type],
                s.section_id,
                s.section_id,
                sp.proc_id,
                effective_date,
                section_name,
                CASE WHEN title_flag='T' THEN 'Yes' ELSE 'No' END AS output_column_headers,
                CASE WHEN current_flag = 'T' THEN 'CURRENT' ELSE 'OLD' END as status,
                sp.description AS procedure_description,
                sp.proc_name AS stored_procedure
    FROM        WORLD_INDEX.dbo.product_section s
    INNER JOIN  (SELECT DISTINCT pc.section_id FROM WORLD_INDEX.dbo.product_column AS pc WHERE pc.product_id = @product_id) AS used_sections
    ON          s.section_id = used_sections.section_id    
    INNER JOIN  WORLD_INDEX.dbo.stored_procedure AS sp
    ON          s.proc_id =sp.proc_id
    WHERE       s.product_id = @product_id
    ORDER BY    s.section_id
    
    --Section Parameter
    SELECT      'Section Parameter' AS [type],
                sp.section_id,
                pp.proc_id,
                pp.description,
                pp.param_type,
                pp.param_id,
                sp.param_value
    FROM        WORLD_INDEX.dbo.product_section AS s
    INNER JOIN  WORLD_INDEX.dbo.section_parameter AS sp
    ON          s.section_id = sp.section_id
    AND         s.product_id = sp.product_id
    INNER JOIN  WORLD_INDEX.dbo.procedure_parameter AS pp
    ON          sp.param_id = pp.param_id
    AND         pp.proc_id = s.proc_id
    WHERE       s.product_id = @product_id
    ORDER BY    s.section_id

    --Columns
    SELECT      'Column' AS [type],
                section_id,
                pc.product_column_type_id,
                column_pos,
                pc.description AS column_name,
                pc.effective_date,
                decimal_places,
                force_case,
                ignore_chars,
                CASE WHEN quotes_flag = 'Y' THEN 'Yes' ELSE 'No' END AS quote_values, 
                where_info,
                pct.where_help,
                pct.description AS column_description,
                pc.order_pos as sort_order,
                pct.stored_proc,
                pc.column_type_id,
                pc.scale_divisor,
                CASE WHEN pct.where_flag = 'Y' THEN 'Yes' ELSE 'N' END as requires_where_info
    FROM        WORLD_INDEX.dbo.product_column AS pc
    INNER JOIN  WORLD_INDEX.dbo.product AS p
    ON          p.product_id = pc.product_id
    INNER JOIN  WORLD_INDEX.dbo.product_column_type AS pct
    ON          p.product_type_id = pct.product_type_id
    AND         pc.product_column_type_id = pct.product_column_type_id
    WHERE       pc.product_id = @product_id
    AND         current_flag = 'T'
    ORDER BY    section_id,
                pc.column_pos
	
GO

GRANT EXECUTE ON [WORLD_INDEX].[DisplayProduct] TO Public
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[DisplayProduct]') AND type in (N'P', N'PC'))
BEGIN
	PRINT 'CREATED [WORLD_INDEX].[DisplayProduct]'
END
GO
