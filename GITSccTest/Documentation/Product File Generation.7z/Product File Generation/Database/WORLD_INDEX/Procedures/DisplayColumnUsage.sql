USE EXPORT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[DisplayColumnUsage]') AND type in (N'P', N'PC'))
BEGIN
    DROP PROCEDURE [WORLD_INDEX].[DisplayColumnUsage]
    PRINT 'DROPPED PROCEDURE [WORLD_INDEX].[DisplayColumnUsage]'
END
GO

CREATE PROCEDURE [WORLD_INDEX].[DisplayColumnUsage]
(
    @procedure_name VARCHAR(MAX)
)
AS  

    SET NOCOUNT ON;

    SELECT  product_type_id,
            product_column_type_id,
            description,
            CASE WHEN where_flag = 'Y' THEN 'YES' ELSE 'NO' END AS requires_where_info,
            where_help
    FROM    WORLD_INDEX.dbo.product_column_type
    WHERE   stored_proc = @procedure_name

    SELECT      p.file_prefix as product_code, 
                s.section_id,
                pc.description as product_file_column_name,
                pc.column_pos as product_file_column_index,
                pc.where_info
    FROM        WORLD_INDEX.dbo.product_column_type AS ct
    INNER JOIN  WORLD_INDEX.dbo.product_column AS pc
    ON          ct.product_column_type_id = pc.product_column_type_id
    INNER JOIN  WORLD_INDEX.dbo.product as p
    ON          ct.product_type_id = p.product_type_id
    AND         p.product_id= pc.product_id
    INNER JOIN  WORLD_INDEX.dbo.product_section AS s
    ON          s.section_id = pc.section_id
    AND         s.product_id = pc.product_id    
    WHERE       stored_proc = @procedure_name
    ORDER by    p.file_prefix


GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[DisplayColumnUsage]') AND type in (N'P', N'PC'))
BEGIN
    PRINT 'CREATED [WORLD_INDEX].[DisplayColumnUsage]'
END
GO