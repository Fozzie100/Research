USE EXPORT
GO

TRUNCATE TABLE EXPORT.WORLD_INDEX.data_type
go

--TODO should integer be rounded to zero
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (1, 'Integer', 'decimal_places', 'RoundedDecimal -NumberOfDecimalPlaces={0}')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (2, 'SEDOL', '', '')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (3, 'String', '', '')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (4, 'Float', 'decimal_places', 'RoundedDecimal -NumberOfDecimalPlaces={0}')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (5, 'Percentage', 'decimal_places', 'RoundedDecimal -NumberOfDecimalPlaces={0}|Suffix -Value=%')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (6, 'Date', 'where_info', 'Date -Format={0}')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (7, 'CONS - Leading C', '', 'Prefix -Value=C')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (8, 'CONS - No prefix', '', '')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (9, 'Percentage - blank if 0', 'decimal_places', 'ZeroToNull|RoundedDecimal -NumberOfDecimalPlaces={0}|Suffix -Value=%')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (10, 'Float - zero if null', 'decimal_places', 'NullToZero|RoundedDecimal -NumberOfDecimalPlaces={0}')
INSERT INTO EXPORT.WORLD_INDEX.data_type (column_type_id, description, argument_field, format_arguments) VALUES (11, 'Float - null if no values', 'decimal_places', 'ZeroToNull|RoundedDecimal -NumberOfDecimalPlaces={0}')

SELECT * FROM EXPORT.WORLD_INDEX.data_type