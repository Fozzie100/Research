USE [EXPORT]
GO

TRUNCATE TABLE [WORLD_INDEX].[stored_procedure_parameter]
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (7, 1, 'List Code',  '@list_code', 0, 1)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (9, 33, 'List Code',  '@list_code', 0, 1)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (10, 37, 'List Code',  '@list_code', 0, 1)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (10, 36, 'Show Blank Index?',  '@show_blank_index', 1, 0)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (12, 45, 'List Code',  '@list_code', 0, 1)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (13, 39, 'List Code',  '@list_code', 0, 1)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (13, 44, 'Show Blank Index?',  '@show_blank_index', 1, 0)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (3, 11, 'List Code',  '@list_code', 0, 1)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (3, 15, 'Number of days',  '@number_of_days', 0, 0)
GO

INSERT INTO [WORLD_INDEX].[stored_procedure_parameter] (proc_id, world_index_parameter_id, world_index_parameter_name, prime_parameter_name, convert_to_bit, translate_index_ids)
VALUES (5, 20, 'List Code',  '@list_code', 0, 1)
GO


select * from EXPORT.[WORLD_INDEX].[stored_procedure_parameter]
