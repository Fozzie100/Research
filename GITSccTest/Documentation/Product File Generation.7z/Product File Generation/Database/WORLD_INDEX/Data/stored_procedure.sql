USE [EXPORT]
GO

INSERT INTO [WORLD_INDEX].[stored_procedure] (proc_id, prime_procedure_name) VALUES (9, 'PRODUCT.get_index_constituents')
INSERT INTO [WORLD_INDEX].[stored_procedure] (proc_id, prime_procedure_name) VALUES (7, 'PRODUCT.get_index_constituents')
INSERT INTO [WORLD_INDEX].[stored_procedure] (proc_id, prime_procedure_name) VALUES (10, 'PRODUCT.get_valuationfile_indices')
INSERT INTO [WORLD_INDEX].[stored_procedure] (proc_id, prime_procedure_name) VALUES (13, 'PRODUCT.get_tracker_section_1')
INSERT INTO [WORLD_INDEX].[stored_procedure] (proc_id, prime_procedure_name) VALUES (12, 'PRODUCT.get_tracker_section_3')
INSERT INTO [WORLD_INDEX].[stored_procedure] (proc_id, prime_procedure_name) VALUES (3, 'PRODUCT.get_tracker_section_2')
INSERT INTO [WORLD_INDEX].[stored_procedure] (proc_id, prime_procedure_name) VALUES (5, 'PRODUCT.get_valuationfile_indices') --todo this could be wrong