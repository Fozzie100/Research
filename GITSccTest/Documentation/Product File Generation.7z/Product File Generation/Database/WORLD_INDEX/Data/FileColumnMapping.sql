USE EXPORT
GO

SET NOCOUNT ON

TRUNCATE TABLE [WORLD_INDEX].[file_column_mapping]
--Closing
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cons code', 1, 1, 2, 0, 'CONS')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sedol', 1, 1, 3, 0, 'SEDL')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cusip', 1, 1, 4, 0, 'CUSP')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('isin', 1, 1, 43, 1, 'ISIN')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('se code/tidm', 1, 1, 159, 1, 'EPIC')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 1, 1, 89, 1, 'AUCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 1, 1, 89, 1, 'USCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 1, 1, 89, 1, 'ITCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 1, 114, 89, 1, NULL) -- Think this is the right one
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('constituent name', 1, 2, 5, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 1, 10, 6, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 1, 235, 6, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('iso code', 1, 11, 7, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('close price', 1, 4, 8, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('weighting', 1, 6, 20, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('industry code', 1, 12, 15, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sector code', 1, 17, 14, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('subsector code', 1, 18, 13, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index weighting close', 1, 3, 19, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index weighting close', 1, 119, 19, 0, NULL) --todo no idea if this is right
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend yield', 1, 14, 42, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('mkt cap (close) before investibility weight', 1, 7, 17, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('mkt cap (close) after investibility weight', 1, 8, 18, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%Wt Country', 1, 25, 22, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%Wt Country', 1, 236, 22, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%Wt Country', 1, 47, 22, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%Wt Industry by country', 1, 29, 23, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%Wt Sector', 1, 30, 24, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 1, 9, 16, 0, '', '', 'INDEX_MARKER')
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 1, 9, 0, 0, '', '', 'ALT_INDEX_MARKER') --TODO new column needed
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 1, 9, 0, 0, '', '', 'INDEX_LOOKUP') --TODO new column needed
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 1, 32, 188, 0, '', '', 'ALT_INDEX_MARKER')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('data date', 1, 50, 189, 0, '')

INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('large/medium classification', 1, 38, 10, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('exchange code', 1, 33, 11, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('supersector code', 1, 107, 12, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('shares in issue', 1, 5, 9, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('one month price performance', 1, 88, 51, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('one month tri performance', 1, 92, 52, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ytd price performance', 1, 90, 53, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ytd tri performance', 1, 94, 54, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('corprorate action story', 1, 76, 55, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('corprorate action type', 1, 77, 56, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('daily price performance', 1, 87, 57, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('daily tri perfomance', 1, 91, 58, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend currency', 1, 81, 59, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('high price', 1, 69, 60, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('low price', 1, 70, 61, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend xd date', 1, 84, 69, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('previous day price', 1, 85, 70, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend type', 1, 83, 74, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend announce date', 1, 79, 75, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend payment date', 1, 82, 76, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('adjusted factor', 1, 75, 77, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('annual dividend', 1, 20, 78, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend amount', 1, 78, 79, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend books close date', 1, 80, 80, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('volume', 1, 73, 81, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('short name', 1, 16, 82, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('90 day alpha', 1, 95, 83, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('90 day multi index alpha', 1, 100, 179, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('90 day beta', 1, 96, 84, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('90 day multi index beta', 1, 101, 180, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('90 day specific risk', 1, 97, 85, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('90 day multi index specific risk', 1, 102, 181, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('90 day total risk', 1, 98, 86, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%wt industry', 1, 26, 122, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%wt sector', 1, 27, 124, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('growth weight factor close', 1, 21, 126, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('mkt cap growth close', 1, 23, 127, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('value weight factor close', 1, 22, 128, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('mkt cap value close', 1, 24, 129, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('world growth percent weight', 1, 45, 130, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('world value percent weight', 1, 46, 131, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country growth percent weight', 1, 52, 132, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country value percent weight', 1, 53, 133, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('industry growth percent weight', 1, 54, 134, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('industry value percent weight', 1, 55, 135, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sector growth percent weight', 1, 56, 136, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sector value percent weight', 1, 57, 137, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('literal value', 1, 49, 87, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('secondary line', 1, 13, 155, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('gross market cap', 1, 37, 156, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('net market cap', 1, 34, 157, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('price return quarter end', 1, 89, 167, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('fundamental cap', 1, 117, 168, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('fundamental weight', 1, 116, 169, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('supersector weight', 1, 223, 185, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('value rank', 1, 58, 190, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('growth rank', 1, 59, 191, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('overall rank', 1, 60, 192, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('year 3 sales growth', 1, 61, 193, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('year 3 eps growth', 1, 62, 194, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('year 2 forward sales', 1, 63, 195, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('year 2 forward eps', 1, 64, 196, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('return on equity', 1, 65, 197, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('price to book', 1, 66, 198, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('price to sales', 1, 67, 199, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('price to cash flow', 1, 68, 200, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ftse 4 good rating', 1, 222, 204, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local code', 1, 109, 205, 0, NULL)

--OPEN
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cons code', 6, 1, 2, 0, 'CONS')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sedol', 6, 1, 3, 0, 'SEDL')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cusip', 6, 1, 4, 0, 'CUSP')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 6, 1, 89, 1, 'AUCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 6, 1, 89, 1, 'USCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 6, 1, 89, 1, 'ITCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 1, 111, 89, 1, NULL) -- Think this is the right one
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('constituent name', 6, 2, 5, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 6, 9, 6, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('iso code', 6, 10, 7, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('price', 6, 3, 27, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index_weighting open', 6, 204, 30, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('exchange code', 6, 32, 11, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend yield', 6, 13, 40, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('mkt cap before investibility weight', 6, 6, 28, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('mkt cap after investibility weight', 6, 7, 29, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%wt country', 6, 207, 31, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%wt industry by country', 6, 28, 32, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%wt sector', 6, 29, 33, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('large/medium classification', 6, 37, 10, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('industry code', 6, 11, 15, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sector code', 6, 16, 14, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('subsector code', 6, 17, 13, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('shares in issue', 6, 4, 9, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 6, 8, 16, 0, '', '', 'INDEX_MARKER')
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 6, 8, 0, 0, '', '', 'ALT_INDEX_MARKER') --TODO new column needed
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 6, 8, 0, 0, '', '', 'INDEX_LOOKUP') --TODO new column needed
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name, mapping_column_name) VALUES ('index marker', 6, 31, 188, 0, '', '', 'ALT_INDEX_MARKER')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('supersector code', 6, 53, 12, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('weighting', 6, 5, 20, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('literal value', 6, 44, 87, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('weighting', 6, 24, 20, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('annual dividend', 6, 19, 78, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 6, 224, 6, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 6, 1, 43, 1, 'ISIN')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('secondary line', 6, 12, 155, 0, NULL)

INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('growth weight factor open', 6, 20, 141, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('market cap growth open', 6, 22, 142, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('value weight factor open', 6, 21, 143, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('market cap value open', 6, 23, 144, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('gwa factor', 6, 208, 145, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('market cap after gwa factor', 6, 209, 146, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%Wt country', 6, 225, 22, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('%Wt sector', 6, 206, 125, 0, NULL)


--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index_weighting open', 6, 44, 30, 0, NULL)

--VALUATION FILE
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index code', 2, 15, 25, 1, 'DG')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ftad code', 2, 15, 175, 1, 'FTAD')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ftad code', 2, 15, 206, 1, 'OAWI')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index sector/name', 2, 32, 34, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index sector/name', 2, 272, 34, 0, NULL) --todo this might be wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('number of constituents', 2, 18, 26, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('tri value', 2, 20, 36, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('mkt cap value', 2, 21, 37, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index value', 2, 19, 35, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('xd adjustment', 2, 25, 38, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend yield', 2, 22, 41, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('iso code', 2, 57, 7, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index name', 2, 16, 34, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('daily index performance', 2, 28, 62, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('daily index tri performance', 2, 30, 63, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('monthly index performance', 2, 44, 64, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('monthly index tri performance', 2, 47, 65, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ytd index performance', 2, 46, 66, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ytd index tri performance', 2, 49, 67, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('monthly industry weight', 2, 65, 68, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sector code', 2, 63, 71, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sub sector code', 2, 62, 72, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('industry code', 2, 61, 73, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('xd adjustment (ytd)', 2, 24, 158, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('weight of index in a comparative index', 2, 17, 170, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('literal value', 2, 36, 87, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('weight in index', 2, 64, 186, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('old sector', 2, 55, 201, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('old subsector', 2, 56, 202, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('gsin', 2, 15, 203, 1, 'GSIN')


--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('secondary line', 3, 21, 155, 0, NULL)

INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend cover', 2, 26, 162, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('price/earnings ratio', 2, 23, 163, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index quarterly tri performance', 2, 48, 174, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('daily change', 2, 29, 176, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('percent change quarter', 2, 45, 187, 0, NULL)



/*
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('', , , , 0, NULL)

--TODO ALL THESE VALUES
--TRACKER SECTION 1
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index code', 3, 1, 25, 1, 'DG')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ftad code', 3, 1, 175, 1, 'FTAD')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('old number of constituents', 3, 3, 99, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('new number of constituents', 3, 2, 98, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('previous market capitalisation', 3, 4, 108, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('new market capitalisation', 3, 5, 106, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('previous divisor', 3, 6, 103, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info, scale_divisor_parameter_name) VALUES ('new divisor', 3, 7, 104, 0, NULL, 'Scale Divisor')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('xd adjustment value', 3, 8, 105, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('exchange code', 3, 11, 11, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('previous adjustment factor', 3, 211, 160, 1, NULL)


--TRACKER SECTION 2
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cons code', 3, 39, 2, 0, 'CONS')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('constituent name', 3, 40, 5, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sedol', 3, 39, 3, 0, 'SEDL')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('isin', 3, 39, 43, 0, 'ISIN')
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cusip', 3, 39, 4, 0, 'CUSP')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 3, 39, 89, 1, 'USCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 3, 1, 89, 1, 'USCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 3, 39, 89, 1, 'ITCD') --todo i think these are wrong

INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 3, 10, 6, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 3, 42, 6, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('local market code', 3, 1, 89, 1, 'ITCD') --todo i think these are wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('exchange code', 3, 43, 11, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('subsector code', 3, 46, 13, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('shares in issue', 3, 47, 9, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('investibility weight', 3, 49, 161, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ex-dividend date', 3, 52, 107, 1, NULL) --todo not sure about this
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend amount', 3, 45, 79, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('iso currency code', 3, 26, 102, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('iso currency code', 3, 44, 102, 0, NULL)
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index marker', 3, 53, 16, 0, NULL) --todo this one is actually a dividend index marker
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('xd adjustment value', 3, 41, 105, 1, NULL) --TODO this is wrong
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ftse dividend code', 3, 27, 101, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('ftse dividend notes', 3, 51, 100, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('growth weight factor tracker section 2', 3, 35, 149, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('value weight factor tracker section 2', 3, 36, 150, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('change in market cap', 3, 30, 151, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('dividend yield tracker section 2', 3, 32, 152, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('current factor', 3, 208, 154, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('new edhec adjustment factor', 3, 210, 154, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('constituent name', 3, 9, 5, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 3, 278, 6, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('country code', 3, 279, 6, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('value date', 3, 37, 177, 0, NULL)

INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('new investibility weight', 3, 20, 111, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('previous investibility weight', 3, 19, 112, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('amendment code', 3, 22, 113, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('amendment notes', 3, 23, 114, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('previous shares in issue', 3, 17, 115, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('new shares in issue', 3, 18, 116, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('adjusted price', 3, 16, 117, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('price adjustment factor', 3, 15, 118, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('closing price', 3, 29, 8, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('new subsector code', 3, 14, 119, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('closing subsector code', 3, 13, 120, 0, NULL)
--INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('index marker', 3, 12, 16, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('last modified', 3, 273, 110, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('effective date', 3, 38, 121, 1, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('secondary line', 3, 50, 178, 0, NULL)
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cusip', 3, 39, 2, 0, 'CUSP')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cons code', 3, 1, 2, 0, 'CONS')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('sedol', 3, 1, 3, 0, 'SEDL')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('cusip', 3, 1, 4, 0, 'CUSP')
INSERT INTO [WORLD_INDEX].[file_column_mapping] (column_name, product_type_id, product_column_type_id, file_column_id, ignore_where_info, select_where_info) VALUES ('isin', 3, 1, 43, 1, 'ISIN')
*/

SELECT * FROM [WORLD_INDEX].[file_column_mapping] ORDER BY product_type_id, product_column_type_id
/*
declare @FileColumnId int = 16
SELECT * FROM PRODUCT.FileColumn where filecolumnid = @FileColumnId
SELECT * FROM PRODUCT.FileColumnParameter where filecolumnid = @FileColumnId
*/