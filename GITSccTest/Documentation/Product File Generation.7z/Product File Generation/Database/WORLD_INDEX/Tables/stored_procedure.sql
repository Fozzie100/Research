USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[stored_procedure]') AND type in (N'U'))
DROP TABLE [WORLD_INDEX].[stored_procedure]
GO

USE [EXPORT]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [WORLD_INDEX].[stored_procedure]
(
	[proc_id] [int] NULL,
	[prime_procedure_name] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


