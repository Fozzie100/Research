USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[product_import_column_result]') AND type in (N'U'))
BEGIN
    DROP TABLE [WORLD_INDEX].[product_import_column_result]
    PRINT 'DROPPED TABLE [WORLD_INDEX].[product_import_column_result]'
END
GO

USE [EXPORT]
GO


CREATE TABLE [WORLD_INDEX].[product_import_column_result]
(
    code                                VARCHAR(10) NOT NULL,
    column_name                         VARCHAR(200) NOT NULL,
    world_index_product_type_id         INT,
    world_index_product_column_type_id  INT,
    export_column_id                    INT,
    success                             BIT
)
GO

ALTER TABLE [WORLD_INDEX].[product_import_column_result]
	ADD CONSTRAINT [pk_product_import_column_result] PRIMARY KEY CLUSTERED 
	(
		code,
		column_name
	)
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[product_import_column_result]') AND type in (N'U'))
BEGIN
    PRINT 'CREATED TABLE [WORLD_INDEX].[product_import_column_result]'
END
GO
