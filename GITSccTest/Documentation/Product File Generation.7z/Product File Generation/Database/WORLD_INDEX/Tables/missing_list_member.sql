USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[missing_list_member]') AND type in (N'U'))
DROP TABLE [WORLD_INDEX].[missing_list_member]
GO

CREATE TABLE [WORLD_INDEX].[missing_list_member]
(
	list_code       [VARCHAR](100) NOT NULL,
	constituent     [VARCHAR] (100) NOT NULL,
	sort_code       [VARCHAR](6),
	value			[VARCHAR](100)
) ON [PRIMARY]

GO