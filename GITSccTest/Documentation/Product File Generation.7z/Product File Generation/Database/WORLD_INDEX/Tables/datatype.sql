USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[data_type]') AND type in (N'U'))
DROP TABLE [WORLD_INDEX].[data_type]
GO

CREATE TABLE [WORLD_INDEX].[data_type]
(
	[column_type_id] [INT] NOT NULL,
	[description] VARCHAR(50) NOT NULL,
	[argument_field] VARCHAR(50),
	[format_arguments] VARCHAR(MAX)
)

GO