USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[product_import_file_result]') AND type in (N'U'))
BEGIN
    DROP TABLE [WORLD_INDEX].[product_import_file_result]
    PRINT 'DROPPED TABLE [WORLD_INDEX].[product_import_file_result]'
END
GO

USE [EXPORT]
GO


CREATE TABLE [WORLD_INDEX].[product_import_file_result]
(
    code    VARCHAR(10) NOT NULL,
    success BIT,
    notes   VARCHAR(MAX)
)
GO

ALTER TABLE [WORLD_INDEX].[product_import_file_result]
	ADD CONSTRAINT [pk_product_import_file_result] PRIMARY KEY CLUSTERED 
	(
		code
	)
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[product_import_file_result]') AND type in (N'U'))
BEGIN
    PRINT 'CREATED TABLE [WORLD_INDEX].[product_import_file_result]'
END
GO
