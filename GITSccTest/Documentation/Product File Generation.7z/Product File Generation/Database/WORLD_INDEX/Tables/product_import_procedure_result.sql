USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[product_import_procedure_result]') AND type in (N'U'))
BEGIN
    DROP TABLE [WORLD_INDEX].[product_import_procedure_result]
    PRINT 'DROPPED TABLE [WORLD_INDEX].[product_import_procedure_result]'
END
GO

USE [EXPORT]
GO


CREATE TABLE [WORLD_INDEX].[product_import_procedure_result]
(
    code                VARCHAR(10) NOT NULL,
    world_index_proc_id INT NOT NULL,
    export_procedure_name  VARCHAR(200)
)
GO

ALTER TABLE [WORLD_INDEX].[product_import_procedure_result]
	ADD CONSTRAINT [pk_product_import_procedure_result] PRIMARY KEY CLUSTERED 
	(
		code,
		world_index_proc_id
	)
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[product_import_procedure_result]') AND type in (N'U'))
BEGIN
    PRINT 'CREATED TABLE [WORLD_INDEX].[product_import_procedure_result]'
END
GO
