USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[stored_procedure_parameter]') AND type in (N'U'))
DROP TABLE [WORLD_INDEX].[stored_procedure_parameter]
GO

USE [EXPORT]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [WORLD_INDEX].[stored_procedure_parameter]
(
	[proc_id] [int] NULL,
	[world_index_parameter_id] [int] NULL,
	[world_index_parameter_name] [varchar](max) NULL,
	[prime_parameter_name] [varchar](max) NULL,
	[convert_to_bit] [bit] NOT NULL CONSTRAINT DF_stored_procedure_convert_to_bit DEFAULT (0),
	[translate_index_ids] [bit] NOT NULL CONSTRAINT DF_stored_procedure_parameter_translate_index_ids DEFAULT (0)
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO