USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[file_column_mapping]') AND type in (N'U'))
DROP TABLE [WORLD_INDEX].[file_column_mapping]
GO

USE [EXPORT]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [WORLD_INDEX].[file_column_mapping]
(
	[column_name] [varchar](200) NOT NULL,
	[product_type_id] [int] NULL,
	[product_column_type_id] [int] NULL,
	[file_column_id] [int] NOT NULL,
	[ignore_where_info] BIT NOT NULL CONSTRAINT DF_file_column_mapping_ignore_where_info DEFAULT (0),
	[select_where_info] VARCHAR(MAX),
	[scale_divisor_parameter_name] VARCHAR(MAX) NOT NULL CONSTRAINT DF_file_column_mapping_scale_divisor_parameter_name DEFAULT (''),
	[mapping_column_name] VARCHAR(MAX) NOT NULL CONSTRAINT DF_file_column_mapping_mapping_column_name DEFAULT ('')
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


