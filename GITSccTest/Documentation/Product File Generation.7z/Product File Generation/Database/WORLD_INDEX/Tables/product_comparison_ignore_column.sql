USE [EXPORT]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORLD_INDEX].[product_comparison_ignore_column]') AND type in (N'U'))
DROP TABLE [WORLD_INDEX].[product_comparison_ignore_column]
GO

CREATE TABLE [WORLD_INDEX].[product_comparison_ignore_column]
(
    product_code    VARCHAR(50) NOT NULL,
    column_name     VARCHAR(100) NOT NULL,
    data_type       VARCHAR(50),
    notes           VARCHAR(MAX)
)

GO

ALTER TABLE [WORLD_INDEX].[product_comparison_ignore_column]
	ADD CONSTRAINT [pk_product_comparison_ignore_column] PRIMARY KEY CLUSTERED 
	(
		product_code,
		column_name
	)
GO