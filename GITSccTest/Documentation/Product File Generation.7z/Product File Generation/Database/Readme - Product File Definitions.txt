Historically, product file definitions have tended to go into folder 'Product File Definitions', regardless as to whether they are in the RA or PRIME platforms.
Yes, this is sub-optimal, but from now onwards:

If you are checking in an RA product file - use "Product File Definitions"
If you are checking in a PRIME product file - use "Prime Product File Definitions"
