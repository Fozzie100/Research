USE world_index
go
IF OBJECT_ID('dbo.pe_extract_keys') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.pe_extract_keys
    IF OBJECT_ID('dbo.pe_extract_keys') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.pe_extract_keys >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.pe_extract_keys >>>'
END
go
create procedure dbo.pe_extract_keys(
  @list       varchar(40), 
  @prod_date  datetime, 
  @mode       char(1),          -- 'C'=constituent list, 'V'=valuation list
  @structured char(1)    = 'N', -- determines if list is structured (=Y) or not structured (=N)
  @trace      char(1)    = 'F',
  @index_constituents_sl_trace      char(1)    = 'F'
  )
as

/*
** Name:		pe_extract_keys
** Created:		8th April 2003
** Author:		Phil Rowan
** Version:		1.0
**
** Date			By				Version	Comment
**-------------------------------------------------------------------------------------
** 05/09/01     Phil Rowan 	    1.0     First issue
** 12/09/03     Tim Page        1.1     Fix to non structured valuation.
** 08/03/05     Milton Cogheil  1.2     ICB phase 10 - index_link replaces index_structure
** 03/02/09     Mark Harniess   1.3     Split code out into sub-procs to get better query
**                                      plans for each route through.
**
** Parameters : A list of indices to cover, the date of coverage and some idea of what 
**              type of product is being created
** Output	  : A table
** Description			  :
**
****************************************************************************************
** Populates the #keys table which is used in subsequent proc calls AND passed out to Java
**
** 1. Take params and find out the product type (via @mode)
** 2. If it's a Valuation
**      take the list_consts and put them straight into #keys
** 3. If it's a Cons list
**      take the list_consts and cursor through them, and put the stocks into #keys
** 4. If a Valuation list
**      take notice of @structured = 'Y' and expand list into sub-indexes else just use list in #keys
** 5. Exit (Let the pe_get_core procs take it from there...)
**
****************************************************************************************
** Assumption
**
*/
begin

  if upper(@mode) = 'C'
  begin
    exec @ret = pe_extract_keys_C  @list, @prod_date, @trace, @index_constituents_sl_trace
  end
  else
  /* VALUATION PRODUCT list processing */
  begin
    if @structured = 'N'
    begin
      exec @ret = pe_extract_keys_V_unstructured  @list, @prod_date, @trace
    end
    else
    /* expand structured product list; code lifted and altered for Product Extractor (Java-based) processing 
     from original stored proc. pg_index_list_sl by Matt Francis.
    */
    begin
      exec @ret = pe_extract_keys_V_structured  @list, @prod_date, @trace  
    end
  end
end
go