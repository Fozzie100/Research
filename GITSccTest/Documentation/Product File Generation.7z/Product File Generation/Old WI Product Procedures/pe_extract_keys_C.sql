USE world_index
go
IF OBJECT_ID('dbo.pe_extract_keys_C') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.pe_extract_keys_C
    IF OBJECT_ID('dbo.pe_extract_keys_C') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.pe_extract_keys_C >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.pe_extract_keys_C >>>'
END
go
create procedure dbo.pe_extract_keys_C(
  @list       varchar(40), 
  @prod_date  datetime, 
  @trace      char(1)    = 'F',
  @index_constituents_sl_trace      char(1)    = 'F'
  )
as

/* 
** ------------------------------------------------------------------------------------ 
** $Id: pe_extract_keys_C.sql,v 1.1 2009/02/12 14:54:25 markh Exp $
** ------------------------------------------------------------------------------------
** Description	: Selects reference data for the effective_date
** 
** Used by      : Products
**               
** Used         : Called from pe_extract_keys
** 
** Parameters   
**  @list                   The list for which to get the keys
**  @prod_date              The date for which the product is being run
**  @trace                  'T' for trace print statements, 'F' for normal use.
**
** Description  :
**
** Populates the #keys table which is used in subsequent proc calls and passed out to Java.
** Populates it for structured valuation products.
** Split out from pe_extract_keys for performance tuning.
**
** $Log: pe_extract_keys_C.sql,v $
** Revision 1.1  2009/02/12 14:54:25  markh
** Split pe_extract_keys into separate procs for performance tuning
**
**
**
*/
begin

  declare @ret                int,
          @member_code        varchar(40)
            
  create table #stocks(
    index_code        int      NULL,
    constituent_code  int      NULL,
    weight            float    NULL,
    index_xref        char(50) NULL
  )
  
  select  distinct c.xref
    into  #xk_xref
    from  list_const  lc
          join  ccr   c on  lc.constituent = c.instrument
    where c.xtype = 'DG'
      and lc.list = @list
      
  create unique clustered index #xk_xref_ix on #xk_xref(xref)
      
  select @member_code = min(xref) from #xk_xref
  
  while @member_code is not NULL
  begin
          
    exec @ret = index_constituents_sl @member_code, @prod_date, @trace = @index_constituents_sl_trace

    select @member_code = min(xref) from #xk_xref where xref > @member_code
  end

/* populate the target table */
  insert #keys (instrument, weight, index_code)
    select distinct constituent_code, weight, index_code from #stocks
        
end
go
