USE world_index
go
IF OBJECT_ID('dbo.pe_extract_keys_V_unstructured') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.pe_extract_keys_V_unstructured
    IF OBJECT_ID('dbo.pe_extract_keys_V_unstructured') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.pe_extract_keys_V_unstructured >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.pe_extract_keys_V_unstructured >>>'
END
go
create procedure dbo.pe_extract_keys_V_unstructured(
  @list       varchar(40), 
  @prod_date  datetime, 
  @trace      char(1)    = 'F'
  )
as

/* 
** ------------------------------------------------------------------------------------ 
** $Id: pe_extract_keys_V_unstructured.sql,v 1.1 2009/02/12 14:54:25 markh Exp $
** ------------------------------------------------------------------------------------
** Description	: Selects reference data for the effective_date
** 
** Used by      : Products
**               
** Used         : Called from pe_extract_keys
** 
** Parameters   
**  @list                   The list for which to get the keys
**  @prod_date              The date for which the product is being run
**  @trace                  'T' for trace print statements, 'F' for normal use.
**
** Description  :
**
** Populates the #keys table which is used in subsequent proc calls and passed out to Java.
** Populates it for unstructured valuation products.
** Split out from pe_extract_keys for performance tuning.
**
** $Log: pe_extract_keys_V_unstructured.sql,v $
** Revision 1.1  2009/02/12 14:54:25  markh
** Split pe_extract_keys into separate procs for performance tuning
**
**
**
*/
begin
            
insert  #keys(instrument)
select  constituent from  list_const where list  = @list
--  ORDER BY sort_code

end
go