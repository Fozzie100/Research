USE world_index
go
IF OBJECT_ID('dbo.pe_extract_keys_soi') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.pe_extract_keys_soi
    IF OBJECT_ID('dbo.pe_extract_keys_soi') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.pe_extract_keys_soi >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.pe_extract_keys_soi >>>'
END
go
CREATE PROCEDURE dbo.pe_extract_keys_soi(
   @list VARCHAR(40),
   @prod_date datetime,
   @mode CHAR(1), -- 'C'=constituent list, 'V'=valuation list, 'S'=securities of interest list
   @structured CHAR(1) = 'N' -- determines if list is structured (=Y) or not structured (=N)
) 
AS
/*
   ** Name:		pe_extract_keys
   ** Created:		8th April 2003
   ** Author:		Phil Rowan
   ** Version:		1.0
   **
   ** Date			By				Version	Comment
   **-------------------------------------------------------------------------------------
   ** 05/09/01     Phil Rowan 	    1.0     First issue
   ** 12/09/03     Tim Page        1.1     Fix to non structured valuation.
   ** 08/03/05     Milton Cogheil  1.2     ICB phase 10 - index_link replaces index_structure
   **
   ** Parameters : A list of indices to cover, the date of coverage and some idea of what 
   **              type of product is being created
   ** Output	  : A table
   ** Description			  :
   **
   ****************************************************************************************
   ** Populates the #keys table which is used in subsequent proc calls AND passed out to Java
   **
   ** 1. Take params and find out the product type (via @mode)
   ** 2. If it's a Valuation
   **      take the list_consts and put them straight into #keys
   ** 3. If it's a Cons list
   **      take the list_consts and cursor through them, and put the stocks into #keys
   ** 4. If a Valuation list
   **      take notice of @structured = 'Y' and expand list into sub-indexes else just use list in #keys
   ** 5. Exit (Let the pe_get_core procs take it from there...)
   **
   ****************************************************************************************
   ** Assumption
   **
   */

   DECLARE @proc_name CHAR(30), @batch_id INT, @error_buf INT, @parent INT, 
   @max_level INT, @row_count INT, @level INT, @rc INT, -- row count for debugging
   @country VARCHAR(20), @source VARCHAR(4), @template_instance VARCHAR(20), 
   @class_code VARCHAR(10)

   SELECT @proc_name = name 
      FROM sysobjects 
      WHERE id = @@procid 

   IF UPPER(@mode) = 'S' 
      BEGIN
         IF @list = 'XSP' 	
            BEGIN
	
               INSERT #keys(
                  instrument
               ) 	
                  SELECT DISTINCT instrument 	
                     FROM ca_data_set ca 	
                     WHERE ca.select_id IN ('BLOOMBERG', 'INTERACTIVE', 'ALLSOI') 	
                     AND  ca.select_date = (select MAX(select_date) 
                           FROM ca_data_set
                           WHERE select_date<= @prod_date ) 
                     ORDER BY instrument 	
            END 
         ELSE
	         BEGIN
	          INSERT #keys(
                  instrument
               ) 		
                  SELECT DISTINCT instrument 		
                     FROM ca_data_set ca 		
                     WHERE ca.select_id IN ('ALLSOI', @list) 
                     AND  ca.select_date = (select MAX(select_date) 
                           FROM ca_data_set
                           WHERE select_date<= @prod_date ) 		
                     ORDER BY instrument 	
            END 
      END 
   ELSE
      IF UPPER(@mode) = 'C' 
         BEGIN
            CREATE TABLE #stocks(
               index_code INT NULL,
               constituent_code INT NULL,
               weight FLOAT NULL,
               index_xref CHAR(50) NULL 
            ) 
            DECLARE @member_code VARCHAR(40) 
            DECLARE members_c CURSOR 
            FOR 
            SELECT DISTINCT c.xref 
               FROM list_const lc, ccr c 
               WHERE lc.constituent = c.instrument AND c.xtype = 'DG' AND lc.list
               = @list OPEN members_c FETCH members_c 
            INTO @member_code 
            WHILE @@sqlstatus = 0 
               BEGIN
                  EXEC @error_buf = index_constituents_sl @member_code,
                     @prod_date
                  WITH recompile 
                  IF @error_buf <> 0 
                     BEGIN
RAISERROR 25000 '%1!: %2!: 1. Error executing index_constituents_sl', 
@proc_name, @error_buf 
                        RETURN @error_buf 
                     END FETCH members_c 
                  INTO @member_code 
               END CLOSE members_c DEALLOCATE CURSOR members_c 
            /* populate the target table */

            INSERT #keys(
               instrument, weight, index_code) 
               SELECT DISTINCT constituent_code,
                  weight,
                  index_code 
                  FROM #stocks 
         END 
      ELSE
/* VALUATION PRODUCT list processing */

         BEGIN
            IF @structured = 'N' 
               BEGIN
                  INSERT #keys(
                     instrument
                  ) 
                     SELECT constituent 
                        FROM list_const 
                        WHERE list = @list 
                        ORDER BY sort_code 
               END 
            ELSE

               /* expand structured product list; code lifted and altered for Product Extractor (Java-based) processing 
               from original stored proc. pg_index_list_sl by Matt Francis.
               */
               BEGIN
                  -- Get parent constituents
                  INSERT #keys(
                     instrument
                  ) 
                     SELECT DISTINCT constituent 
                        FROM list_const, index_link il 
                        WHERE list = @list AND constituent = il.index_code AND 
                        il.current_flag = 'T' AND il.effective_date = ( 
                        SELECT MAX(effective_date) 
                           FROM index_link 
                           WHERE index_code = il.index_code AND 
                           child_index_code = il.child_index_code AND 
                           template_instance = il.template_instance AND 
                           effective_date <= @prod_date ) 
                        ORDER BY sort_code 
                  -- Get lower level constituents

                  INSERT 
                  INTO #keys(
                     instrument
                  ) 
                     SELECT DISTINCT l.index_code 
                        FROM list_const_struct l, #keys k, index_link il 
                        WHERE l.constituent = k.instrument AND l.index_code = 
                        il.index_code AND l.list = @list AND il.current_flag = 
                        'T' AND il.effective_date = ( 
                        SELECT MAX(effective_date) 
                           FROM index_link 
                           WHERE index_code = il.index_code AND 
                           child_index_code = il.child_index_code AND 
                           template_instance = il.template_instance AND 
                           effective_date <= @prod_date ) 
               END 
         END 
go